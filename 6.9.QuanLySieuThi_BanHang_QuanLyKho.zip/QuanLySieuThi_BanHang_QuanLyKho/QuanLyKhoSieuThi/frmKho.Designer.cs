﻿namespace QuanLyKhoSieuThi
{
    partial class frmKho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Phiếu nhập kho");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Phiếu xuất kho");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Phiếu chuyển kho");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Sổ kho");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Chứng từ", new System.Windows.Forms.TreeNode[] {
            treeNode16,
            treeNode17,
            treeNode18,
            treeNode19});
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Hàng tồn kho");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Hàng hoá chi tiết");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Hàng hoá theo loại");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Danh mục", new System.Windows.Forms.TreeNode[] {
            treeNode22,
            treeNode23});
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Kho hàng");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Hàng hoá", new System.Windows.Forms.TreeNode[] {
            treeNode21,
            treeNode24,
            treeNode25});
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("Thông tin hàng vào ra");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("Top nhập");
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Top xuất");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("Báo cáo - thống kê", new System.Windows.Forms.TreeNode[] {
            treeNode27,
            treeNode28,
            treeNode29});
            this.mnusKho = new System.Windows.Forms.MenuStrip();
            this.tsmiKhoHeThong = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoThongTinPhienLamViec = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTaiKhoan = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoDoiMatKhau = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoCapNhatThongTin = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoSeparatorHeThong = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiKhoDangXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoThoatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoNghiepVu = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoThongTinHangDaBan = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTaoPhieuXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoInKiemKe = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTienIch = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoMayTinhMini = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoSeparatorTienIch = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiKhoLichLamViec = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTroGiup = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoHuongDanSuDung = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiCapNhatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoBaoCaoLoi = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoSeparatorTroGiup2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiKhoThongTinPhanQuanLiSieuThi = new System.Windows.Forms.ToolStripMenuItem();
            this.tstbKhoVersion = new System.Windows.Forms.ToolStripTextBox();
            this.stasKho = new System.Windows.Forms.StatusStrip();
            this.tstlKhoReady = new System.Windows.Forms.ToolStripStatusLabel();
            this.tspbKhoProcess = new System.Windows.Forms.ToolStripProgressBar();
            this.tblpKhoMainContainer = new System.Windows.Forms.TableLayoutPanel();
            this.splcKhoContainer = new System.Windows.Forms.SplitContainer();
            this.treKhoChucNang = new System.Windows.Forms.TreeView();
            this.pnlKhobntChucNang = new System.Windows.Forms.Panel();
            this.btnCuoiDanhSach = new System.Windows.Forms.Button();
            this.btnToi = new System.Windows.Forms.Button();
            this.btnLui = new System.Windows.Forms.Button();
            this.btnDauDanhSach = new System.Windows.Forms.Button();
            this.txtLuu = new System.Windows.Forms.Button();
            this.btnDongTabPage = new System.Windows.Forms.Button();
            this.txtXoa = new System.Windows.Forms.Button();
            this.txtSua = new System.Windows.Forms.Button();
            this.txtThem = new System.Windows.Forms.Button();
            this.tabForm = new System.Windows.Forms.TabControl();
            this.tbplKhoMainButton = new System.Windows.Forms.TableLayoutPanel();
            this.grbKhoChungTuChinh = new System.Windows.Forms.GroupBox();
            this.btnDSPhieuNhap = new System.Windows.Forms.Button();
            this.btnDSPhieuXuat = new System.Windows.Forms.Button();
            this.btnDSTheKho = new System.Windows.Forms.Button();
            this.grbHangHoa = new System.Windows.Forms.GroupBox();
            this.btnKhoHang = new System.Windows.Forms.Button();
            this.btnHangTonKho = new System.Windows.Forms.Button();
            this.btnDanhMucHang = new System.Windows.Forms.Button();
            this.grbBaoCaoThongKe = new System.Windows.Forms.GroupBox();
            this.btnThongTinVaoRa = new System.Windows.Forms.Button();
            this.btnTopNhap = new System.Windows.Forms.Button();
            this.btnTopXuat = new System.Windows.Forms.Button();
            this.grbTienIch = new System.Windows.Forms.GroupBox();
            this.btnLichLamViec = new System.Windows.Forms.Button();
            this.mnusKho.SuspendLayout();
            this.stasKho.SuspendLayout();
            this.tblpKhoMainContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splcKhoContainer)).BeginInit();
            this.splcKhoContainer.Panel1.SuspendLayout();
            this.splcKhoContainer.Panel2.SuspendLayout();
            this.splcKhoContainer.SuspendLayout();
            this.pnlKhobntChucNang.SuspendLayout();
            this.tbplKhoMainButton.SuspendLayout();
            this.grbKhoChungTuChinh.SuspendLayout();
            this.grbHangHoa.SuspendLayout();
            this.grbBaoCaoThongKe.SuspendLayout();
            this.grbTienIch.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnusKho
            // 
            this.mnusKho.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoHeThong,
            this.tsmiKhoNghiepVu,
            this.tsmiKhoTienIch,
            this.tsmiKhoTroGiup});
            this.mnusKho.Location = new System.Drawing.Point(0, 0);
            this.mnusKho.Name = "mnusKho";
            this.mnusKho.Size = new System.Drawing.Size(877, 24);
            this.mnusKho.TabIndex = 0;
            this.mnusKho.Text = "mnusKho";
            // 
            // tsmiKhoHeThong
            // 
            this.tsmiKhoHeThong.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoThongTinPhienLamViec,
            this.tsmiKhoTaiKhoan,
            this.tsmiKhoSeparatorHeThong,
            this.tsmiKhoDangXuat,
            this.tsmiKhoThoatChuongTrinh});
            this.tsmiKhoHeThong.Name = "tsmiKhoHeThong";
            this.tsmiKhoHeThong.Size = new System.Drawing.Size(69, 20);
            this.tsmiKhoHeThong.Text = "&Hệ thống";
            // 
            // tsmiKhoThongTinPhienLamViec
            // 
            this.tsmiKhoThongTinPhienLamViec.Name = "tsmiKhoThongTinPhienLamViec";
            this.tsmiKhoThongTinPhienLamViec.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.tsmiKhoThongTinPhienLamViec.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoThongTinPhienLamViec.Text = "Thông tin &phiên làm việc";
            // 
            // tsmiKhoTaiKhoan
            // 
            this.tsmiKhoTaiKhoan.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoDoiMatKhau,
            this.tsmiKhoCapNhatThongTin});
            this.tsmiKhoTaiKhoan.Name = "tsmiKhoTaiKhoan";
            this.tsmiKhoTaiKhoan.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoTaiKhoan.Text = "Tài &khoản";
            // 
            // tsmiKhoDoiMatKhau
            // 
            this.tsmiKhoDoiMatKhau.Name = "tsmiKhoDoiMatKhau";
            this.tsmiKhoDoiMatKhau.Size = new System.Drawing.Size(174, 22);
            this.tsmiKhoDoiMatKhau.Text = "Đổi &mật khẩu";
            // 
            // tsmiKhoCapNhatThongTin
            // 
            this.tsmiKhoCapNhatThongTin.Name = "tsmiKhoCapNhatThongTin";
            this.tsmiKhoCapNhatThongTin.Size = new System.Drawing.Size(174, 22);
            this.tsmiKhoCapNhatThongTin.Text = "&Cập nhật thông tin";
            // 
            // tsmiKhoSeparatorHeThong
            // 
            this.tsmiKhoSeparatorHeThong.Name = "tsmiKhoSeparatorHeThong";
            this.tsmiKhoSeparatorHeThong.Size = new System.Drawing.Size(243, 6);
            // 
            // tsmiKhoDangXuat
            // 
            this.tsmiKhoDangXuat.Name = "tsmiKhoDangXuat";
            this.tsmiKhoDangXuat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F4)));
            this.tsmiKhoDangXuat.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoDangXuat.Text = "Đăng &xuất";
            // 
            // tsmiKhoThoatChuongTrinh
            // 
            this.tsmiKhoThoatChuongTrinh.Name = "tsmiKhoThoatChuongTrinh";
            this.tsmiKhoThoatChuongTrinh.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.tsmiKhoThoatChuongTrinh.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoThoatChuongTrinh.Text = "&Thoát chương trình";
            // 
            // tsmiKhoNghiepVu
            // 
            this.tsmiKhoNghiepVu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoThongTinHangDaBan,
            this.tsmiKhoTaoPhieuXuat,
            this.tsmiKhoInKiemKe});
            this.tsmiKhoNghiepVu.Name = "tsmiKhoNghiepVu";
            this.tsmiKhoNghiepVu.Size = new System.Drawing.Size(74, 20);
            this.tsmiKhoNghiepVu.Text = "&Nghiệp vụ";
            // 
            // tsmiKhoThongTinHangDaBan
            // 
            this.tsmiKhoThongTinHangDaBan.Name = "tsmiKhoThongTinHangDaBan";
            this.tsmiKhoThongTinHangDaBan.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.tsmiKhoThongTinHangDaBan.Size = new System.Drawing.Size(192, 22);
            this.tsmiKhoThongTinHangDaBan.Text = "&Nhập hàng";
            // 
            // tsmiKhoTaoPhieuXuat
            // 
            this.tsmiKhoTaoPhieuXuat.Name = "tsmiKhoTaoPhieuXuat";
            this.tsmiKhoTaoPhieuXuat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.tsmiKhoTaoPhieuXuat.Size = new System.Drawing.Size(192, 22);
            this.tsmiKhoTaoPhieuXuat.Text = "Tạo phiếu &xuất";
            // 
            // tsmiKhoInKiemKe
            // 
            this.tsmiKhoInKiemKe.Name = "tsmiKhoInKiemKe";
            this.tsmiKhoInKiemKe.Size = new System.Drawing.Size(192, 22);
            this.tsmiKhoInKiemKe.Text = "In kiểm kê";
            // 
            // tsmiKhoTienIch
            // 
            this.tsmiKhoTienIch.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoMayTinhMini,
            this.tsmiKhoSeparatorTienIch,
            this.tsmiKhoLichLamViec});
            this.tsmiKhoTienIch.Name = "tsmiKhoTienIch";
            this.tsmiKhoTienIch.Size = new System.Drawing.Size(61, 20);
            this.tsmiKhoTienIch.Text = "Tiện &ích";
            // 
            // tsmiKhoMayTinhMini
            // 
            this.tsmiKhoMayTinhMini.Name = "tsmiKhoMayTinhMini";
            this.tsmiKhoMayTinhMini.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.tsmiKhoMayTinhMini.Size = new System.Drawing.Size(189, 22);
            this.tsmiKhoMayTinhMini.Text = "&Máy tính mini";
            // 
            // tsmiKhoSeparatorTienIch
            // 
            this.tsmiKhoSeparatorTienIch.Name = "tsmiKhoSeparatorTienIch";
            this.tsmiKhoSeparatorTienIch.Size = new System.Drawing.Size(186, 6);
            // 
            // tsmiKhoLichLamViec
            // 
            this.tsmiKhoLichLamViec.Name = "tsmiKhoLichLamViec";
            this.tsmiKhoLichLamViec.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.tsmiKhoLichLamViec.Size = new System.Drawing.Size(189, 22);
            this.tsmiKhoLichLamViec.Text = "&Lịch làm việc";
            // 
            // tsmiKhoTroGiup
            // 
            this.tsmiKhoTroGiup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoHuongDanSuDung,
            this.tsmiCapNhatChuongTrinh,
            this.tsmiKhoBaoCaoLoi,
            this.tsmiKhoSeparatorTroGiup2,
            this.tsmiKhoThongTinPhanQuanLiSieuThi,
            this.tstbKhoVersion});
            this.tsmiKhoTroGiup.Name = "tsmiKhoTroGiup";
            this.tsmiKhoTroGiup.Size = new System.Drawing.Size(64, 20);
            this.tsmiKhoTroGiup.Text = "Trợ &giúp";
            // 
            // tsmiKhoHuongDanSuDung
            // 
            this.tsmiKhoHuongDanSuDung.Name = "tsmiKhoHuongDanSuDung";
            this.tsmiKhoHuongDanSuDung.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.tsmiKhoHuongDanSuDung.Size = new System.Drawing.Size(267, 22);
            this.tsmiKhoHuongDanSuDung.Text = "Hướng dẫn &sử dụng";
            // 
            // tsmiCapNhatChuongTrinh
            // 
            this.tsmiCapNhatChuongTrinh.Name = "tsmiCapNhatChuongTrinh";
            this.tsmiCapNhatChuongTrinh.Size = new System.Drawing.Size(267, 22);
            this.tsmiCapNhatChuongTrinh.Text = "&Cập nhật chương trình";
            // 
            // tsmiKhoBaoCaoLoi
            // 
            this.tsmiKhoBaoCaoLoi.Name = "tsmiKhoBaoCaoLoi";
            this.tsmiKhoBaoCaoLoi.Size = new System.Drawing.Size(267, 22);
            this.tsmiKhoBaoCaoLoi.Text = "Báo cáo &lỗi";
            // 
            // tsmiKhoSeparatorTroGiup2
            // 
            this.tsmiKhoSeparatorTroGiup2.Name = "tsmiKhoSeparatorTroGiup2";
            this.tsmiKhoSeparatorTroGiup2.Size = new System.Drawing.Size(264, 6);
            // 
            // tsmiKhoThongTinPhanQuanLiSieuThi
            // 
            this.tsmiKhoThongTinPhanQuanLiSieuThi.Name = "tsmiKhoThongTinPhanQuanLiSieuThi";
            this.tsmiKhoThongTinPhanQuanLiSieuThi.Size = new System.Drawing.Size(267, 22);
            this.tsmiKhoThongTinPhanQuanLiSieuThi.Text = "Thông tin phần mềm &quản lí siêu thị";
            // 
            // tstbKhoVersion
            // 
            this.tstbKhoVersion.BackColor = System.Drawing.Color.White;
            this.tstbKhoVersion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tstbKhoVersion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.tstbKhoVersion.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.tstbKhoVersion.Name = "tstbKhoVersion";
            this.tstbKhoVersion.Size = new System.Drawing.Size(120, 12);
            this.tstbKhoVersion.Text = "© 2011 QLST – Version 1.0";
            // 
            // stasKho
            // 
            this.stasKho.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstlKhoReady,
            this.tspbKhoProcess});
            this.stasKho.Location = new System.Drawing.Point(0, 616);
            this.stasKho.Name = "stasKho";
            this.stasKho.Size = new System.Drawing.Size(877, 22);
            this.stasKho.TabIndex = 9;
            this.stasKho.Text = "statusStrip1";
            // 
            // tstlKhoReady
            // 
            this.tstlKhoReady.Name = "tstlKhoReady";
            this.tstlKhoReady.Size = new System.Drawing.Size(39, 17);
            this.tstlKhoReady.Text = "Ready";
            // 
            // tspbKhoProcess
            // 
            this.tspbKhoProcess.Name = "tspbKhoProcess";
            this.tspbKhoProcess.Size = new System.Drawing.Size(100, 16);
            // 
            // tblpKhoMainContainer
            // 
            this.tblpKhoMainContainer.ColumnCount = 1;
            this.tblpKhoMainContainer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpKhoMainContainer.Controls.Add(this.splcKhoContainer, 0, 1);
            this.tblpKhoMainContainer.Controls.Add(this.tbplKhoMainButton, 0, 0);
            this.tblpKhoMainContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpKhoMainContainer.Location = new System.Drawing.Point(0, 24);
            this.tblpKhoMainContainer.Name = "tblpKhoMainContainer";
            this.tblpKhoMainContainer.RowCount = 2;
            this.tblpKhoMainContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 88F));
            this.tblpKhoMainContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpKhoMainContainer.Size = new System.Drawing.Size(877, 592);
            this.tblpKhoMainContainer.TabIndex = 10;
            // 
            // splcKhoContainer
            // 
            this.splcKhoContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splcKhoContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splcKhoContainer.Location = new System.Drawing.Point(3, 91);
            this.splcKhoContainer.Name = "splcKhoContainer";
            // 
            // splcKhoContainer.Panel1
            // 
            this.splcKhoContainer.Panel1.Controls.Add(this.treKhoChucNang);
            // 
            // splcKhoContainer.Panel2
            // 
            this.splcKhoContainer.Panel2.Controls.Add(this.pnlKhobntChucNang);
            this.splcKhoContainer.Panel2.Controls.Add(this.tabForm);
            this.splcKhoContainer.Size = new System.Drawing.Size(871, 498);
            this.splcKhoContainer.SplitterDistance = 224;
            this.splcKhoContainer.TabIndex = 4;
            // 
            // treKhoChucNang
            // 
            this.treKhoChucNang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treKhoChucNang.Location = new System.Drawing.Point(0, 0);
            this.treKhoChucNang.Name = "treKhoChucNang";
            treeNode16.Name = "nodePhieuNhapKho";
            treeNode16.Text = "Phiếu nhập kho";
            treeNode17.Name = "nodePhieuXuatKho";
            treeNode17.Text = "Phiếu xuất kho";
            treeNode18.Name = "nodePhieuChuyenKho";
            treeNode18.Text = "Phiếu chuyển kho";
            treeNode19.Name = "nodeSoKho";
            treeNode19.Text = "Sổ kho";
            treeNode20.Checked = true;
            treeNode20.Name = "nodeChungTu";
            treeNode20.StateImageKey = "(none)";
            treeNode20.Text = "Chứng từ";
            treeNode20.ToolTipText = "Các loại chứng từ của quản lý kho";
            treeNode21.Name = "nodeHangTonKho";
            treeNode21.Text = "Hàng tồn kho";
            treeNode22.Name = "nodeHangHoaChiTiet";
            treeNode22.Text = "Hàng hoá chi tiết";
            treeNode23.Name = "nodeHangHoaTheoLoai";
            treeNode23.Text = "Hàng hoá theo loại";
            treeNode24.Name = "nodeDanhMuc";
            treeNode24.Text = "Danh mục";
            treeNode25.Name = "nodeKhoHang";
            treeNode25.Text = "Kho hàng";
            treeNode26.Name = "nodeHangHoa";
            treeNode26.Text = "Hàng hoá";
            treeNode27.Name = "nodeThongTinHangVaoRa";
            treeNode27.Text = "Thông tin hàng vào ra";
            treeNode28.Name = "nodeTopNhap";
            treeNode28.Text = "Top nhập";
            treeNode29.Name = "nodeTopXuat";
            treeNode29.Text = "Top xuất";
            treeNode30.Name = "nodeBaoCaoThongKe";
            treeNode30.Text = "Báo cáo - thống kê";
            this.treKhoChucNang.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode20,
            treeNode26,
            treeNode30});
            this.treKhoChucNang.Size = new System.Drawing.Size(224, 498);
            this.treKhoChucNang.TabIndex = 0;
            this.treKhoChucNang.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treKhoChucNang_AfterSelect);
            // 
            // pnlKhobntChucNang
            // 
            this.pnlKhobntChucNang.Controls.Add(this.btnCuoiDanhSach);
            this.pnlKhobntChucNang.Controls.Add(this.btnToi);
            this.pnlKhobntChucNang.Controls.Add(this.btnLui);
            this.pnlKhobntChucNang.Controls.Add(this.btnDauDanhSach);
            this.pnlKhobntChucNang.Controls.Add(this.txtLuu);
            this.pnlKhobntChucNang.Controls.Add(this.btnDongTabPage);
            this.pnlKhobntChucNang.Controls.Add(this.txtXoa);
            this.pnlKhobntChucNang.Controls.Add(this.txtSua);
            this.pnlKhobntChucNang.Controls.Add(this.txtThem);
            this.pnlKhobntChucNang.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlKhobntChucNang.Location = new System.Drawing.Point(0, 463);
            this.pnlKhobntChucNang.Name = "pnlKhobntChucNang";
            this.pnlKhobntChucNang.Size = new System.Drawing.Size(643, 35);
            this.pnlKhobntChucNang.TabIndex = 1;
            // 
            // btnCuoiDanhSach
            // 
            this.btnCuoiDanhSach.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.next_green;
            this.btnCuoiDanhSach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCuoiDanhSach.Location = new System.Drawing.Point(89, 5);
            this.btnCuoiDanhSach.Name = "btnCuoiDanhSach";
            this.btnCuoiDanhSach.Size = new System.Drawing.Size(25, 25);
            this.btnCuoiDanhSach.TabIndex = 3;
            this.btnCuoiDanhSach.UseVisualStyleBackColor = true;
            // 
            // btnToi
            // 
            this.btnToi.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.play_green;
            this.btnToi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnToi.Location = new System.Drawing.Point(62, 5);
            this.btnToi.Name = "btnToi";
            this.btnToi.Size = new System.Drawing.Size(25, 25);
            this.btnToi.TabIndex = 2;
            this.btnToi.UseVisualStyleBackColor = true;
            // 
            // btnLui
            // 
            this.btnLui.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.reverse_green;
            this.btnLui.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLui.Location = new System.Drawing.Point(35, 5);
            this.btnLui.Name = "btnLui";
            this.btnLui.Size = new System.Drawing.Size(25, 25);
            this.btnLui.TabIndex = 1;
            this.btnLui.UseVisualStyleBackColor = true;
            // 
            // btnDauDanhSach
            // 
            this.btnDauDanhSach.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.previous_green;
            this.btnDauDanhSach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDauDanhSach.Location = new System.Drawing.Point(8, 5);
            this.btnDauDanhSach.Name = "btnDauDanhSach";
            this.btnDauDanhSach.Size = new System.Drawing.Size(25, 25);
            this.btnDauDanhSach.TabIndex = 0;
            this.btnDauDanhSach.UseVisualStyleBackColor = true;
            // 
            // txtLuu
            // 
            this.txtLuu.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.txtLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtLuu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtLuu.Location = new System.Drawing.Point(249, 5);
            this.txtLuu.Name = "txtLuu";
            this.txtLuu.Size = new System.Drawing.Size(59, 25);
            this.txtLuu.TabIndex = 6;
            this.txtLuu.Text = "&Lưu";
            this.txtLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtLuu.UseVisualStyleBackColor = true;
            // 
            // btnDongTabPage
            // 
            this.btnDongTabPage.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.bullet_cross;
            this.btnDongTabPage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDongTabPage.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnDongTabPage.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDongTabPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDongTabPage.Location = new System.Drawing.Point(575, 0);
            this.btnDongTabPage.Name = "btnDongTabPage";
            this.btnDongTabPage.Size = new System.Drawing.Size(68, 35);
            this.btnDongTabPage.TabIndex = 8;
            this.btnDongTabPage.Text = "&Đón&g";
            this.btnDongTabPage.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDongTabPage.UseVisualStyleBackColor = true;
            this.btnDongTabPage.Click += new System.EventHandler(this.btnDongTabPage_Click);
            // 
            // txtXoa
            // 
            this.txtXoa.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.delete_Icon;
            this.txtXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtXoa.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtXoa.Location = new System.Drawing.Point(310, 5);
            this.txtXoa.Name = "txtXoa";
            this.txtXoa.Size = new System.Drawing.Size(59, 25);
            this.txtXoa.TabIndex = 7;
            this.txtXoa.Text = "&Xoá";
            this.txtXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtXoa.UseVisualStyleBackColor = true;
            // 
            // txtSua
            // 
            this.txtSua.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.icon_edit;
            this.txtSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtSua.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtSua.Location = new System.Drawing.Point(188, 5);
            this.txtSua.Name = "txtSua";
            this.txtSua.Size = new System.Drawing.Size(59, 25);
            this.txtSua.TabIndex = 5;
            this.txtSua.Text = "&Sửa";
            this.txtSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtSua.UseVisualStyleBackColor = true;
            // 
            // txtThem
            // 
            this.txtThem.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.add_icon;
            this.txtThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtThem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtThem.Location = new System.Drawing.Point(120, 5);
            this.txtThem.Name = "txtThem";
            this.txtThem.Size = new System.Drawing.Size(65, 25);
            this.txtThem.TabIndex = 4;
            this.txtThem.Text = "&Thêm";
            this.txtThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtThem.UseVisualStyleBackColor = true;
            // 
            // tabForm
            // 
            this.tabForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabForm.Location = new System.Drawing.Point(0, 0);
            this.tabForm.Name = "tabForm";
            this.tabForm.SelectedIndex = 0;
            this.tabForm.Size = new System.Drawing.Size(643, 498);
            this.tabForm.TabIndex = 0;
            // 
            // tbplKhoMainButton
            // 
            this.tbplKhoMainButton.ColumnCount = 4;
            this.tbplKhoMainButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 230F));
            this.tbplKhoMainButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 240F));
            this.tbplKhoMainButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 232F));
            this.tbplKhoMainButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 84F));
            this.tbplKhoMainButton.Controls.Add(this.grbKhoChungTuChinh, 0, 0);
            this.tbplKhoMainButton.Controls.Add(this.grbHangHoa, 1, 0);
            this.tbplKhoMainButton.Controls.Add(this.grbBaoCaoThongKe, 2, 0);
            this.tbplKhoMainButton.Controls.Add(this.grbTienIch, 3, 0);
            this.tbplKhoMainButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplKhoMainButton.Location = new System.Drawing.Point(3, 3);
            this.tbplKhoMainButton.Name = "tbplKhoMainButton";
            this.tbplKhoMainButton.RowCount = 1;
            this.tbplKhoMainButton.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplKhoMainButton.Size = new System.Drawing.Size(871, 82);
            this.tbplKhoMainButton.TabIndex = 3;
            // 
            // grbKhoChungTuChinh
            // 
            this.grbKhoChungTuChinh.Controls.Add(this.btnDSPhieuNhap);
            this.grbKhoChungTuChinh.Controls.Add(this.btnDSPhieuXuat);
            this.grbKhoChungTuChinh.Controls.Add(this.btnDSTheKho);
            this.grbKhoChungTuChinh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbKhoChungTuChinh.Location = new System.Drawing.Point(3, 3);
            this.grbKhoChungTuChinh.Name = "grbKhoChungTuChinh";
            this.grbKhoChungTuChinh.Size = new System.Drawing.Size(224, 76);
            this.grbKhoChungTuChinh.TabIndex = 0;
            this.grbKhoChungTuChinh.TabStop = false;
            this.grbKhoChungTuChinh.Text = "Chứng từ chính";
            // 
            // btnDSPhieuNhap
            // 
            this.btnDSPhieuNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDSPhieuNhap.Location = new System.Drawing.Point(4, 19);
            this.btnDSPhieuNhap.Name = "btnDSPhieuNhap";
            this.btnDSPhieuNhap.Size = new System.Drawing.Size(68, 48);
            this.btnDSPhieuNhap.TabIndex = 0;
            this.btnDSPhieuNhap.Text = "DS Phiếu nhập";
            this.btnDSPhieuNhap.UseVisualStyleBackColor = true;
            // 
            // btnDSPhieuXuat
            // 
            this.btnDSPhieuXuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDSPhieuXuat.Location = new System.Drawing.Point(78, 19);
            this.btnDSPhieuXuat.Name = "btnDSPhieuXuat";
            this.btnDSPhieuXuat.Size = new System.Drawing.Size(68, 48);
            this.btnDSPhieuXuat.TabIndex = 1;
            this.btnDSPhieuXuat.Text = "DS Phiếu xuất";
            this.btnDSPhieuXuat.UseVisualStyleBackColor = true;
            // 
            // btnDSTheKho
            // 
            this.btnDSTheKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDSTheKho.Location = new System.Drawing.Point(152, 19);
            this.btnDSTheKho.Name = "btnDSTheKho";
            this.btnDSTheKho.Size = new System.Drawing.Size(68, 48);
            this.btnDSTheKho.TabIndex = 2;
            this.btnDSTheKho.Text = "DS Thẻ kho";
            this.btnDSTheKho.UseVisualStyleBackColor = true;
            // 
            // grbHangHoa
            // 
            this.grbHangHoa.Controls.Add(this.btnKhoHang);
            this.grbHangHoa.Controls.Add(this.btnHangTonKho);
            this.grbHangHoa.Controls.Add(this.btnDanhMucHang);
            this.grbHangHoa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbHangHoa.Location = new System.Drawing.Point(233, 3);
            this.grbHangHoa.Name = "grbHangHoa";
            this.grbHangHoa.Size = new System.Drawing.Size(234, 76);
            this.grbHangHoa.TabIndex = 2;
            this.grbHangHoa.TabStop = false;
            this.grbHangHoa.Text = "Hàng hoá";
            // 
            // btnKhoHang
            // 
            this.btnKhoHang.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnKhoHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhoHang.Location = new System.Drawing.Point(6, 19);
            this.btnKhoHang.Name = "btnKhoHang";
            this.btnKhoHang.Size = new System.Drawing.Size(68, 51);
            this.btnKhoHang.TabIndex = 0;
            this.btnKhoHang.Text = "Kho hàng";
            this.btnKhoHang.UseVisualStyleBackColor = true;
            // 
            // btnHangTonKho
            // 
            this.btnHangTonKho.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHangTonKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHangTonKho.Location = new System.Drawing.Point(80, 19);
            this.btnHangTonKho.Name = "btnHangTonKho";
            this.btnHangTonKho.Size = new System.Drawing.Size(68, 51);
            this.btnHangTonKho.TabIndex = 1;
            this.btnHangTonKho.Text = "Hàng tồn kho";
            this.btnHangTonKho.UseVisualStyleBackColor = true;
            // 
            // btnDanhMucHang
            // 
            this.btnDanhMucHang.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDanhMucHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDanhMucHang.Location = new System.Drawing.Point(154, 19);
            this.btnDanhMucHang.Name = "btnDanhMucHang";
            this.btnDanhMucHang.Size = new System.Drawing.Size(74, 51);
            this.btnDanhMucHang.TabIndex = 2;
            this.btnDanhMucHang.Text = "Danh mục hàng";
            this.btnDanhMucHang.UseVisualStyleBackColor = true;
            // 
            // grbBaoCaoThongKe
            // 
            this.grbBaoCaoThongKe.Controls.Add(this.btnThongTinVaoRa);
            this.grbBaoCaoThongKe.Controls.Add(this.btnTopNhap);
            this.grbBaoCaoThongKe.Controls.Add(this.btnTopXuat);
            this.grbBaoCaoThongKe.Location = new System.Drawing.Point(473, 3);
            this.grbBaoCaoThongKe.Name = "grbBaoCaoThongKe";
            this.grbBaoCaoThongKe.Size = new System.Drawing.Size(226, 73);
            this.grbBaoCaoThongKe.TabIndex = 3;
            this.grbBaoCaoThongKe.TabStop = false;
            this.grbBaoCaoThongKe.Text = "Báo cáo - thống kê";
            // 
            // btnThongTinVaoRa
            // 
            this.btnThongTinVaoRa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongTinVaoRa.Location = new System.Drawing.Point(6, 19);
            this.btnThongTinVaoRa.Name = "btnThongTinVaoRa";
            this.btnThongTinVaoRa.Size = new System.Drawing.Size(68, 48);
            this.btnThongTinVaoRa.TabIndex = 0;
            this.btnThongTinVaoRa.Text = "Thông tin vào ra kho";
            this.btnThongTinVaoRa.UseVisualStyleBackColor = true;
            // 
            // btnTopNhap
            // 
            this.btnTopNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTopNhap.Location = new System.Drawing.Point(79, 19);
            this.btnTopNhap.Name = "btnTopNhap";
            this.btnTopNhap.Size = new System.Drawing.Size(68, 48);
            this.btnTopNhap.TabIndex = 1;
            this.btnTopNhap.Text = "Top nhập";
            this.btnTopNhap.UseVisualStyleBackColor = true;
            // 
            // btnTopXuat
            // 
            this.btnTopXuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTopXuat.Location = new System.Drawing.Point(152, 19);
            this.btnTopXuat.Name = "btnTopXuat";
            this.btnTopXuat.Size = new System.Drawing.Size(68, 48);
            this.btnTopXuat.TabIndex = 2;
            this.btnTopXuat.Text = "Top xuất";
            this.btnTopXuat.UseVisualStyleBackColor = true;
            // 
            // grbTienIch
            // 
            this.grbTienIch.Controls.Add(this.btnLichLamViec);
            this.grbTienIch.Location = new System.Drawing.Point(705, 3);
            this.grbTienIch.Name = "grbTienIch";
            this.grbTienIch.Size = new System.Drawing.Size(78, 73);
            this.grbTienIch.TabIndex = 3;
            this.grbTienIch.TabStop = false;
            this.grbTienIch.Text = "Tiện ích";
            // 
            // btnLichLamViec
            // 
            this.btnLichLamViec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLichLamViec.Location = new System.Drawing.Point(4, 19);
            this.btnLichLamViec.Name = "btnLichLamViec";
            this.btnLichLamViec.Size = new System.Drawing.Size(70, 48);
            this.btnLichLamViec.TabIndex = 0;
            this.btnLichLamViec.Text = "Lịch Làm Việc";
            this.btnLichLamViec.UseVisualStyleBackColor = true;
            // 
            // frmKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 638);
            this.Controls.Add(this.tblpKhoMainContainer);
            this.Controls.Add(this.stasKho);
            this.Controls.Add(this.mnusKho);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.mnusKho;
            this.MinimumSize = new System.Drawing.Size(885, 665);
            this.Name = "frmKho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QLST --- Quản lý kho";
            this.Load += new System.EventHandler(this.frmKho_Load);
            this.mnusKho.ResumeLayout(false);
            this.mnusKho.PerformLayout();
            this.stasKho.ResumeLayout(false);
            this.stasKho.PerformLayout();
            this.tblpKhoMainContainer.ResumeLayout(false);
            this.splcKhoContainer.Panel1.ResumeLayout(false);
            this.splcKhoContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splcKhoContainer)).EndInit();
            this.splcKhoContainer.ResumeLayout(false);
            this.pnlKhobntChucNang.ResumeLayout(false);
            this.tbplKhoMainButton.ResumeLayout(false);
            this.grbKhoChungTuChinh.ResumeLayout(false);
            this.grbHangHoa.ResumeLayout(false);
            this.grbBaoCaoThongKe.ResumeLayout(false);
            this.grbTienIch.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnusKho;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoHeThong;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThongTinPhienLamViec;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTaiKhoan;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoDoiMatKhau;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoCapNhatThongTin;
        private System.Windows.Forms.ToolStripSeparator tsmiKhoSeparatorHeThong;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoDangXuat;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThoatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoNghiepVu;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThongTinHangDaBan;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTaoPhieuXuat;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoInKiemKe;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTienIch;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoMayTinhMini;
        private System.Windows.Forms.ToolStripSeparator tsmiKhoSeparatorTienIch;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoLichLamViec;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTroGiup;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoHuongDanSuDung;
        private System.Windows.Forms.ToolStripMenuItem tsmiCapNhatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoBaoCaoLoi;
        private System.Windows.Forms.ToolStripSeparator tsmiKhoSeparatorTroGiup2;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThongTinPhanQuanLiSieuThi;
        private System.Windows.Forms.ToolStripTextBox tstbKhoVersion;
        private System.Windows.Forms.StatusStrip stasKho;
        private System.Windows.Forms.ToolStripStatusLabel tstlKhoReady;
        private System.Windows.Forms.ToolStripProgressBar tspbKhoProcess;
        private System.Windows.Forms.TableLayoutPanel tblpKhoMainContainer;
        private System.Windows.Forms.TableLayoutPanel tbplKhoMainButton;
        private System.Windows.Forms.GroupBox grbKhoChungTuChinh;
        private System.Windows.Forms.Button btnDSTheKho;
        private System.Windows.Forms.Button btnDSPhieuXuat;
        private System.Windows.Forms.Button btnDSPhieuNhap;
        private System.Windows.Forms.GroupBox grbHangHoa;
        private System.Windows.Forms.Button btnDanhMucHang;
        private System.Windows.Forms.Button btnHangTonKho;
        private System.Windows.Forms.Button btnKhoHang;
        private System.Windows.Forms.GroupBox grbBaoCaoThongKe;
        private System.Windows.Forms.Button btnTopXuat;
        private System.Windows.Forms.Button btnTopNhap;
        private System.Windows.Forms.Button btnThongTinVaoRa;
        private System.Windows.Forms.GroupBox grbTienIch;
        private System.Windows.Forms.Button btnLichLamViec;
        private System.Windows.Forms.SplitContainer splcKhoContainer;
        private System.Windows.Forms.TreeView treKhoChucNang;
        private System.Windows.Forms.TabControl tabForm;
        private System.Windows.Forms.Panel pnlKhobntChucNang;
        private System.Windows.Forms.Button btnCuoiDanhSach;
        private System.Windows.Forms.Button btnToi;
        private System.Windows.Forms.Button btnLui;
        private System.Windows.Forms.Button btnDauDanhSach;
        private System.Windows.Forms.Button txtLuu;
        private System.Windows.Forms.Button btnDongTabPage;
        private System.Windows.Forms.Button txtXoa;
        private System.Windows.Forms.Button txtSua;
        private System.Windows.Forms.Button txtThem;
    }
}

