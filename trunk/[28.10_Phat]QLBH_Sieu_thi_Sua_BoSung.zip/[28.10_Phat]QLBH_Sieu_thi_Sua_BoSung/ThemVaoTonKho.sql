-- ================================================
-- Template generated from Template Explorer using:
-- Create Trigger (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- See additional Create Trigger templates for more
-- examples of different Trigger statements.
--
-- This block of comments will not be included in
-- the definition of the function.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER TangSoLuongTonKho
   ON  CTPHIEUNHAP
   AFTER INSERT
AS 
BEGIN
	Declare @soluongthem int
	Declare @soluongton int
	Declare @tongton int
	set @soluongthem = (select soluong from inserted);
	set @soluongton = (select tonkho from dmhang JOIN inserted ON inserted.mahang = dmhang.mahang);
	set @tongton = @soluongton + @soluongthem;
	
	update dmhang set tonkho=@tongton where mahang=(select mahang from inserted);

END
GO
