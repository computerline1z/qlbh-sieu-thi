﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;
using System.Data.SqlClient;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    class QUYDINH_BUS:DataProvider
    {
        string sql = "";
        DataTable tempTable;
        public DataTable LayDSQuyDinh()
        {
            tempTable = new DataTable();
            openConnection();
            sql = string.Format("select * from Quydinh");
            tempTable = this.getDataSetTBl(sql);
            closeConnection();
            return tempTable;
        }

       

        public void CapnhatQuyDinh(QUYDINH_OBJ NewQuydinh)
        {
            openConnection();
    
                                                
                                                    
            closeConnection();
        }

    }
}
