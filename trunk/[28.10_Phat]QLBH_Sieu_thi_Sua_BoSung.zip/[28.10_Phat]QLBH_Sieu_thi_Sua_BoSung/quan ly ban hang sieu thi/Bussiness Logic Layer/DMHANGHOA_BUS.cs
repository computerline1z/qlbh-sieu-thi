﻿using System;
using System.Collections.Generic;
using System.Linq;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;
using System.Windows.Forms;

namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class DMHANGHOA_BUS:DataProvider 
    {    
        string sql = "";
        
        DataTable tempTable;
        LOAIHANG_BUS Loaihang_bus = new LOAIHANG_BUS();
        TYSUATGIACA_BUS Tysuat_bus = new TYSUATGIACA_BUS();
        NHACUNGCAP_BUS Nhacungcap_bus = new NHACUNGCAP_BUS();
        KHUYENMAI_BUS Khuyenmai_bus = new KHUYENMAI_BUS();
        HOADONCTY_BUS HoaconCty_bus = new HOADONCTY_BUS();
        HOADONLE_BUS HoadonLe_bus = new HOADONLE_BUS();

        public DataTable LayDanhSachHangHoa()
        {
            tempTable = new DataTable();
            openConnection();
            sql = "SELECT T.NHOMHANG, T.MAHANG, T.TENHANG , T.LOAI, T.DVT, T.GIABAN, T.MANCC, KM.LOAIKM, T.TONBANLE, T.TONKHO " +
                     "FROM (SELECT DM.NHOMHANG, DM.MAHANG, TENHANG, LH.LOAI, DVT, GIABAN, NCC.MANCC, TONBANLE, TONKHO " +
							"FROM DMHANG DM, LOAIHANG LH, NHACUNGCAP NCC, CUNGCAP CC "+
							"WHERE  DM.LOAI = LH.LOAI AND DM.MAHANG = CC.MAHANG AND NCC.MANCC = CC.MANCC AND DM.TRANGTHAI='TRUE' AND DM.LOAI <> 'X') AS T "+
					"LEFT OUTER JOIN HANG_KM KM "+
                    "ON T.MAHANG = KM.MAHANG ";
            tempTable = this.getDataTable(sql);
            closeConnection();
            return tempTable;
        }

        public int ktRongHanghoa(DMHANGHOA_OBJ Hanghoa)
        {
            int kq=0;
            
            if (Hanghoa.Mahang == "")
                return kq=1;

            if (Hanghoa.Tenhang == "")
                return kq = 2;

            if (Hanghoa.Manhom == "")
                return kq = 3;

            if (Hanghoa.Maloai == "")
                return kq = 4;

            if (Hanghoa.MaNCC == "")
                return kq = 5;

            return kq;
        }

        public bool ktTrungMahang(string NewMa)
        {
            bool kq;
            openConnection();
            string sql = "";
            sql = string.Format("SELECT count(*) From DMHang WHERE MAHANG='{0}'", NewMa);         
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }

        public int[] ktTontai(DMHANGHOA_OBJ Hanghoa)
        {
            int [] kq = new int[6];
            
            // kt ton tai loai hang
            if (Loaihang_bus.ktTontaiTrongLoaiHang(Hanghoa.Maloai))
                kq[0] = 1;
            // kt ton tai ma nhom 

            if (Tysuat_bus.ktTontaiTrongTySuatGCa(Hanghoa.Manhom))
                kq[1] = 1;
            
            // kt ton tai nha cung cap 
            if (Nhacungcap_bus.ktNCCTontaiNCC(Hanghoa.MaNCC))
                kq[2] = 1;

            if (Khuyenmai_bus.ktCTKhuyenmai(Hanghoa.Khuyenmai))
                kq[3] = 1;
            // kt Ton tai trong hoa don cty 
            if (HoaconCty_bus.ktTontaiHangTrongHoaDon(Hanghoa.Mahang))
                kq[4] = 1;
            //kt Ton tai trong hoa don le 

            if (HoadonLe_bus.ktTontaiHangTrongHoaDon(Hanghoa.Mahang))
                kq[5] = 1;

            return kq;


        }

        
        public void Them(DMHANGHOA_OBJ NewHH)
        {
            openConnection();
            sql = string.Format("insert into DMHANG values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}');", NewHH.Mahang, NewHH.Maloai, NewHH.Manhom, NewHH.Tenhang, "0", NewHH.DVT, "0", "True","0");
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public void Sua(DMHANGHOA_OBJ NewHH)
        {
            openConnection();
            sql = string.Format("update DMHang set Tenhang='{0}', loai='{1}', nhomhang='{2}',DVT='{3}' where Mahang='{4}'",NewHH.Tenhang,NewHH.Maloai,NewHH.Manhom, NewHH.DVT, NewHH.Mahang);
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public void Xoa(string Mahang)
        {
            openConnection();
            sql = string.Format("update DMHang set Trangthai='false' where mahang='{0}'",Mahang);
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public void XoaTheoLoaiHang(string Loaihang)
        {
            openConnection();
            sql = string.Format("update DMHang set Trangthai='false', loai = 'X' where loai='{0}'", Loaihang);
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public void XoaTheoNCC(string MaNCC)
        { 
            openConnection();
            sql = string.Format("update DMHang set Trangthai='false' where MaNCC='{0}'", MaNCC);
            this.excuteNonQuery(sql);
            closeConnection();
        
        }
    }   
}
