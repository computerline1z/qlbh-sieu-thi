﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class PHIEUNHAP_BUS:DataProvider
    {
        string sql = "";
        DataTable tempTable;
       // NHACUNGCAP_BUS Nhacungcap_bus = new NHACUNGCAP_BUS();

        public DataTable LayDSPhieuNhap()
        {
            tempTable = new DataTable();
            openConnection();
            sql = "select Maphieu, MaNCC, MaKho, MaNV, Ngaynhap from Phieunhap";
            tempTable = this.getDataSetTBl(sql,true,"PN");
            closeConnection();
            return tempTable;
        }
        /*
        public string LayIDTiepTheo()
        {
            int ID;
            string s;
            sql = "select MAX(CONVERT(int,RIGHT(MaPhieu,4))) from PHIEUNHAP";
            try
            {
                ID = (int)this.excuteScalar(sql);
            }
            catch(Exception ex) {
                ID = 0;
            }
            ID++;
            s = ID.ToString();
            for (int i = 0; i < 6 - s.Length; i++) 
            {
                s = "0" + s;
            }
            s = "PNK" + s;
            return s;
        }*/

        public int LayIDHienThoi()
        {
            int ID=0;
            try
            {
                
                string s;
                sql = "select MAX(CONVERT(int,RIGHT(MaPhieu,4))) from Phieunhap";
                object t = this.excuteScalar(sql);
                ID = ( t!=null ) ? (int) t : 0 ;
                return ID;
            }
            catch (Exception ex)
            {
                throw;
            }
            
        }

        public int[] ktRong(PHIEUNHAP_OBJ NewPhieuNhap)
        {
            int[] kq = new int[4];
            if (NewPhieuNhap.MaNCC == "")
                kq[0] = 1;
            if (NewPhieuNhap.Makho == "")
                kq[1] = 1;
            if (NewPhieuNhap.MaNV == "")
                kq[2] = 1;
            if (NewPhieuNhap.Ngaynhap == "")
                kq[3] = 1;

            return kq;
        }

        public bool ktTontaiPhieunhap(string Maphieu)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Phieunhap  where Maphieu='{0}'", Maphieu);
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }

        public bool ktNCCTontaiTrongPhieunhap(string MaNCC)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Phieunhap  where MaaNCC='{0}'", MaNCC);
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }

        public void Them(PHIEUNHAP_OBJ NewPhieunhap)
        {
            sql = string.Format("insert into Phieunhap values('{0}','{1}','{2}','{3}','{4}')", NewPhieunhap.Maphieunhap, NewPhieunhap.MaNCC, NewPhieunhap.Makho, NewPhieunhap.MaNV, NewPhieunhap.Ngaynhap);
            this.excuteNonQuery(sql);

        }

        public void XoaTheoMaphieu(string Maphieu)
        {

            sql = string.Format("delete Phieunhap where Maphieu='{0}'", Maphieu);
            openConnection();
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public void XoaTheoNCC(string MaNCC)
        {
            sql = string.Format("delete Phieunhap where MaNCC='{0}'", MaNCC);
            this.excuteNonQuery(sql);
        }

        public void Sua(PHIEUNHAP_OBJ NewPhieunhap)
        {
            sql = string.Format("update Phieunhap set Maphieu='{0}', MaNCC='{1}',Makho='{2}', MaNV='{3}', Ngaylap='{4}'", NewPhieunhap.Maphieunhap, NewPhieunhap.MaNCC, NewPhieunhap.Makho, NewPhieunhap.MaNV, NewPhieunhap.Ngaynhap);
            this.excuteNonQuery(sql);
        }

        public int Save(string name)
        {
            int rec=0;
            openConnection();
            try
            {
                rec = this.SaveToDB(name);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }
            
            closeConnection();
            return rec;
            usrDMHang.DongboDulieu();
        }


    }
}
