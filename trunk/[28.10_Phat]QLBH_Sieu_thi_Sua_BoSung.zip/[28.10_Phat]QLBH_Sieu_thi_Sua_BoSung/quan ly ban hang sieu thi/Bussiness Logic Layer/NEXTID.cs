﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
  public  class NEXTID
    {
     // Dat
      QUYDINH_BUS Quydinh_bus = new QUYDINH_BUS();

      
        
        static public string getNextID(int ID, string prefix)
        {
            
            int lenPre = prefix.Length;
            int sizeOfnum = 7 - lenPre;
            string s = ID.ToString();
            for (int i = 1;i<sizeOfnum-1;i++)
            {
                s = "0" + s;
            }
            return prefix + s;

        }
    }
}
