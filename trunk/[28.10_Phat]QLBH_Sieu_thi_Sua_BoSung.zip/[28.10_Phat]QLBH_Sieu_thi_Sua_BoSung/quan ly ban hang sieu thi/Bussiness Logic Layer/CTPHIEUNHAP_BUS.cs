﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;
using System.Windows.Forms;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class CTPHIEUNHAP_BUS:DataProvider
    {
        string sql = "";
        DataTable tempTable;
        public DataTable LayDSCTPhieunhap()
        {
            tempTable = new DataTable();
            sql = string.Format("select Maphieu, Mahang, Gianhap, Soluong, DVT from CTPhieunhap ");
            openConnection();
            tempTable =  this.getDataSetTBl(sql,true,"CTPN");
            closeConnection();
            return tempTable;

        }

        public int[] ktRong(CTPHIEUNHAP_OBJ CTPhieuNhap)
        {
            int[] kq = new int[5];
            if (CTPhieuNhap.Maphieunhap == "")
                kq[0] = 1;
            if (CTPhieuNhap.Mahang == "")
                kq[1] = 1;
            if (CTPhieuNhap.Dvt == "")
                kq[2] = 1;
            if (CTPhieuNhap.Gianhap == "")
                kq[3] = 1;
            if (CTPhieuNhap.Soluong == "")
                kq[4] = 1;

            return kq;
        }


        public DataTable LayDSCTPhieuNhapTheoMaPhieu(string Maphieu)
        {
            tempTable = new DataTable();
            sql = string.Format("select Maphieu, Mahang, Gianhap, Soluong, DVT from CTPhieunhap where Maphieu='{0}' ", Maphieu);
            openConnection();
            tempTable = this.getDataSetTBl(sql,true,"CTPN");
            closeConnection();
            return tempTable;
        }




        public void Them(CTPHIEUNHAP_OBJ CTPhieunhap)
        {
            sql = string.Format("insert into CTPhieunhap values('{0}','{1}','{2}','{3}','{4}' where Maphieu='{5})", CTPhieunhap.Mahang, CTPhieunhap.Gianhap, CTPhieunhap.Soluong,CTPhieunhap.Dvt,CTPhieunhap.Maphieunhap);
            openConnection();
            this.excuteNonQuery(sql);
            closeConnection();

        }

        public void XoatheoMaPhieu(string Maphieu)
        {
            sql = string.Format("delete CTPhieunhap where Maphieu = '{0}'", Maphieu);
            openConnection();
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public void XoatheoMaHang(string Mahang)
        {
            sql = string.Format("delete CTPhieunhap where Mahang = '{0}'", Mahang);
            openConnection();
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public int Save(string name)
        {
            int rec = 0;
            openConnection();
            try
            {
                rec = this.SaveToDB(name);
            }
            catch (Exception ex)
            {
                throw;
            }

            closeConnection();
            return rec;
        }

    }
}
