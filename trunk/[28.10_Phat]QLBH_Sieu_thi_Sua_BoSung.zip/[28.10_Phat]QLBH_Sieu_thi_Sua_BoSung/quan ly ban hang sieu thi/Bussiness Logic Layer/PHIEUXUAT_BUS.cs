﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;
using System.Windows.Forms;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class PHIEUXUAT_BUS:DataProvider
    {
        DataTable tempTable;
        string sql = "";
        public DataTable LayDSPhieuXuat()
        {
            tempTable = new DataTable();
            openConnection();
            sql = "select Maphieu, MaKho, MaNV, Ngayxuat from Phieuxuat";
            tempTable = this.getDataSetTBl(sql, true, "PX");
            closeConnection();
            return tempTable;
        }

        public int LayIDHienThoi()
        {
            int ID = 0;
            try
            {

                string s;
                sql = "select MAX(CONVERT(int,RIGHT(MaPhieu,4))) from Phieuxuat";
                object t = this.excuteScalar(sql);
                ID = (t != null) ? (int)t : 0;
                return ID;
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        public void Them(PHIEUXUAT_OBJ NewPhieuxuat)
        {
            sql = string.Format("insert into Phieuxuat values('{0}','{1}','{2}','{3}','{4}')", NewPhieuxuat.Maphieu, NewPhieuxuat.Makho, NewPhieuxuat.MaNV, NewPhieuxuat.Ngayxuat, NewPhieuxuat.Xuatcho);
            this.excuteNonQuery(sql);

        }

        public void Sua(PHIEUXUAT_OBJ NewPhieuxuat)
        {
            sql = string.Format("update Phieuxuat set Maphieu='{0}', MaKho='{1}',MaNV='{2}', Ngaylap='{3}', Xuatcho='{4}'", NewPhieuxuat.Maphieu, NewPhieuxuat.Makho, NewPhieuxuat.MaNV, NewPhieuxuat.Ngayxuat, NewPhieuxuat.Xuatcho);
            this.excuteNonQuery(sql);
        }

        public void XoaTheoMaphieu(string Maphieu)
        {

            sql = string.Format("delete Phieuxuat where Maphieu='{0}'", Maphieu);
            openConnection();
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public int Save(string name)
        {
            int rec = 0;
            openConnection();
            try
            {
                rec = this.SaveToDB(name);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }

            closeConnection();
            return rec;
        }


    }
}
