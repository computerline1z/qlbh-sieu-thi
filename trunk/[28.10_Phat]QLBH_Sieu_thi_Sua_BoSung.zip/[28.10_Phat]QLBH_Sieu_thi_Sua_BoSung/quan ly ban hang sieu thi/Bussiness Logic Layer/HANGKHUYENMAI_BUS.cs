﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{  
    public class HANGKHUYENMAI_BUS:DataProvider
    {
         string sql = "";
         DataTable tempTable;
       
         public bool ktTonTaiKMChoHang(HANGKHUYENMAI_OBJ HangKM)
         {
             bool kq;
             openConnection();
             sql = string.Format("select count(*) as SL from Hang_KM where loaiKM='{0}' and mahang='{1}'", HangKM.LoaiKM, HangKM.Mahang);
             kq = this.countQuantity(sql) == 1;
             closeConnection();
             return kq;
         }

         public void Them(HANGKHUYENMAI_OBJ HangKM)
         {
             openConnection();
             sql = string.Format("insert into HANG_KM values('{0}','{1}','{3}','{4}')", HangKM.Mahang, HangKM.LoaiKM,HangKM.tg_batdau,HangKM.songayKM);
             this.excuteNonQuery(sql);
             closeConnection();

         }
         public void Sua(HANGKHUYENMAI_OBJ HangKM)
         {
             openConnection();
             sql = string.Format("update Hang_KM set Mahang='{0}',LoaiKM='{1}', Tg_batdau= {2} ,Tg_Ketthuc='{3}' where Mahang='{4}'", HangKM.Mahang, HangKM.LoaiKM, HangKM.tg_batdau, HangKM.songayKM);
             this.excuteNonQuery(sql);
             closeConnection();
         }
         public void Xoa(string Mahang)
         {
             openConnection();
             sql = string.Format("delete Hang_KM where mahang='{0}'", Mahang);
             this.excuteNonQuery(sql);
             closeConnection();
         }
              
    }
}
