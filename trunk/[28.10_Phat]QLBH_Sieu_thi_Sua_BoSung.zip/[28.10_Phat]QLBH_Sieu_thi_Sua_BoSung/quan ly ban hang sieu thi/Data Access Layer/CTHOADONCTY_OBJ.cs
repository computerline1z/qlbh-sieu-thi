﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace quan_ly_ban_hang_sieu_thi.Data_Access_Layer
{
    public class CTHOADONCTY_OBJ
    {
        public string SoHD { get; set; }
        public string Mahang { get; set; }
        public string Soluong { get; set; }

    }
}
