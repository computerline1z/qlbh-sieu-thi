﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace quan_ly_ban_hang_sieu_thi.Data_Access_Layer
{
    public class PHIEUXUAT_OBJ
    {
        public string Maphieu { get; set; }
        public string Makho { get; set; }
        public string MaNV { get; set; }
        public string Ngayxuat { get; set; }
        public string Xuatcho { get; set; }

    }
}
