﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace quan_ly_ban_hang_sieu_thi.Data_Access_Layer
{
    public class KHACHCTY_OBJ
    {

        public string MaKH { get; set; }

        public string TenKH { get; set; }

        public string Diachi { get; set; }

        public string Dienthoai { get; set; }

        public string Fax { get; set; }

        public string Mathue { get; set; }

        public string SotK { get; set; }
        
    }
}
