﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace quan_ly_ban_hang_sieu_thi.Data_Access_Layer
{
    public class TYSUATGIACA_OBJ
    {
        public string Manhom { get; set; }
        public string Tysuat { get; set; }
    }
}
