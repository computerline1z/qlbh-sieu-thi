﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace quan_ly_ban_hang_sieu_thi.Data_Access_Layer
{
    public class DVTINH_OBJ
    {
        public string DVT { set; get; }
    }
}
