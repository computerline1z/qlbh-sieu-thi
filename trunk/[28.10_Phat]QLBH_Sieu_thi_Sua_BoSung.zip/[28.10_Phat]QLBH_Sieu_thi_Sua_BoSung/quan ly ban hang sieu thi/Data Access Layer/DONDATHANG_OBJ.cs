﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace quan_ly_ban_hang_sieu_thi.Data_Access_Layer
{
    public class DONDATHANG_OBJ
    {
        public string SoDDH { get; set;}
        public string MaNCC { get; set;}
        public string MaNV { get; set; }
        public string Ngaylap { get; set; }
        public string PhuongthucTT { get; set; }

    }
}
