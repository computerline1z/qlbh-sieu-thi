﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using quan_ly_ban_hang_sieu_thi.Presentation_Layer;

namespace quan_ly_ban_hang_sieu_thi
{
    public partial class usrDMHang : UserControl
    {
        static public DMHANGHOA_BUS Dmhh_bus = new DMHANGHOA_BUS();
        private DMHANGHOA_OBJ Hanghoa = new DMHANGHOA_OBJ();
        private CUNGCAP_OBJ Cungcap = new CUNGCAP_OBJ();
        static private NHACUNGCAP_BUS Nhacungcap_bus = new NHACUNGCAP_BUS();
        private HANGKHUYENMAI_OBJ HangKM = new HANGKHUYENMAI_OBJ();
        private HANGKHUYENMAI_BUS HangKM_bus = new HANGKHUYENMAI_BUS();
        private KHUYENMAI_BUS Khuyenmai_bus = new KHUYENMAI_BUS();
        static private LOAIHANG_BUS Loaihang_bus = new LOAIHANG_BUS();
        static private TYSUATGIACA_BUS Tysuat_bus = new TYSUATGIACA_BUS();
        private CUNGCAP_BUS Cungcap_bus = new CUNGCAP_BUS();
        static public DVTINH_BUS DVT_bus = new DVTINH_BUS();
        static public BindingSource bindingSource = new BindingSource();
        static public BindingSource bindingDVT = new BindingSource();
        static public BindingSource bindingNCC = new BindingSource();
        static public BindingSource bindingMaloai = new BindingSource();
        static public BindingSource bindingNhomhang = new BindingSource();
        private string flag = "";
        private string tempValue = "";


        public usrDMHang()
        {
            InitializeComponent();
            bindingSource.DataSource = Dmhh_bus.LayDanhSachHangHoa();
            bindingDVT.DataSource = DVT_bus.layDanhSachDVT();
            bindingNCC.DataSource = Nhacungcap_bus.LayDanhSachRutGonNCC();
            bindingNhomhang.DataSource = Tysuat_bus.LayDSNhom();
            bindingMaloai.DataSource = Loaihang_bus.LayLoaiHang();
            dgvHanghoa.DataSource = bindingSource;
            disableInput();
            loadToCombobox();
        }

        private void disableInput()
        {

            cboManhom.Enabled = false;
            txtMahang.ReadOnly = true;
            txtTenhang.ReadOnly = true;
            cboDVT.Enabled = false;
            cboMaloai.Enabled = false;
            txtGia.ReadOnly = true;
            cboNCC.Enabled = false;
        }

        private void enableInput()
        {
            cboManhom.Enabled = true;
            txtTenhang.ReadOnly = false;
            cboDVT.Enabled = true;
            cboMaloai.Enabled = true;
            cboNCC.Enabled = true;
        }

        private void clearInput()
        {
            cboManhom.Text = "";
            txtMahang.Text = "";
            txtTenhang.Text = "";
            cboDVT.Text = "";
            cboMaloai.Text = "";
            txtGia.Text = "";
            cboNCC.Text = "";
        }

        private void loadToCombobox()
        {

            cboDVT.DataSource = bindingDVT;
            cboDVT.ValueMember = "DVT";
            cboDVT.DisplayMember = "DVT";

            cboManhom.DataSource = bindingNhomhang;
            cboManhom.ValueMember = "Nhomhang";
            cboManhom.DisplayMember = "Nhomhang";

            cboNCC.DataSource = bindingNCC;
            cboNCC.ValueMember = "MaNCC";
            cboNCC.DisplayMember = "TenNCC";

            cboMaloai.DataSource = bindingMaloai;
            cboMaloai.ValueMember = "Loai";
            cboMaloai.DisplayMember = "Tenloai";

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            enableInput();
            txtMahang.ReadOnly = false;
            clearInput();
            txtMahang.Focus();
            flag = "Them";
        }


        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (flag != "")
            {

                TranferValueToObject();
                //step 1 : Kiem tra rong  

                switch (Dmhh_bus.ktRongHanghoa(Hanghoa))
                {
                    case 1:
                        {
                            MessageBox.Show("Mã hàng rỗng");
                            txtMahang.Focus();
                            return;
                        }
                    case 2:
                        {
                            MessageBox.Show("Tên hàng rỗng");
                            txtTenhang.Focus();
                            return;
                        }

                }



                // step 3 : xu ly 

                switch (flag)
                {
                    case "Them":
                        {


                            Dmhh_bus.Them(Hanghoa);

                            // them vao cung cap   
                            Cungcap_bus.Them(Cungcap);

                            break;
                        }

                    case "Sua":
                        {
                            //// Trigger ??????????????
                            Dmhh_bus.Sua(Hanghoa);
                            Cungcap_bus.Sua(Cungcap);

                            tempValue = "";
                            break;

                        }


                }

                bindingSource.DataSource = Dmhh_bus.LayDanhSachHangHoa();
                dgvHanghoa.DataSource = bindingSource;
                disableInput();
                flag = "";

            }
        }

        public void TranferValueToObject()
        {
            Hanghoa.Mahang = txtMahang.Text.Trim();
            Hanghoa.Tenhang = txtTenhang.Text.Trim();
            Hanghoa.DVT = cboDVT.Text.Trim();
            Hanghoa.Maloai = cboMaloai.SelectedValue.ToString().Trim();
            Hanghoa.Manhom = cboManhom.Text.Trim();
            Hanghoa.MaNCC = cboNCC.SelectedValue.ToString().Trim();
            Cungcap.Mahang = Hanghoa.Mahang;
            Cungcap.MaNCC = Hanghoa.MaNCC;


        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            flag = "Sua";
            enableInput();
            txtMahang.ReadOnly = true;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {   /// kiem tra trong hoa don truoc 
            /// neu chua nam trong hoa don nao thi se xoa 
            /// neu da nam trong 1 hoa don thi se danh dau cho xoa 
            /// kiem tra trong phieu nhap
            ///     neu co ton == 0 thi se xoa 
            ///     neu co ton > 0 thi se danh dau cho den khi nao can se xoa
            ///  khi danh dau xoa ta se thay doi ma cua sp thanh Ma "RÁC" va thay doi trang thai cua san pham thanh false ( voi y nghia la hang nay da dc danh dau xoa)
            DialogResult kq = MessageBox.Show("Bạn có chắc chắn xóa sản phẩm này không ? ", "Chú ý", MessageBoxButtons.YesNo);
            if (kq == DialogResult.Yes)
            {
                TranferValueToObject();

                // xoa du lieu trong cac bang phu Khuyen mai 
                HangKM_bus.Xoa(Hanghoa.Mahang);

                // thay doi trang thai cua hang hoa 
                Dmhh_bus.Xoa(Hanghoa.Mahang);

                bindingSource.DataSource = Dmhh_bus.LayDanhSachHangHoa();
                dgvHanghoa.DataSource = bindingSource;
            }
        }
        private void btnThemNCC_Click(object sender, EventArgs e)
        {
            newForm NCC = new newForm("frmNCC", "NHÀ CUNG CẤP");
            ucNCC newNCC = new ucNCC();
            NCC.taoForm(newNCC);
        }
        private void btnThemDVT_Click(object sender, EventArgs e)
        {
            newForm DVT = new newForm("frmDVT", "ĐƠN VỊ TÍNH");
            ucDVT newDVT = new ucDVT();
            DVT.taoForm(newDVT);
        }
        private void btnThemLoaiHang_Click(object sender, EventArgs e)
        {
            newForm LoaiHang = new newForm("frmLoaiHang", "LOẠI MẶT HÀNG");
            ucLoaiHang newLoaiHang = new ucLoaiHang();
            LoaiHang.taoForm(newLoaiHang);

        }
        private void btnThemNhom_Click(object sender, EventArgs e)
        {
            newForm Nhom = new newForm("frmNhom", "NHÓM GIÁ CẢ");
            ucQLGiaCa newNhom = new ucQLGiaCa();
            Nhom.taoForm(newNhom);
        }

        private void dtGWHanghoa_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                cboManhom.DataBindings.Add("SelectedValue", bindingSource, "Nhomhang");
                txtMahang.DataBindings.Add("Text", bindingSource, "Mahang");
                txtTenhang.DataBindings.Add("Text", bindingSource, "Tenhang");
                cboMaloai.DataBindings.Add("SelectedValue", bindingSource, "loai");
                cboDVT.DataBindings.Add("SelectedValue", bindingSource, "DVT");
                txtGia.DataBindings.Add("Text", bindingSource, "Giaban");
                cboNCC.DataBindings.Add("SelectedValue", bindingSource, "MaNCC");
                txtKM.DataBindings.Add("Text", bindingSource, "LoaiKM");



            }
            catch (Exception ex)
            {

            }
        }

        static public void DongboDulieu()
        {
            bindingSource.DataSource = Dmhh_bus.LayDanhSachHangHoa();
            bindingDVT.DataSource = DVT_bus.layDanhSachDVT();
            bindingNCC.DataSource = Nhacungcap_bus.LayDanhSachRutGonNCC();
            bindingNhomhang.DataSource = Tysuat_bus.LayDSNhom();
            bindingMaloai.DataSource = Loaihang_bus.LayLoaiHang();
        }

        private void tlpThongTinHangHoa_Paint(object sender, PaintEventArgs e)
        {

        }

        


    }
}
