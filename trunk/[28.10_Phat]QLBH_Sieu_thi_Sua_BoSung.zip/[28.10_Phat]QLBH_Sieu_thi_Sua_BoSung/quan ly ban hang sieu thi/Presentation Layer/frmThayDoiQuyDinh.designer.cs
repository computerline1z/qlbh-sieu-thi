﻿namespace quan_ly_ban_hang_sieu_thi.Presentation_Layer
{
    partial class frmThayDoiQuyDinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tctQuyDinh = new System.Windows.Forms.TabControl();
            this.tpHangHoa = new System.Windows.Forms.TabPage();
            this.grbQuyDinhThoiGian = new System.Windows.Forms.GroupBox();
            this.lblSoNgayToiDa = new System.Windows.Forms.Label();
            this.lblToiThieu = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.txtSoNgayToiThieu = new System.Windows.Forms.TextBox();
            this.lblSoNgayKMMax = new System.Windows.Forms.Label();
            this.grbQuyDinhSoLuong = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblSLDatHangMin = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.lblSLTonToiDa = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblSLTonToiThieu = new System.Windows.Forms.Label();
            this.tbQuyCachDanhMa = new System.Windows.Forms.TabPage();
            this.listView1 = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTenDoiTuong = new System.Windows.Forms.Label();
            this.lblDauNgu = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.tpThongTinChung = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblNamTL = new System.Windows.Forms.Label();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.txtSoDT = new System.Windows.Forms.TextBox();
            this.lblFax = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblSoDT = new System.Windows.Forms.Label();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtTenHienThi = new System.Windows.Forms.TextBox();
            this.lblTenHienThi = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.tctQuyDinh.SuspendLayout();
            this.tpHangHoa.SuspendLayout();
            this.grbQuyDinhThoiGian.SuspendLayout();
            this.grbQuyDinhSoLuong.SuspendLayout();
            this.tbQuyCachDanhMa.SuspendLayout();
            this.tpThongTinChung.SuspendLayout();
            this.SuspendLayout();
            // 
            // tctQuyDinh
            // 
            this.tctQuyDinh.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tctQuyDinh.Controls.Add(this.tpHangHoa);
            this.tctQuyDinh.Controls.Add(this.tbQuyCachDanhMa);
            this.tctQuyDinh.Controls.Add(this.tpThongTinChung);
            this.tctQuyDinh.Location = new System.Drawing.Point(2, 5);
            this.tctQuyDinh.Name = "tctQuyDinh";
            this.tctQuyDinh.SelectedIndex = 0;
            this.tctQuyDinh.Size = new System.Drawing.Size(393, 399);
            this.tctQuyDinh.TabIndex = 0;
            // 
            // tpHangHoa
            // 
            this.tpHangHoa.Controls.Add(this.grbQuyDinhThoiGian);
            this.tpHangHoa.Controls.Add(this.grbQuyDinhSoLuong);
            this.tpHangHoa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tpHangHoa.Location = new System.Drawing.Point(4, 22);
            this.tpHangHoa.Name = "tpHangHoa";
            this.tpHangHoa.Padding = new System.Windows.Forms.Padding(3);
            this.tpHangHoa.Size = new System.Drawing.Size(385, 373);
            this.tpHangHoa.TabIndex = 0;
            this.tpHangHoa.Text = "Hàng hóa";
            this.tpHangHoa.UseVisualStyleBackColor = true;
            // 
            // grbQuyDinhThoiGian
            // 
            this.grbQuyDinhThoiGian.Controls.Add(this.lblSoNgayToiDa);
            this.grbQuyDinhThoiGian.Controls.Add(this.lblToiThieu);
            this.grbQuyDinhThoiGian.Controls.Add(this.textBox9);
            this.grbQuyDinhThoiGian.Controls.Add(this.txtSoNgayToiThieu);
            this.grbQuyDinhThoiGian.Controls.Add(this.lblSoNgayKMMax);
            this.grbQuyDinhThoiGian.Location = new System.Drawing.Point(19, 169);
            this.grbQuyDinhThoiGian.Name = "grbQuyDinhThoiGian";
            this.grbQuyDinhThoiGian.Size = new System.Drawing.Size(346, 146);
            this.grbQuyDinhThoiGian.TabIndex = 3;
            this.grbQuyDinhThoiGian.TabStop = false;
            this.grbQuyDinhThoiGian.Text = "Quy định về thời gian";
            // 
            // lblSoNgayToiDa
            // 
            this.lblSoNgayToiDa.AutoSize = true;
            this.lblSoNgayToiDa.Location = new System.Drawing.Point(230, 35);
            this.lblSoNgayToiDa.Name = "lblSoNgayToiDa";
            this.lblSoNgayToiDa.Size = new System.Drawing.Size(41, 15);
            this.lblSoNgayToiDa.TabIndex = 2;
            this.lblSoNgayToiDa.Text = "Tối đa";
            // 
            // lblToiThieu
            // 
            this.lblToiThieu.AutoSize = true;
            this.lblToiThieu.Location = new System.Drawing.Point(95, 35);
            this.lblToiThieu.Name = "lblToiThieu";
            this.lblToiThieu.Size = new System.Drawing.Size(55, 15);
            this.lblToiThieu.TabIndex = 2;
            this.lblToiThieu.Text = "Tối thiểu";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(277, 32);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(42, 21);
            this.textBox9.TabIndex = 1;
            // 
            // txtSoNgayToiThieu
            // 
            this.txtSoNgayToiThieu.Location = new System.Drawing.Point(170, 32);
            this.txtSoNgayToiThieu.Name = "txtSoNgayToiThieu";
            this.txtSoNgayToiThieu.Size = new System.Drawing.Size(41, 21);
            this.txtSoNgayToiThieu.TabIndex = 1;
            // 
            // lblSoNgayKMMax
            // 
            this.lblSoNgayKMMax.AutoSize = true;
            this.lblSoNgayKMMax.Location = new System.Drawing.Point(13, 35);
            this.lblSoNgayKMMax.Name = "lblSoNgayKMMax";
            this.lblSoNgayKMMax.Size = new System.Drawing.Size(76, 15);
            this.lblSoNgayKMMax.TabIndex = 0;
            this.lblSoNgayKMMax.Text = "Số ngày KM:";
            // 
            // grbQuyDinhSoLuong
            // 
            this.grbQuyDinhSoLuong.Controls.Add(this.textBox3);
            this.grbQuyDinhSoLuong.Controls.Add(this.lblSLDatHangMin);
            this.grbQuyDinhSoLuong.Controls.Add(this.textBox5);
            this.grbQuyDinhSoLuong.Controls.Add(this.lblSLTonToiDa);
            this.grbQuyDinhSoLuong.Controls.Add(this.textBox2);
            this.grbQuyDinhSoLuong.Controls.Add(this.lblSLTonToiThieu);
            this.grbQuyDinhSoLuong.Location = new System.Drawing.Point(19, 10);
            this.grbQuyDinhSoLuong.Name = "grbQuyDinhSoLuong";
            this.grbQuyDinhSoLuong.Size = new System.Drawing.Size(346, 144);
            this.grbQuyDinhSoLuong.TabIndex = 2;
            this.grbQuyDinhSoLuong.TabStop = false;
            this.grbQuyDinhSoLuong.Text = "Quy định về số lượng";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(191, 105);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 21);
            this.textBox3.TabIndex = 1;
            // 
            // lblSLDatHangMin
            // 
            this.lblSLDatHangMin.AutoSize = true;
            this.lblSLDatHangMin.Location = new System.Drawing.Point(25, 108);
            this.lblSLDatHangMin.Name = "lblSLDatHangMin";
            this.lblSLDatHangMin.Size = new System.Drawing.Size(160, 15);
            this.lblSLDatHangMin.TabIndex = 0;
            this.lblSLDatHangMin.Text = "Số lượng đặt hàng tối thiểu";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(191, 65);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 21);
            this.textBox5.TabIndex = 1;
            // 
            // lblSLTonToiDa
            // 
            this.lblSLTonToiDa.AutoSize = true;
            this.lblSLTonToiDa.Location = new System.Drawing.Point(30, 71);
            this.lblSLTonToiDa.Name = "lblSLTonToiDa";
            this.lblSLTonToiDa.Size = new System.Drawing.Size(115, 15);
            this.lblSLTonToiDa.TabIndex = 0;
            this.lblSLTonToiDa.Text = "Số lượng tồn tối đa";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(191, 32);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 1;
            // 
            // lblSLTonToiThieu
            // 
            this.lblSLTonToiThieu.AutoSize = true;
            this.lblSLTonToiThieu.Location = new System.Drawing.Point(25, 38);
            this.lblSLTonToiThieu.Name = "lblSLTonToiThieu";
            this.lblSLTonToiThieu.Size = new System.Drawing.Size(129, 15);
            this.lblSLTonToiThieu.TabIndex = 0;
            this.lblSLTonToiThieu.Text = "Số lượng tồn tối thiểu";
            this.lblSLTonToiThieu.Click += new System.EventHandler(this.lblSLTonToiThieu_Click);
            // 
            // tbQuyCachDanhMa
            // 
            this.tbQuyCachDanhMa.Controls.Add(this.listView1);
            this.tbQuyCachDanhMa.Controls.Add(this.label1);
            this.tbQuyCachDanhMa.Controls.Add(this.lblTenDoiTuong);
            this.tbQuyCachDanhMa.Controls.Add(this.lblDauNgu);
            this.tbQuyCachDanhMa.Controls.Add(this.textBox4);
            this.tbQuyCachDanhMa.Controls.Add(this.textBox6);
            this.tbQuyCachDanhMa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbQuyCachDanhMa.Location = new System.Drawing.Point(4, 22);
            this.tbQuyCachDanhMa.Name = "tbQuyCachDanhMa";
            this.tbQuyCachDanhMa.Size = new System.Drawing.Size(385, 373);
            this.tbQuyCachDanhMa.TabIndex = 2;
            this.tbQuyCachDanhMa.Text = "Quy cách đánh mã";
            this.tbQuyCachDanhMa.UseVisualStyleBackColor = true;
            this.tbQuyCachDanhMa.Click += new System.EventHandler(this.tbQuyCachDanhMa_Click);
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(26, 154);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(339, 182);
            this.listView1.TabIndex = 4;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(95, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Tiếp đầu ngữ có tối đa 4 kí tự";
            // 
            // lblTenDoiTuong
            // 
            this.lblTenDoiTuong.AutoSize = true;
            this.lblTenDoiTuong.Location = new System.Drawing.Point(35, 34);
            this.lblTenDoiTuong.Name = "lblTenDoiTuong";
            this.lblTenDoiTuong.Size = new System.Drawing.Size(87, 15);
            this.lblTenDoiTuong.TabIndex = 3;
            this.lblTenDoiTuong.Text = "Tên đối tượng";
            // 
            // lblDauNgu
            // 
            this.lblDauNgu.AutoSize = true;
            this.lblDauNgu.Location = new System.Drawing.Point(41, 75);
            this.lblDauNgu.Name = "lblDauNgu";
            this.lblDauNgu.Size = new System.Drawing.Size(81, 15);
            this.lblDauNgu.TabIndex = 2;
            this.lblDauNgu.Text = "Tiếp đầu ngữ";
            // 
            // textBox4
            // 
            this.textBox4.Enabled = false;
            this.textBox4.Location = new System.Drawing.Point(134, 34);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(136, 21);
            this.textBox4.TabIndex = 1;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(134, 75);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(136, 21);
            this.textBox6.TabIndex = 1;
            // 
            // tpThongTinChung
            // 
            this.tpThongTinChung.Controls.Add(this.textBox1);
            this.tpThongTinChung.Controls.Add(this.lblNamTL);
            this.tpThongTinChung.Controls.Add(this.txtFax);
            this.tpThongTinChung.Controls.Add(this.txtSoDT);
            this.tpThongTinChung.Controls.Add(this.lblFax);
            this.tpThongTinChung.Controls.Add(this.txtDiaChi);
            this.tpThongTinChung.Controls.Add(this.lblSoDT);
            this.tpThongTinChung.Controls.Add(this.lblDiaChi);
            this.tpThongTinChung.Controls.Add(this.txtTenHienThi);
            this.tpThongTinChung.Controls.Add(this.lblTenHienThi);
            this.tpThongTinChung.Location = new System.Drawing.Point(4, 22);
            this.tpThongTinChung.Name = "tpThongTinChung";
            this.tpThongTinChung.Padding = new System.Windows.Forms.Padding(3);
            this.tpThongTinChung.Size = new System.Drawing.Size(385, 373);
            this.tpThongTinChung.TabIndex = 1;
            this.tpThongTinChung.Text = "Thông tin siêu thị";
            this.tpThongTinChung.ToolTipText = "Thông tin siêu thị";
            this.tpThongTinChung.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(117, 82);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(46, 21);
            this.textBox1.TabIndex = 4;
            this.textBox1.Text = "2000";
            // 
            // lblNamTL
            // 
            this.lblNamTL.AutoSize = true;
            this.lblNamTL.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNamTL.Location = new System.Drawing.Point(23, 82);
            this.lblNamTL.Name = "lblNamTL";
            this.lblNamTL.Size = new System.Drawing.Size(88, 15);
            this.lblNamTL.TabIndex = 3;
            this.lblNamTL.Text = "Năm thành lập";
            // 
            // txtFax
            // 
            this.txtFax.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFax.Location = new System.Drawing.Point(117, 219);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(102, 21);
            this.txtFax.TabIndex = 1;
            this.txtFax.Text = "08-4545515";
            // 
            // txtSoDT
            // 
            this.txtSoDT.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoDT.Location = new System.Drawing.Point(117, 173);
            this.txtSoDT.Name = "txtSoDT";
            this.txtSoDT.Size = new System.Drawing.Size(102, 21);
            this.txtSoDT.TabIndex = 1;
            this.txtSoDT.Text = "08-4545515";
            // 
            // lblFax
            // 
            this.lblFax.AutoSize = true;
            this.lblFax.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFax.Location = new System.Drawing.Point(82, 222);
            this.lblFax.Name = "lblFax";
            this.lblFax.Size = new System.Drawing.Size(29, 15);
            this.lblFax.TabIndex = 0;
            this.lblFax.Text = "FAX";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChi.Location = new System.Drawing.Point(117, 128);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(221, 21);
            this.txtDiaChi.TabIndex = 1;
            this.txtDiaChi.Text = "29/5 Huỳnh Tấn Phát - KP6 - Nhà Bè";
            // 
            // lblSoDT
            // 
            this.lblSoDT.AutoSize = true;
            this.lblSoDT.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoDT.Location = new System.Drawing.Point(47, 176);
            this.lblSoDT.Name = "lblSoDT";
            this.lblSoDT.Size = new System.Drawing.Size(64, 15);
            this.lblSoDT.TabIndex = 0;
            this.lblSoDT.Text = "Điện thoại";
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiaChi.Location = new System.Drawing.Point(65, 131);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(46, 15);
            this.lblDiaChi.TabIndex = 0;
            this.lblDiaChi.Text = "Địa chỉ";
            // 
            // txtTenHienThi
            // 
            this.txtTenHienThi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenHienThi.Location = new System.Drawing.Point(117, 37);
            this.txtTenHienThi.Name = "txtTenHienThi";
            this.txtTenHienThi.Size = new System.Drawing.Size(184, 21);
            this.txtTenHienThi.TabIndex = 1;
            this.txtTenHienThi.Text = "Siêu thị ABC";
            // 
            // lblTenHienThi
            // 
            this.lblTenHienThi.AutoSize = true;
            this.lblTenHienThi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenHienThi.Location = new System.Drawing.Point(39, 40);
            this.lblTenHienThi.Name = "lblTenHienThi";
            this.lblTenHienThi.Size = new System.Drawing.Size(72, 15);
            this.lblTenHienThi.TabIndex = 0;
            this.lblTenHienThi.Text = "Tên hiển thị";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(306, 410);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(5, 1, 0, 0);
            this.button1.Size = new System.Drawing.Size(65, 25);
            this.button1.TabIndex = 5;
            this.button1.Text = "      &Lưu";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Yes;
            this.btnOK.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnOK.Location = new System.Drawing.Point(231, 410);
            this.btnOK.Name = "btnOK";
            this.btnOK.Padding = new System.Windows.Forms.Padding(5, 1, 0, 0);
            this.btnOK.Size = new System.Drawing.Size(65, 25);
            this.btnOK.TabIndex = 4;
            this.btnOK.Text = "    &OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // frmThayDoiQuyDinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 443);
            this.Controls.Add(this.tctQuyDinh);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.button1);
            this.Name = "frmThayDoiQuyDinh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NHỮNG QUY ĐỊNH CHO SỐ LIỆU";
            this.tctQuyDinh.ResumeLayout(false);
            this.tpHangHoa.ResumeLayout(false);
            this.grbQuyDinhThoiGian.ResumeLayout(false);
            this.grbQuyDinhThoiGian.PerformLayout();
            this.grbQuyDinhSoLuong.ResumeLayout(false);
            this.grbQuyDinhSoLuong.PerformLayout();
            this.tbQuyCachDanhMa.ResumeLayout(false);
            this.tbQuyCachDanhMa.PerformLayout();
            this.tpThongTinChung.ResumeLayout(false);
            this.tpThongTinChung.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tctQuyDinh;
        private System.Windows.Forms.TabPage tpHangHoa;
        private System.Windows.Forms.TabPage tpThongTinChung;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.TextBox txtSoDT;
        private System.Windows.Forms.Label lblFax;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblSoDT;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtTenHienThi;
        private System.Windows.Forms.Label lblTenHienThi;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblNamTL;
        private System.Windows.Forms.GroupBox grbQuyDinhThoiGian;
        private System.Windows.Forms.Label lblSoNgayToiDa;
        private System.Windows.Forms.Label lblToiThieu;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox txtSoNgayToiThieu;
        private System.Windows.Forms.Label lblSoNgayKMMax;
        private System.Windows.Forms.GroupBox grbQuyDinhSoLuong;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lblSLDatHangMin;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblSLTonToiThieu;
        private System.Windows.Forms.TabPage tbQuyCachDanhMa;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label lblTenDoiTuong;
        private System.Windows.Forms.Label lblDauNgu;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label lblSLTonToiDa;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label1;
    }
}