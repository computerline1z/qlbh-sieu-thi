﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace quan_ly_ban_hang_sieu_thi
{
    public partial class ucHoaDonCty : UserControl
    {
        public ucHoaDonCty()
        {
            InitializeComponent();
        }

        private void ucHoaDonCty_Load(object sender, EventArgs e)
        {

        }

        private void bnaEditHoaDonCty_RefreshItems(object sender, EventArgs e)
        {

        }

 
   

        
    }
}
