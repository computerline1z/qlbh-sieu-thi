﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucMatHangKM
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLoaiKM = new System.Windows.Forms.Label();
            this.lblDen = new System.Windows.Forms.Label();
            this.lblTu = new System.Windows.Forms.Label();
            this.cboLoaiKM = new System.Windows.Forms.ComboBox();
            this.grbTimKiemKM = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpDen = new System.Windows.Forms.DateTimePicker();
            this.dtpTu = new System.Windows.Forms.DateTimePicker();
            this.txtMaHang = new System.Windows.Forms.TextBox();
            this.cboTenHang = new System.Windows.Forms.ComboBox();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.lblTenHang = new System.Windows.Forms.Label();
            this.lblMaHang = new System.Windows.Forms.Label();
            this.grbMatHangKM = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoaiKM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayAD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayHetKM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblMatHangKM = new System.Windows.Forms.TableLayoutPanel();
            this.grbTimKiemKM.SuspendLayout();
            this.grbMatHangKM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tblMatHangKM.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblLoaiKM
            // 
            this.lblLoaiKM.AutoSize = true;
            this.lblLoaiKM.Location = new System.Drawing.Point(25, 24);
            this.lblLoaiKM.Name = "lblLoaiKM";
            this.lblLoaiKM.Size = new System.Drawing.Size(52, 15);
            this.lblLoaiKM.TabIndex = 0;
            this.lblLoaiKM.Text = "Loại KM";
            // 
            // lblDen
            // 
            this.lblDen.AutoSize = true;
            this.lblDen.Location = new System.Drawing.Point(514, 19);
            this.lblDen.Name = "lblDen";
            this.lblDen.Size = new System.Drawing.Size(30, 15);
            this.lblDen.TabIndex = 0;
            this.lblDen.Text = "Đến";
            // 
            // lblTu
            // 
            this.lblTu.AutoSize = true;
            this.lblTu.Location = new System.Drawing.Point(357, 22);
            this.lblTu.Name = "lblTu";
            this.lblTu.Size = new System.Drawing.Size(23, 15);
            this.lblTu.TabIndex = 0;
            this.lblTu.Text = "Từ";
            // 
            // cboLoaiKM
            // 
            this.cboLoaiKM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiKM.FormattingEnabled = true;
            this.cboLoaiKM.Location = new System.Drawing.Point(83, 19);
            this.cboLoaiKM.Name = "cboLoaiKM";
            this.cboLoaiKM.Size = new System.Drawing.Size(119, 23);
            this.cboLoaiKM.TabIndex = 3;
            // 
            // grbTimKiemKM
            // 
            this.grbTimKiemKM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.grbTimKiemKM.Controls.Add(this.label1);
            this.grbTimKiemKM.Controls.Add(this.dtpDen);
            this.grbTimKiemKM.Controls.Add(this.dtpTu);
            this.grbTimKiemKM.Controls.Add(this.txtMaHang);
            this.grbTimKiemKM.Controls.Add(this.cboTenHang);
            this.grbTimKiemKM.Controls.Add(this.cboLoaiKM);
            this.grbTimKiemKM.Controls.Add(this.btnTimKiem);
            this.grbTimKiemKM.Controls.Add(this.lblTu);
            this.grbTimKiemKM.Controls.Add(this.lblTenHang);
            this.grbTimKiemKM.Controls.Add(this.lblMaHang);
            this.grbTimKiemKM.Controls.Add(this.lblDen);
            this.grbTimKiemKM.Controls.Add(this.lblLoaiKM);
            this.grbTimKiemKM.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTimKiemKM.Location = new System.Drawing.Point(3, 3);
            this.grbTimKiemKM.Name = "grbTimKiemKM";
            this.grbTimKiemKM.Size = new System.Drawing.Size(794, 84);
            this.grbTimKiemKM.TabIndex = 3;
            this.grbTimKiemKM.TabStop = false;
            this.grbTimKiemKM.Text = "Tìm kiếm mặt hàng khuyến mãi";
            this.grbTimKiemKM.Enter += new System.EventHandler(this.grbTimKiemKM_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(222, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Thời gian khuyến mãi:";
            // 
            // dtpDen
            // 
            this.dtpDen.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDen.Location = new System.Drawing.Point(550, 17);
            this.dtpDen.Name = "dtpDen";
            this.dtpDen.Size = new System.Drawing.Size(107, 21);
            this.dtpDen.TabIndex = 6;
            // 
            // dtpTu
            // 
            this.dtpTu.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTu.Location = new System.Drawing.Point(386, 16);
            this.dtpTu.Name = "dtpTu";
            this.dtpTu.Size = new System.Drawing.Size(107, 21);
            this.dtpTu.TabIndex = 6;
            // 
            // txtMaHang
            // 
            this.txtMaHang.Location = new System.Drawing.Point(83, 50);
            this.txtMaHang.Name = "txtMaHang";
            this.txtMaHang.Size = new System.Drawing.Size(119, 21);
            this.txtMaHang.TabIndex = 5;
            // 
            // cboTenHang
            // 
            this.cboTenHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTenHang.FormattingEnabled = true;
            this.cboTenHang.Location = new System.Drawing.Point(287, 48);
            this.cboTenHang.Name = "cboTenHang";
            this.cboTenHang.Size = new System.Drawing.Size(206, 23);
            this.cboTenHang.TabIndex = 3;
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTimKiem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Find;
            this.btnTimKiem.Location = new System.Drawing.Point(690, 19);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(65, 54);
            this.btnTimKiem.TabIndex = 2;
            this.btnTimKiem.UseVisualStyleBackColor = true;
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);
            // 
            // lblTenHang
            // 
            this.lblTenHang.AutoSize = true;
            this.lblTenHang.Location = new System.Drawing.Point(222, 52);
            this.lblTenHang.Name = "lblTenHang";
            this.lblTenHang.Size = new System.Drawing.Size(59, 15);
            this.lblTenHang.TabIndex = 0;
            this.lblTenHang.Text = "Tên hàng";
            // 
            // lblMaHang
            // 
            this.lblMaHang.AutoSize = true;
            this.lblMaHang.Location = new System.Drawing.Point(25, 54);
            this.lblMaHang.Name = "lblMaHang";
            this.lblMaHang.Size = new System.Drawing.Size(55, 15);
            this.lblMaHang.TabIndex = 0;
            this.lblMaHang.Text = "Mã hàng";
            // 
            // grbMatHangKM
            // 
            this.grbMatHangKM.Controls.Add(this.dataGridView1);
            this.grbMatHangKM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbMatHangKM.Location = new System.Drawing.Point(3, 93);
            this.grbMatHangKM.Name = "grbMatHangKM";
            this.grbMatHangKM.Size = new System.Drawing.Size(794, 404);
            this.grbMatHangKM.TabIndex = 2;
            this.grbMatHangKM.TabStop = false;
            this.grbMatHangKM.Text = "Mặt hàng khuyến mãi ";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.LoaiKM,
            this.NgayAD,
            this.NgayHetKM});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 16);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(788, 385);
            this.dataGridView1.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // LoaiKM
            // 
            this.LoaiKM.HeaderText = "Loại KM";
            this.LoaiKM.Name = "LoaiKM";
            // 
            // NgayAD
            // 
            this.NgayAD.HeaderText = "Ngày áp dụng";
            this.NgayAD.Name = "NgayAD";
            // 
            // NgayHetKM
            // 
            this.NgayHetKM.HeaderText = "Ngày hết áp dụng";
            this.NgayHetKM.Name = "NgayHetKM";
            // 
            // tblMatHangKM
            // 
            this.tblMatHangKM.ColumnCount = 1;
            this.tblMatHangKM.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblMatHangKM.Controls.Add(this.grbMatHangKM, 0, 1);
            this.tblMatHangKM.Controls.Add(this.grbTimKiemKM, 0, 0);
            this.tblMatHangKM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblMatHangKM.Location = new System.Drawing.Point(0, 0);
            this.tblMatHangKM.Name = "tblMatHangKM";
            this.tblMatHangKM.RowCount = 2;
            this.tblMatHangKM.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tblMatHangKM.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 82F));
            this.tblMatHangKM.Size = new System.Drawing.Size(800, 500);
            this.tblMatHangKM.TabIndex = 4;
            // 
            // ucMatHangKM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblMatHangKM);
            this.Name = "ucMatHangKM";
            this.Size = new System.Drawing.Size(800, 500);
            this.grbTimKiemKM.ResumeLayout(false);
            this.grbTimKiemKM.PerformLayout();
            this.grbMatHangKM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tblMatHangKM.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbTimKiemKM;
        private System.Windows.Forms.ComboBox cboLoaiKM;
        private System.Windows.Forms.Label lblTu;
        private System.Windows.Forms.Label lblDen;
        private System.Windows.Forms.Label lblLoaiKM;
        private System.Windows.Forms.GroupBox grbMatHangKM;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TableLayoutPanel tblMatHangKM;
        private System.Windows.Forms.ComboBox cboTenHang;
        private System.Windows.Forms.Label lblMaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaiKM;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayAD;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayHetKM;
        private System.Windows.Forms.TextBox txtMaHang;
        private System.Windows.Forms.Label lblTenHang;
        private System.Windows.Forms.DateTimePicker dtpDen;
        private System.Windows.Forms.DateTimePicker dtpTu;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.Label label1;

    }
}
