﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace quan_ly_ban_hang_sieu_thi
{
    class newForm
    {
        private string tenForm = "";
        private string tieuDe = "";
        private int count=1;
        public newForm()
        {
            this.tenForm = "frmForm" + count;
            this.tieuDe = "frmForm" + count;
            this.count++;
        }
        public newForm(string tenForm, string tieuDe)
        {
            this.tenForm = tenForm;
            this.tieuDe = tieuDe;
        }
        public void taoForm(UserControl content)
        {
            TagForm frm = new TagForm();
            frm.Name = tenForm;
            frm.Text = tieuDe;
            frm.Controls.Add(content);
            frm.ShowDialog();
        }


      
    }
}
