﻿namespace quan_ly_ban_hang_sieu_thi.Presentation_Layer
{
    partial class ucThongKeXuatNhap
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbplThongKeNhapXuat = new System.Windows.Forms.TableLayoutPanel();
            this.grbChiTietThongKe = new System.Windows.Forms.GroupBox();
            this.btnXemThongKe = new System.Windows.Forms.Button();
            this.btnXuatBaoCao = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.raDatHang = new System.Windows.Forms.RadioButton();
            this.raNhapVao = new System.Windows.Forms.RadioButton();
            this.raBanLe = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.btnTang = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThoiGianThongKe = new System.Windows.Forms.GroupBox();
            this.raXemTheoNgay = new System.Windows.Forms.RadioButton();
            this.raXemTheoThang = new System.Windows.Forms.RadioButton();
            this.grbXemTheoNgay = new System.Windows.Forms.GroupBox();
            this.mtxtDenNgay = new System.Windows.Forms.MaskedTextBox();
            this.lblTuNgay = new System.Windows.Forms.Label();
            this.mtxtTuNgay = new System.Windows.Forms.MaskedTextBox();
            this.lblDenNgay = new System.Windows.Forms.Label();
            this.grbXemTheoThang = new System.Windows.Forms.GroupBox();
            this.mtxtDenThang = new System.Windows.Forms.MaskedTextBox();
            this.lblTuThang = new System.Windows.Forms.Label();
            this.mtxtTuThang = new System.Windows.Forms.MaskedTextBox();
            this.lblDenThang = new System.Windows.Forms.Label();
            this.picbThongKeHangHoa = new System.Windows.Forms.PictureBox();
            this.tbplThongKeNhapXuat.SuspendLayout();
            this.grbChiTietThongKe.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.grbThoiGianThongKe.SuspendLayout();
            this.grbXemTheoNgay.SuspendLayout();
            this.grbXemTheoThang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbThongKeHangHoa)).BeginInit();
            this.SuspendLayout();
            // 
            // tbplThongKeNhapXuat
            // 
            this.tbplThongKeNhapXuat.ColumnCount = 1;
            this.tbplThongKeNhapXuat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbplThongKeNhapXuat.Controls.Add(this.grbChiTietThongKe, 0, 1);
            this.tbplThongKeNhapXuat.Controls.Add(this.grbThoiGianThongKe, 0, 0);
            this.tbplThongKeNhapXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplThongKeNhapXuat.Location = new System.Drawing.Point(0, 0);
            this.tbplThongKeNhapXuat.Name = "tbplThongKeNhapXuat";
            this.tbplThongKeNhapXuat.RowCount = 2;
            this.tbplThongKeNhapXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.0885F));
            this.tbplThongKeNhapXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 69.91151F));
            this.tbplThongKeNhapXuat.Size = new System.Drawing.Size(800, 522);
            this.tbplThongKeNhapXuat.TabIndex = 0;
            // 
            // grbChiTietThongKe
            // 
            this.grbChiTietThongKe.Controls.Add(this.btnXemThongKe);
            this.grbChiTietThongKe.Controls.Add(this.btnXuatBaoCao);
            this.grbChiTietThongKe.Controls.Add(this.groupBox3);
            this.grbChiTietThongKe.Controls.Add(this.button2);
            this.grbChiTietThongKe.Controls.Add(this.btnTang);
            this.grbChiTietThongKe.Controls.Add(this.dataGridView1);
            this.grbChiTietThongKe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietThongKe.Location = new System.Drawing.Point(3, 160);
            this.grbChiTietThongKe.Name = "grbChiTietThongKe";
            this.grbChiTietThongKe.Size = new System.Drawing.Size(794, 359);
            this.grbChiTietThongKe.TabIndex = 0;
            this.grbChiTietThongKe.TabStop = false;
            this.grbChiTietThongKe.Text = "Chi tiết thống kê";
            // 
            // btnXemThongKe
            // 
            this.btnXemThongKe.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemThongKe.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Yes;
            this.btnXemThongKe.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXemThongKe.Location = new System.Drawing.Point(43, 193);
            this.btnXemThongKe.Name = "btnXemThongKe";
            this.btnXemThongKe.Size = new System.Drawing.Size(115, 47);
            this.btnXemThongKe.TabIndex = 6;
            this.btnXemThongKe.Text = "Xem thống kê";
            this.btnXemThongKe.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXemThongKe.UseVisualStyleBackColor = true;
            this.btnXemThongKe.Click += new System.EventHandler(this.btnXuatBaoCao_Click);
            // 
            // btnXuatBaoCao
            // 
            this.btnXuatBaoCao.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatBaoCao.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Notes;
            this.btnXuatBaoCao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXuatBaoCao.Location = new System.Drawing.Point(43, 246);
            this.btnXuatBaoCao.Name = "btnXuatBaoCao";
            this.btnXuatBaoCao.Size = new System.Drawing.Size(115, 47);
            this.btnXuatBaoCao.TabIndex = 6;
            this.btnXuatBaoCao.Text = "Xuất báo cáo";
            this.btnXuatBaoCao.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXuatBaoCao.UseVisualStyleBackColor = true;
            this.btnXuatBaoCao.Click += new System.EventHandler(this.btnXuatBaoCao_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox3.Controls.Add(this.raDatHang);
            this.groupBox3.Controls.Add(this.raNhapVao);
            this.groupBox3.Controls.Add(this.raBanLe);
            this.groupBox3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(38, 29);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(115, 151);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tùy chọn";
            // 
            // raDatHang
            // 
            this.raDatHang.AutoSize = true;
            this.raDatHang.Location = new System.Drawing.Point(25, 111);
            this.raDatHang.Name = "raDatHang";
            this.raDatHang.Size = new System.Drawing.Size(76, 19);
            this.raDatHang.TabIndex = 3;
            this.raDatHang.TabStop = true;
            this.raDatHang.Text = "Đặt hàng";
            this.raDatHang.UseVisualStyleBackColor = true;
            // 
            // raNhapVao
            // 
            this.raNhapVao.AutoSize = true;
            this.raNhapVao.Location = new System.Drawing.Point(25, 72);
            this.raNhapVao.Name = "raNhapVao";
            this.raNhapVao.Size = new System.Drawing.Size(77, 19);
            this.raNhapVao.TabIndex = 2;
            this.raNhapVao.TabStop = true;
            this.raNhapVao.Text = "Nhập vào";
            this.raNhapVao.UseVisualStyleBackColor = true;
            // 
            // raBanLe
            // 
            this.raBanLe.AutoSize = true;
            this.raBanLe.Location = new System.Drawing.Point(25, 33);
            this.raBanLe.Name = "raBanLe";
            this.raBanLe.Size = new System.Drawing.Size(60, 19);
            this.raBanLe.TabIndex = 1;
            this.raBanLe.TabStop = true;
            this.raBanLe.Text = "Bán lẻ";
            this.raBanLe.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Fall;
            this.button2.Location = new System.Drawing.Point(176, 81);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(35, 35);
            this.button2.TabIndex = 4;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // btnTang
            // 
            this.btnTang.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Raise;
            this.btnTang.Location = new System.Drawing.Point(176, 40);
            this.btnTang.Name = "btnTang";
            this.btnTang.Size = new System.Drawing.Size(35, 35);
            this.btnTang.TabIndex = 4;
            this.btnTang.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.SoLuong});
            this.dataGridView1.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dataGridView1.Location = new System.Drawing.Point(217, 19);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(571, 321);
            this.dataGridView1.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            this.MaHang.ReadOnly = true;
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            this.TenHang.ReadOnly = true;
            // 
            // SoLuong
            // 
            this.SoLuong.HeaderText = "Số lượng";
            this.SoLuong.Name = "SoLuong";
            this.SoLuong.ReadOnly = true;
            // 
            // grbThoiGianThongKe
            // 
            this.grbThoiGianThongKe.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.grbThoiGianThongKe.Controls.Add(this.raXemTheoNgay);
            this.grbThoiGianThongKe.Controls.Add(this.raXemTheoThang);
            this.grbThoiGianThongKe.Controls.Add(this.grbXemTheoNgay);
            this.grbThoiGianThongKe.Controls.Add(this.grbXemTheoThang);
            this.grbThoiGianThongKe.Controls.Add(this.picbThongKeHangHoa);
            this.grbThoiGianThongKe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThoiGianThongKe.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThoiGianThongKe.Location = new System.Drawing.Point(3, 3);
            this.grbThoiGianThongKe.Name = "grbThoiGianThongKe";
            this.grbThoiGianThongKe.Size = new System.Drawing.Size(794, 151);
            this.grbThoiGianThongKe.TabIndex = 1;
            this.grbThoiGianThongKe.TabStop = false;
            this.grbThoiGianThongKe.Text = "Thời gian thống kê";
            // 
            // raXemTheoNgay
            // 
            this.raXemTheoNgay.AutoSize = true;
            this.raXemTheoNgay.Location = new System.Drawing.Point(261, 20);
            this.raXemTheoNgay.Name = "raXemTheoNgay";
            this.raXemTheoNgay.Size = new System.Drawing.Size(109, 19);
            this.raXemTheoNgay.TabIndex = 6;
            this.raXemTheoNgay.TabStop = true;
            this.raXemTheoNgay.Text = "Xem theo ngày";
            this.raXemTheoNgay.UseVisualStyleBackColor = true;
            this.raXemTheoNgay.CheckedChanged += new System.EventHandler(this.raXemTheoNgay_CheckedChanged);
            // 
            // raXemTheoThang
            // 
            this.raXemTheoThang.AutoSize = true;
            this.raXemTheoThang.Location = new System.Drawing.Point(22, 20);
            this.raXemTheoThang.Name = "raXemTheoThang";
            this.raXemTheoThang.Size = new System.Drawing.Size(114, 19);
            this.raXemTheoThang.TabIndex = 6;
            this.raXemTheoThang.TabStop = true;
            this.raXemTheoThang.Text = "Xem theo tháng";
            this.raXemTheoThang.UseVisualStyleBackColor = true;
            this.raXemTheoThang.CheckedChanged += new System.EventHandler(this.raXemTheoThang_CheckedChanged);
            // 
            // grbXemTheoNgay
            // 
            this.grbXemTheoNgay.Controls.Add(this.mtxtDenNgay);
            this.grbXemTheoNgay.Controls.Add(this.lblTuNgay);
            this.grbXemTheoNgay.Controls.Add(this.mtxtTuNgay);
            this.grbXemTheoNgay.Controls.Add(this.lblDenNgay);
            this.grbXemTheoNgay.Location = new System.Drawing.Point(261, 36);
            this.grbXemTheoNgay.Name = "grbXemTheoNgay";
            this.grbXemTheoNgay.Size = new System.Drawing.Size(234, 92);
            this.grbXemTheoNgay.TabIndex = 5;
            this.grbXemTheoNgay.TabStop = false;
            // 
            // mtxtDenNgay
            // 
            this.mtxtDenNgay.Location = new System.Drawing.Point(94, 54);
            this.mtxtDenNgay.Mask = "00/00/0000";
            this.mtxtDenNgay.Name = "mtxtDenNgay";
            this.mtxtDenNgay.Size = new System.Drawing.Size(103, 21);
            this.mtxtDenNgay.TabIndex = 3;
            this.mtxtDenNgay.ValidatingType = typeof(System.DateTime);
            // 
            // lblTuNgay
            // 
            this.lblTuNgay.AutoSize = true;
            this.lblTuNgay.Location = new System.Drawing.Point(35, 27);
            this.lblTuNgay.Name = "lblTuNgay";
            this.lblTuNgay.Size = new System.Drawing.Size(53, 15);
            this.lblTuNgay.TabIndex = 0;
            this.lblTuNgay.Text = "Từ ngày";
            // 
            // mtxtTuNgay
            // 
            this.mtxtTuNgay.Location = new System.Drawing.Point(94, 26);
            this.mtxtTuNgay.Mask = "00/00/0000";
            this.mtxtTuNgay.Name = "mtxtTuNgay";
            this.mtxtTuNgay.Size = new System.Drawing.Size(103, 21);
            this.mtxtTuNgay.TabIndex = 3;
            this.mtxtTuNgay.ValidatingType = typeof(System.DateTime);
            // 
            // lblDenNgay
            // 
            this.lblDenNgay.AutoSize = true;
            this.lblDenNgay.Location = new System.Drawing.Point(28, 58);
            this.lblDenNgay.Name = "lblDenNgay";
            this.lblDenNgay.Size = new System.Drawing.Size(60, 15);
            this.lblDenNgay.TabIndex = 0;
            this.lblDenNgay.Text = "Đến ngày";
            // 
            // grbXemTheoThang
            // 
            this.grbXemTheoThang.Controls.Add(this.mtxtDenThang);
            this.grbXemTheoThang.Controls.Add(this.lblTuThang);
            this.grbXemTheoThang.Controls.Add(this.mtxtTuThang);
            this.grbXemTheoThang.Controls.Add(this.lblDenThang);
            this.grbXemTheoThang.Location = new System.Drawing.Point(21, 36);
            this.grbXemTheoThang.Name = "grbXemTheoThang";
            this.grbXemTheoThang.Size = new System.Drawing.Size(234, 92);
            this.grbXemTheoThang.TabIndex = 4;
            this.grbXemTheoThang.TabStop = false;
            // 
            // mtxtDenThang
            // 
            this.mtxtDenThang.Location = new System.Drawing.Point(90, 52);
            this.mtxtDenThang.Mask = "00/0000";
            this.mtxtDenThang.Name = "mtxtDenThang";
            this.mtxtDenThang.Size = new System.Drawing.Size(104, 21);
            this.mtxtDenThang.TabIndex = 3;
            // 
            // lblTuThang
            // 
            this.lblTuThang.AutoSize = true;
            this.lblTuThang.Location = new System.Drawing.Point(26, 24);
            this.lblTuThang.Name = "lblTuThang";
            this.lblTuThang.Size = new System.Drawing.Size(58, 15);
            this.lblTuThang.TabIndex = 0;
            this.lblTuThang.Text = "Từ tháng";
            // 
            // mtxtTuThang
            // 
            this.mtxtTuThang.Location = new System.Drawing.Point(90, 24);
            this.mtxtTuThang.Mask = "00/0000";
            this.mtxtTuThang.Name = "mtxtTuThang";
            this.mtxtTuThang.Size = new System.Drawing.Size(104, 21);
            this.mtxtTuThang.TabIndex = 3;
            // 
            // lblDenThang
            // 
            this.lblDenThang.AutoSize = true;
            this.lblDenThang.Location = new System.Drawing.Point(19, 55);
            this.lblDenThang.Name = "lblDenThang";
            this.lblDenThang.Size = new System.Drawing.Size(65, 15);
            this.lblDenThang.TabIndex = 0;
            this.lblDenThang.Text = "Đến tháng";
            // 
            // picbThongKeHangHoa
            // 
            this.picbThongKeHangHoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.statistics;
            this.picbThongKeHangHoa.InitialImage = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.statistics;
            this.picbThongKeHangHoa.Location = new System.Drawing.Point(612, 14);
            this.picbThongKeHangHoa.Name = "picbThongKeHangHoa";
            this.picbThongKeHangHoa.Size = new System.Drawing.Size(166, 131);
            this.picbThongKeHangHoa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picbThongKeHangHoa.TabIndex = 2;
            this.picbThongKeHangHoa.TabStop = false;
            // 
            // ucThongKeXuatNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbplThongKeNhapXuat);
            this.Name = "ucThongKeXuatNhap";
            this.Size = new System.Drawing.Size(800, 522);
            this.tbplThongKeNhapXuat.ResumeLayout(false);
            this.grbChiTietThongKe.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.grbThoiGianThongKe.ResumeLayout(false);
            this.grbThoiGianThongKe.PerformLayout();
            this.grbXemTheoNgay.ResumeLayout(false);
            this.grbXemTheoNgay.PerformLayout();
            this.grbXemTheoThang.ResumeLayout(false);
            this.grbXemTheoThang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbThongKeHangHoa)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tbplThongKeNhapXuat;
        private System.Windows.Forms.GroupBox grbChiTietThongKe;
        private System.Windows.Forms.Button btnXuatBaoCao;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton raDatHang;
        private System.Windows.Forms.RadioButton raNhapVao;
        private System.Windows.Forms.RadioButton raBanLe;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnTang;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox grbThoiGianThongKe;
        private System.Windows.Forms.PictureBox picbThongKeHangHoa;
        private System.Windows.Forms.GroupBox grbXemTheoThang;
        private System.Windows.Forms.MaskedTextBox mtxtDenThang;
        private System.Windows.Forms.Label lblTuThang;
        private System.Windows.Forms.MaskedTextBox mtxtTuThang;
        private System.Windows.Forms.Label lblDenThang;
        private System.Windows.Forms.GroupBox grbXemTheoNgay;
        private System.Windows.Forms.MaskedTextBox mtxtDenNgay;
        private System.Windows.Forms.Label lblTuNgay;
        private System.Windows.Forms.MaskedTextBox mtxtTuNgay;
        private System.Windows.Forms.Label lblDenNgay;
        private System.Windows.Forms.RadioButton raXemTheoNgay;
        private System.Windows.Forms.RadioButton raXemTheoThang;
        private System.Windows.Forms.Button btnXemThongKe;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuong;
    }
}
