﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucDoanhThuThoiGian
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl = new System.Windows.Forms.Panel();
            this.grbCacLuaChon = new System.Windows.Forms.GroupBox();
            this.tblHoidap = new System.Windows.Forms.TableLayoutPanel();
            this.pnlXemTheoThang = new System.Windows.Forms.Panel();
            this.grbXemTheoThang = new System.Windows.Forms.GroupBox();
            this.mtxtDenThang = new System.Windows.Forms.MaskedTextBox();
            this.lblTuThang = new System.Windows.Forms.Label();
            this.mtxtTuThang = new System.Windows.Forms.MaskedTextBox();
            this.lblDenThang = new System.Windows.Forms.Label();
            this.raXemTheoThang = new System.Windows.Forms.RadioButton();
            this.pnlXemTheoNgay = new System.Windows.Forms.Panel();
            this.grbXemTheoNgay = new System.Windows.Forms.GroupBox();
            this.mtxtDenNgay = new System.Windows.Forms.MaskedTextBox();
            this.lblTuNgay = new System.Windows.Forms.Label();
            this.mtxtTuNgay = new System.Windows.Forms.MaskedTextBox();
            this.lblDenNgay = new System.Windows.Forms.Label();
            this.raXemTheoNgay = new System.Windows.Forms.RadioButton();
            this.pnlCacTuyChon = new System.Windows.Forms.Panel();
            this.raTongDT = new System.Windows.Forms.RadioButton();
            this.raDTBanLe = new System.Windows.Forms.RadioButton();
            this.raDoanhThuBanSi = new System.Windows.Forms.RadioButton();
            this.pnlCacNut = new System.Windows.Forms.Panel();
            this.btnXuatBaoCao = new System.Windows.Forms.Button();
            this.btnXemTheoThang = new System.Windows.Forms.Button();
            this.tbplDoanhThu = new System.Windows.Forms.TableLayoutPanel();
            this.tlpChiTietDoanhthu = new System.Windows.Forms.TableLayoutPanel();
            this.dgvXemTheoNgay = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvXemTheoThang = new System.Windows.Forms.DataGridView();
            this.Nam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DoanhThu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnl.SuspendLayout();
            this.grbCacLuaChon.SuspendLayout();
            this.tblHoidap.SuspendLayout();
            this.pnlXemTheoThang.SuspendLayout();
            this.grbXemTheoThang.SuspendLayout();
            this.pnlXemTheoNgay.SuspendLayout();
            this.grbXemTheoNgay.SuspendLayout();
            this.pnlCacTuyChon.SuspendLayout();
            this.pnlCacNut.SuspendLayout();
            this.tbplDoanhThu.SuspendLayout();
            this.tlpChiTietDoanhthu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXemTheoNgay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXemTheoThang)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl
            // 
            this.pnl.Controls.Add(this.grbCacLuaChon);
            this.pnl.Controls.Add(this.tbplDoanhThu);
            this.pnl.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl.Location = new System.Drawing.Point(0, 1);
            this.pnl.Name = "pnl";
            this.pnl.Size = new System.Drawing.Size(803, 508);
            this.pnl.TabIndex = 0;
            // 
            // grbCacLuaChon
            // 
            this.grbCacLuaChon.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.grbCacLuaChon.Controls.Add(this.tblHoidap);
            this.grbCacLuaChon.Dock = System.Windows.Forms.DockStyle.Top;
            this.grbCacLuaChon.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbCacLuaChon.Location = new System.Drawing.Point(0, 0);
            this.grbCacLuaChon.Name = "grbCacLuaChon";
            this.grbCacLuaChon.Size = new System.Drawing.Size(803, 139);
            this.grbCacLuaChon.TabIndex = 0;
            this.grbCacLuaChon.TabStop = false;
            this.grbCacLuaChon.Text = "Tùy chọn xem doanh thu";
            // 
            // tblHoidap
            // 
            this.tblHoidap.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tblHoidap.ColumnCount = 4;
            this.tblHoidap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.76723F));
            this.tblHoidap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.69832F));
            this.tblHoidap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.76723F));
            this.tblHoidap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.76723F));
            this.tblHoidap.Controls.Add(this.pnlXemTheoThang, 0, 0);
            this.tblHoidap.Controls.Add(this.pnlXemTheoNgay, 1, 0);
            this.tblHoidap.Controls.Add(this.pnlCacTuyChon, 2, 0);
            this.tblHoidap.Controls.Add(this.pnlCacNut, 3, 0);
            this.tblHoidap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblHoidap.Location = new System.Drawing.Point(3, 17);
            this.tblHoidap.Name = "tblHoidap";
            this.tblHoidap.RowCount = 1;
            this.tblHoidap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblHoidap.Size = new System.Drawing.Size(797, 119);
            this.tblHoidap.TabIndex = 0;
            // 
            // pnlXemTheoThang
            // 
            this.pnlXemTheoThang.Controls.Add(this.grbXemTheoThang);
            this.pnlXemTheoThang.Controls.Add(this.raXemTheoThang);
            this.pnlXemTheoThang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlXemTheoThang.Location = new System.Drawing.Point(6, 6);
            this.pnlXemTheoThang.Name = "pnlXemTheoThang";
            this.pnlXemTheoThang.Size = new System.Drawing.Size(187, 107);
            this.pnlXemTheoThang.TabIndex = 3;
            // 
            // grbXemTheoThang
            // 
            this.grbXemTheoThang.Controls.Add(this.mtxtDenThang);
            this.grbXemTheoThang.Controls.Add(this.lblTuThang);
            this.grbXemTheoThang.Controls.Add(this.mtxtTuThang);
            this.grbXemTheoThang.Controls.Add(this.lblDenThang);
            this.grbXemTheoThang.Location = new System.Drawing.Point(5, 29);
            this.grbXemTheoThang.Name = "grbXemTheoThang";
            this.grbXemTheoThang.Size = new System.Drawing.Size(166, 74);
            this.grbXemTheoThang.TabIndex = 0;
            this.grbXemTheoThang.TabStop = false;
            // 
            // mtxtDenThang
            // 
            this.mtxtDenThang.Location = new System.Drawing.Point(68, 43);
            this.mtxtDenThang.Mask = "00/0000";
            this.mtxtDenThang.Name = "mtxtDenThang";
            this.mtxtDenThang.Size = new System.Drawing.Size(86, 21);
            this.mtxtDenThang.TabIndex = 1;
            // 
            // lblTuThang
            // 
            this.lblTuThang.AutoSize = true;
            this.lblTuThang.Location = new System.Drawing.Point(9, 15);
            this.lblTuThang.Name = "lblTuThang";
            this.lblTuThang.Size = new System.Drawing.Size(58, 15);
            this.lblTuThang.TabIndex = 0;
            this.lblTuThang.Text = "Từ tháng";
            // 
            // mtxtTuThang
            // 
            this.mtxtTuThang.Location = new System.Drawing.Point(68, 15);
            this.mtxtTuThang.Mask = "00/0000";
            this.mtxtTuThang.Name = "mtxtTuThang";
            this.mtxtTuThang.Size = new System.Drawing.Size(86, 21);
            this.mtxtTuThang.TabIndex = 0;
            // 
            // lblDenThang
            // 
            this.lblDenThang.AutoSize = true;
            this.lblDenThang.Location = new System.Drawing.Point(2, 46);
            this.lblDenThang.Name = "lblDenThang";
            this.lblDenThang.Size = new System.Drawing.Size(65, 15);
            this.lblDenThang.TabIndex = 0;
            this.lblDenThang.Text = "Đến tháng";
            // 
            // raXemTheoThang
            // 
            this.raXemTheoThang.AutoSize = true;
            this.raXemTheoThang.Checked = true;
            this.raXemTheoThang.Location = new System.Drawing.Point(5, 10);
            this.raXemTheoThang.Name = "raXemTheoThang";
            this.raXemTheoThang.Size = new System.Drawing.Size(114, 19);
            this.raXemTheoThang.TabIndex = 0;
            this.raXemTheoThang.TabStop = true;
            this.raXemTheoThang.Text = "Xem theo tháng";
            this.raXemTheoThang.UseVisualStyleBackColor = true;
            // 
            // pnlXemTheoNgay
            // 
            this.pnlXemTheoNgay.Controls.Add(this.grbXemTheoNgay);
            this.pnlXemTheoNgay.Controls.Add(this.raXemTheoNgay);
            this.pnlXemTheoNgay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlXemTheoNgay.Location = new System.Drawing.Point(202, 6);
            this.pnlXemTheoNgay.Name = "pnlXemTheoNgay";
            this.pnlXemTheoNgay.Size = new System.Drawing.Size(194, 107);
            this.pnlXemTheoNgay.TabIndex = 0;
            // 
            // grbXemTheoNgay
            // 
            this.grbXemTheoNgay.Controls.Add(this.mtxtDenNgay);
            this.grbXemTheoNgay.Controls.Add(this.lblTuNgay);
            this.grbXemTheoNgay.Controls.Add(this.mtxtTuNgay);
            this.grbXemTheoNgay.Controls.Add(this.lblDenNgay);
            this.grbXemTheoNgay.Location = new System.Drawing.Point(9, 35);
            this.grbXemTheoNgay.Name = "grbXemTheoNgay";
            this.grbXemTheoNgay.Size = new System.Drawing.Size(158, 68);
            this.grbXemTheoNgay.TabIndex = 1;
            this.grbXemTheoNgay.TabStop = false;
            // 
            // mtxtDenNgay
            // 
            this.mtxtDenNgay.Location = new System.Drawing.Point(67, 40);
            this.mtxtDenNgay.Mask = "00/00/0000";
            this.mtxtDenNgay.Name = "mtxtDenNgay";
            this.mtxtDenNgay.Size = new System.Drawing.Size(79, 21);
            this.mtxtDenNgay.TabIndex = 1;
            this.mtxtDenNgay.ValidatingType = typeof(System.DateTime);
            // 
            // lblTuNgay
            // 
            this.lblTuNgay.AutoSize = true;
            this.lblTuNgay.Location = new System.Drawing.Point(13, 14);
            this.lblTuNgay.Name = "lblTuNgay";
            this.lblTuNgay.Size = new System.Drawing.Size(53, 15);
            this.lblTuNgay.TabIndex = 0;
            this.lblTuNgay.Text = "Từ ngày";
            // 
            // mtxtTuNgay
            // 
            this.mtxtTuNgay.Location = new System.Drawing.Point(67, 12);
            this.mtxtTuNgay.Mask = "00/00/0000";
            this.mtxtTuNgay.Name = "mtxtTuNgay";
            this.mtxtTuNgay.Size = new System.Drawing.Size(79, 21);
            this.mtxtTuNgay.TabIndex = 0;
            this.mtxtTuNgay.ValidatingType = typeof(System.DateTime);
            // 
            // lblDenNgay
            // 
            this.lblDenNgay.AutoSize = true;
            this.lblDenNgay.Location = new System.Drawing.Point(6, 45);
            this.lblDenNgay.Name = "lblDenNgay";
            this.lblDenNgay.Size = new System.Drawing.Size(60, 15);
            this.lblDenNgay.TabIndex = 0;
            this.lblDenNgay.Text = "Đến ngày";
            // 
            // raXemTheoNgay
            // 
            this.raXemTheoNgay.AutoSize = true;
            this.raXemTheoNgay.Location = new System.Drawing.Point(19, 10);
            this.raXemTheoNgay.Name = "raXemTheoNgay";
            this.raXemTheoNgay.Size = new System.Drawing.Size(109, 19);
            this.raXemTheoNgay.TabIndex = 0;
            this.raXemTheoNgay.TabStop = true;
            this.raXemTheoNgay.Text = "Xem theo ngày";
            this.raXemTheoNgay.UseVisualStyleBackColor = true;
            // 
            // pnlCacTuyChon
            // 
            this.pnlCacTuyChon.Controls.Add(this.raTongDT);
            this.pnlCacTuyChon.Controls.Add(this.raDTBanLe);
            this.pnlCacTuyChon.Controls.Add(this.raDoanhThuBanSi);
            this.pnlCacTuyChon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCacTuyChon.Location = new System.Drawing.Point(405, 6);
            this.pnlCacTuyChon.Name = "pnlCacTuyChon";
            this.pnlCacTuyChon.Size = new System.Drawing.Size(187, 107);
            this.pnlCacTuyChon.TabIndex = 2;
            // 
            // raTongDT
            // 
            this.raTongDT.AutoSize = true;
            this.raTongDT.Checked = true;
            this.raTongDT.Location = new System.Drawing.Point(26, 67);
            this.raTongDT.Name = "raTongDT";
            this.raTongDT.Size = new System.Drawing.Size(112, 19);
            this.raTongDT.TabIndex = 2;
            this.raTongDT.TabStop = true;
            this.raTongDT.Text = "Tổng doanh thu";
            this.raTongDT.UseVisualStyleBackColor = true;
            // 
            // raDTBanLe
            // 
            this.raDTBanLe.AutoSize = true;
            this.raDTBanLe.Location = new System.Drawing.Point(26, 10);
            this.raDTBanLe.Name = "raDTBanLe";
            this.raDTBanLe.Size = new System.Drawing.Size(119, 19);
            this.raDTBanLe.TabIndex = 0;
            this.raDTBanLe.Text = "Doanh thu bán lẻ";
            this.raDTBanLe.UseVisualStyleBackColor = true;
            // 
            // raDoanhThuBanSi
            // 
            this.raDoanhThuBanSi.AutoSize = true;
            this.raDoanhThuBanSi.Location = new System.Drawing.Point(26, 39);
            this.raDoanhThuBanSi.Name = "raDoanhThuBanSi";
            this.raDoanhThuBanSi.Size = new System.Drawing.Size(119, 19);
            this.raDoanhThuBanSi.TabIndex = 1;
            this.raDoanhThuBanSi.Text = "Doanh thu bán sỉ";
            this.raDoanhThuBanSi.UseVisualStyleBackColor = true;
            // 
            // pnlCacNut
            // 
            this.pnlCacNut.Controls.Add(this.btnXuatBaoCao);
            this.pnlCacNut.Controls.Add(this.btnXemTheoThang);
            this.pnlCacNut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCacNut.Location = new System.Drawing.Point(601, 6);
            this.pnlCacNut.Name = "pnlCacNut";
            this.pnlCacNut.Size = new System.Drawing.Size(190, 107);
            this.pnlCacNut.TabIndex = 3;
            // 
            // btnXuatBaoCao
            // 
            this.btnXuatBaoCao.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatBaoCao.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Notes;
            this.btnXuatBaoCao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXuatBaoCao.Location = new System.Drawing.Point(17, 49);
            this.btnXuatBaoCao.Name = "btnXuatBaoCao";
            this.btnXuatBaoCao.Size = new System.Drawing.Size(113, 39);
            this.btnXuatBaoCao.TabIndex = 1;
            this.btnXuatBaoCao.Text = "Xuất báo cáo";
            this.btnXuatBaoCao.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXuatBaoCao.UseVisualStyleBackColor = true;
            // 
            // btnXemTheoThang
            // 
            this.btnXemTheoThang.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Yes;
            this.btnXemTheoThang.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXemTheoThang.Location = new System.Drawing.Point(17, 10);
            this.btnXemTheoThang.Name = "btnXemTheoThang";
            this.btnXemTheoThang.Size = new System.Drawing.Size(73, 36);
            this.btnXemTheoThang.TabIndex = 0;
            this.btnXemTheoThang.Text = "Xem";
            this.btnXemTheoThang.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXemTheoThang.UseVisualStyleBackColor = true;
            // 
            // tbplDoanhThu
            // 
            this.tbplDoanhThu.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tbplDoanhThu.ColumnCount = 2;
            this.tbplDoanhThu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.375F));
            this.tbplDoanhThu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.625F));
            this.tbplDoanhThu.Controls.Add(this.tlpChiTietDoanhthu, 0, 0);
            this.tbplDoanhThu.Controls.Add(this.dgvXemTheoThang, 0, 0);
            this.tbplDoanhThu.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbplDoanhThu.Location = new System.Drawing.Point(0, 139);
            this.tbplDoanhThu.Name = "tbplDoanhThu";
            this.tbplDoanhThu.RowCount = 1;
            this.tbplDoanhThu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplDoanhThu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbplDoanhThu.Size = new System.Drawing.Size(803, 369);
            this.tbplDoanhThu.TabIndex = 0;
            // 
            // tlpChiTietDoanhthu
            // 
            this.tlpChiTietDoanhthu.ColumnCount = 1;
            this.tlpChiTietDoanhthu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpChiTietDoanhthu.Controls.Add(this.dgvXemTheoNgay, 0, 0);
            this.tlpChiTietDoanhthu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpChiTietDoanhthu.Location = new System.Drawing.Point(408, 6);
            this.tlpChiTietDoanhthu.Name = "tlpChiTietDoanhthu";
            this.tlpChiTietDoanhthu.RowCount = 1;
            this.tlpChiTietDoanhthu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpChiTietDoanhthu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpChiTietDoanhthu.Size = new System.Drawing.Size(389, 357);
            this.tlpChiTietDoanhthu.TabIndex = 0;
            // 
            // dgvXemTheoNgay
            // 
            this.dgvXemTheoNgay.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvXemTheoNgay.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvXemTheoNgay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvXemTheoNgay.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dgvXemTheoNgay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvXemTheoNgay.Location = new System.Drawing.Point(3, 3);
            this.dgvXemTheoNgay.Name = "dgvXemTheoNgay";
            this.dgvXemTheoNgay.Size = new System.Drawing.Size(383, 351);
            this.dgvXemTheoNgay.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Ngày";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Doanh thu";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dgvXemTheoThang
            // 
            this.dgvXemTheoThang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvXemTheoThang.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvXemTheoThang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvXemTheoThang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Nam,
            this.DoanhThu});
            this.dgvXemTheoThang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvXemTheoThang.Location = new System.Drawing.Point(6, 6);
            this.dgvXemTheoThang.Name = "dgvXemTheoThang";
            this.dgvXemTheoThang.Size = new System.Drawing.Size(393, 357);
            this.dgvXemTheoThang.TabIndex = 1;
            // 
            // Nam
            // 
            this.Nam.HeaderText = "Tháng";
            this.Nam.Name = "Nam";
            // 
            // DoanhThu
            // 
            this.DoanhThu.HeaderText = "Doanh thu";
            this.DoanhThu.Name = "DoanhThu";
            // 
            // ucDoanhThuThoiGian
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.Controls.Add(this.pnl);
            this.Name = "ucDoanhThuThoiGian";
            this.Size = new System.Drawing.Size(803, 509);
            this.pnl.ResumeLayout(false);
            this.grbCacLuaChon.ResumeLayout(false);
            this.tblHoidap.ResumeLayout(false);
            this.pnlXemTheoThang.ResumeLayout(false);
            this.pnlXemTheoThang.PerformLayout();
            this.grbXemTheoThang.ResumeLayout(false);
            this.grbXemTheoThang.PerformLayout();
            this.pnlXemTheoNgay.ResumeLayout(false);
            this.pnlXemTheoNgay.PerformLayout();
            this.grbXemTheoNgay.ResumeLayout(false);
            this.grbXemTheoNgay.PerformLayout();
            this.pnlCacTuyChon.ResumeLayout(false);
            this.pnlCacTuyChon.PerformLayout();
            this.pnlCacNut.ResumeLayout(false);
            this.tbplDoanhThu.ResumeLayout(false);
            this.tlpChiTietDoanhthu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvXemTheoNgay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXemTheoThang)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl;
        private System.Windows.Forms.TableLayoutPanel tbplDoanhThu;
        private System.Windows.Forms.GroupBox grbCacLuaChon;
        private System.Windows.Forms.TableLayoutPanel tblHoidap;
        private System.Windows.Forms.Panel pnlXemTheoThang;
        private System.Windows.Forms.GroupBox grbXemTheoThang;
        private System.Windows.Forms.MaskedTextBox mtxtDenThang;
        private System.Windows.Forms.Label lblTuThang;
        private System.Windows.Forms.MaskedTextBox mtxtTuThang;
        private System.Windows.Forms.Label lblDenThang;
        private System.Windows.Forms.RadioButton raXemTheoThang;
        private System.Windows.Forms.Panel pnlXemTheoNgay;
        private System.Windows.Forms.GroupBox grbXemTheoNgay;
        private System.Windows.Forms.MaskedTextBox mtxtDenNgay;
        private System.Windows.Forms.Label lblTuNgay;
        private System.Windows.Forms.MaskedTextBox mtxtTuNgay;
        private System.Windows.Forms.Label lblDenNgay;
        private System.Windows.Forms.RadioButton raXemTheoNgay;
        private System.Windows.Forms.Panel pnlCacTuyChon;
        private System.Windows.Forms.RadioButton raTongDT;
        private System.Windows.Forms.RadioButton raDTBanLe;
        private System.Windows.Forms.RadioButton raDoanhThuBanSi;
        private System.Windows.Forms.Panel pnlCacNut;
        private System.Windows.Forms.Button btnXuatBaoCao;
        private System.Windows.Forms.Button btnXemTheoThang;
        private System.Windows.Forms.DataGridView dgvXemTheoThang;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nam;
        private System.Windows.Forms.DataGridViewTextBoxColumn DoanhThu;
        private System.Windows.Forms.TableLayoutPanel tlpChiTietDoanhthu;
        private System.Windows.Forms.DataGridView dgvXemTheoNgay;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;

    }
}
