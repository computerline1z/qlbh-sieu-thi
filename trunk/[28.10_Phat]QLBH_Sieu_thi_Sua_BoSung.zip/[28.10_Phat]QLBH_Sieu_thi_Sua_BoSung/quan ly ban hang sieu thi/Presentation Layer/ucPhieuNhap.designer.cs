﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucPhieuNhap
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tpnlPhieuNhap = new System.Windows.Forms.TableLayoutPanel();
            this.grbDanhSachPhieuNhap = new System.Windows.Forms.GroupBox();
            this.dgvDanhSachPhieuNhap = new System.Windows.Forms.DataGridView();
            this.MaPhieu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNCC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NhanVienNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbChiTietPhieuNhap = new System.Windows.Forms.GroupBox();
            this.dgvChiTietPhieuNhap = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpnlPhieuNhap.SuspendLayout();
            this.grbDanhSachPhieuNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachPhieuNhap)).BeginInit();
            this.grbChiTietPhieuNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuNhap)).BeginInit();
            this.SuspendLayout();
            // 
            // tpnlPhieuNhap
            // 
            this.tpnlPhieuNhap.ColumnCount = 1;
            this.tpnlPhieuNhap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tpnlPhieuNhap.Controls.Add(this.grbDanhSachPhieuNhap, 0, 0);
            this.tpnlPhieuNhap.Controls.Add(this.grbChiTietPhieuNhap, 0, 1);
            this.tpnlPhieuNhap.Location = new System.Drawing.Point(0, 0);
            this.tpnlPhieuNhap.Name = "tpnlPhieuNhap";
            this.tpnlPhieuNhap.RowCount = 2;
            this.tpnlPhieuNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tpnlPhieuNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tpnlPhieuNhap.Size = new System.Drawing.Size(800, 522);
            this.tpnlPhieuNhap.TabIndex = 0;
            // 
            // grbDanhSachPhieuNhap
            // 
            this.grbDanhSachPhieuNhap.Controls.Add(this.dgvDanhSachPhieuNhap);
            this.grbDanhSachPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhSachPhieuNhap.Location = new System.Drawing.Point(3, 3);
            this.grbDanhSachPhieuNhap.Name = "grbDanhSachPhieuNhap";
            this.grbDanhSachPhieuNhap.Size = new System.Drawing.Size(794, 255);
            this.grbDanhSachPhieuNhap.TabIndex = 3;
            this.grbDanhSachPhieuNhap.TabStop = false;
            this.grbDanhSachPhieuNhap.Text = "Danh sách phiếu nhập";
            // 
            // dgvDanhSachPhieuNhap
            // 
            this.dgvDanhSachPhieuNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSachPhieuNhap.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvDanhSachPhieuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachPhieuNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPhieu,
            this.MaNCC,
            this.MaKho,
            this.NgayLap,
            this.NhanVienNhap});
            this.dgvDanhSachPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSachPhieuNhap.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvDanhSachPhieuNhap.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhSachPhieuNhap.Name = "dgvDanhSachPhieuNhap";
            this.dgvDanhSachPhieuNhap.Size = new System.Drawing.Size(788, 236);
            this.dgvDanhSachPhieuNhap.TabIndex = 1;
            // 
            // MaPhieu
            // 
            this.MaPhieu.HeaderText = "Mã phiếu nhập";
            this.MaPhieu.Name = "MaPhieu";
            // 
            // MaNCC
            // 
            this.MaNCC.HeaderText = "Mã NCC";
            this.MaNCC.Name = "MaNCC";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // NgayLap
            // 
            this.NgayLap.HeaderText = "Ngày lập phiếu";
            this.NgayLap.Name = "NgayLap";
            // 
            // NhanVienNhap
            // 
            this.NhanVienNhap.HeaderText = "Nhân viên nhập";
            this.NhanVienNhap.Name = "NhanVienNhap";
            // 
            // grbChiTietPhieuNhap
            // 
            this.grbChiTietPhieuNhap.Controls.Add(this.dgvChiTietPhieuNhap);
            this.grbChiTietPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietPhieuNhap.Location = new System.Drawing.Point(3, 264);
            this.grbChiTietPhieuNhap.Name = "grbChiTietPhieuNhap";
            this.grbChiTietPhieuNhap.Size = new System.Drawing.Size(794, 255);
            this.grbChiTietPhieuNhap.TabIndex = 2;
            this.grbChiTietPhieuNhap.TabStop = false;
            this.grbChiTietPhieuNhap.Text = "Chi tiết phiếu nhập";
            // 
            // dgvChiTietPhieuNhap
            // 
            this.dgvChiTietPhieuNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPhieuNhap.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvChiTietPhieuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPhieuNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.DVT,
            this.SL,
            this.GiaNhap});
            this.dgvChiTietPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChiTietPhieuNhap.Location = new System.Drawing.Point(3, 16);
            this.dgvChiTietPhieuNhap.Name = "dgvChiTietPhieuNhap";
            this.dgvChiTietPhieuNhap.Size = new System.Drawing.Size(788, 236);
            this.dgvChiTietPhieuNhap.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // GiaNhap
            // 
            this.GiaNhap.HeaderText = "Giá nhập";
            this.GiaNhap.Name = "GiaNhap";
            // 
            // ucPhieuNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.tpnlPhieuNhap);
            this.Name = "ucPhieuNhap";
            this.Size = new System.Drawing.Size(803, 525);
            this.tpnlPhieuNhap.ResumeLayout(false);
            this.grbDanhSachPhieuNhap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachPhieuNhap)).EndInit();
            this.grbChiTietPhieuNhap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuNhap)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tpnlPhieuNhap;
        private System.Windows.Forms.GroupBox grbDanhSachPhieuNhap;
        private System.Windows.Forms.DataGridView dgvDanhSachPhieuNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPhieu;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNCC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn NhanVienNhap;
        private System.Windows.Forms.GroupBox grbChiTietPhieuNhap;
        private System.Windows.Forms.DataGridView dgvChiTietPhieuNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaNhap;

    }
}
