﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucKhachHangCty
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMaKH = new System.Windows.Forms.Label();
            this.grbThongTinKHCty = new System.Windows.Forms.GroupBox();
            this.txtMathue = new System.Windows.Forms.TextBox();
            this.txtFAX = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.txtTenKH = new System.Windows.Forms.TextBox();
            this.txtMaKH = new System.Windows.Forms.TextBox();
            this.lblMaThue = new System.Windows.Forms.Label();
            this.lblFAX = new System.Windows.Forms.Label();
            this.lblDienThoai = new System.Windows.Forms.Label();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.lblTenKH = new System.Windows.Forms.Label();
            this.pnlBtn = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnDSKhachHang = new System.Windows.Forms.Panel();
            this.grbKhachHangCty = new System.Windows.Forms.GroupBox();
            this.dgvKhachHangCty = new System.Windows.Forms.DataGridView();
            this.MaKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiaChi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaThue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinKHCty.SuspendLayout();
            this.pnlBtn.SuspendLayout();
            this.btnDSKhachHang.SuspendLayout();
            this.grbKhachHangCty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhachHangCty)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMaKH
            // 
            this.lblMaKH.AutoSize = true;
            this.lblMaKH.Location = new System.Drawing.Point(18, 30);
            this.lblMaKH.Name = "lblMaKH";
            this.lblMaKH.Size = new System.Drawing.Size(43, 15);
            this.lblMaKH.TabIndex = 1;
            this.lblMaKH.Text = "Mã KH";
            // 
            // grbThongTinKHCty
            // 
            this.grbThongTinKHCty.Controls.Add(this.txtMathue);
            this.grbThongTinKHCty.Controls.Add(this.txtFAX);
            this.grbThongTinKHCty.Controls.Add(this.txtDiaChi);
            this.grbThongTinKHCty.Controls.Add(this.txtDienThoai);
            this.grbThongTinKHCty.Controls.Add(this.txtTenKH);
            this.grbThongTinKHCty.Controls.Add(this.txtMaKH);
            this.grbThongTinKHCty.Controls.Add(this.lblMaThue);
            this.grbThongTinKHCty.Controls.Add(this.lblFAX);
            this.grbThongTinKHCty.Controls.Add(this.lblDienThoai);
            this.grbThongTinKHCty.Controls.Add(this.lblDiaChi);
            this.grbThongTinKHCty.Controls.Add(this.lblTenKH);
            this.grbThongTinKHCty.Controls.Add(this.lblMaKH);
            this.grbThongTinKHCty.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinKHCty.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinKHCty.Name = "grbThongTinKHCty";
            this.grbThongTinKHCty.Size = new System.Drawing.Size(770, 107);
            this.grbThongTinKHCty.TabIndex = 2;
            this.grbThongTinKHCty.TabStop = false;
            this.grbThongTinKHCty.Text = "Thông tin Khách Hàng Công Ty";
            // 
            // txtMathue
            // 
            this.txtMathue.Location = new System.Drawing.Point(563, 60);
            this.txtMathue.Name = "txtMathue";
            this.txtMathue.Size = new System.Drawing.Size(126, 21);
            this.txtMathue.TabIndex = 3;
            // 
            // txtFAX
            // 
            this.txtFAX.Location = new System.Drawing.Point(67, 66);
            this.txtFAX.Name = "txtFAX";
            this.txtFAX.Size = new System.Drawing.Size(126, 21);
            this.txtFAX.TabIndex = 3;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(283, 63);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(162, 21);
            this.txtDiaChi.TabIndex = 3;
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Location = new System.Drawing.Point(563, 24);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(126, 21);
            this.txtDienThoai.TabIndex = 3;
            // 
            // txtTenKH
            // 
            this.txtTenKH.Location = new System.Drawing.Point(283, 27);
            this.txtTenKH.Name = "txtTenKH";
            this.txtTenKH.Size = new System.Drawing.Size(162, 21);
            this.txtTenKH.TabIndex = 3;
            // 
            // txtMaKH
            // 
            this.txtMaKH.Location = new System.Drawing.Point(67, 27);
            this.txtMaKH.Name = "txtMaKH";
            this.txtMaKH.Size = new System.Drawing.Size(126, 21);
            this.txtMaKH.TabIndex = 3;
            // 
            // lblMaThue
            // 
            this.lblMaThue.AutoSize = true;
            this.lblMaThue.Location = new System.Drawing.Point(502, 66);
            this.lblMaThue.Name = "lblMaThue";
            this.lblMaThue.Size = new System.Drawing.Size(55, 15);
            this.lblMaThue.TabIndex = 1;
            this.lblMaThue.Text = "Mã Thuế";
            // 
            // lblFAX
            // 
            this.lblFAX.AutoSize = true;
            this.lblFAX.Location = new System.Drawing.Point(32, 69);
            this.lblFAX.Name = "lblFAX";
            this.lblFAX.Size = new System.Drawing.Size(29, 15);
            this.lblFAX.TabIndex = 1;
            this.lblFAX.Text = "FAX";
            // 
            // lblDienThoai
            // 
            this.lblDienThoai.AutoSize = true;
            this.lblDienThoai.Location = new System.Drawing.Point(493, 27);
            this.lblDienThoai.Name = "lblDienThoai";
            this.lblDienThoai.Size = new System.Drawing.Size(64, 15);
            this.lblDienThoai.TabIndex = 1;
            this.lblDienThoai.Text = "Điện thoại";
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(230, 69);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(47, 15);
            this.lblDiaChi.TabIndex = 1;
            this.lblDiaChi.Text = "Địa Chỉ";
            // 
            // lblTenKH
            // 
            this.lblTenKH.AutoSize = true;
            this.lblTenKH.Location = new System.Drawing.Point(230, 30);
            this.lblTenKH.Name = "lblTenKH";
            this.lblTenKH.Size = new System.Drawing.Size(47, 15);
            this.lblTenKH.TabIndex = 1;
            this.lblTenKH.Text = "Tên KH";
            // 
            // pnlBtn
            // 
            this.pnlBtn.Controls.Add(this.btnLuu);
            this.pnlBtn.Controls.Add(this.btnXoa);
            this.pnlBtn.Controls.Add(this.btnTimKiem);
            this.pnlBtn.Controls.Add(this.btnSua);
            this.pnlBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBtn.Location = new System.Drawing.Point(0, 435);
            this.pnlBtn.Name = "pnlBtn";
            this.pnlBtn.Size = new System.Drawing.Size(776, 37);
            this.pnlBtn.TabIndex = 3;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(685, 6);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 10;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(611, 6);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 11;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTimKiem.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKiem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnTimKiem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTimKiem.Location = new System.Drawing.Point(461, 6);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(65, 25);
            this.btnTimKiem.TabIndex = 8;
            this.btnTimKiem.Text = "  &Thêm";
            this.btnTimKiem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTimKiem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(536, 6);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 9;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // btnDSKhachHang
            // 
            this.btnDSKhachHang.Controls.Add(this.grbKhachHangCty);
            this.btnDSKhachHang.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnDSKhachHang.Location = new System.Drawing.Point(0, 116);
            this.btnDSKhachHang.Name = "btnDSKhachHang";
            this.btnDSKhachHang.Size = new System.Drawing.Size(776, 319);
            this.btnDSKhachHang.TabIndex = 4;
            // 
            // grbKhachHangCty
            // 
            this.grbKhachHangCty.Controls.Add(this.dgvKhachHangCty);
            this.grbKhachHangCty.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbKhachHangCty.Location = new System.Drawing.Point(0, 0);
            this.grbKhachHangCty.Name = "grbKhachHangCty";
            this.grbKhachHangCty.Size = new System.Drawing.Size(776, 319);
            this.grbKhachHangCty.TabIndex = 1;
            this.grbKhachHangCty.TabStop = false;
            this.grbKhachHangCty.Text = "Danh sách khách hàng";
            // 
            // dgvKhachHangCty
            // 
            this.dgvKhachHangCty.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKhachHangCty.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvKhachHangCty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKhachHangCty.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaKH,
            this.TenKH,
            this.DiaChi,
            this.DT,
            this.Fax,
            this.MaThue});
            this.dgvKhachHangCty.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvKhachHangCty.Location = new System.Drawing.Point(3, 16);
            this.dgvKhachHangCty.Name = "dgvKhachHangCty";
            this.dgvKhachHangCty.RowTemplate.Height = 24;
            this.dgvKhachHangCty.Size = new System.Drawing.Size(770, 300);
            this.dgvKhachHangCty.TabIndex = 0;
            // 
            // MaKH
            // 
            this.MaKH.HeaderText = "Mã khách hàng";
            this.MaKH.Name = "MaKH";
            // 
            // TenKH
            // 
            this.TenKH.HeaderText = "Tên khách hàng";
            this.TenKH.Name = "TenKH";
            // 
            // DiaChi
            // 
            this.DiaChi.HeaderText = "Địa chỉ";
            this.DiaChi.Name = "DiaChi";
            // 
            // DT
            // 
            this.DT.HeaderText = "Điện thoại";
            this.DT.Name = "DT";
            // 
            // Fax
            // 
            this.Fax.HeaderText = "FAX";
            this.Fax.Name = "Fax";
            // 
            // MaThue
            // 
            this.MaThue.HeaderText = "Mã thuế";
            this.MaThue.Name = "MaThue";
            // 
            // ucKhachHangCty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnDSKhachHang);
            this.Controls.Add(this.pnlBtn);
            this.Controls.Add(this.grbThongTinKHCty);
            this.Name = "ucKhachHangCty";
            this.Size = new System.Drawing.Size(776, 472);
            this.grbThongTinKHCty.ResumeLayout(false);
            this.grbThongTinKHCty.PerformLayout();
            this.pnlBtn.ResumeLayout(false);
            this.btnDSKhachHang.ResumeLayout(false);
            this.grbKhachHangCty.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhachHangCty)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblMaKH;
        private System.Windows.Forms.GroupBox grbThongTinKHCty;
        private System.Windows.Forms.Panel pnlBtn;
        private System.Windows.Forms.Label lblMaThue;
        private System.Windows.Forms.Label lblFAX;
        private System.Windows.Forms.Label lblDienThoai;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.Label lblTenKH;
        private System.Windows.Forms.Panel btnDSKhachHang;
        private System.Windows.Forms.TextBox txtMaKH;
        private System.Windows.Forms.TextBox txtMathue;
        private System.Windows.Forms.TextBox txtFAX;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.TextBox txtTenKH;
        private System.Windows.Forms.GroupBox grbKhachHangCty;
        private System.Windows.Forms.DataGridView dgvKhachHangCty;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiaChi;
        private System.Windows.Forms.DataGridViewTextBoxColumn DT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fax;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaThue;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.Button btnSua;
    }
}
