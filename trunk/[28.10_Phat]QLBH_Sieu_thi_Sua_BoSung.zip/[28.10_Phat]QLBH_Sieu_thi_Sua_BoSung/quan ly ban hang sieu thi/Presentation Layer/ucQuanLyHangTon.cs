﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace quan_ly_ban_hang_sieu_thi

{
    public partial class ucQuanLyHangTon : UserControl
    {
        public ucQuanLyHangTon()
        {
            InitializeComponent();
        }

        private void btnXemTheKho_Click(object sender, EventArgs e)
        {
            newForm TheKho = new newForm("frmTheKho", "THẺ KHO");
            ucTheKho newTheKho = new ucTheKho();
            TheKho.taoForm(newTheKho);
        }

    }
}
