﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucNCC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbplNCC = new System.Windows.Forms.TableLayoutPanel();
            this.grbDSNCC = new System.Windows.Forms.GroupBox();
            this.dgvNCC = new System.Windows.Forms.DataGridView();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.grbNCC = new System.Windows.Forms.GroupBox();
            this.picXeHang = new System.Windows.Forms.PictureBox();
            this.txtTenNCC = new System.Windows.Forms.TextBox();
            this.lblTenNCC = new System.Windows.Forms.Label();
            this.txtSoTk = new System.Windows.Forms.TextBox();
            this.lblSoTKNCC = new System.Windows.Forms.Label();
            this.txtMathue = new System.Windows.Forms.TextBox();
            this.lblSoThueNCC = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDiaChiNCC = new System.Windows.Forms.Label();
            this.txtDienthoai = new System.Windows.Forms.TextBox();
            this.lblSodtNCC = new System.Windows.Forms.Label();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.lblSoFaxNCC = new System.Windows.Forms.Label();
            this.txtMaNCC = new System.Windows.Forms.TextBox();
            this.lblMaNCC = new System.Windows.Forms.Label();
            this.tbplNCC.SuspendLayout();
            this.grbDSNCC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNCC)).BeginInit();
            this.pnlButton.SuspendLayout();
            this.grbNCC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picXeHang)).BeginInit();
            this.SuspendLayout();
            // 
            // tbplNCC
            // 
            this.tbplNCC.ColumnCount = 1;
            this.tbplNCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbplNCC.Controls.Add(this.grbDSNCC, 0, 1);
            this.tbplNCC.Controls.Add(this.pnlButton, 0, 2);
            this.tbplNCC.Controls.Add(this.grbNCC, 0, 0);
            this.tbplNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplNCC.Location = new System.Drawing.Point(0, 0);
            this.tbplNCC.Name = "tbplNCC";
            this.tbplNCC.RowCount = 3;
            this.tbplNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.02614F));
            this.tbplNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 67.97385F));
            this.tbplNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tbplNCC.Size = new System.Drawing.Size(800, 522);
            this.tbplNCC.TabIndex = 0;
            // 
            // grbDSNCC
            // 
            this.grbDSNCC.Controls.Add(this.dgvNCC);
            this.grbDSNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDSNCC.Location = new System.Drawing.Point(3, 157);
            this.grbDSNCC.Name = "grbDSNCC";
            this.grbDSNCC.Size = new System.Drawing.Size(794, 321);
            this.grbDSNCC.TabIndex = 1;
            this.grbDSNCC.TabStop = false;
            this.grbDSNCC.Text = "Danh sách nhà cung cấp";
            // 
            // dgvNCC
            // 
            this.dgvNCC.AllowUserToAddRows = false;
            this.dgvNCC.AllowUserToDeleteRows = false;
            this.dgvNCC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNCC.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvNCC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNCC.Location = new System.Drawing.Point(3, 16);
            this.dgvNCC.MultiSelect = false;
            this.dgvNCC.Name = "dgvNCC";
            this.dgvNCC.ReadOnly = true;
            this.dgvNCC.RowTemplate.Height = 24;
            this.dgvNCC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNCC.Size = new System.Drawing.Size(788, 302);
            this.dgvNCC.TabIndex = 0;
            this.dgvNCC.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtGWNCC_CellClick);
            // 
            // pnlButton
            // 
            this.pnlButton.Controls.Add(this.btnLuu);
            this.pnlButton.Controls.Add(this.btnXoa);
            this.pnlButton.Controls.Add(this.btnThem);
            this.pnlButton.Controls.Add(this.btnSua);
            this.pnlButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButton.Location = new System.Drawing.Point(3, 484);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(794, 35);
            this.pnlButton.TabIndex = 2;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(689, 6);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 18;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(615, 6);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 19;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnThem
            // 
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(465, 6);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 16;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(540, 6);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 17;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // grbNCC
            // 
            this.grbNCC.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.grbNCC.Controls.Add(this.picXeHang);
            this.grbNCC.Controls.Add(this.txtTenNCC);
            this.grbNCC.Controls.Add(this.lblTenNCC);
            this.grbNCC.Controls.Add(this.txtSoTk);
            this.grbNCC.Controls.Add(this.lblSoTKNCC);
            this.grbNCC.Controls.Add(this.txtMathue);
            this.grbNCC.Controls.Add(this.lblSoThueNCC);
            this.grbNCC.Controls.Add(this.txtDiaChi);
            this.grbNCC.Controls.Add(this.lblDiaChiNCC);
            this.grbNCC.Controls.Add(this.txtDienthoai);
            this.grbNCC.Controls.Add(this.lblSodtNCC);
            this.grbNCC.Controls.Add(this.txtFax);
            this.grbNCC.Controls.Add(this.lblSoFaxNCC);
            this.grbNCC.Controls.Add(this.txtMaNCC);
            this.grbNCC.Controls.Add(this.lblMaNCC);
            this.grbNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbNCC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbNCC.Location = new System.Drawing.Point(3, 3);
            this.grbNCC.Name = "grbNCC";
            this.grbNCC.Size = new System.Drawing.Size(794, 148);
            this.grbNCC.TabIndex = 0;
            this.grbNCC.TabStop = false;
            this.grbNCC.Text = "Thông tin nhà cung cấp";
            // 
            // picXeHang
            // 
            this.picXeHang.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.xe_cho_hang;
            this.picXeHang.Location = new System.Drawing.Point(604, 17);
            this.picXeHang.Name = "picXeHang";
            this.picXeHang.Size = new System.Drawing.Size(184, 125);
            this.picXeHang.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picXeHang.TabIndex = 2;
            this.picXeHang.TabStop = false;
            // 
            // txtTenNCC
            // 
            this.txtTenNCC.Location = new System.Drawing.Point(97, 48);
            this.txtTenNCC.Name = "txtTenNCC";
            this.txtTenNCC.Size = new System.Drawing.Size(159, 21);
            this.txtTenNCC.TabIndex = 1;
            // 
            // lblTenNCC
            // 
            this.lblTenNCC.AutoSize = true;
            this.lblTenNCC.Location = new System.Drawing.Point(36, 51);
            this.lblTenNCC.Name = "lblTenNCC";
            this.lblTenNCC.Size = new System.Drawing.Size(55, 15);
            this.lblTenNCC.TabIndex = 0;
            this.lblTenNCC.Text = "Tên NCC";
            // 
            // txtSoTk
            // 
            this.txtSoTk.Location = new System.Drawing.Point(97, 79);
            this.txtSoTk.Name = "txtSoTk";
            this.txtSoTk.Size = new System.Drawing.Size(159, 21);
            this.txtSoTk.TabIndex = 1;
            // 
            // lblSoTKNCC
            // 
            this.lblSoTKNCC.AutoSize = true;
            this.lblSoTKNCC.Location = new System.Drawing.Point(14, 82);
            this.lblSoTKNCC.Name = "lblSoTKNCC";
            this.lblSoTKNCC.Size = new System.Drawing.Size(77, 15);
            this.lblSoTKNCC.TabIndex = 0;
            this.lblSoTKNCC.Text = "Số tài khoản";
            // 
            // txtMathue
            // 
            this.txtMathue.Location = new System.Drawing.Point(97, 106);
            this.txtMathue.Name = "txtMathue";
            this.txtMathue.Size = new System.Drawing.Size(159, 21);
            this.txtMathue.TabIndex = 1;
            // 
            // lblSoThueNCC
            // 
            this.lblSoThueNCC.AutoSize = true;
            this.lblSoThueNCC.Location = new System.Drawing.Point(22, 109);
            this.lblSoThueNCC.Name = "lblSoThueNCC";
            this.lblSoThueNCC.Size = new System.Drawing.Size(69, 15);
            this.lblSoThueNCC.TabIndex = 0;
            this.lblSoThueNCC.Text = "Mã số thuế";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(329, 17);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(207, 21);
            this.txtDiaChi.TabIndex = 1;
            // 
            // lblDiaChiNCC
            // 
            this.lblDiaChiNCC.AutoSize = true;
            this.lblDiaChiNCC.Location = new System.Drawing.Point(277, 23);
            this.lblDiaChiNCC.Name = "lblDiaChiNCC";
            this.lblDiaChiNCC.Size = new System.Drawing.Size(46, 15);
            this.lblDiaChiNCC.TabIndex = 0;
            this.lblDiaChiNCC.Text = "Địa chỉ";
            // 
            // txtDienthoai
            // 
            this.txtDienthoai.Location = new System.Drawing.Point(329, 48);
            this.txtDienthoai.Name = "txtDienthoai";
            this.txtDienthoai.Size = new System.Drawing.Size(123, 21);
            this.txtDienthoai.TabIndex = 1;
            // 
            // lblSodtNCC
            // 
            this.lblSodtNCC.AutoSize = true;
            this.lblSodtNCC.Location = new System.Drawing.Point(277, 54);
            this.lblSodtNCC.Name = "lblSodtNCC";
            this.lblSodtNCC.Size = new System.Drawing.Size(41, 15);
            this.lblSodtNCC.TabIndex = 0;
            this.lblSodtNCC.Text = "Số ĐT";
            // 
            // txtFax
            // 
            this.txtFax.Location = new System.Drawing.Point(329, 79);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(123, 21);
            this.txtFax.TabIndex = 1;
            // 
            // lblSoFaxNCC
            // 
            this.lblSoFaxNCC.AutoSize = true;
            this.lblSoFaxNCC.Location = new System.Drawing.Point(273, 85);
            this.lblSoFaxNCC.Name = "lblSoFaxNCC";
            this.lblSoFaxNCC.Size = new System.Drawing.Size(45, 15);
            this.lblSoFaxNCC.TabIndex = 0;
            this.lblSoFaxNCC.Text = "Số Fax";
            // 
            // txtMaNCC
            // 
            this.txtMaNCC.Location = new System.Drawing.Point(97, 17);
            this.txtMaNCC.Name = "txtMaNCC";
            this.txtMaNCC.Size = new System.Drawing.Size(159, 21);
            this.txtMaNCC.TabIndex = 1;
            // 
            // lblMaNCC
            // 
            this.lblMaNCC.AutoSize = true;
            this.lblMaNCC.Location = new System.Drawing.Point(36, 23);
            this.lblMaNCC.Name = "lblMaNCC";
            this.lblMaNCC.Size = new System.Drawing.Size(51, 15);
            this.lblMaNCC.TabIndex = 0;
            this.lblMaNCC.Text = "Mã NCC";
            // 
            // ucNCC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbplNCC);
            this.Name = "ucNCC";
            this.Size = new System.Drawing.Size(800, 522);
            this.tbplNCC.ResumeLayout(false);
            this.grbDSNCC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNCC)).EndInit();
            this.pnlButton.ResumeLayout(false);
            this.grbNCC.ResumeLayout(false);
            this.grbNCC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picXeHang)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tbplNCC;
        private System.Windows.Forms.GroupBox grbNCC;
        private System.Windows.Forms.GroupBox grbDSNCC;
        private System.Windows.Forms.DataGridView dgvNCC;
        private System.Windows.Forms.TextBox txtTenNCC;
        private System.Windows.Forms.Label lblTenNCC;
        private System.Windows.Forms.TextBox txtSoTk;
        private System.Windows.Forms.Label lblSoTKNCC;
        private System.Windows.Forms.TextBox txtMathue;
        private System.Windows.Forms.Label lblSoThueNCC;
        private System.Windows.Forms.TextBox txtMaNCC;
        private System.Windows.Forms.Label lblMaNCC;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Label lblSoFaxNCC;
        private System.Windows.Forms.TextBox txtDienthoai;
        private System.Windows.Forms.Label lblSodtNCC;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblDiaChiNCC;
        private System.Windows.Forms.PictureBox picXeHang;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
    }
}
