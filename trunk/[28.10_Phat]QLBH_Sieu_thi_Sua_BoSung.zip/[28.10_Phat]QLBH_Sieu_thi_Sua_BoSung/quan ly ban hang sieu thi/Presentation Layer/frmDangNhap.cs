﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using quan_ly_ban_hang_sieu_thi.Presentation_Layer;
using quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer;
namespace quan_ly_ban_hang_sieu_thi
{   

    public partial class frmDangNhap : Form
    {
        LOGIN_BUS Login_bus = new LOGIN_BUS();
        public frmDangNhap()
        {
            InitializeComponent();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            Thread thread = new Thread(new ThreadStart(showFormQuanLy));
            thread.Start();
            this.Close();

           if(txtID.Text == "" || txtPass.Text == "")
           {
                MessageBox.Show("Username hoặc Password rỗng","Chú ý");
           }
           else
           {
               if (Login_bus.ktTaiKhoan(txtID.Text.Trim(), txtPass.Text.Trim()))
               {
                   /*
                   Thread thread = new Thread(new ThreadStart(showFormQuanLy));
                   thread.Start();
                   this.Close();*/
               }
               else
               {
                   MessageBox.Show("Sai mật khẩu hay tên đăng nhập không đúng!", "Chú ý", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                 
               }
           }
        }

        public void showFormQuanLy()
        {
            frmQL QL = new frmQL();
            QL.ShowDialog();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void focusNext(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnDangNhap.PerformClick();
                
            }
        }

        private void frmDangNhap_Load(object sender, EventArgs e)
        {
            txtID.Focus();
        }
    }
}
