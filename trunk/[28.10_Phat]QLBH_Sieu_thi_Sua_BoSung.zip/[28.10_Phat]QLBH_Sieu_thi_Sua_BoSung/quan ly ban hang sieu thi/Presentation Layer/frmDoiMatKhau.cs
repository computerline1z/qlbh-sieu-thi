﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace quan_ly_ban_hang_sieu_thi.Presentation_Layer
{
    public partial class frmDoiMatKhau : Form
    {
        public frmDoiMatKhau()
        {
            InitializeComponent();
        }


        private void btnLuuThayDoi_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn thay đổi mật khẩu?", "Xác nhận?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                MessageBox.Show("Thay đổi thành công!");
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
