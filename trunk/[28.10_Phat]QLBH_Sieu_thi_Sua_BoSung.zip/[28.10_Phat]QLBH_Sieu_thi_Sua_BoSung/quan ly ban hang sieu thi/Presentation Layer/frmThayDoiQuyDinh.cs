﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace quan_ly_ban_hang_sieu_thi.Presentation_Layer
{
    public partial class frmThayDoiQuyDinh : Form
    {
        public frmThayDoiQuyDinh()
        {
            InitializeComponent();
        }

        private void lblSLTonToiThieu_Click(object sender, EventArgs e)
        {

        }

        private void tbQuyCachDanhMa_Click(object sender, EventArgs e)
        {

        }

        private void txtVD1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
