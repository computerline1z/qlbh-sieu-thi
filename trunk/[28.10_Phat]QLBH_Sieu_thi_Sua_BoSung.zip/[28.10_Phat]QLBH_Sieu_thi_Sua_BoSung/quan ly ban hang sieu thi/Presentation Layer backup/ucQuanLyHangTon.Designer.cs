﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucQuanLyHangTon
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbplQuanLyHangTon = new System.Windows.Forms.TableLayoutPanel();
            this.grbLocThongTin = new System.Windows.Forms.GroupBox();
            this.grbLocTheoMaHang = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.btnXemTheKho = new System.Windows.Forms.Button();
            this.btnHienThiTatCa = new System.Windows.Forms.Button();
            this.btnLoc = new System.Windows.Forms.Button();
            this.grbLcTheoSoLuong = new System.Windows.Forms.GroupBox();
            this.lblHoac = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numDen = new System.Windows.Forms.NumericUpDown();
            this.numTu = new System.Windows.Forms.NumericUpDown();
            this.raTong = new System.Windows.Forms.RadioButton();
            this.raTrenKe = new System.Windows.Forms.RadioButton();
            this.raTrongKho = new System.Windows.Forms.RadioButton();
            this.raNhoHon = new System.Windows.Forms.RadioButton();
            this.raLonHon = new System.Windows.Forms.RadioButton();
            this.lblDen = new System.Windows.Forms.Label();
            this.lblTu = new System.Windows.Forms.Label();
            this.grbChiTietHangTon = new System.Windows.Forms.GroupBox();
            this.drvChiTietHangTon = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SLKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SLKe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SLTong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbplQuanLyHangTon.SuspendLayout();
            this.grbLocThongTin.SuspendLayout();
            this.grbLocTheoMaHang.SuspendLayout();
            this.grbLcTheoSoLuong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTu)).BeginInit();
            this.grbChiTietHangTon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.drvChiTietHangTon)).BeginInit();
            this.SuspendLayout();
            // 
            // tbplQuanLyHangTon
            // 
            this.tbplQuanLyHangTon.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbplQuanLyHangTon.AutoScroll = true;
            this.tbplQuanLyHangTon.BackColor = System.Drawing.SystemColors.Control;
            this.tbplQuanLyHangTon.ColumnCount = 2;
            this.tbplQuanLyHangTon.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75.57981F));
            this.tbplQuanLyHangTon.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.42019F));
            this.tbplQuanLyHangTon.Controls.Add(this.grbLocThongTin, 1, 0);
            this.tbplQuanLyHangTon.Controls.Add(this.grbChiTietHangTon, 0, 0);
            this.tbplQuanLyHangTon.Location = new System.Drawing.Point(0, 0);
            this.tbplQuanLyHangTon.Name = "tbplQuanLyHangTon";
            this.tbplQuanLyHangTon.RowCount = 1;
            this.tbplQuanLyHangTon.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbplQuanLyHangTon.Size = new System.Drawing.Size(800, 522);
            this.tbplQuanLyHangTon.TabIndex = 0;
            // 
            // grbLocThongTin
            // 
            this.grbLocThongTin.Controls.Add(this.grbLocTheoMaHang);
            this.grbLocThongTin.Controls.Add(this.btnXemTheKho);
            this.grbLocThongTin.Controls.Add(this.btnHienThiTatCa);
            this.grbLocThongTin.Controls.Add(this.btnLoc);
            this.grbLocThongTin.Controls.Add(this.grbLcTheoSoLuong);
            this.grbLocThongTin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbLocThongTin.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbLocThongTin.Location = new System.Drawing.Point(607, 3);
            this.grbLocThongTin.Name = "grbLocThongTin";
            this.grbLocThongTin.Size = new System.Drawing.Size(190, 516);
            this.grbLocThongTin.TabIndex = 1;
            this.grbLocThongTin.TabStop = false;
            this.grbLocThongTin.Text = "Lọc thông tin";
            // 
            // grbLocTheoMaHang
            // 
            this.grbLocTheoMaHang.Controls.Add(this.comboBox1);
            this.grbLocTheoMaHang.Controls.Add(this.label1);
            this.grbLocTheoMaHang.Controls.Add(this.comboBox2);
            this.grbLocTheoMaHang.Controls.Add(this.label2);
            this.grbLocTheoMaHang.Controls.Add(this.checkBox1);
            this.grbLocTheoMaHang.Controls.Add(this.checkBox2);
            this.grbLocTheoMaHang.Location = new System.Drawing.Point(6, 16);
            this.grbLocTheoMaHang.Name = "grbLocTheoMaHang";
            this.grbLocTheoMaHang.Size = new System.Drawing.Size(178, 123);
            this.grbLocTheoMaHang.TabIndex = 8;
            this.grbLocTheoMaHang.TabStop = false;
            this.grbLocTheoMaHang.Text = "Lọc theo chi tiết hàng ";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(70, 47);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(98, 23);
            this.comboBox1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Tên hàng";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(70, 14);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(98, 23);
            this.comboBox2.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Mã hàng";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(40, 102);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(57, 15);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Hết hàng";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(40, 77);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(69, 15);
            this.checkBox2.TabIndex = 4;
            this.checkBox2.Text = "Khuyến mãi";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // btnXemTheKho
            // 
            this.btnXemTheKho.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Next;
            this.btnXemTheKho.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXemTheKho.Location = new System.Drawing.Point(43, 470);
            this.btnXemTheKho.Name = "btnXemTheKho";
            this.btnXemTheKho.Size = new System.Drawing.Size(112, 34);
            this.btnXemTheKho.TabIndex = 3;
            this.btnXemTheKho.Text = "&Xem thẻ kho";
            this.btnXemTheKho.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXemTheKho.UseVisualStyleBackColor = true;
            this.btnXemTheKho.Click += new System.EventHandler(this.btnXemTheKho_Click);
            // 
            // btnHienThiTatCa
            // 
            this.btnHienThiTatCa.Location = new System.Drawing.Point(43, 426);
            this.btnHienThiTatCa.Name = "btnHienThiTatCa";
            this.btnHienThiTatCa.Size = new System.Drawing.Size(112, 34);
            this.btnHienThiTatCa.TabIndex = 3;
            this.btnHienThiTatCa.Text = "&Hiển thị tất cả";
            this.btnHienThiTatCa.UseVisualStyleBackColor = true;
            // 
            // btnLoc
            // 
            this.btnLoc.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Filter;
            this.btnLoc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoc.Location = new System.Drawing.Point(66, 384);
            this.btnLoc.Name = "btnLoc";
            this.btnLoc.Size = new System.Drawing.Size(70, 34);
            this.btnLoc.TabIndex = 3;
            this.btnLoc.Text = "&Lọc";
            this.btnLoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoc.UseVisualStyleBackColor = true;
            // 
            // grbLcTheoSoLuong
            // 
            this.grbLcTheoSoLuong.Controls.Add(this.lblHoac);
            this.grbLcTheoSoLuong.Controls.Add(this.numericUpDown2);
            this.grbLcTheoSoLuong.Controls.Add(this.numericUpDown1);
            this.grbLcTheoSoLuong.Controls.Add(this.numDen);
            this.grbLcTheoSoLuong.Controls.Add(this.numTu);
            this.grbLcTheoSoLuong.Controls.Add(this.raTong);
            this.grbLcTheoSoLuong.Controls.Add(this.raTrenKe);
            this.grbLcTheoSoLuong.Controls.Add(this.raTrongKho);
            this.grbLcTheoSoLuong.Controls.Add(this.raNhoHon);
            this.grbLcTheoSoLuong.Controls.Add(this.raLonHon);
            this.grbLcTheoSoLuong.Controls.Add(this.lblDen);
            this.grbLcTheoSoLuong.Controls.Add(this.lblTu);
            this.grbLcTheoSoLuong.Location = new System.Drawing.Point(6, 140);
            this.grbLcTheoSoLuong.Name = "grbLcTheoSoLuong";
            this.grbLcTheoSoLuong.Size = new System.Drawing.Size(178, 238);
            this.grbLcTheoSoLuong.TabIndex = 2;
            this.grbLcTheoSoLuong.TabStop = false;
            this.grbLcTheoSoLuong.Text = "Lọc theo số lượng";
            // 
            // lblHoac
            // 
            this.lblHoac.AutoSize = true;
            this.lblHoac.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblHoac.Location = new System.Drawing.Point(71, 162);
            this.lblHoac.Name = "lblHoac";
            this.lblHoac.Size = new System.Drawing.Size(36, 15);
            this.lblHoac.TabIndex = 7;
            this.lblHoac.Text = "Hoặc";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(106, 207);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(62, 21);
            this.numericUpDown2.TabIndex = 6;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(106, 180);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(62, 21);
            this.numericUpDown1.TabIndex = 6;
            // 
            // numDen
            // 
            this.numDen.Location = new System.Drawing.Point(70, 135);
            this.numDen.Name = "numDen";
            this.numDen.Size = new System.Drawing.Size(62, 21);
            this.numDen.TabIndex = 6;
            // 
            // numTu
            // 
            this.numTu.Location = new System.Drawing.Point(70, 109);
            this.numTu.Name = "numTu";
            this.numTu.Size = new System.Drawing.Size(62, 21);
            this.numTu.TabIndex = 6;
            // 
            // raTong
            // 
            this.raTong.AutoSize = true;
            this.raTong.Location = new System.Drawing.Point(14, 70);
            this.raTong.Name = "raTong";
            this.raTong.Size = new System.Drawing.Size(106, 19);
            this.raTong.TabIndex = 5;
            this.raTong.TabStop = true;
            this.raTong.Text = "Số lượng tổng";
            this.raTong.UseVisualStyleBackColor = true;
            // 
            // raTrenKe
            // 
            this.raTrenKe.AutoSize = true;
            this.raTrenKe.Location = new System.Drawing.Point(14, 45);
            this.raTrenKe.Name = "raTrenKe";
            this.raTrenKe.Size = new System.Drawing.Size(121, 19);
            this.raTrenKe.TabIndex = 5;
            this.raTrenKe.TabStop = true;
            this.raTrenKe.Text = "Số lượng trên kệ";
            this.raTrenKe.UseVisualStyleBackColor = true;
            // 
            // raTrongKho
            // 
            this.raTrongKho.AutoSize = true;
            this.raTrongKho.Location = new System.Drawing.Point(14, 20);
            this.raTrongKho.Name = "raTrongKho";
            this.raTrongKho.Size = new System.Drawing.Size(135, 19);
            this.raTrongKho.TabIndex = 5;
            this.raTrongKho.TabStop = true;
            this.raTrongKho.Text = "Số lượng trong kho";
            this.raTrongKho.UseVisualStyleBackColor = true;
            // 
            // raNhoHon
            // 
            this.raNhoHon.AutoSize = true;
            this.raNhoHon.Location = new System.Drawing.Point(34, 204);
            this.raNhoHon.Name = "raNhoHon";
            this.raNhoHon.Size = new System.Drawing.Size(73, 19);
            this.raNhoHon.TabIndex = 4;
            this.raNhoHon.TabStop = true;
            this.raNhoHon.Text = "Nhỏ hơn";
            this.raNhoHon.UseVisualStyleBackColor = true;
            // 
            // raLonHon
            // 
            this.raLonHon.AutoSize = true;
            this.raLonHon.Location = new System.Drawing.Point(34, 180);
            this.raLonHon.Name = "raLonHon";
            this.raLonHon.Size = new System.Drawing.Size(74, 19);
            this.raLonHon.TabIndex = 4;
            this.raLonHon.TabStop = true;
            this.raLonHon.Text = "Lớn hơn";
            this.raLonHon.UseVisualStyleBackColor = true;
            // 
            // lblDen
            // 
            this.lblDen.AutoSize = true;
            this.lblDen.Location = new System.Drawing.Point(34, 141);
            this.lblDen.Name = "lblDen";
            this.lblDen.Size = new System.Drawing.Size(30, 15);
            this.lblDen.TabIndex = 2;
            this.lblDen.Text = "Đến";
            // 
            // lblTu
            // 
            this.lblTu.AutoSize = true;
            this.lblTu.Location = new System.Drawing.Point(34, 115);
            this.lblTu.Name = "lblTu";
            this.lblTu.Size = new System.Drawing.Size(23, 15);
            this.lblTu.TabIndex = 2;
            this.lblTu.Text = "Từ";
            // 
            // grbChiTietHangTon
            // 
            this.grbChiTietHangTon.Controls.Add(this.drvChiTietHangTon);
            this.grbChiTietHangTon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietHangTon.Location = new System.Drawing.Point(3, 3);
            this.grbChiTietHangTon.Name = "grbChiTietHangTon";
            this.grbChiTietHangTon.Size = new System.Drawing.Size(598, 516);
            this.grbChiTietHangTon.TabIndex = 2;
            this.grbChiTietHangTon.TabStop = false;
            this.grbChiTietHangTon.Text = "Chi tiết hàng tồn";
            // 
            // drvChiTietHangTon
            // 
            this.drvChiTietHangTon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.drvChiTietHangTon.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.drvChiTietHangTon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.drvChiTietHangTon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.DVT,
            this.SLKho,
            this.SLKe,
            this.SLTong});
            this.drvChiTietHangTon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.drvChiTietHangTon.Location = new System.Drawing.Point(3, 16);
            this.drvChiTietHangTon.Name = "drvChiTietHangTon";
            this.drvChiTietHangTon.RowTemplate.Height = 24;
            this.drvChiTietHangTon.Size = new System.Drawing.Size(592, 497);
            this.drvChiTietHangTon.TabIndex = 1;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SLKho
            // 
            this.SLKho.HeaderText = "Số lượng trong kho";
            this.SLKho.Name = "SLKho";
            // 
            // SLKe
            // 
            this.SLKe.HeaderText = "Số lượng trên kệ";
            this.SLKe.Name = "SLKe";
            // 
            // SLTong
            // 
            this.SLTong.HeaderText = "Số lượng tổng";
            this.SLTong.Name = "SLTong";
            // 
            // ucQuanLyHangTon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.Controls.Add(this.tbplQuanLyHangTon);
            this.MaximumSize = new System.Drawing.Size(1024, 768);
            this.Name = "ucQuanLyHangTon";
            this.Size = new System.Drawing.Size(1024, 646);
            this.tbplQuanLyHangTon.ResumeLayout(false);
            this.grbLocThongTin.ResumeLayout(false);
            this.grbLocTheoMaHang.ResumeLayout(false);
            this.grbLocTheoMaHang.PerformLayout();
            this.grbLcTheoSoLuong.ResumeLayout(false);
            this.grbLcTheoSoLuong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTu)).EndInit();
            this.grbChiTietHangTon.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.drvChiTietHangTon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tbplQuanLyHangTon;
        private System.Windows.Forms.GroupBox grbLocThongTin;
        private System.Windows.Forms.Button btnXemTheKho;
        private System.Windows.Forms.Button btnHienThiTatCa;
        private System.Windows.Forms.Button btnLoc;
        private System.Windows.Forms.GroupBox grbLcTheoSoLuong;
        private System.Windows.Forms.Label lblHoac;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numDen;
        private System.Windows.Forms.NumericUpDown numTu;
        private System.Windows.Forms.RadioButton raTong;
        private System.Windows.Forms.RadioButton raTrenKe;
        private System.Windows.Forms.RadioButton raTrongKho;
        private System.Windows.Forms.RadioButton raNhoHon;
        private System.Windows.Forms.RadioButton raLonHon;
        private System.Windows.Forms.Label lblDen;
        private System.Windows.Forms.Label lblTu;
        private System.Windows.Forms.GroupBox grbLocTheoMaHang;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.GroupBox grbChiTietHangTon;
        private System.Windows.Forms.DataGridView drvChiTietHangTon;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SLKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn SLKe;
        private System.Windows.Forms.DataGridViewTextBoxColumn SLTong;
    }
}
