﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucKhachHangCty
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMaKH = new System.Windows.Forms.Label();
            this.grbThongTinKHCty = new System.Windows.Forms.GroupBox();
            this.txtMathue = new System.Windows.Forms.TextBox();
            this.txtFAX = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.txtTenKH = new System.Windows.Forms.TextBox();
            this.txtMaKH = new System.Windows.Forms.TextBox();
            this.lblMaThue = new System.Windows.Forms.Label();
            this.lblFAX = new System.Windows.Forms.Label();
            this.lblDienThoai = new System.Windows.Forms.Label();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.lblTenKH = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.grbKhachHangCty = new System.Windows.Forms.GroupBox();
            this.dgvKhachHangCty = new System.Windows.Forms.DataGridView();
            this.MaKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiaChi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaThue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinKHCty.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.grbKhachHangCty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhachHangCty)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMaKH
            // 
            this.lblMaKH.AutoSize = true;
            this.lblMaKH.Location = new System.Drawing.Point(24, 37);
            this.lblMaKH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMaKH.Name = "lblMaKH";
            this.lblMaKH.Size = new System.Drawing.Size(55, 18);
            this.lblMaKH.TabIndex = 1;
            this.lblMaKH.Text = "Mã KH";
            // 
            // grbThongTinKHCty
            // 
            this.grbThongTinKHCty.Controls.Add(this.txtMathue);
            this.grbThongTinKHCty.Controls.Add(this.txtFAX);
            this.grbThongTinKHCty.Controls.Add(this.txtDiaChi);
            this.grbThongTinKHCty.Controls.Add(this.txtDienThoai);
            this.grbThongTinKHCty.Controls.Add(this.txtTenKH);
            this.grbThongTinKHCty.Controls.Add(this.txtMaKH);
            this.grbThongTinKHCty.Controls.Add(this.lblMaThue);
            this.grbThongTinKHCty.Controls.Add(this.lblFAX);
            this.grbThongTinKHCty.Controls.Add(this.lblDienThoai);
            this.grbThongTinKHCty.Controls.Add(this.lblDiaChi);
            this.grbThongTinKHCty.Controls.Add(this.lblTenKH);
            this.grbThongTinKHCty.Controls.Add(this.lblMaKH);
            this.grbThongTinKHCty.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinKHCty.Location = new System.Drawing.Point(4, 4);
            this.grbThongTinKHCty.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grbThongTinKHCty.Name = "grbThongTinKHCty";
            this.grbThongTinKHCty.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grbThongTinKHCty.Size = new System.Drawing.Size(1027, 132);
            this.grbThongTinKHCty.TabIndex = 2;
            this.grbThongTinKHCty.TabStop = false;
            this.grbThongTinKHCty.Text = "Thông tin Khách Hàng Công Ty";
            // 
            // txtMathue
            // 
            this.txtMathue.Location = new System.Drawing.Point(751, 74);
            this.txtMathue.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMathue.Name = "txtMathue";
            this.txtMathue.Size = new System.Drawing.Size(167, 25);
            this.txtMathue.TabIndex = 3;
            // 
            // txtFAX
            // 
            this.txtFAX.Location = new System.Drawing.Point(89, 81);
            this.txtFAX.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFAX.Name = "txtFAX";
            this.txtFAX.Size = new System.Drawing.Size(167, 25);
            this.txtFAX.TabIndex = 3;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(377, 78);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(215, 25);
            this.txtDiaChi.TabIndex = 3;
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Location = new System.Drawing.Point(751, 30);
            this.txtDienThoai.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(167, 25);
            this.txtDienThoai.TabIndex = 3;
            // 
            // txtTenKH
            // 
            this.txtTenKH.Location = new System.Drawing.Point(377, 33);
            this.txtTenKH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTenKH.Name = "txtTenKH";
            this.txtTenKH.Size = new System.Drawing.Size(215, 25);
            this.txtTenKH.TabIndex = 3;
            // 
            // txtMaKH
            // 
            this.txtMaKH.Location = new System.Drawing.Point(89, 33);
            this.txtMaKH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMaKH.Name = "txtMaKH";
            this.txtMaKH.Size = new System.Drawing.Size(167, 25);
            this.txtMaKH.TabIndex = 3;
            // 
            // lblMaThue
            // 
            this.lblMaThue.AutoSize = true;
            this.lblMaThue.Location = new System.Drawing.Point(669, 81);
            this.lblMaThue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMaThue.Name = "lblMaThue";
            this.lblMaThue.Size = new System.Drawing.Size(70, 18);
            this.lblMaThue.TabIndex = 1;
            this.lblMaThue.Text = "Mã Thuế";
            // 
            // lblFAX
            // 
            this.lblFAX.AutoSize = true;
            this.lblFAX.Location = new System.Drawing.Point(43, 85);
            this.lblFAX.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFAX.Name = "lblFAX";
            this.lblFAX.Size = new System.Drawing.Size(35, 18);
            this.lblFAX.TabIndex = 1;
            this.lblFAX.Text = "FAX";
            // 
            // lblDienThoai
            // 
            this.lblDienThoai.AutoSize = true;
            this.lblDienThoai.Location = new System.Drawing.Point(657, 33);
            this.lblDienThoai.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDienThoai.Name = "lblDienThoai";
            this.lblDienThoai.Size = new System.Drawing.Size(80, 18);
            this.lblDienThoai.TabIndex = 1;
            this.lblDienThoai.Text = "Điện thoại";
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(307, 85);
            this.lblDiaChi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(59, 18);
            this.lblDiaChi.TabIndex = 1;
            this.lblDiaChi.Text = "Địa Chỉ";
            // 
            // lblTenKH
            // 
            this.lblTenKH.AutoSize = true;
            this.lblTenKH.Location = new System.Drawing.Point(307, 37);
            this.lblTenKH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTenKH.Name = "lblTenKH";
            this.lblTenKH.Size = new System.Drawing.Size(62, 18);
            this.lblTenKH.TabIndex = 1;
            this.lblTenKH.Text = "Tên KH";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnLuu);
            this.panel1.Controls.Add(this.btnXoa);
            this.panel1.Controls.Add(this.btnTimKiem);
            this.panel1.Controls.Add(this.btnSua);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 535);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1035, 46);
            this.panel1.TabIndex = 3;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(913, 7);
            this.btnLuu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(87, 31);
            this.btnLuu.TabIndex = 10;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(815, 7);
            this.btnXoa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(87, 31);
            this.btnXoa.TabIndex = 11;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTimKiem.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKiem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnTimKiem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTimKiem.Location = new System.Drawing.Point(615, 7);
            this.btnTimKiem.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(87, 31);
            this.btnTimKiem.TabIndex = 8;
            this.btnTimKiem.Text = "  &Thêm";
            this.btnTimKiem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTimKiem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(715, 7);
            this.btnSua.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(87, 31);
            this.btnSua.TabIndex = 9;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grbKhachHangCty);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 142);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1035, 393);
            this.panel2.TabIndex = 4;
            // 
            // grbKhachHangCty
            // 
            this.grbKhachHangCty.Controls.Add(this.dgvKhachHangCty);
            this.grbKhachHangCty.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbKhachHangCty.Location = new System.Drawing.Point(0, 0);
            this.grbKhachHangCty.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grbKhachHangCty.Name = "grbKhachHangCty";
            this.grbKhachHangCty.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grbKhachHangCty.Size = new System.Drawing.Size(1035, 393);
            this.grbKhachHangCty.TabIndex = 1;
            this.grbKhachHangCty.TabStop = false;
            this.grbKhachHangCty.Text = "Danh sách khách hàng";
            // 
            // dgvKhachHangCty
            // 
            this.dgvKhachHangCty.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKhachHangCty.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvKhachHangCty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKhachHangCty.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaKH,
            this.TenKH,
            this.DiaChi,
            this.DT,
            this.Fax,
            this.MaThue});
            this.dgvKhachHangCty.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvKhachHangCty.Location = new System.Drawing.Point(4, 20);
            this.dgvKhachHangCty.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvKhachHangCty.Name = "dgvKhachHangCty";
            this.dgvKhachHangCty.RowTemplate.Height = 24;
            this.dgvKhachHangCty.Size = new System.Drawing.Size(1027, 369);
            this.dgvKhachHangCty.TabIndex = 0;
            // 
            // MaKH
            // 
            this.MaKH.HeaderText = "Mã khách hàng";
            this.MaKH.Name = "MaKH";
            // 
            // TenKH
            // 
            this.TenKH.HeaderText = "Tên khách hàng";
            this.TenKH.Name = "TenKH";
            // 
            // DiaChi
            // 
            this.DiaChi.HeaderText = "Địa chỉ";
            this.DiaChi.Name = "DiaChi";
            // 
            // DT
            // 
            this.DT.HeaderText = "Điện thoại";
            this.DT.Name = "DT";
            // 
            // Fax
            // 
            this.Fax.HeaderText = "FAX";
            this.Fax.Name = "Fax";
            // 
            // MaThue
            // 
            this.MaThue.HeaderText = "Mã thuế";
            this.MaThue.Name = "MaThue";
            // 
            // ucKhachHangCty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.grbThongTinKHCty);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ucKhachHangCty";
            this.Size = new System.Drawing.Size(1035, 581);
            this.grbThongTinKHCty.ResumeLayout(false);
            this.grbThongTinKHCty.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.grbKhachHangCty.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhachHangCty)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblMaKH;
        private System.Windows.Forms.GroupBox grbThongTinKHCty;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblMaThue;
        private System.Windows.Forms.Label lblFAX;
        private System.Windows.Forms.Label lblDienThoai;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.Label lblTenKH;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtMaKH;
        private System.Windows.Forms.TextBox txtMathue;
        private System.Windows.Forms.TextBox txtFAX;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.TextBox txtTenKH;
        private System.Windows.Forms.GroupBox grbKhachHangCty;
        private System.Windows.Forms.DataGridView dgvKhachHangCty;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiaChi;
        private System.Windows.Forms.DataGridViewTextBoxColumn DT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fax;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaThue;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.Button btnSua;
    }
}
