﻿namespace QuanLyBanHang
{
    partial class ucNCC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlpNCC = new System.Windows.Forms.TableLayoutPanel();
            this.grbNCC = new System.Windows.Forms.GroupBox();
            this.txtTenNCC = new System.Windows.Forms.TextBox();
            this.txtSoTk = new System.Windows.Forms.TextBox();
            this.lblSoTKNCC = new System.Windows.Forms.Label();
            this.txtMathue = new System.Windows.Forms.TextBox();
            this.lblSoThueNCC = new System.Windows.Forms.Label();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.lblSoFaxNCC = new System.Windows.Forms.Label();
            this.txtDienthoai = new System.Windows.Forms.TextBox();
            this.lblSodtNCC = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDiaChiNCC = new System.Windows.Forms.Label();
            this.lblTenNCC = new System.Windows.Forms.Label();
            this.lblMaNCC = new System.Windows.Forms.Label();
            this.txtMaNCC = new System.Windows.Forms.TextBox();
            this.dtGWNCC = new System.Windows.Forms.DataGridView();
            this.plButton = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.tlpNCC.SuspendLayout();
            this.grbNCC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGWNCC)).BeginInit();
            this.plButton.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpNCC
            // 
            this.tlpNCC.ColumnCount = 1;
            this.tlpNCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpNCC.Controls.Add(this.grbNCC, 0, 0);
            this.tlpNCC.Controls.Add(this.dtGWNCC, 0, 1);
            this.tlpNCC.Controls.Add(this.plButton, 0, 2);
            this.tlpNCC.Location = new System.Drawing.Point(0, 0);
            this.tlpNCC.Name = "tlpNCC";
            this.tlpNCC.RowCount = 3;
            this.tlpNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.84519F));
            this.tlpNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 67.15481F));
            this.tlpNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tlpNCC.Size = new System.Drawing.Size(763, 522);
            this.tlpNCC.TabIndex = 0;
            // 
            // grbNCC
            // 
            this.grbNCC.Controls.Add(this.txtTenNCC);
            this.grbNCC.Controls.Add(this.txtSoTk);
            this.grbNCC.Controls.Add(this.lblSoTKNCC);
            this.grbNCC.Controls.Add(this.txtMathue);
            this.grbNCC.Controls.Add(this.lblSoThueNCC);
            this.grbNCC.Controls.Add(this.txtFax);
            this.grbNCC.Controls.Add(this.lblSoFaxNCC);
            this.grbNCC.Controls.Add(this.txtDienthoai);
            this.grbNCC.Controls.Add(this.lblSodtNCC);
            this.grbNCC.Controls.Add(this.txtDiaChi);
            this.grbNCC.Controls.Add(this.lblDiaChiNCC);
            this.grbNCC.Controls.Add(this.lblTenNCC);
            this.grbNCC.Controls.Add(this.lblMaNCC);
            this.grbNCC.Controls.Add(this.txtMaNCC);
            this.grbNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbNCC.Location = new System.Drawing.Point(3, 3);
            this.grbNCC.Name = "grbNCC";
            this.grbNCC.Size = new System.Drawing.Size(757, 152);
            this.grbNCC.TabIndex = 0;
            this.grbNCC.TabStop = false;
            this.grbNCC.Tag = "S";
            this.grbNCC.Text = "Thông tin Nhà Cung Cấp";
            // 
            // txtTenNCC
            // 
            this.txtTenNCC.Location = new System.Drawing.Point(420, 14);
            this.txtTenNCC.Name = "txtTenNCC";
            this.txtTenNCC.Size = new System.Drawing.Size(186, 20);
            this.txtTenNCC.TabIndex = 10;
            // 
            // txtSoTk
            // 
            this.txtSoTk.AllowDrop = true;
            this.txtSoTk.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSoTk.Location = new System.Drawing.Point(420, 86);
            this.txtSoTk.Name = "txtSoTk";
            this.txtSoTk.Size = new System.Drawing.Size(186, 20);
            this.txtSoTk.TabIndex = 7;
            // 
            // lblSoTKNCC
            // 
            this.lblSoTKNCC.AllowDrop = true;
            this.lblSoTKNCC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSoTKNCC.AutoSize = true;
            this.lblSoTKNCC.Location = new System.Drawing.Point(347, 90);
            this.lblSoTKNCC.Name = "lblSoTKNCC";
            this.lblSoTKNCC.Size = new System.Drawing.Size(67, 13);
            this.lblSoTKNCC.TabIndex = 6;
            this.lblSoTKNCC.Text = "Số tài khoản";
            // 
            // txtMathue
            // 
            this.txtMathue.AllowDrop = true;
            this.txtMathue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMathue.Location = new System.Drawing.Point(420, 50);
            this.txtMathue.Name = "txtMathue";
            this.txtMathue.Size = new System.Drawing.Size(186, 20);
            this.txtMathue.TabIndex = 7;
            // 
            // lblSoThueNCC
            // 
            this.lblSoThueNCC.AllowDrop = true;
            this.lblSoThueNCC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSoThueNCC.AutoSize = true;
            this.lblSoThueNCC.Location = new System.Drawing.Point(363, 53);
            this.lblSoThueNCC.Name = "lblSoThueNCC";
            this.lblSoThueNCC.Size = new System.Drawing.Size(48, 13);
            this.lblSoThueNCC.TabIndex = 6;
            this.lblSoThueNCC.Text = "Số Thuế";
            // 
            // txtFax
            // 
            this.txtFax.AllowDrop = true;
            this.txtFax.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtFax.Location = new System.Drawing.Point(130, 118);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(173, 20);
            this.txtFax.TabIndex = 7;
            // 
            // lblSoFaxNCC
            // 
            this.lblSoFaxNCC.AllowDrop = true;
            this.lblSoFaxNCC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSoFaxNCC.AutoSize = true;
            this.lblSoFaxNCC.Location = new System.Drawing.Point(84, 118);
            this.lblSoFaxNCC.Name = "lblSoFaxNCC";
            this.lblSoFaxNCC.Size = new System.Drawing.Size(43, 13);
            this.lblSoFaxNCC.TabIndex = 6;
            this.lblSoFaxNCC.Text = "Số FAX";
            // 
            // txtDienthoai
            // 
            this.txtDienthoai.AllowDrop = true;
            this.txtDienthoai.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDienthoai.Location = new System.Drawing.Point(130, 83);
            this.txtDienthoai.Name = "txtDienthoai";
            this.txtDienthoai.Size = new System.Drawing.Size(173, 20);
            this.txtDienthoai.TabIndex = 7;
            // 
            // lblSodtNCC
            // 
            this.lblSodtNCC.AllowDrop = true;
            this.lblSodtNCC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSodtNCC.AutoSize = true;
            this.lblSodtNCC.Location = new System.Drawing.Point(49, 86);
            this.lblSodtNCC.Name = "lblSodtNCC";
            this.lblSodtNCC.Size = new System.Drawing.Size(75, 13);
            this.lblSodtNCC.TabIndex = 6;
            this.lblSodtNCC.Text = "Số Điện Thoại";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.AllowDrop = true;
            this.txtDiaChi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDiaChi.Location = new System.Drawing.Point(130, 50);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(173, 20);
            this.txtDiaChi.TabIndex = 7;
            // 
            // lblDiaChiNCC
            // 
            this.lblDiaChiNCC.AllowDrop = true;
            this.lblDiaChiNCC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDiaChiNCC.AutoSize = true;
            this.lblDiaChiNCC.Location = new System.Drawing.Point(84, 53);
            this.lblDiaChiNCC.Name = "lblDiaChiNCC";
            this.lblDiaChiNCC.Size = new System.Drawing.Size(40, 13);
            this.lblDiaChiNCC.TabIndex = 6;
            this.lblDiaChiNCC.Text = "Địa chỉ";
            // 
            // lblTenNCC
            // 
            this.lblTenNCC.AllowDrop = true;
            this.lblTenNCC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTenNCC.AutoSize = true;
            this.lblTenNCC.Location = new System.Drawing.Point(363, 19);
            this.lblTenNCC.Name = "lblTenNCC";
            this.lblTenNCC.Size = new System.Drawing.Size(51, 13);
            this.lblTenNCC.TabIndex = 4;
            this.lblTenNCC.Text = "Tên NCC";
            // 
            // lblMaNCC
            // 
            this.lblMaNCC.AllowDrop = true;
            this.lblMaNCC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMaNCC.AutoSize = true;
            this.lblMaNCC.Location = new System.Drawing.Point(77, 17);
            this.lblMaNCC.Name = "lblMaNCC";
            this.lblMaNCC.Size = new System.Drawing.Size(47, 13);
            this.lblMaNCC.TabIndex = 3;
            this.lblMaNCC.Text = "Mã NCC";
            // 
            // txtMaNCC
            // 
            this.txtMaNCC.AllowDrop = true;
            this.txtMaNCC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMaNCC.Location = new System.Drawing.Point(130, 14);
            this.txtMaNCC.Name = "txtMaNCC";
            this.txtMaNCC.ReadOnly = true;
            this.txtMaNCC.Size = new System.Drawing.Size(173, 20);
            this.txtMaNCC.TabIndex = 2;
            // 
            // dtGWNCC
            // 
            this.dtGWNCC.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dtGWNCC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGWNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtGWNCC.Location = new System.Drawing.Point(3, 161);
            this.dtGWNCC.Name = "dtGWNCC";
            this.dtGWNCC.ReadOnly = true;
            this.dtGWNCC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGWNCC.Size = new System.Drawing.Size(757, 318);
            this.dtGWNCC.TabIndex = 1;
            this.dtGWNCC.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtGWNCC_CellClick);
            // 
            // plButton
            // 
            this.plButton.AutoSize = true;
            this.plButton.Controls.Add(this.btnLuu);
            this.plButton.Controls.Add(this.btnXoa);
            this.plButton.Controls.Add(this.btnThem);
            this.plButton.Controls.Add(this.btnSua);
            this.plButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plButton.Location = new System.Drawing.Point(3, 485);
            this.plButton.Name = "plButton";
            this.plButton.Size = new System.Drawing.Size(757, 34);
            this.plButton.TabIndex = 2;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.Image = global::QuanLyBanHang.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(660, 5);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 10;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.Image = global::QuanLyBanHang.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(586, 5);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 11;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.Image = global::QuanLyBanHang.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(436, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 8;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.Image = global::QuanLyBanHang.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(511, 5);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 9;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // ucNCC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.tlpNCC);
            this.Name = "ucNCC";
            this.Size = new System.Drawing.Size(766, 525);
            this.tlpNCC.ResumeLayout(false);
            this.tlpNCC.PerformLayout();
            this.grbNCC.ResumeLayout(false);
            this.grbNCC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGWNCC)).EndInit();
            this.plButton.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpNCC;
        private System.Windows.Forms.GroupBox grbNCC;
        private System.Windows.Forms.Label lblMaNCC;
        private System.Windows.Forms.TextBox txtMaNCC;
        private System.Windows.Forms.Label lblTenNCC;
        private System.Windows.Forms.TextBox txtSoTk;
        private System.Windows.Forms.Label lblSoTKNCC;
        private System.Windows.Forms.TextBox txtMathue;
        private System.Windows.Forms.Label lblSoThueNCC;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Label lblSoFaxNCC;
        private System.Windows.Forms.TextBox txtDienthoai;
        private System.Windows.Forms.Label lblSodtNCC;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblDiaChiNCC;
        private System.Windows.Forms.DataGridView dtGWNCC;
        private System.Windows.Forms.Panel plButton;
        private System.Windows.Forms.TextBox txtTenNCC;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;

    }
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               