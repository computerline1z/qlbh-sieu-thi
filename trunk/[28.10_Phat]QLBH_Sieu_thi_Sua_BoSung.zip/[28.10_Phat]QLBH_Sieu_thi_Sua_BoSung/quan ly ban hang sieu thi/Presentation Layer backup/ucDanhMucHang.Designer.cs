﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class usrDMHang
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gdbThongTinHangHoa = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cboNCC = new System.Windows.Forms.ComboBox();
            this.txtTenhang = new System.Windows.Forms.TextBox();
            this.txtMahang = new System.Windows.Forms.TextBox();
            this.imgSP = new System.Windows.Forms.PictureBox();
            this.btnThemLoaiHang = new System.Windows.Forms.Button();
            this.btnThemNCC = new System.Windows.Forms.Button();
            this.btnThemNhom = new System.Windows.Forms.Button();
            this.btnThemDVT = new System.Windows.Forms.Button();
            this.cboMaloai = new System.Windows.Forms.ComboBox();
            this.cboManhom = new System.Windows.Forms.ComboBox();
            this.cboDVT = new System.Windows.Forms.ComboBox();
            this.txtGia = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblNCC = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblMaNhom = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grbDanhMucHang = new System.Windows.Forms.GroupBox();
            this.dtGWHanghoa = new System.Windows.Forms.DataGridView();
            this.pnlDanhMucHang = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.pnlDanhMucHangHoa = new System.Windows.Forms.Panel();
            this.cboKM = new System.Windows.Forms.ComboBox();
            this.gdbThongTinHangHoa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).BeginInit();
            this.grbDanhMucHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGWHanghoa)).BeginInit();
            this.pnlDanhMucHang.SuspendLayout();
            this.pnlDanhMucHangHoa.SuspendLayout();
            this.SuspendLayout();
            // 
            // gdbThongTinHangHoa
            // 
            this.gdbThongTinHangHoa.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gdbThongTinHangHoa.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.gdbThongTinHangHoa.Controls.Add(this.cboKM);
            this.gdbThongTinHangHoa.Controls.Add(this.label4);
            this.gdbThongTinHangHoa.Controls.Add(this.cboNCC);
            this.gdbThongTinHangHoa.Controls.Add(this.txtTenhang);
            this.gdbThongTinHangHoa.Controls.Add(this.txtMahang);
            this.gdbThongTinHangHoa.Controls.Add(this.imgSP);
            this.gdbThongTinHangHoa.Controls.Add(this.btnThemLoaiHang);
            this.gdbThongTinHangHoa.Controls.Add(this.btnThemNCC);
            this.gdbThongTinHangHoa.Controls.Add(this.btnThemNhom);
            this.gdbThongTinHangHoa.Controls.Add(this.btnThemDVT);
            this.gdbThongTinHangHoa.Controls.Add(this.cboMaloai);
            this.gdbThongTinHangHoa.Controls.Add(this.cboManhom);
            this.gdbThongTinHangHoa.Controls.Add(this.cboDVT);
            this.gdbThongTinHangHoa.Controls.Add(this.txtGia);
            this.gdbThongTinHangHoa.Controls.Add(this.label7);
            this.gdbThongTinHangHoa.Controls.Add(this.lblNCC);
            this.gdbThongTinHangHoa.Controls.Add(this.label3);
            this.gdbThongTinHangHoa.Controls.Add(this.label2);
            this.gdbThongTinHangHoa.Controls.Add(this.lblMaNhom);
            this.gdbThongTinHangHoa.Controls.Add(this.label5);
            this.gdbThongTinHangHoa.Controls.Add(this.label1);
            this.gdbThongTinHangHoa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gdbThongTinHangHoa.Location = new System.Drawing.Point(4, 4);
            this.gdbThongTinHangHoa.Margin = new System.Windows.Forms.Padding(4);
            this.gdbThongTinHangHoa.Name = "gdbThongTinHangHoa";
            this.gdbThongTinHangHoa.Padding = new System.Windows.Forms.Padding(4);
            this.gdbThongTinHangHoa.Size = new System.Drawing.Size(1068, 218);
            this.gdbThongTinHangHoa.TabIndex = 8;
            this.gdbThongTinHangHoa.TabStop = false;
            this.gdbThongTinHangHoa.Text = "Thông tin hàng hóa";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(448, 118);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 18);
            this.label4.TabIndex = 10;
            this.label4.Text = "Khuyến mãi";
            // 
            // cboNCC
            // 
            this.cboNCC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNCC.FormattingEnabled = true;
            this.cboNCC.Location = new System.Drawing.Point(552, 155);
            this.cboNCC.Margin = new System.Windows.Forms.Padding(4);
            this.cboNCC.Name = "cboNCC";
            this.cboNCC.Size = new System.Drawing.Size(187, 26);
            this.cboNCC.TabIndex = 9;
            // 
            // txtTenhang
            // 
            this.txtTenhang.Location = new System.Drawing.Point(129, 73);
            this.txtTenhang.Margin = new System.Windows.Forms.Padding(4);
            this.txtTenhang.Name = "txtTenhang";
            this.txtTenhang.Size = new System.Drawing.Size(183, 25);
            this.txtTenhang.TabIndex = 8;
            // 
            // txtMahang
            // 
            this.txtMahang.Location = new System.Drawing.Point(129, 34);
            this.txtMahang.Margin = new System.Windows.Forms.Padding(4);
            this.txtMahang.Name = "txtMahang";
            this.txtMahang.Size = new System.Drawing.Size(183, 25);
            this.txtMahang.TabIndex = 7;
            // 
            // imgSP
            // 
            this.imgSP.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.imgSP.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.cart;
            this.imgSP.Location = new System.Drawing.Point(843, 27);
            this.imgSP.Margin = new System.Windows.Forms.Padding(4);
            this.imgSP.Name = "imgSP";
            this.imgSP.Size = new System.Drawing.Size(199, 169);
            this.imgSP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgSP.TabIndex = 6;
            this.imgSP.TabStop = false;
            // 
            // btnThemLoaiHang
            // 
            this.btnThemLoaiHang.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThemLoaiHang.Location = new System.Drawing.Point(321, 155);
            this.btnThemLoaiHang.Margin = new System.Windows.Forms.Padding(4);
            this.btnThemLoaiHang.Name = "btnThemLoaiHang";
            this.btnThemLoaiHang.Size = new System.Drawing.Size(43, 30);
            this.btnThemLoaiHang.TabIndex = 5;
            this.btnThemLoaiHang.UseVisualStyleBackColor = true;
            this.btnThemLoaiHang.Click += new System.EventHandler(this.btnThemLoaiHang_Click);
            // 
            // btnThemNCC
            // 
            this.btnThemNCC.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThemNCC.Location = new System.Drawing.Point(748, 155);
            this.btnThemNCC.Margin = new System.Windows.Forms.Padding(4);
            this.btnThemNCC.Name = "btnThemNCC";
            this.btnThemNCC.Size = new System.Drawing.Size(41, 30);
            this.btnThemNCC.TabIndex = 4;
            this.btnThemNCC.UseVisualStyleBackColor = true;
            this.btnThemNCC.Click += new System.EventHandler(this.btnThemNCC_Click);
            // 
            // btnThemNhom
            // 
            this.btnThemNhom.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThemNhom.Location = new System.Drawing.Point(748, 27);
            this.btnThemNhom.Margin = new System.Windows.Forms.Padding(4);
            this.btnThemNhom.Name = "btnThemNhom";
            this.btnThemNhom.Size = new System.Drawing.Size(41, 30);
            this.btnThemNhom.TabIndex = 4;
            this.btnThemNhom.UseVisualStyleBackColor = true;
            this.btnThemNhom.Click += new System.EventHandler(this.btnThemNhom_Click);
            // 
            // btnThemDVT
            // 
            this.btnThemDVT.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThemDVT.Location = new System.Drawing.Point(321, 111);
            this.btnThemDVT.Margin = new System.Windows.Forms.Padding(4);
            this.btnThemDVT.Name = "btnThemDVT";
            this.btnThemDVT.Size = new System.Drawing.Size(41, 31);
            this.btnThemDVT.TabIndex = 4;
            this.btnThemDVT.UseVisualStyleBackColor = true;
            this.btnThemDVT.Click += new System.EventHandler(this.btnThemDVT_Click);
            // 
            // cboMaloai
            // 
            this.cboMaloai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaloai.FormattingEnabled = true;
            this.cboMaloai.Location = new System.Drawing.Point(129, 155);
            this.cboMaloai.Margin = new System.Windows.Forms.Padding(4);
            this.cboMaloai.Name = "cboMaloai";
            this.cboMaloai.Size = new System.Drawing.Size(183, 26);
            this.cboMaloai.TabIndex = 3;
            // 
            // cboManhom
            // 
            this.cboManhom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboManhom.FormattingEnabled = true;
            this.cboManhom.Location = new System.Drawing.Point(552, 27);
            this.cboManhom.Margin = new System.Windows.Forms.Padding(4);
            this.cboManhom.Name = "cboManhom";
            this.cboManhom.Size = new System.Drawing.Size(187, 26);
            this.cboManhom.TabIndex = 3;
            // 
            // cboDVT
            // 
            this.cboDVT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDVT.FormattingEnabled = true;
            this.cboDVT.Location = new System.Drawing.Point(129, 111);
            this.cboDVT.Margin = new System.Windows.Forms.Padding(4);
            this.cboDVT.Name = "cboDVT";
            this.cboDVT.Size = new System.Drawing.Size(183, 26);
            this.cboDVT.TabIndex = 3;
            // 
            // txtGia
            // 
            this.txtGia.Location = new System.Drawing.Point(552, 71);
            this.txtGia.Margin = new System.Windows.Forms.Padding(4);
            this.txtGia.Name = "txtGia";
            this.txtGia.Size = new System.Drawing.Size(187, 25);
            this.txtGia.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(36, 159);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 18);
            this.label7.TabIndex = 1;
            this.label7.Text = "Loại hàng";
            // 
            // lblNCC
            // 
            this.lblNCC.AutoSize = true;
            this.lblNCC.Location = new System.Drawing.Point(448, 160);
            this.lblNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNCC.Name = "lblNCC";
            this.lblNCC.Size = new System.Drawing.Size(62, 18);
            this.lblNCC.TabIndex = 1;
            this.lblNCC.Text = "Nhà CC";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 114);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Đơn vị tính";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên Hàng";
            // 
            // lblMaNhom
            // 
            this.lblMaNhom.AutoSize = true;
            this.lblMaNhom.Location = new System.Drawing.Point(448, 38);
            this.lblMaNhom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMaNhom.Name = "lblMaNhom";
            this.lblMaNhom.Size = new System.Drawing.Size(72, 18);
            this.lblMaNhom.TabIndex = 1;
            this.lblMaNhom.Text = "Mã nhóm";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(448, 80);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 18);
            this.label5.TabIndex = 1;
            this.label5.Text = "Đơn giá";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mã hàng";
            // 
            // grbDanhMucHang
            // 
            this.grbDanhMucHang.Controls.Add(this.dtGWHanghoa);
            this.grbDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhMucHang.Location = new System.Drawing.Point(0, 0);
            this.grbDanhMucHang.Margin = new System.Windows.Forms.Padding(4);
            this.grbDanhMucHang.Name = "grbDanhMucHang";
            this.grbDanhMucHang.Padding = new System.Windows.Forms.Padding(4);
            this.grbDanhMucHang.Size = new System.Drawing.Size(1081, 362);
            this.grbDanhMucHang.TabIndex = 9;
            this.grbDanhMucHang.TabStop = false;
            this.grbDanhMucHang.Text = "Danh mục hàng hóa";
            // 
            // dtGWHanghoa
            // 
            this.dtGWHanghoa.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtGWHanghoa.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dtGWHanghoa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGWHanghoa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtGWHanghoa.Location = new System.Drawing.Point(4, 20);
            this.dtGWHanghoa.Margin = new System.Windows.Forms.Padding(4);
            this.dtGWHanghoa.Name = "dtGWHanghoa";
            this.dtGWHanghoa.ReadOnly = true;
            this.dtGWHanghoa.RowTemplate.Height = 24;
            this.dtGWHanghoa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGWHanghoa.Size = new System.Drawing.Size(1073, 338);
            this.dtGWHanghoa.TabIndex = 0;
            this.dtGWHanghoa.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtGWHanghoa_CellClick_1);
            // 
            // pnlDanhMucHang
            // 
            this.pnlDanhMucHang.Controls.Add(this.btnLuu);
            this.pnlDanhMucHang.Controls.Add(this.btnXoa);
            this.pnlDanhMucHang.Controls.Add(this.btnThem);
            this.pnlDanhMucHang.Controls.Add(this.btnSua);
            this.pnlDanhMucHang.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlDanhMucHang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlDanhMucHang.Location = new System.Drawing.Point(0, 591);
            this.pnlDanhMucHang.Margin = new System.Windows.Forms.Padding(4);
            this.pnlDanhMucHang.Name = "pnlDanhMucHang";
            this.pnlDanhMucHang.Size = new System.Drawing.Size(1081, 48);
            this.pnlDanhMucHang.TabIndex = 10;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(945, 10);
            this.btnLuu.Margin = new System.Windows.Forms.Padding(4);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(87, 31);
            this.btnLuu.TabIndex = 14;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(847, 10);
            this.btnXoa.Margin = new System.Windows.Forms.Padding(4);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(87, 31);
            this.btnXoa.TabIndex = 15;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(647, 10);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(87, 31);
            this.btnThem.TabIndex = 12;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(747, 10);
            this.btnSua.Margin = new System.Windows.Forms.Padding(4);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(87, 31);
            this.btnSua.TabIndex = 13;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // pnlDanhMucHangHoa
            // 
            this.pnlDanhMucHangHoa.Controls.Add(this.grbDanhMucHang);
            this.pnlDanhMucHangHoa.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlDanhMucHangHoa.Location = new System.Drawing.Point(0, 229);
            this.pnlDanhMucHangHoa.Margin = new System.Windows.Forms.Padding(4);
            this.pnlDanhMucHangHoa.Name = "pnlDanhMucHangHoa";
            this.pnlDanhMucHangHoa.Size = new System.Drawing.Size(1081, 362);
            this.pnlDanhMucHangHoa.TabIndex = 11;
            // 
            // cboKM
            // 
            this.cboKM.FormattingEnabled = true;
            this.cboKM.Location = new System.Drawing.Point(552, 111);
            this.cboKM.Name = "cboKM";
            this.cboKM.Size = new System.Drawing.Size(187, 26);
            this.cboKM.TabIndex = 11;
            // 
            // usrDMHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlDanhMucHangHoa);
            this.Controls.Add(this.pnlDanhMucHang);
            this.Controls.Add(this.gdbThongTinHangHoa);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "usrDMHang";
            this.Size = new System.Drawing.Size(1081, 639);
            this.gdbThongTinHangHoa.ResumeLayout(false);
            this.gdbThongTinHangHoa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).EndInit();
            this.grbDanhMucHang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGWHanghoa)).EndInit();
            this.pnlDanhMucHang.ResumeLayout(false);
            this.pnlDanhMucHangHoa.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gdbThongTinHangHoa;
        private System.Windows.Forms.ComboBox cboManhom;
        private System.Windows.Forms.ComboBox cboDVT;
        private System.Windows.Forms.TextBox txtGia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblNCC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblMaNhom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnThemNCC;
        private System.Windows.Forms.Button btnThemDVT;
        private System.Windows.Forms.Button btnThemLoaiHang;
        private System.Windows.Forms.GroupBox grbDanhMucHang;
        private System.Windows.Forms.DataGridView dtGWHanghoa;
        private System.Windows.Forms.PictureBox imgSP;
        private System.Windows.Forms.Button btnThemNhom;
        private System.Windows.Forms.ComboBox cboMaloai;
        private System.Windows.Forms.Panel pnlDanhMucHang;
        private System.Windows.Forms.Panel pnlDanhMucHangHoa;
        private System.Windows.Forms.TextBox txtTenhang;
        private System.Windows.Forms.TextBox txtMahang;
        private System.Windows.Forms.ComboBox cboNCC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.ComboBox cboKM;



    }
}
