﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucLoaiHinhKM
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLoaiKM = new System.Windows.Forms.Label();
            this.txtLoaiKM = new System.Windows.Forms.TextBox();
            this.lblDienGiai = new System.Windows.Forms.Label();
            this.txtDienGiai = new System.Windows.Forms.TextBox();
            this.grbLoaiKM = new System.Windows.Forms.GroupBox();
            this.grbLoai = new System.Windows.Forms.GroupBox();
            this.dgvDanhSachLoaiKM = new System.Windows.Forms.DataGridView();
            this.LoaiKM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DienGiai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.pnlDanhSachLoaiKM = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.grbLoaiKM.SuspendLayout();
            this.grbLoai.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachLoaiKM)).BeginInit();
            this.pnlButton.SuspendLayout();
            this.pnlDanhSachLoaiKM.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblLoaiKM
            // 
            this.lblLoaiKM.AutoSize = true;
            this.lblLoaiKM.Location = new System.Drawing.Point(20, 30);
            this.lblLoaiKM.Name = "lblLoaiKM";
            this.lblLoaiKM.Size = new System.Drawing.Size(99, 15);
            this.lblLoaiKM.TabIndex = 0;
            this.lblLoaiKM.Text = "Loại khuyến mãi";
            // 
            // txtLoaiKM
            // 
            this.txtLoaiKM.Location = new System.Drawing.Point(125, 24);
            this.txtLoaiKM.Name = "txtLoaiKM";
            this.txtLoaiKM.Size = new System.Drawing.Size(177, 21);
            this.txtLoaiKM.TabIndex = 1;
            // 
            // lblDienGiai
            // 
            this.lblDienGiai.AutoSize = true;
            this.lblDienGiai.Location = new System.Drawing.Point(64, 62);
            this.lblDienGiai.Name = "lblDienGiai";
            this.lblDienGiai.Size = new System.Drawing.Size(55, 15);
            this.lblDienGiai.TabIndex = 2;
            this.lblDienGiai.Text = "Diễn giải";
            // 
            // txtDienGiai
            // 
            this.txtDienGiai.Location = new System.Drawing.Point(125, 62);
            this.txtDienGiai.Name = "txtDienGiai";
            this.txtDienGiai.Size = new System.Drawing.Size(300, 21);
            this.txtDienGiai.TabIndex = 3;
            // 
            // grbLoaiKM
            // 
            this.grbLoaiKM.Controls.Add(this.txtDienGiai);
            this.grbLoaiKM.Controls.Add(this.lblDienGiai);
            this.grbLoaiKM.Controls.Add(this.txtLoaiKM);
            this.grbLoaiKM.Controls.Add(this.lblLoaiKM);
            this.grbLoaiKM.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbLoaiKM.Location = new System.Drawing.Point(3, 3);
            this.grbLoaiKM.Name = "grbLoaiKM";
            this.grbLoaiKM.Size = new System.Drawing.Size(459, 93);
            this.grbLoaiKM.TabIndex = 4;
            this.grbLoaiKM.TabStop = false;
            this.grbLoaiKM.Text = "Thông tin loại khuyến mãi";
            // 
            // grbLoai
            // 
            this.grbLoai.Controls.Add(this.dgvDanhSachLoaiKM);
            this.grbLoai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbLoai.Location = new System.Drawing.Point(0, 0);
            this.grbLoai.Name = "grbLoai";
            this.grbLoai.Size = new System.Drawing.Size(525, 198);
            this.grbLoai.TabIndex = 5;
            this.grbLoai.TabStop = false;
            this.grbLoai.Text = "Danh sách loại khuyến mãi";
            // 
            // dgvDanhSachLoaiKM
            // 
            this.dgvDanhSachLoaiKM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSachLoaiKM.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvDanhSachLoaiKM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachLoaiKM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LoaiKM,
            this.DienGiai});
            this.dgvDanhSachLoaiKM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSachLoaiKM.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhSachLoaiKM.Name = "dgvDanhSachLoaiKM";
            this.dgvDanhSachLoaiKM.Size = new System.Drawing.Size(519, 179);
            this.dgvDanhSachLoaiKM.TabIndex = 0;
            // 
            // LoaiKM
            // 
            this.LoaiKM.HeaderText = "Loại khuyến mãi";
            this.LoaiKM.Name = "LoaiKM";
            // 
            // DienGiai
            // 
            this.DienGiai.HeaderText = "Diễn giải";
            this.DienGiai.Name = "DienGiai";
            // 
            // pnlButton
            // 
            this.pnlButton.Controls.Add(this.btnLuu);
            this.pnlButton.Controls.Add(this.btnXoa);
            this.pnlButton.Controls.Add(this.btnThem);
            this.pnlButton.Controls.Add(this.btnSua);
            this.pnlButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButton.Location = new System.Drawing.Point(0, 295);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(525, 37);
            this.pnlButton.TabIndex = 5;
            // 
            // pnlDanhSachLoaiKM
            // 
            this.pnlDanhSachLoaiKM.Controls.Add(this.grbLoai);
            this.pnlDanhSachLoaiKM.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlDanhSachLoaiKM.Location = new System.Drawing.Point(0, 97);
            this.pnlDanhSachLoaiKM.Name = "pnlDanhSachLoaiKM";
            this.pnlDanhSachLoaiKM.Size = new System.Drawing.Size(525, 198);
            this.pnlDanhSachLoaiKM.TabIndex = 6;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(426, 6);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 10;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(352, 6);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 11;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(202, 6);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 8;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(277, 6);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 9;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // ucLoaiHinhKM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlDanhSachLoaiKM);
            this.Controls.Add(this.pnlButton);
            this.Controls.Add(this.grbLoaiKM);
            this.Name = "ucLoaiHinhKM";
            this.Size = new System.Drawing.Size(525, 332);
            this.grbLoaiKM.ResumeLayout(false);
            this.grbLoaiKM.PerformLayout();
            this.grbLoai.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachLoaiKM)).EndInit();
            this.pnlButton.ResumeLayout(false);
            this.pnlDanhSachLoaiKM.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblLoaiKM;
        private System.Windows.Forms.TextBox txtLoaiKM;
        private System.Windows.Forms.Label lblDienGiai;
        private System.Windows.Forms.TextBox txtDienGiai;
        private System.Windows.Forms.GroupBox grbLoaiKM;
        private System.Windows.Forms.GroupBox grbLoai;
        private System.Windows.Forms.DataGridView dgvDanhSachLoaiKM;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.Panel pnlDanhSachLoaiKM;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaiKM;
        private System.Windows.Forms.DataGridViewTextBoxColumn DienGiai;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
    }
}
