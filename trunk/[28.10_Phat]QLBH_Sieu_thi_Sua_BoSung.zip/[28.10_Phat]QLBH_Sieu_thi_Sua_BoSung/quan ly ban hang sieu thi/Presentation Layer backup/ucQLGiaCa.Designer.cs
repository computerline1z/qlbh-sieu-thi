﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucQLGiaCa
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMaLoaiHang = new System.Windows.Forms.Label();
            this.lblTySuat = new System.Windows.Forms.Label();
            this.txtTySuat = new System.Windows.Forms.TextBox();
            this.lblNgayApDung = new System.Windows.Forms.Label();
            this.dtpNgayHieuLuc = new System.Windows.Forms.DateTimePicker();
            this.lblNgayHetApDung = new System.Windows.Forms.Label();
            this.dtpNgayHetApDung = new System.Windows.Forms.DateTimePicker();
            this.grbThongTinGiaCa = new System.Windows.Forms.GroupBox();
            this.lblPhanTram = new System.Windows.Forms.Label();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.grbDanhSachTySuat = new System.Windows.Forms.GroupBox();
            this.dgvDanhSachTySuat = new System.Windows.Forms.DataGridView();
            this.MaNhom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TySuat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayAD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayHetAD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoMH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cboMaLoaiHang = new System.Windows.Forms.ComboBox();
            this.btnThemMaLoai = new System.Windows.Forms.Button();
            this.grbThongTinGiaCa.SuspendLayout();
            this.pnlButton.SuspendLayout();
            this.grbDanhSachTySuat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachTySuat)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMaLoaiHang
            // 
            this.lblMaLoaiHang.AutoSize = true;
            this.lblMaLoaiHang.Location = new System.Drawing.Point(40, 23);
            this.lblMaLoaiHang.Name = "lblMaLoaiHang";
            this.lblMaLoaiHang.Size = new System.Drawing.Size(59, 15);
            this.lblMaLoaiHang.TabIndex = 0;
            this.lblMaLoaiHang.Text = "Mã nhóm";
            // 
            // lblTySuat
            // 
            this.lblTySuat.AutoSize = true;
            this.lblTySuat.Location = new System.Drawing.Point(303, 26);
            this.lblTySuat.Name = "lblTySuat";
            this.lblTySuat.Size = new System.Drawing.Size(48, 15);
            this.lblTySuat.TabIndex = 0;
            this.lblTySuat.Text = "Tỷ suất";
            // 
            // txtTySuat
            // 
            this.txtTySuat.Location = new System.Drawing.Point(362, 20);
            this.txtTySuat.Name = "txtTySuat";
            this.txtTySuat.Size = new System.Drawing.Size(77, 21);
            this.txtTySuat.TabIndex = 1;
            // 
            // lblNgayApDung
            // 
            this.lblNgayApDung.AutoSize = true;
            this.lblNgayApDung.Location = new System.Drawing.Point(17, 55);
            this.lblNgayApDung.Name = "lblNgayApDung";
            this.lblNgayApDung.Size = new System.Drawing.Size(83, 15);
            this.lblNgayApDung.TabIndex = 2;
            this.lblNgayApDung.Text = "Ngày áp dụng";
            // 
            // dtpNgayHieuLuc
            // 
            this.dtpNgayHieuLuc.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayHieuLuc.Location = new System.Drawing.Point(105, 49);
            this.dtpNgayHieuLuc.Name = "dtpNgayHieuLuc";
            this.dtpNgayHieuLuc.Size = new System.Drawing.Size(120, 21);
            this.dtpNgayHieuLuc.TabIndex = 3;
            this.dtpNgayHieuLuc.Value = new System.DateTime(2011, 10, 2, 17, 26, 0, 0);
            // 
            // lblNgayHetApDung
            // 
            this.lblNgayHetApDung.AutoSize = true;
            this.lblNgayHetApDung.Location = new System.Drawing.Point(255, 52);
            this.lblNgayHetApDung.Name = "lblNgayHetApDung";
            this.lblNgayHetApDung.Size = new System.Drawing.Size(104, 15);
            this.lblNgayHetApDung.TabIndex = 2;
            this.lblNgayHetApDung.Text = "Ngày hết áp dụng";
            // 
            // dtpNgayHetApDung
            // 
            this.dtpNgayHetApDung.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayHetApDung.Location = new System.Drawing.Point(362, 49);
            this.dtpNgayHetApDung.Name = "dtpNgayHetApDung";
            this.dtpNgayHetApDung.Size = new System.Drawing.Size(97, 21);
            this.dtpNgayHetApDung.TabIndex = 3;
            // 
            // grbThongTinGiaCa
            // 
            this.grbThongTinGiaCa.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbThongTinGiaCa.AutoSize = true;
            this.grbThongTinGiaCa.Controls.Add(this.btnThemMaLoai);
            this.grbThongTinGiaCa.Controls.Add(this.cboMaLoaiHang);
            this.grbThongTinGiaCa.Controls.Add(this.dtpNgayHetApDung);
            this.grbThongTinGiaCa.Controls.Add(this.lblNgayHetApDung);
            this.grbThongTinGiaCa.Controls.Add(this.dtpNgayHieuLuc);
            this.grbThongTinGiaCa.Controls.Add(this.lblNgayApDung);
            this.grbThongTinGiaCa.Controls.Add(this.txtTySuat);
            this.grbThongTinGiaCa.Controls.Add(this.lblPhanTram);
            this.grbThongTinGiaCa.Controls.Add(this.lblTySuat);
            this.grbThongTinGiaCa.Controls.Add(this.lblMaLoaiHang);
            this.grbThongTinGiaCa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinGiaCa.Location = new System.Drawing.Point(3, 0);
            this.grbThongTinGiaCa.Name = "grbThongTinGiaCa";
            this.grbThongTinGiaCa.Size = new System.Drawing.Size(540, 93);
            this.grbThongTinGiaCa.TabIndex = 5;
            this.grbThongTinGiaCa.TabStop = false;
            this.grbThongTinGiaCa.Text = "Thông tin giá cả";
            // 
            // lblPhanTram
            // 
            this.lblPhanTram.AutoSize = true;
            this.lblPhanTram.Location = new System.Drawing.Point(443, 23);
            this.lblPhanTram.Name = "lblPhanTram";
            this.lblPhanTram.Size = new System.Drawing.Size(16, 15);
            this.lblPhanTram.TabIndex = 0;
            this.lblPhanTram.Text = "%";
            // 
            // pnlButton
            // 
            this.pnlButton.Controls.Add(this.btnLuu);
            this.pnlButton.Controls.Add(this.btnXoa);
            this.pnlButton.Controls.Add(this.btnThem);
            this.pnlButton.Controls.Add(this.btnSua);
            this.pnlButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButton.Location = new System.Drawing.Point(0, 344);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(546, 38);
            this.pnlButton.TabIndex = 6;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(459, 6);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 18;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(385, 6);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 19;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(235, 6);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 16;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(310, 6);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 17;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // grbDanhSachTySuat
            // 
            this.grbDanhSachTySuat.Controls.Add(this.dgvDanhSachTySuat);
            this.grbDanhSachTySuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhSachTySuat.Location = new System.Drawing.Point(0, 0);
            this.grbDanhSachTySuat.Name = "grbDanhSachTySuat";
            this.grbDanhSachTySuat.Size = new System.Drawing.Size(546, 245);
            this.grbDanhSachTySuat.TabIndex = 7;
            this.grbDanhSachTySuat.TabStop = false;
            this.grbDanhSachTySuat.Text = "Danh sách nhóm giá cả";
            // 
            // dgvDanhSachTySuat
            // 
            this.dgvDanhSachTySuat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSachTySuat.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvDanhSachTySuat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachTySuat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaNhom,
            this.TySuat,
            this.NgayAD,
            this.NgayHetAD,
            this.SoMH});
            this.dgvDanhSachTySuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSachTySuat.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhSachTySuat.Name = "dgvDanhSachTySuat";
            this.dgvDanhSachTySuat.Size = new System.Drawing.Size(540, 226);
            this.dgvDanhSachTySuat.TabIndex = 0;
            // 
            // MaNhom
            // 
            this.MaNhom.HeaderText = "Mã nhóm";
            this.MaNhom.Name = "MaNhom";
            // 
            // TySuat
            // 
            this.TySuat.HeaderText = "Tỷ Suất";
            this.TySuat.Name = "TySuat";
            // 
            // NgayAD
            // 
            this.NgayAD.HeaderText = "Ngày áp dụng";
            this.NgayAD.Name = "NgayAD";
            // 
            // NgayHetAD
            // 
            this.NgayHetAD.HeaderText = "Ngày hết áp dụng";
            this.NgayHetAD.Name = "NgayHetAD";
            // 
            // SoMH
            // 
            this.SoMH.HeaderText = "Số mặt hàng trong nhóm";
            this.SoMH.Name = "SoMH";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grbDanhSachTySuat);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 99);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(546, 245);
            this.panel2.TabIndex = 8;
            // 
            // cboMaLoaiHang
            // 
            this.cboMaLoaiHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaLoaiHang.FormattingEnabled = true;
            this.cboMaLoaiHang.Location = new System.Drawing.Point(105, 15);
            this.cboMaLoaiHang.Name = "cboMaLoaiHang";
            this.cboMaLoaiHang.Size = new System.Drawing.Size(120, 23);
            this.cboMaLoaiHang.TabIndex = 4;
            // 
            // btnThemMaLoai
            // 
            this.btnThemMaLoai.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThemMaLoai.Location = new System.Drawing.Point(231, 15);
            this.btnThemMaLoai.Name = "btnThemMaLoai";
            this.btnThemMaLoai.Size = new System.Drawing.Size(28, 26);
            this.btnThemMaLoai.TabIndex = 5;
            this.btnThemMaLoai.UseVisualStyleBackColor = true;
            this.btnThemMaLoai.Click += new System.EventHandler(this.btnThemMaLoai_Click);
            // 
            // ucQLGiaCa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlButton);
            this.Controls.Add(this.grbThongTinGiaCa);
            this.MaximumSize = new System.Drawing.Size(546, 382);
            this.Name = "ucQLGiaCa";
            this.Size = new System.Drawing.Size(546, 382);
            this.grbThongTinGiaCa.ResumeLayout(false);
            this.grbThongTinGiaCa.PerformLayout();
            this.pnlButton.ResumeLayout(false);
            this.grbDanhSachTySuat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachTySuat)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMaLoaiHang;
        private System.Windows.Forms.Label lblTySuat;
        private System.Windows.Forms.TextBox txtTySuat;
        private System.Windows.Forms.Label lblNgayApDung;
        private System.Windows.Forms.DateTimePicker dtpNgayHieuLuc;
        private System.Windows.Forms.Label lblNgayHetApDung;
        private System.Windows.Forms.DateTimePicker dtpNgayHetApDung;
        private System.Windows.Forms.GroupBox grbThongTinGiaCa;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.GroupBox grbDanhSachTySuat;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPhanTram;
        private System.Windows.Forms.DataGridView dgvDanhSachTySuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNhom;
        private System.Windows.Forms.DataGridViewTextBoxColumn TySuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayAD;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayHetAD;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoMH;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnThemMaLoai;
        private System.Windows.Forms.ComboBox cboMaLoaiHang;
    }
}
