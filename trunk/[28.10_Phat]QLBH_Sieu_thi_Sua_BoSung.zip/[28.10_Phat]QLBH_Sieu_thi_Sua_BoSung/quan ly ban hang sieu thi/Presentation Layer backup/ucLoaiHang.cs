﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace quan_ly_ban_hang_sieu_thi
{
    public partial class ucLoaiHang : UserControl
    {
        public ucLoaiHang()
        {
            InitializeComponent();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {

        }

        private void lblTenLoai_Click(object sender, EventArgs e)
        {

        }

        private void txtTenLoai_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
