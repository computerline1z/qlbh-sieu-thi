-- ================================================
-- Template generated from Template Explorer using:
-- Create Trigger (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- See additional Create Trigger templates for more
-- examples of different Trigger statements.
--
-- This block of comments will not be included in
-- the definition of the function.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER CapNhatTonKho
   ON  CTPHIEUNHAP
   AFTER UPDATE
AS 
BEGIN
	
	Declare @soluongChenhlech int
	Declare @mahang char(7)
	Declare @soluongton int
	Declare @tongton int
	
	set @soluongChenhlech = (select i.soluong - d.soluong from inserted i, deleted d);
	set @mahang = (select mahang from inserted);
	set @soluongton = (select tonkho from dmhang JOIN inserted ON inserted.mahang = dmhang.mahang);
	set @tongton = @soluongton + @soluongChenhlech;
	
	update dmhang set tonkho=@tongton where mahang=@mahang;
	
END
GO
