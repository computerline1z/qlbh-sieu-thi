-- ================================================
-- Template generated from Template Explorer using:
-- Create Trigger (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- See additional Create Trigger templates for more
-- examples of different Trigger statements.
--
-- This block of comments will not be included in
-- the definition of the function.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER CapNhatGiaCa
   ON  CTPHIEUNHAP
   AFTER INSERT,UPDATE
AS 
BEGIN
	Declare @gianhap money;
	Declare @tysuat float;
	set @gianhap = (select gianhap from inserted);
	set @tysuat =  (select tysuat from (select nhomhang from inserted i JOIN Dmhang d  ON i.mahang = d.mahang) as T, Tysuatgiaca ts where T.nhomhang = ts.nhomhang ) 
					
	
	update Dmhang set giaban = (@tysuat * @gianhap) + @gianhap where mahang = (select mahang from inserted);   
				  
							
END
GO
