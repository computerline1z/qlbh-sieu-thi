﻿namespace QuanLyKhoSieuThi
{
    partial class Kho_MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("Phiếu nhập");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Phiếu xuất");
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("Phiếu chuyển kho");
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("Sổ kho");
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("Thẻ kho");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("Chứng từ", new System.Windows.Forms.TreeNode[] {
            treeNode33,
            treeNode34,
            treeNode35,
            treeNode36,
            treeNode37});
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("Hàng tồn kho");
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("Hàng hoá chi tiết");
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("Hàng hoá theo loại");
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("Danh mục", new System.Windows.Forms.TreeNode[] {
            treeNode40,
            treeNode41});
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("Kho hàng");
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("Hàng hoá", new System.Windows.Forms.TreeNode[] {
            treeNode39,
            treeNode42,
            treeNode43});
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("Thông tin hàng vào ra");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("Top nhập");
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("Top xuất");
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("Báo cáo - thống kê", new System.Windows.Forms.TreeNode[] {
            treeNode45,
            treeNode46,
            treeNode47});
            this.menuStrip_Main = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smtThongTinPhienLamViec = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinTàuKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiDoiMatKhau = new System.Windows.Forms.ToolStripMenuItem();
            this.smiCapNhatThongTin = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.smiDangXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.smiThoatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.nghiệpVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiThongTinHangDaBan = new System.Windows.Forms.ToolStripMenuItem();
            this.smiInHoaDonBanLe = new System.Windows.Forms.ToolStripMenuItem();
            this.inKiểmKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiệnÍchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiMayTinhMini = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.lịchLàmViệcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiHuongDanSuDung = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.smiCapNhatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.smiBaoCaoLoi = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.smiThongTinPhanMemBanHang = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.btnKhoHang = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panelButtonTacVu = new System.Windows.Forms.Panel();
            this.NutChucNang = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxChungTu = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnDSPhieuNhap = new System.Windows.Forms.Button();
            this.groupBoxHangHoa = new System.Windows.Forms.GroupBox();
            this.btnDanhMucHang = new System.Windows.Forms.Button();
            this.btnHangTonKho = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBoxBaoCao = new System.Windows.Forms.GroupBox();
            this.btnTopXuat = new System.Windows.Forms.Button();
            this.btnTopNhap = new System.Windows.Forms.Button();
            this.btnThongTinVaoRa = new System.Windows.Forms.Button();
            this.groupBoxTienIch = new System.Windows.Forms.GroupBox();
            this.btnLichLamViec = new System.Windows.Forms.Button();
            this.btnCuoiDanhSach = new System.Windows.Forms.Button();
            this.btnToi = new System.Windows.Forms.Button();
            this.btnLui = new System.Windows.Forms.Button();
            this.btnDauDanhSach = new System.Windows.Forms.Button();
            this.txtLuu = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtXoa = new System.Windows.Forms.Button();
            this.txtSua = new System.Windows.Forms.Button();
            this.txtThem = new System.Windows.Forms.Button();
            this.menuStrip_Main.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.panelButtonTacVu.SuspendLayout();
            this.NutChucNang.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBoxChungTu.SuspendLayout();
            this.groupBoxHangHoa.SuspendLayout();
            this.groupBoxBaoCao.SuspendLayout();
            this.groupBoxTienIch.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip_Main
            // 
            this.menuStrip_Main.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.nghiệpVụToolStripMenuItem,
            this.tiệnÍchToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip_Main.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_Main.Name = "menuStrip_Main";
            this.menuStrip_Main.Size = new System.Drawing.Size(792, 24);
            this.menuStrip_Main.TabIndex = 7;
            this.menuStrip_Main.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smtThongTinPhienLamViec,
            this.thôngTinTàuKhoảnToolStripMenuItem,
            this.toolStripSeparator1,
            this.smiDangXuat,
            this.smiThoatChuongTrinh});
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.hệThốngToolStripMenuItem.Text = "&Hệ thống";
            // 
            // smtThongTinPhienLamViec
            // 
            this.smtThongTinPhienLamViec.Name = "smtThongTinPhienLamViec";
            this.smtThongTinPhienLamViec.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.smtThongTinPhienLamViec.Size = new System.Drawing.Size(246, 22);
            this.smtThongTinPhienLamViec.Text = "Thông tin &phiên làm việc";
            // 
            // thôngTinTàuKhoảnToolStripMenuItem
            // 
            this.thôngTinTàuKhoảnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiDoiMatKhau,
            this.smiCapNhatThongTin});
            this.thôngTinTàuKhoảnToolStripMenuItem.Name = "thôngTinTàuKhoảnToolStripMenuItem";
            this.thôngTinTàuKhoảnToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.thôngTinTàuKhoảnToolStripMenuItem.Text = "Tài &khoản";
            // 
            // smiDoiMatKhau
            // 
            this.smiDoiMatKhau.Name = "smiDoiMatKhau";
            this.smiDoiMatKhau.Size = new System.Drawing.Size(174, 22);
            this.smiDoiMatKhau.Text = "Đổi &mật khẩu";
            // 
            // smiCapNhatThongTin
            // 
            this.smiCapNhatThongTin.Name = "smiCapNhatThongTin";
            this.smiCapNhatThongTin.Size = new System.Drawing.Size(174, 22);
            this.smiCapNhatThongTin.Text = "&Cập nhật thông tin";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(243, 6);
            // 
            // smiDangXuat
            // 
            this.smiDangXuat.Name = "smiDangXuat";
            this.smiDangXuat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F4)));
            this.smiDangXuat.Size = new System.Drawing.Size(246, 22);
            this.smiDangXuat.Text = "Đăng &xuất";
            // 
            // smiThoatChuongTrinh
            // 
            this.smiThoatChuongTrinh.Name = "smiThoatChuongTrinh";
            this.smiThoatChuongTrinh.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.smiThoatChuongTrinh.Size = new System.Drawing.Size(246, 22);
            this.smiThoatChuongTrinh.Text = "&Thoát chương trình";
            // 
            // nghiệpVụToolStripMenuItem
            // 
            this.nghiệpVụToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiThongTinHangDaBan,
            this.smiInHoaDonBanLe,
            this.inKiểmKêToolStripMenuItem});
            this.nghiệpVụToolStripMenuItem.Name = "nghiệpVụToolStripMenuItem";
            this.nghiệpVụToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.nghiệpVụToolStripMenuItem.Text = "&Nghiệp vụ";
            // 
            // smiThongTinHangDaBan
            // 
            this.smiThongTinHangDaBan.Name = "smiThongTinHangDaBan";
            this.smiThongTinHangDaBan.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.smiThongTinHangDaBan.Size = new System.Drawing.Size(192, 22);
            this.smiThongTinHangDaBan.Text = "&Nhập hàng";
            // 
            // smiInHoaDonBanLe
            // 
            this.smiInHoaDonBanLe.Name = "smiInHoaDonBanLe";
            this.smiInHoaDonBanLe.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.smiInHoaDonBanLe.Size = new System.Drawing.Size(192, 22);
            this.smiInHoaDonBanLe.Text = "Tạo phiếu &xuất";
            // 
            // inKiểmKêToolStripMenuItem
            // 
            this.inKiểmKêToolStripMenuItem.Name = "inKiểmKêToolStripMenuItem";
            this.inKiểmKêToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.inKiểmKêToolStripMenuItem.Text = "In kiểm kê";
            // 
            // tiệnÍchToolStripMenuItem
            // 
            this.tiệnÍchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiMayTinhMini,
            this.toolStripSeparator4,
            this.lịchLàmViệcToolStripMenuItem});
            this.tiệnÍchToolStripMenuItem.Name = "tiệnÍchToolStripMenuItem";
            this.tiệnÍchToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.tiệnÍchToolStripMenuItem.Text = "Tiện &ích";
            // 
            // smiMayTinhMini
            // 
            this.smiMayTinhMini.Name = "smiMayTinhMini";
            this.smiMayTinhMini.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.smiMayTinhMini.Size = new System.Drawing.Size(189, 22);
            this.smiMayTinhMini.Text = "&Máy tính mini";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(186, 6);
            // 
            // lịchLàmViệcToolStripMenuItem
            // 
            this.lịchLàmViệcToolStripMenuItem.Name = "lịchLàmViệcToolStripMenuItem";
            this.lịchLàmViệcToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.lịchLàmViệcToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.lịchLàmViệcToolStripMenuItem.Text = "&Lịch làm việc";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiHuongDanSuDung,
            this.toolStripSeparator2,
            this.smiCapNhatChuongTrinh,
            this.smiBaoCaoLoi,
            this.toolStripSeparator3,
            this.smiThongTinPhanMemBanHang,
            this.toolStripTextBox1});
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ &giúp";
            // 
            // smiHuongDanSuDung
            // 
            this.smiHuongDanSuDung.Name = "smiHuongDanSuDung";
            this.smiHuongDanSuDung.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.smiHuongDanSuDung.Size = new System.Drawing.Size(240, 22);
            this.smiHuongDanSuDung.Text = "Hướng dẫn &sử dụng";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(237, 6);
            // 
            // smiCapNhatChuongTrinh
            // 
            this.smiCapNhatChuongTrinh.Name = "smiCapNhatChuongTrinh";
            this.smiCapNhatChuongTrinh.Size = new System.Drawing.Size(240, 22);
            this.smiCapNhatChuongTrinh.Text = "&Cập nhật chương trình";
            // 
            // smiBaoCaoLoi
            // 
            this.smiBaoCaoLoi.Name = "smiBaoCaoLoi";
            this.smiBaoCaoLoi.Size = new System.Drawing.Size(240, 22);
            this.smiBaoCaoLoi.Text = "Báo cáo &lỗi";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(237, 6);
            // 
            // smiThongTinPhanMemBanHang
            // 
            this.smiThongTinPhanMemBanHang.Name = "smiThongTinPhanMemBanHang";
            this.smiThongTinPhanMemBanHang.Size = new System.Drawing.Size(240, 22);
            this.smiThongTinPhanMemBanHang.Text = "Thông tin phần mềm &bán hàng";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.BackColor = System.Drawing.Color.White;
            this.toolStripTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.toolStripTextBox1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(120, 12);
            this.toolStripTextBox1.Text = "© 2011 QLST – Version 1.0";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripProgressBar1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 551);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(792, 22);
            this.statusStrip1.TabIndex = 9;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel1.Text = "Ready";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.splitContainer1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 88F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(792, 527);
            this.tableLayoutPanel1.TabIndex = 10;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(3, 91);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Panel2.Controls.Add(this.panelButtonTacVu);
            this.splitContainer1.Size = new System.Drawing.Size(786, 433);
            this.splitContainer1.SplitterDistance = 224;
            this.splitContainer1.TabIndex = 4;
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Name = "treeView1";
            treeNode33.Name = "nodPhieuNhap";
            treeNode33.Text = "Phiếu nhập";
            treeNode34.Name = "nodePhieuXuat";
            treeNode34.Text = "Phiếu xuất";
            treeNode35.Name = "nodePhieuChuyenKho";
            treeNode35.Text = "Phiếu chuyển kho";
            treeNode36.Name = "nodeSoKho";
            treeNode36.Text = "Sổ kho";
            treeNode37.Name = "nodeTheKho";
            treeNode37.Text = "Thẻ kho";
            treeNode38.Checked = true;
            treeNode38.Name = "nodeChungTu";
            treeNode38.StateImageKey = "(none)";
            treeNode38.Text = "Chứng từ";
            treeNode38.ToolTipText = "Các loại chứng từ của quản lý kho";
            treeNode39.Name = "nodeHangTonKho";
            treeNode39.Text = "Hàng tồn kho";
            treeNode40.Name = "nodeHangHoaChiTiet";
            treeNode40.Text = "Hàng hoá chi tiết";
            treeNode41.Name = "nodeHangHoaTheoLoai";
            treeNode41.Text = "Hàng hoá theo loại";
            treeNode42.Name = "nodeDanhMuc";
            treeNode42.Text = "Danh mục";
            treeNode43.Name = "nodeKhoHang";
            treeNode43.Text = "Kho hàng";
            treeNode44.Name = "nodeHangHoa";
            treeNode44.Text = "Hàng hoá";
            treeNode45.Name = "nodeThongTinHangVaoRa";
            treeNode45.Text = "Thông tin hàng vào ra";
            treeNode46.Name = "nodeTopNhap";
            treeNode46.Text = "Top nhập";
            treeNode47.Name = "nodeTopXuat";
            treeNode47.Text = "Top xuất";
            treeNode48.Name = "nodeBaoCaoThongKe";
            treeNode48.Text = "Báo cáo - thống kê";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode38,
            treeNode44,
            treeNode48});
            this.treeView1.Size = new System.Drawing.Size(224, 433);
            this.treeView1.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.btnKhoHang);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(558, 392);
            this.tabControl1.TabIndex = 1;
            // 
            // btnKhoHang
            // 
            this.btnKhoHang.Location = new System.Drawing.Point(4, 22);
            this.btnKhoHang.Name = "btnKhoHang";
            this.btnKhoHang.Padding = new System.Windows.Forms.Padding(3);
            this.btnKhoHang.Size = new System.Drawing.Size(550, 366);
            this.btnKhoHang.TabIndex = 0;
            this.btnKhoHang.Text = "tabPage1";
            this.btnKhoHang.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(550, 360);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panelButtonTacVu
            // 
            this.panelButtonTacVu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelButtonTacVu.Controls.Add(this.NutChucNang);
            this.panelButtonTacVu.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelButtonTacVu.Location = new System.Drawing.Point(0, 392);
            this.panelButtonTacVu.Name = "panelButtonTacVu";
            this.panelButtonTacVu.Size = new System.Drawing.Size(558, 41);
            this.panelButtonTacVu.TabIndex = 0;
            // 
            // NutChucNang
            // 
            this.NutChucNang.Controls.Add(this.btnCuoiDanhSach);
            this.NutChucNang.Controls.Add(this.btnToi);
            this.NutChucNang.Controls.Add(this.btnLui);
            this.NutChucNang.Controls.Add(this.btnDauDanhSach);
            this.NutChucNang.Controls.Add(this.txtLuu);
            this.NutChucNang.Controls.Add(this.button3);
            this.NutChucNang.Controls.Add(this.txtXoa);
            this.NutChucNang.Controls.Add(this.txtSua);
            this.NutChucNang.Controls.Add(this.txtThem);
            this.NutChucNang.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.NutChucNang.Location = new System.Drawing.Point(0, 2);
            this.NutChucNang.Name = "NutChucNang";
            this.NutChucNang.Size = new System.Drawing.Size(554, 35);
            this.NutChucNang.TabIndex = 2;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 230F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 240F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 232F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 84F));
            this.tableLayoutPanel2.Controls.Add(this.groupBoxChungTu, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxHangHoa, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxBaoCao, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBoxTienIch, 3, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(786, 79);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // groupBoxChungTu
            // 
            this.groupBoxChungTu.Controls.Add(this.button2);
            this.groupBoxChungTu.Controls.Add(this.button1);
            this.groupBoxChungTu.Controls.Add(this.btnDSPhieuNhap);
            this.groupBoxChungTu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxChungTu.Location = new System.Drawing.Point(3, 3);
            this.groupBoxChungTu.Name = "groupBoxChungTu";
            this.groupBoxChungTu.Size = new System.Drawing.Size(224, 73);
            this.groupBoxChungTu.TabIndex = 1;
            this.groupBoxChungTu.TabStop = false;
            this.groupBoxChungTu.Text = "Chứng từ chính";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(152, 19);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(68, 48);
            this.button2.TabIndex = 0;
            this.button2.Text = "DS Thẻ kho";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(78, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(68, 48);
            this.button1.TabIndex = 0;
            this.button1.Text = "DS Phiếu xuất";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnDSPhieuNhap
            // 
            this.btnDSPhieuNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDSPhieuNhap.Location = new System.Drawing.Point(4, 19);
            this.btnDSPhieuNhap.Name = "btnDSPhieuNhap";
            this.btnDSPhieuNhap.Size = new System.Drawing.Size(68, 48);
            this.btnDSPhieuNhap.TabIndex = 0;
            this.btnDSPhieuNhap.Text = "DS Phiếu nhập";
            this.btnDSPhieuNhap.UseVisualStyleBackColor = true;
            // 
            // groupBoxHangHoa
            // 
            this.groupBoxHangHoa.Controls.Add(this.btnDanhMucHang);
            this.groupBoxHangHoa.Controls.Add(this.btnHangTonKho);
            this.groupBoxHangHoa.Controls.Add(this.button5);
            this.groupBoxHangHoa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxHangHoa.Location = new System.Drawing.Point(233, 3);
            this.groupBoxHangHoa.Name = "groupBoxHangHoa";
            this.groupBoxHangHoa.Size = new System.Drawing.Size(234, 73);
            this.groupBoxHangHoa.TabIndex = 1;
            this.groupBoxHangHoa.TabStop = false;
            this.groupBoxHangHoa.Text = "Hàng hoá";
            // 
            // btnDanhMucHang
            // 
            this.btnDanhMucHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDanhMucHang.Location = new System.Drawing.Point(154, 19);
            this.btnDanhMucHang.Name = "btnDanhMucHang";
            this.btnDanhMucHang.Size = new System.Drawing.Size(74, 48);
            this.btnDanhMucHang.TabIndex = 0;
            this.btnDanhMucHang.Text = "Danh mục hàng";
            this.btnDanhMucHang.UseVisualStyleBackColor = true;
            // 
            // btnHangTonKho
            // 
            this.btnHangTonKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHangTonKho.Location = new System.Drawing.Point(80, 19);
            this.btnHangTonKho.Name = "btnHangTonKho";
            this.btnHangTonKho.Size = new System.Drawing.Size(68, 48);
            this.btnHangTonKho.TabIndex = 0;
            this.btnHangTonKho.Text = "Hàng tồn kho";
            this.btnHangTonKho.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(6, 19);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(68, 48);
            this.button5.TabIndex = 0;
            this.button5.Text = "Kho hàng";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // groupBoxBaoCao
            // 
            this.groupBoxBaoCao.Controls.Add(this.btnTopXuat);
            this.groupBoxBaoCao.Controls.Add(this.btnTopNhap);
            this.groupBoxBaoCao.Controls.Add(this.btnThongTinVaoRa);
            this.groupBoxBaoCao.Location = new System.Drawing.Point(473, 3);
            this.groupBoxBaoCao.Name = "groupBoxBaoCao";
            this.groupBoxBaoCao.Size = new System.Drawing.Size(226, 73);
            this.groupBoxBaoCao.TabIndex = 1;
            this.groupBoxBaoCao.TabStop = false;
            this.groupBoxBaoCao.Text = "Báo cáo - thống kê";
            // 
            // btnTopXuat
            // 
            this.btnTopXuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTopXuat.Location = new System.Drawing.Point(153, 19);
            this.btnTopXuat.Name = "btnTopXuat";
            this.btnTopXuat.Size = new System.Drawing.Size(68, 48);
            this.btnTopXuat.TabIndex = 0;
            this.btnTopXuat.Text = "Top xuất";
            this.btnTopXuat.UseVisualStyleBackColor = true;
            // 
            // btnTopNhap
            // 
            this.btnTopNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTopNhap.Location = new System.Drawing.Point(79, 19);
            this.btnTopNhap.Name = "btnTopNhap";
            this.btnTopNhap.Size = new System.Drawing.Size(68, 48);
            this.btnTopNhap.TabIndex = 0;
            this.btnTopNhap.Text = "Top nhập";
            this.btnTopNhap.UseVisualStyleBackColor = true;
            // 
            // btnThongTinVaoRa
            // 
            this.btnThongTinVaoRa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongTinVaoRa.Location = new System.Drawing.Point(5, 19);
            this.btnThongTinVaoRa.Name = "btnThongTinVaoRa";
            this.btnThongTinVaoRa.Size = new System.Drawing.Size(68, 48);
            this.btnThongTinVaoRa.TabIndex = 0;
            this.btnThongTinVaoRa.Text = "Thông tin vào ra kho";
            this.btnThongTinVaoRa.UseVisualStyleBackColor = true;
            // 
            // groupBoxTienIch
            // 
            this.groupBoxTienIch.Controls.Add(this.btnLichLamViec);
            this.groupBoxTienIch.Location = new System.Drawing.Point(705, 3);
            this.groupBoxTienIch.Name = "groupBoxTienIch";
            this.groupBoxTienIch.Size = new System.Drawing.Size(78, 73);
            this.groupBoxTienIch.TabIndex = 2;
            this.groupBoxTienIch.TabStop = false;
            this.groupBoxTienIch.Text = "Tiện ích";
            // 
            // btnLichLamViec
            // 
            this.btnLichLamViec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLichLamViec.Location = new System.Drawing.Point(4, 19);
            this.btnLichLamViec.Name = "btnLichLamViec";
            this.btnLichLamViec.Size = new System.Drawing.Size(70, 48);
            this.btnLichLamViec.TabIndex = 0;
            this.btnLichLamViec.Text = "Lịch Làm Việc";
            this.btnLichLamViec.UseVisualStyleBackColor = true;
            // 
            // btnCuoiDanhSach
            // 
            this.btnCuoiDanhSach.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.next_green;
            this.btnCuoiDanhSach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCuoiDanhSach.Location = new System.Drawing.Point(89, 5);
            this.btnCuoiDanhSach.Name = "btnCuoiDanhSach";
            this.btnCuoiDanhSach.Size = new System.Drawing.Size(25, 25);
            this.btnCuoiDanhSach.TabIndex = 3;
            this.btnCuoiDanhSach.UseVisualStyleBackColor = true;
            // 
            // btnToi
            // 
            this.btnToi.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.play_green;
            this.btnToi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnToi.Location = new System.Drawing.Point(62, 5);
            this.btnToi.Name = "btnToi";
            this.btnToi.Size = new System.Drawing.Size(25, 25);
            this.btnToi.TabIndex = 2;
            this.btnToi.UseVisualStyleBackColor = true;
            // 
            // btnLui
            // 
            this.btnLui.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.reverse_green;
            this.btnLui.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLui.Location = new System.Drawing.Point(35, 5);
            this.btnLui.Name = "btnLui";
            this.btnLui.Size = new System.Drawing.Size(25, 25);
            this.btnLui.TabIndex = 1;
            this.btnLui.UseVisualStyleBackColor = true;
            // 
            // btnDauDanhSach
            // 
            this.btnDauDanhSach.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.previous_green;
            this.btnDauDanhSach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDauDanhSach.Location = new System.Drawing.Point(8, 5);
            this.btnDauDanhSach.Name = "btnDauDanhSach";
            this.btnDauDanhSach.Size = new System.Drawing.Size(25, 25);
            this.btnDauDanhSach.TabIndex = 0;
            this.btnDauDanhSach.UseVisualStyleBackColor = true;
            // 
            // txtLuu
            // 
            this.txtLuu.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.txtLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtLuu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtLuu.Location = new System.Drawing.Point(249, 5);
            this.txtLuu.Name = "txtLuu";
            this.txtLuu.Size = new System.Drawing.Size(59, 25);
            this.txtLuu.TabIndex = 6;
            this.txtLuu.Text = "&Lưu";
            this.txtLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtLuu.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.bullet_cross;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button3.Dock = System.Windows.Forms.DockStyle.Right;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(486, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(68, 35);
            this.button3.TabIndex = 7;
            this.button3.Text = "&Đón&g";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // txtXoa
            // 
            this.txtXoa.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.delete_Icon;
            this.txtXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtXoa.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtXoa.Location = new System.Drawing.Point(310, 5);
            this.txtXoa.Name = "txtXoa";
            this.txtXoa.Size = new System.Drawing.Size(59, 25);
            this.txtXoa.TabIndex = 7;
            this.txtXoa.Text = "&Xoá";
            this.txtXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtXoa.UseVisualStyleBackColor = true;
            // 
            // txtSua
            // 
            this.txtSua.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.icon_edit;
            this.txtSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtSua.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtSua.Location = new System.Drawing.Point(188, 5);
            this.txtSua.Name = "txtSua";
            this.txtSua.Size = new System.Drawing.Size(59, 25);
            this.txtSua.TabIndex = 5;
            this.txtSua.Text = "&Sửa";
            this.txtSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtSua.UseVisualStyleBackColor = true;
            // 
            // txtThem
            // 
            this.txtThem.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.add_icon;
            this.txtThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtThem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtThem.Location = new System.Drawing.Point(120, 5);
            this.txtThem.Name = "txtThem";
            this.txtThem.Size = new System.Drawing.Size(65, 25);
            this.txtThem.TabIndex = 4;
            this.txtThem.Text = "&Thêm";
            this.txtThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtThem.UseVisualStyleBackColor = true;
            // 
            // Kho_MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 573);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip_Main);
            this.Name = "Kho_MainForm";
            this.Text = "QLST --- Quản lý kho";
            this.menuStrip_Main.ResumeLayout(false);
            this.menuStrip_Main.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.panelButtonTacVu.ResumeLayout(false);
            this.NutChucNang.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBoxChungTu.ResumeLayout(false);
            this.groupBoxHangHoa.ResumeLayout(false);
            this.groupBoxBaoCao.ResumeLayout(false);
            this.groupBoxTienIch.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip_Main;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smtThongTinPhienLamViec;
        private System.Windows.Forms.ToolStripMenuItem thôngTinTàuKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smiDoiMatKhau;
        private System.Windows.Forms.ToolStripMenuItem smiCapNhatThongTin;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem smiDangXuat;
        private System.Windows.Forms.ToolStripMenuItem smiThoatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem nghiệpVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smiThongTinHangDaBan;
        private System.Windows.Forms.ToolStripMenuItem smiInHoaDonBanLe;
        private System.Windows.Forms.ToolStripMenuItem inKiểmKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiệnÍchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smiMayTinhMini;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem lịchLàmViệcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smiHuongDanSuDung;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem smiCapNhatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem smiBaoCaoLoi;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem smiThongTinPhanMemBanHang;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBoxChungTu;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnDSPhieuNhap;
        private System.Windows.Forms.GroupBox groupBoxHangHoa;
        private System.Windows.Forms.Button btnDanhMucHang;
        private System.Windows.Forms.Button btnHangTonKho;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBoxBaoCao;
        private System.Windows.Forms.Button btnTopXuat;
        private System.Windows.Forms.Button btnTopNhap;
        private System.Windows.Forms.Button btnThongTinVaoRa;
        private System.Windows.Forms.GroupBox groupBoxTienIch;
        private System.Windows.Forms.Button btnLichLamViec;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage btnKhoHang;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panelButtonTacVu;
        private System.Windows.Forms.Panel NutChucNang;
        private System.Windows.Forms.Button btnCuoiDanhSach;
        private System.Windows.Forms.Button btnToi;
        private System.Windows.Forms.Button btnLui;
        private System.Windows.Forms.Button btnDauDanhSach;
        private System.Windows.Forms.Button txtLuu;
        private System.Windows.Forms.Button txtXoa;
        private System.Windows.Forms.Button txtSua;
        private System.Windows.Forms.Button txtThem;
        private System.Windows.Forms.Button button3;
    }
}

