﻿namespace QuanLyKhoSieuThi
{
    partial class ucPhieuNhapKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbThongTinPhieuNhap = new System.Windows.Forms.GroupBox();
            this.dgvThongTinPN = new System.Windows.Forms.DataGridView();
            this.MaPN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNCC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongGT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbChiTietNhap = new System.Windows.Forms.GroupBox();
            this.dgvChiTietPhieuNhap = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinPhieuNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPN)).BeginInit();
            this.grbChiTietNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuNhap)).BeginInit();
            this.SuspendLayout();
            // 
            // grbThongTinPhieuNhap
            // 
            this.grbThongTinPhieuNhap.Controls.Add(this.dgvThongTinPN);
            this.grbThongTinPhieuNhap.Dock = System.Windows.Forms.DockStyle.Top;
            this.grbThongTinPhieuNhap.Location = new System.Drawing.Point(0, 0);
            this.grbThongTinPhieuNhap.Name = "grbThongTinPhieuNhap";
            this.grbThongTinPhieuNhap.Size = new System.Drawing.Size(800, 249);
            this.grbThongTinPhieuNhap.TabIndex = 1;
            this.grbThongTinPhieuNhap.TabStop = false;
            this.grbThongTinPhieuNhap.Text = "Thông tin phiếu nhập kho";
            // 
            // dgvThongTinPN
            // 
            this.dgvThongTinPN.AllowUserToOrderColumns = true;
            this.dgvThongTinPN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinPN.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvThongTinPN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinPN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPN,
            this.MaNCC,
            this.MaKho,
            this.NgayNhap,
            this.TongGT});
            this.dgvThongTinPN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinPN.Location = new System.Drawing.Point(3, 16);
            this.dgvThongTinPN.Name = "dgvThongTinPN";
            this.dgvThongTinPN.Size = new System.Drawing.Size(794, 230);
            this.dgvThongTinPN.TabIndex = 0;
            // 
            // MaPN
            // 
            this.MaPN.HeaderText = "Mã phiếu nhập";
            this.MaPN.Name = "MaPN";
            // 
            // MaNCC
            // 
            this.MaNCC.HeaderText = "Mã NCC";
            this.MaNCC.Name = "MaNCC";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // NgayNhap
            // 
            this.NgayNhap.HeaderText = "Ngày nhập";
            this.NgayNhap.Name = "NgayNhap";
            // 
            // TongGT
            // 
            this.TongGT.HeaderText = "Tổng giá trị";
            this.TongGT.Name = "TongGT";
            // 
            // grbChiTietNhap
            // 
            this.grbChiTietNhap.Controls.Add(this.dgvChiTietPhieuNhap);
            this.grbChiTietNhap.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.grbChiTietNhap.Location = new System.Drawing.Point(0, 255);
            this.grbChiTietNhap.Name = "grbChiTietNhap";
            this.grbChiTietNhap.Size = new System.Drawing.Size(800, 318);
            this.grbChiTietNhap.TabIndex = 2;
            this.grbChiTietNhap.TabStop = false;
            this.grbChiTietNhap.Text = "Chi tiết phiếu nhập kho";
            // 
            // dgvChiTietPhieuNhap
            // 
            this.dgvChiTietPhieuNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPhieuNhap.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvChiTietPhieuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPhieuNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.MaLoai,
            this.DVT,
            this.SL,
            this.GiaNhap});
            this.dgvChiTietPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChiTietPhieuNhap.Location = new System.Drawing.Point(3, 16);
            this.dgvChiTietPhieuNhap.Name = "dgvChiTietPhieuNhap";
            this.dgvChiTietPhieuNhap.Size = new System.Drawing.Size(794, 299);
            this.dgvChiTietPhieuNhap.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã Hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên Hàng";
            this.TenHang.Name = "TenHang";
            // 
            // MaLoai
            // 
            this.MaLoai.HeaderText = "Mã loại";
            this.MaLoai.Name = "MaLoai";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // GiaNhap
            // 
            this.GiaNhap.HeaderText = "Giá nhập";
            this.GiaNhap.Name = "GiaNhap";
            // 
            // ucPhieuNhapKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grbChiTietNhap);
            this.Controls.Add(this.grbThongTinPhieuNhap);
            this.Name = "ucPhieuNhapKho";
            this.Size = new System.Drawing.Size(800, 573);
            this.grbThongTinPhieuNhap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPN)).EndInit();
            this.grbChiTietNhap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuNhap)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbThongTinPhieuNhap;
        private System.Windows.Forms.DataGridView dgvThongTinPN;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPN;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNCC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongGT;
        private System.Windows.Forms.GroupBox grbChiTietNhap;
        private System.Windows.Forms.DataGridView dgvChiTietPhieuNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaNhap;
    }
}
