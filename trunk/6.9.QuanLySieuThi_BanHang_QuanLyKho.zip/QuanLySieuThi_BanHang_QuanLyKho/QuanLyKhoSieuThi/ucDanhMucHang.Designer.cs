﻿namespace QuanLyKhoSieuThi
{
    partial class ucDanhMucHang
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucDanhMucHang));
            this.gdbThongTinHangHoa = new System.Windows.Forms.GroupBox();
            this.imgSP = new System.Windows.Forms.PictureBox();
            this.btnThemNCC = new System.Windows.Forms.Button();
            this.btnThemLoai = new System.Windows.Forms.Button();
            this.btnThemNhom = new System.Windows.Forms.Button();
            this.btnThemDVT = new System.Windows.Forms.Button();
            this.btnTimTenHang = new System.Windows.Forms.Button();
            this.btnThemMH = new System.Windows.Forms.Button();
            this.btnTimMH = new System.Windows.Forms.Button();
            this.cbTenHang = new System.Windows.Forms.ComboBox();
            this.cboMaLoai = new System.Windows.Forms.ComboBox();
            this.cboMaNhom = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblNCC = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblMaLoai = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblMaNhom = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlDanhMucHangHoa = new System.Windows.Forms.Panel();
            this.grbDanhMucHang = new System.Windows.Forms.GroupBox();
            this.dgvDanhMucHang = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNhom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNCC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gdbThongTinHangHoa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).BeginInit();
            this.pnlDanhMucHangHoa.SuspendLayout();
            this.grbDanhMucHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHang)).BeginInit();
            this.SuspendLayout();
            // 
            // gdbThongTinHangHoa
            // 
            this.gdbThongTinHangHoa.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gdbThongTinHangHoa.Controls.Add(this.imgSP);
            this.gdbThongTinHangHoa.Controls.Add(this.btnThemNCC);
            this.gdbThongTinHangHoa.Controls.Add(this.btnThemLoai);
            this.gdbThongTinHangHoa.Controls.Add(this.btnThemNhom);
            this.gdbThongTinHangHoa.Controls.Add(this.btnThemDVT);
            this.gdbThongTinHangHoa.Controls.Add(this.btnTimTenHang);
            this.gdbThongTinHangHoa.Controls.Add(this.btnThemMH);
            this.gdbThongTinHangHoa.Controls.Add(this.btnTimMH);
            this.gdbThongTinHangHoa.Controls.Add(this.cbTenHang);
            this.gdbThongTinHangHoa.Controls.Add(this.cboMaLoai);
            this.gdbThongTinHangHoa.Controls.Add(this.cboMaNhom);
            this.gdbThongTinHangHoa.Controls.Add(this.comboBox3);
            this.gdbThongTinHangHoa.Controls.Add(this.comboBox1);
            this.gdbThongTinHangHoa.Controls.Add(this.textBox1);
            this.gdbThongTinHangHoa.Controls.Add(this.textBox3);
            this.gdbThongTinHangHoa.Controls.Add(this.lblNCC);
            this.gdbThongTinHangHoa.Controls.Add(this.label3);
            this.gdbThongTinHangHoa.Controls.Add(this.lblMaLoai);
            this.gdbThongTinHangHoa.Controls.Add(this.label2);
            this.gdbThongTinHangHoa.Controls.Add(this.lblMaNhom);
            this.gdbThongTinHangHoa.Controls.Add(this.label5);
            this.gdbThongTinHangHoa.Controls.Add(this.label1);
            this.gdbThongTinHangHoa.Dock = System.Windows.Forms.DockStyle.Top;
            this.gdbThongTinHangHoa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gdbThongTinHangHoa.Location = new System.Drawing.Point(0, 0);
            this.gdbThongTinHangHoa.Name = "gdbThongTinHangHoa";
            this.gdbThongTinHangHoa.Size = new System.Drawing.Size(785, 119);
            this.gdbThongTinHangHoa.TabIndex = 9;
            this.gdbThongTinHangHoa.TabStop = false;
            this.gdbThongTinHangHoa.Text = "Thông tin hàng hóa";
            // 
            // imgSP
            // 
            this.imgSP.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.imgSP.Location = new System.Drawing.Point(655, 19);
            this.imgSP.Name = "imgSP";
            this.imgSP.Size = new System.Drawing.Size(122, 94);
            this.imgSP.TabIndex = 6;
            this.imgSP.TabStop = false;
            // 
            // btnThemNCC
            // 
            this.btnThemNCC.Image = ((System.Drawing.Image)(resources.GetObject("btnThemNCC.Image")));
            this.btnThemNCC.Location = new System.Drawing.Point(595, 89);
            this.btnThemNCC.Name = "btnThemNCC";
            this.btnThemNCC.Size = new System.Drawing.Size(26, 23);
            this.btnThemNCC.TabIndex = 4;
            this.btnThemNCC.UseVisualStyleBackColor = true;
            // 
            // btnThemLoai
            // 
            this.btnThemLoai.Image = ((System.Drawing.Image)(resources.GetObject("btnThemLoai.Image")));
            this.btnThemLoai.Location = new System.Drawing.Point(623, 23);
            this.btnThemLoai.Name = "btnThemLoai";
            this.btnThemLoai.Size = new System.Drawing.Size(26, 23);
            this.btnThemLoai.TabIndex = 4;
            this.btnThemLoai.UseVisualStyleBackColor = true;
            // 
            // btnThemNhom
            // 
            this.btnThemNhom.Image = global::QuanLyKhoSieuThi.Properties.Resources.add_icon;
            this.btnThemNhom.Location = new System.Drawing.Point(475, 23);
            this.btnThemNhom.Name = "btnThemNhom";
            this.btnThemNhom.Size = new System.Drawing.Size(26, 23);
            this.btnThemNhom.TabIndex = 4;
            this.btnThemNhom.UseVisualStyleBackColor = true;
            // 
            // btnThemDVT
            // 
            this.btnThemDVT.Image = ((System.Drawing.Image)(resources.GetObject("btnThemDVT.Image")));
            this.btnThemDVT.Location = new System.Drawing.Point(270, 90);
            this.btnThemDVT.Name = "btnThemDVT";
            this.btnThemDVT.Size = new System.Drawing.Size(26, 23);
            this.btnThemDVT.TabIndex = 4;
            this.btnThemDVT.UseVisualStyleBackColor = true;
            // 
            // btnTimTenHang
            // 
            this.btnTimTenHang.Image = global::QuanLyKhoSieuThi.Properties.Resources.search;
            this.btnTimTenHang.Location = new System.Drawing.Point(270, 59);
            this.btnTimTenHang.Name = "btnTimTenHang";
            this.btnTimTenHang.Size = new System.Drawing.Size(26, 23);
            this.btnTimTenHang.TabIndex = 4;
            this.btnTimTenHang.UseVisualStyleBackColor = true;
            // 
            // btnThemMH
            // 
            this.btnThemMH.Image = global::QuanLyKhoSieuThi.Properties.Resources.add_icon;
            this.btnThemMH.Location = new System.Drawing.Point(302, 23);
            this.btnThemMH.Name = "btnThemMH";
            this.btnThemMH.Size = new System.Drawing.Size(26, 23);
            this.btnThemMH.TabIndex = 4;
            this.btnThemMH.UseVisualStyleBackColor = true;
            // 
            // btnTimMH
            // 
            this.btnTimMH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTimMH.Image = global::QuanLyKhoSieuThi.Properties.Resources.search;
            this.btnTimMH.Location = new System.Drawing.Point(270, 23);
            this.btnTimMH.Name = "btnTimMH";
            this.btnTimMH.Size = new System.Drawing.Size(26, 23);
            this.btnTimMH.TabIndex = 4;
            this.btnTimMH.UseVisualStyleBackColor = true;
            // 
            // cbTenHang
            // 
            this.cbTenHang.FormattingEnabled = true;
            this.cbTenHang.Location = new System.Drawing.Point(76, 59);
            this.cbTenHang.Name = "cbTenHang";
            this.cbTenHang.Size = new System.Drawing.Size(187, 23);
            this.cbTenHang.TabIndex = 3;
            // 
            // cboMaLoai
            // 
            this.cboMaLoai.FormattingEnabled = true;
            this.cboMaLoai.Location = new System.Drawing.Point(558, 23);
            this.cboMaLoai.Name = "cboMaLoai";
            this.cboMaLoai.Size = new System.Drawing.Size(60, 23);
            this.cboMaLoai.TabIndex = 3;
            // 
            // cboMaNhom
            // 
            this.cboMaNhom.FormattingEnabled = true;
            this.cboMaNhom.Location = new System.Drawing.Point(407, 23);
            this.cboMaNhom.Name = "cboMaNhom";
            this.cboMaNhom.Size = new System.Drawing.Size(63, 23);
            this.cboMaNhom.TabIndex = 3;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(78, 23);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(185, 23);
            this.comboBox3.TabIndex = 3;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(78, 90);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(185, 23);
            this.comboBox1.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(403, 90);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(186, 21);
            this.textBox1.TabIndex = 2;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(403, 57);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(186, 21);
            this.textBox3.TabIndex = 2;
            // 
            // lblNCC
            // 
            this.lblNCC.AutoSize = true;
            this.lblNCC.Location = new System.Drawing.Point(345, 90);
            this.lblNCC.Name = "lblNCC";
            this.lblNCC.Size = new System.Drawing.Size(48, 15);
            this.lblNCC.TabIndex = 1;
            this.lblNCC.Text = "Nhà CC";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Đơn vị tính";
            // 
            // lblMaLoai
            // 
            this.lblMaLoai.AutoSize = true;
            this.lblMaLoai.Location = new System.Drawing.Point(505, 27);
            this.lblMaLoai.Name = "lblMaLoai";
            this.lblMaLoai.Size = new System.Drawing.Size(47, 15);
            this.lblMaLoai.TabIndex = 1;
            this.lblMaLoai.Text = "Mã loại";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên Hàng";
            // 
            // lblMaNhom
            // 
            this.lblMaNhom.AutoSize = true;
            this.lblMaNhom.Location = new System.Drawing.Point(342, 27);
            this.lblMaNhom.Name = "lblMaNhom";
            this.lblMaNhom.Size = new System.Drawing.Size(59, 15);
            this.lblMaNhom.TabIndex = 1;
            this.lblMaNhom.Text = "Mã nhóm";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(345, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 15);
            this.label5.TabIndex = 1;
            this.label5.Text = "Đơn giá";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mã hàng";
            // 
            // pnlDanhMucHangHoa
            // 
            this.pnlDanhMucHangHoa.Controls.Add(this.grbDanhMucHang);
            this.pnlDanhMucHangHoa.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlDanhMucHangHoa.Location = new System.Drawing.Point(0, 124);
            this.pnlDanhMucHangHoa.Name = "pnlDanhMucHangHoa";
            this.pnlDanhMucHangHoa.Size = new System.Drawing.Size(785, 333);
            this.pnlDanhMucHangHoa.TabIndex = 12;
            // 
            // grbDanhMucHang
            // 
            this.grbDanhMucHang.Controls.Add(this.dgvDanhMucHang);
            this.grbDanhMucHang.Dock = System.Windows.Forms.DockStyle.Top;
            this.grbDanhMucHang.Location = new System.Drawing.Point(0, 0);
            this.grbDanhMucHang.Name = "grbDanhMucHang";
            this.grbDanhMucHang.Size = new System.Drawing.Size(785, 333);
            this.grbDanhMucHang.TabIndex = 9;
            this.grbDanhMucHang.TabStop = false;
            this.grbDanhMucHang.Text = "Danh mục hàng hóa";
            // 
            // dgvDanhMucHang
            // 
            this.dgvDanhMucHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhMucHang.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvDanhMucHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhMucHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.MaNhom,
            this.MaLoai,
            this.DVT,
            this.DonGia,
            this.MaNCC});
            this.dgvDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhMucHang.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhMucHang.Name = "dgvDanhMucHang";
            this.dgvDanhMucHang.Size = new System.Drawing.Size(779, 314);
            this.dgvDanhMucHang.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // MaNhom
            // 
            this.MaNhom.HeaderText = "Mã nhóm";
            this.MaNhom.Name = "MaNhom";
            // 
            // MaLoai
            // 
            this.MaLoai.HeaderText = "Mã loại";
            this.MaLoai.Name = "MaLoai";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Đơn giá";
            this.DonGia.Name = "DonGia";
            // 
            // MaNCC
            // 
            this.MaNCC.HeaderText = "Mã NCC";
            this.MaNCC.Name = "MaNCC";
            // 
            // ucDanhMucHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlDanhMucHangHoa);
            this.Controls.Add(this.gdbThongTinHangHoa);
            this.Name = "ucDanhMucHang";
            this.Size = new System.Drawing.Size(785, 457);
            this.gdbThongTinHangHoa.ResumeLayout(false);
            this.gdbThongTinHangHoa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).EndInit();
            this.pnlDanhMucHangHoa.ResumeLayout(false);
            this.grbDanhMucHang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHang)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gdbThongTinHangHoa;
        private System.Windows.Forms.PictureBox imgSP;
        private System.Windows.Forms.Button btnThemNCC;
        private System.Windows.Forms.Button btnThemLoai;
        private System.Windows.Forms.Button btnThemNhom;
        private System.Windows.Forms.Button btnThemDVT;
        private System.Windows.Forms.Button btnTimTenHang;
        private System.Windows.Forms.Button btnThemMH;
        private System.Windows.Forms.Button btnTimMH;
        private System.Windows.Forms.ComboBox cbTenHang;
        private System.Windows.Forms.ComboBox cboMaLoai;
        private System.Windows.Forms.ComboBox cboMaNhom;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lblNCC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblMaLoai;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblMaNhom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlDanhMucHangHoa;
        private System.Windows.Forms.GroupBox grbDanhMucHang;
        private System.Windows.Forms.DataGridView dgvDanhMucHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNhom;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNCC;
    }
}
