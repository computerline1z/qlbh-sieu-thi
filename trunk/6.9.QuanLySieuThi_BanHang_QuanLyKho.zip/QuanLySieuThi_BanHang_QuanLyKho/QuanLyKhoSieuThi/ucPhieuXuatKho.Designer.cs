﻿namespace QuanLyKhoSieuThi
{
    partial class ucPhieuXuatKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbChiTietNhap = new System.Windows.Forms.GroupBox();
            this.dgvChiTietPhieuXuatKho = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinPhieuXuatKho = new System.Windows.Forms.GroupBox();
            this.dgvThongTinPX = new System.Windows.Forms.DataGridView();
            this.MaPX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.XuatCho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayXuat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongSL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongGiaTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbChiTietNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuXuatKho)).BeginInit();
            this.grbThongTinPhieuXuatKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPX)).BeginInit();
            this.SuspendLayout();
            // 
            // grbChiTietNhap
            // 
            this.grbChiTietNhap.Controls.Add(this.dgvChiTietPhieuXuatKho);
            this.grbChiTietNhap.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.grbChiTietNhap.Location = new System.Drawing.Point(0, 255);
            this.grbChiTietNhap.Name = "grbChiTietNhap";
            this.grbChiTietNhap.Size = new System.Drawing.Size(800, 318);
            this.grbChiTietNhap.TabIndex = 4;
            this.grbChiTietNhap.TabStop = false;
            this.grbChiTietNhap.Text = "Chi tiết phiếu xuất kho";
            // 
            // dgvChiTietPhieuXuatKho
            // 
            this.dgvChiTietPhieuXuatKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPhieuXuatKho.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvChiTietPhieuXuatKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPhieuXuatKho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.DonGia,
            this.DVT,
            this.SL});
            this.dgvChiTietPhieuXuatKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChiTietPhieuXuatKho.Location = new System.Drawing.Point(3, 16);
            this.dgvChiTietPhieuXuatKho.Name = "dgvChiTietPhieuXuatKho";
            this.dgvChiTietPhieuXuatKho.Size = new System.Drawing.Size(794, 299);
            this.dgvChiTietPhieuXuatKho.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã Hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên Hàng";
            this.TenHang.Name = "TenHang";
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Đơn giá";
            this.DonGia.Name = "DonGia";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // grbThongTinPhieuXuatKho
            // 
            this.grbThongTinPhieuXuatKho.Controls.Add(this.dgvThongTinPX);
            this.grbThongTinPhieuXuatKho.Dock = System.Windows.Forms.DockStyle.Top;
            this.grbThongTinPhieuXuatKho.Location = new System.Drawing.Point(0, 0);
            this.grbThongTinPhieuXuatKho.Name = "grbThongTinPhieuXuatKho";
            this.grbThongTinPhieuXuatKho.Size = new System.Drawing.Size(800, 249);
            this.grbThongTinPhieuXuatKho.TabIndex = 3;
            this.grbThongTinPhieuXuatKho.TabStop = false;
            this.grbThongTinPhieuXuatKho.Text = "Thông tin phiếu xuất kho";
            // 
            // dgvThongTinPX
            // 
            this.dgvThongTinPX.AllowUserToOrderColumns = true;
            this.dgvThongTinPX.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinPX.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvThongTinPX.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinPX.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPX,
            this.XuatCho,
            this.MaKho,
            this.NgayXuat,
            this.TongSL,
            this.TongGiaTri});
            this.dgvThongTinPX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinPX.Location = new System.Drawing.Point(3, 16);
            this.dgvThongTinPX.Name = "dgvThongTinPX";
            this.dgvThongTinPX.Size = new System.Drawing.Size(794, 230);
            this.dgvThongTinPX.TabIndex = 0;
            // 
            // MaPX
            // 
            this.MaPX.HeaderText = "Mã phiếu xuất";
            this.MaPX.Name = "MaPX";
            // 
            // XuatCho
            // 
            this.XuatCho.HeaderText = "Xuất cho";
            this.XuatCho.Name = "XuatCho";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // NgayXuat
            // 
            this.NgayXuat.HeaderText = "Ngày xuất";
            this.NgayXuat.Name = "NgayXuat";
            // 
            // TongSL
            // 
            this.TongSL.HeaderText = "Tổng số lượng";
            this.TongSL.Name = "TongSL";
            // 
            // TongGiaTri
            // 
            this.TongGiaTri.HeaderText = "Tổng giá trị";
            this.TongGiaTri.Name = "TongGiaTri";
            // 
            // ucPhieuXuatKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grbChiTietNhap);
            this.Controls.Add(this.grbThongTinPhieuXuatKho);
            this.Name = "ucPhieuXuatKho";
            this.Size = new System.Drawing.Size(800, 573);
            this.grbChiTietNhap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuXuatKho)).EndInit();
            this.grbThongTinPhieuXuatKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPX)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbChiTietNhap;
        private System.Windows.Forms.DataGridView dgvChiTietPhieuXuatKho;
        private System.Windows.Forms.GroupBox grbThongTinPhieuXuatKho;
        private System.Windows.Forms.DataGridView dgvThongTinPX;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPX;
        private System.Windows.Forms.DataGridViewTextBoxColumn XuatCho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayXuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongSL;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongGiaTri;
    }
}
