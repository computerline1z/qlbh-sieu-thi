﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace QuanLyKhoSieuThi
{
    class newTab
    {
        public void createtabPage(TabControl tabForms, string tabPageName, UserControl newUr)
        {
            tabForms.Visible = true;
            TabPage tbPage = new TabPage();
            tbPage.Text = tabPageName;
            tabForms.TabPages.Add(tbPage);
            tbPage.Controls.Add(newUr);
            tbPage.Show();
            tabForms.SelectedTab = tbPage;
        }
    }
}
