﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLyKhoSieuThi
{
    public partial class frmKho : Form
    {
        private newTab MainTab = new newTab();
        public frmKho()
        {
            InitializeComponent();
        }
        //
        // Expand TreeNode khi load form
        //
        private void frmKho_Load(object sender, EventArgs e)
        {
            treKhoChucNang.ExpandAll();
        }
        //
        // Dong Tab
        //
        private void btnDongTabPage_Click(object sender, EventArgs e)
        {
            if (tabForm.TabCount >= 1)
            {
                tabForm.Controls.Remove(tabForm.SelectedTab);
            }
            else
                return;
        }
        //
        // Open Tree node
        //
        private void treKhoChucNang_AfterSelect(object sender, TreeViewEventArgs e)
        {
            switch (treKhoChucNang.SelectedNode.Name)
            {
                case "nodePhieuNhapKho":
                    {
                        ucPhieuNhapKho PN = new ucPhieuNhapKho();
                        MainTab.createtabPage(tabForm, treKhoChucNang.SelectedNode.Text, PN);
                        break;
                    }
                case "nodePhieuXuatKho":
                    {
                        ucPhieuXuatKho PX = new ucPhieuXuatKho();
                        MainTab.createtabPage(tabForm, treKhoChucNang.SelectedNode.Text, PX);
                        break;
                    }
                case "nodePhieuChuyenKho":
                    {
                        ucPhieuChuyenKho PC = new ucPhieuChuyenKho();
                        MainTab.createtabPage(tabForm, treKhoChucNang.SelectedNode.Text, PC);
                        break;
                    }
                case "nodeSoKho":
                    {
                        ucSoKho SK = new ucSoKho();
                        MainTab.createtabPage(tabForm, treKhoChucNang.SelectedNode.Text, SK);
                        break;
                    }
                case "nodeHangTonKho":
                    {
                        ucHangTonKho SK = new ucHangTonKho();
                        MainTab.createtabPage(tabForm, treKhoChucNang.SelectedNode.Text, SK);
                        break;
                    }
                case "nodeHangHoaChiTiet":
                    {
                        ucDanhMucHang DM = new ucDanhMucHang();
                        MainTab.createtabPage(tabForm, treKhoChucNang.SelectedNode.Text, DM);
                        break;
                    }
                case "nodeThongTinHangVaoRa":
                    {
                        ucThongTinVaoRa VR = new ucThongTinVaoRa();
                        MainTab.createtabPage(tabForm, treKhoChucNang.SelectedNode.Text, VR);
                        break;
                    }
            }
        }
    }
}
