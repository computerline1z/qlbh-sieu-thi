﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLySieuThi_Winform
{
    public partial class frmBH : Form
    {
        public frmBH()
        {
            InitializeComponent();
        }

        private void hOADONLEBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.hOADONLEBindingSource.EndEdit();

        }

        private void smiThoatChuongTrinh_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
