﻿namespace QuanLyKhoSieuThi
{
    partial class ucPhieuChuyenKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbChiTietPhieuChuyenKho = new System.Windows.Forms.GroupBox();
            this.dgvChiTietPhieuNhap = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinPhieuChuyenKho = new System.Windows.Forms.GroupBox();
            this.dgvThongTinPC = new System.Windows.Forms.DataGridView();
            this.MaPC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ChuyenDenKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayChuyen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongSL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbChiTietPhieuChuyenKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuNhap)).BeginInit();
            this.grbThongTinPhieuChuyenKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPC)).BeginInit();
            this.SuspendLayout();
            // 
            // grbChiTietPhieuChuyenKho
            // 
            this.grbChiTietPhieuChuyenKho.Controls.Add(this.dgvChiTietPhieuNhap);
            this.grbChiTietPhieuChuyenKho.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.grbChiTietPhieuChuyenKho.Location = new System.Drawing.Point(0, 255);
            this.grbChiTietPhieuChuyenKho.Name = "grbChiTietPhieuChuyenKho";
            this.grbChiTietPhieuChuyenKho.Size = new System.Drawing.Size(800, 318);
            this.grbChiTietPhieuChuyenKho.TabIndex = 6;
            this.grbChiTietPhieuChuyenKho.TabStop = false;
            this.grbChiTietPhieuChuyenKho.Text = "Chi tiết phiếu chuyển kho";
            // 
            // dgvChiTietPhieuNhap
            // 
            this.dgvChiTietPhieuNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPhieuNhap.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvChiTietPhieuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPhieuNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.DonGia,
            this.DVT,
            this.SL});
            this.dgvChiTietPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChiTietPhieuNhap.Location = new System.Drawing.Point(3, 16);
            this.dgvChiTietPhieuNhap.Name = "dgvChiTietPhieuNhap";
            this.dgvChiTietPhieuNhap.Size = new System.Drawing.Size(794, 299);
            this.dgvChiTietPhieuNhap.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã Hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên Hàng";
            this.TenHang.Name = "TenHang";
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Đơn giá";
            this.DonGia.Name = "DonGia";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // grbThongTinPhieuChuyenKho
            // 
            this.grbThongTinPhieuChuyenKho.Controls.Add(this.dgvThongTinPC);
            this.grbThongTinPhieuChuyenKho.Dock = System.Windows.Forms.DockStyle.Top;
            this.grbThongTinPhieuChuyenKho.Location = new System.Drawing.Point(0, 0);
            this.grbThongTinPhieuChuyenKho.Name = "grbThongTinPhieuChuyenKho";
            this.grbThongTinPhieuChuyenKho.Size = new System.Drawing.Size(800, 249);
            this.grbThongTinPhieuChuyenKho.TabIndex = 5;
            this.grbThongTinPhieuChuyenKho.TabStop = false;
            this.grbThongTinPhieuChuyenKho.Text = "Thông tin phiếu chuyển kho";
            // 
            // dgvThongTinPC
            // 
            this.dgvThongTinPC.AllowUserToOrderColumns = true;
            this.dgvThongTinPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinPC.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvThongTinPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinPC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPC,
            this.ChuyenDenKho,
            this.MaKho,
            this.NgayChuyen,
            this.TongSL});
            this.dgvThongTinPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinPC.Location = new System.Drawing.Point(3, 16);
            this.dgvThongTinPC.Name = "dgvThongTinPC";
            this.dgvThongTinPC.Size = new System.Drawing.Size(794, 230);
            this.dgvThongTinPC.TabIndex = 0;
            // 
            // MaPC
            // 
            this.MaPC.HeaderText = "Mã phiếu Chuyển";
            this.MaPC.Name = "MaPC";
            // 
            // ChuyenDenKho
            // 
            this.ChuyenDenKho.HeaderText = "Chuyển đến kho";
            this.ChuyenDenKho.Name = "ChuyenDenKho";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // NgayChuyen
            // 
            this.NgayChuyen.HeaderText = "Ngày chuyển";
            this.NgayChuyen.Name = "NgayChuyen";
            // 
            // TongSL
            // 
            this.TongSL.HeaderText = "Tổng số lượng";
            this.TongSL.Name = "TongSL";
            // 
            // ucPhieuChuyenKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grbChiTietPhieuChuyenKho);
            this.Controls.Add(this.grbThongTinPhieuChuyenKho);
            this.Name = "ucPhieuChuyenKho";
            this.Size = new System.Drawing.Size(800, 573);
            this.grbChiTietPhieuChuyenKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuNhap)).EndInit();
            this.grbThongTinPhieuChuyenKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbChiTietPhieuChuyenKho;
        private System.Windows.Forms.DataGridView dgvChiTietPhieuNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.GroupBox grbThongTinPhieuChuyenKho;
        private System.Windows.Forms.DataGridView dgvThongTinPC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPC;
        private System.Windows.Forms.DataGridViewTextBoxColumn ChuyenDenKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayChuyen;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongSL;
    }
}
