﻿namespace QuanLySieuThi_Winform
{
    partial class frmBH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lblMaHang;
            System.Windows.Forms.Label lblLoai;
            System.Windows.Forms.Label lblTenHang;
            System.Windows.Forms.Label lblGiaBan;
            System.Windows.Forms.Label lblDonViTinh;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBH));
            this.mnusBH = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smtThongTinPhienLamViec = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinTàuKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiDoiMatKhau = new System.Windows.Forms.ToolStripMenuItem();
            this.smiCapNhatThongTin = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.smiDangXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.smiThoatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.nghiệpVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiInHoaDonBanLe = new System.Windows.Forms.ToolStripMenuItem();
            this.inhoáĐơnĐỏToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.smiThongTinHangDaBan = new System.Windows.Forms.ToolStripMenuItem();
            this.doanhthuTrongNgàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiệnÍchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiMayTinhMini = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.smiXemTiGia = new System.Windows.Forms.ToolStripMenuItem();
            this.smiDoiTien = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiHuongDanSuDung = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.smiCapNhatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.smiBaoCaoLoi = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.smiThongTinPhanMemBanHang = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.hOADONLEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stasBH = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.pnlBHMainContainer = new System.Windows.Forms.Panel();
            this.grbBHThongTinHangMua = new System.Windows.Forms.GroupBox();
            this.pnlBHNutChucNang = new System.Windows.Forms.Panel();
            this.btnCuoiDanhSach = new System.Windows.Forms.Button();
            this.btnToi = new System.Windows.Forms.Button();
            this.btnLui = new System.Windows.Forms.Button();
            this.btnDauDanhSach = new System.Windows.Forms.Button();
            this.txtLuu = new System.Windows.Forms.Button();
            this.txtXoa = new System.Windows.Forms.Button();
            this.txtSua = new System.Windows.Forms.Button();
            this.txtThem = new System.Windows.Forms.Button();
            this.dgvBHThongTinHangMua = new System.Windows.Forms.DataGridView();
            this.dgvcSTT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcMaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcTenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvDonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcSoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcDonViTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcKhuyenMai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcThanhTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblpBHKhungThanhToan = new System.Windows.Forms.TableLayoutPanel();
            this.grbThongTinMatHang = new System.Windows.Forms.GroupBox();
            this.btnInHoaDon = new System.Windows.Forms.Button();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.txtMaHang = new System.Windows.Forms.TextBox();
            this.txtLoai = new System.Windows.Forms.TextBox();
            this.txtTenHang = new System.Windows.Forms.TextBox();
            this.txtGiaBan = new System.Windows.Forms.TextBox();
            this.txtDonViTinh = new System.Windows.Forms.TextBox();
            this.grbThanhTien = new System.Windows.Forms.GroupBox();
            this.txtThoiLai = new System.Windows.Forms.TextBox();
            this.lblThoiLai = new System.Windows.Forms.Label();
            this.txtKhachTra = new System.Windows.Forms.TextBox();
            this.lblKhachTra = new System.Windows.Forms.Label();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.lblThanhTien = new System.Windows.Forms.Label();
            lblMaHang = new System.Windows.Forms.Label();
            lblLoai = new System.Windows.Forms.Label();
            lblTenHang = new System.Windows.Forms.Label();
            lblGiaBan = new System.Windows.Forms.Label();
            lblDonViTinh = new System.Windows.Forms.Label();
            this.mnusBH.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hOADONLEBindingSource)).BeginInit();
            this.stasBH.SuspendLayout();
            this.pnlBHMainContainer.SuspendLayout();
            this.grbBHThongTinHangMua.SuspendLayout();
            this.pnlBHNutChucNang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBHThongTinHangMua)).BeginInit();
            this.tblpBHKhungThanhToan.SuspendLayout();
            this.grbThongTinMatHang.SuspendLayout();
            this.grbThanhTien.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMaHang
            // 
            lblMaHang.AutoSize = true;
            lblMaHang.Location = new System.Drawing.Point(10, 32);
            lblMaHang.Name = "lblMaHang";
            lblMaHang.Size = new System.Drawing.Size(52, 13);
            lblMaHang.TabIndex = 0;
            lblMaHang.Text = "Mã hàng:";
            // 
            // lblLoai
            // 
            lblLoai.AutoSize = true;
            lblLoai.Location = new System.Drawing.Point(10, 58);
            lblLoai.Name = "lblLoai";
            lblLoai.Size = new System.Drawing.Size(30, 13);
            lblLoai.TabIndex = 1;
            lblLoai.Text = "Loại:";
            // 
            // lblTenHang
            // 
            lblTenHang.AutoSize = true;
            lblTenHang.Location = new System.Drawing.Point(10, 84);
            lblTenHang.Name = "lblTenHang";
            lblTenHang.Size = new System.Drawing.Size(56, 13);
            lblTenHang.TabIndex = 4;
            lblTenHang.Text = "Tên hàng:";
            // 
            // lblGiaBan
            // 
            lblGiaBan.AutoSize = true;
            lblGiaBan.Location = new System.Drawing.Point(10, 110);
            lblGiaBan.Name = "lblGiaBan";
            lblGiaBan.Size = new System.Drawing.Size(47, 13);
            lblGiaBan.TabIndex = 6;
            lblGiaBan.Text = "Giá bán:";
            // 
            // lblDonViTinh
            // 
            lblDonViTinh.AutoSize = true;
            lblDonViTinh.Location = new System.Drawing.Point(10, 136);
            lblDonViTinh.Name = "lblDonViTinh";
            lblDonViTinh.Size = new System.Drawing.Size(63, 13);
            lblDonViTinh.TabIndex = 8;
            lblDonViTinh.Text = "Đơn vị tính:";
            // 
            // mnusBH
            // 
            this.mnusBH.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.nghiệpVụToolStripMenuItem,
            this.tiệnÍchToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.mnusBH.Location = new System.Drawing.Point(0, 0);
            this.mnusBH.Name = "mnusBH";
            this.mnusBH.Size = new System.Drawing.Size(759, 24);
            this.mnusBH.TabIndex = 0;
            this.mnusBH.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smtThongTinPhienLamViec,
            this.thôngTinTàuKhoảnToolStripMenuItem,
            this.toolStripSeparator1,
            this.smiDangXuat,
            this.smiThoatChuongTrinh});
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.hệThốngToolStripMenuItem.Text = "&Hệ thống";
            // 
            // smtThongTinPhienLamViec
            // 
            this.smtThongTinPhienLamViec.Name = "smtThongTinPhienLamViec";
            this.smtThongTinPhienLamViec.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.smtThongTinPhienLamViec.Size = new System.Drawing.Size(246, 22);
            this.smtThongTinPhienLamViec.Text = "Thông tin &phiên làm việc";
            // 
            // thôngTinTàuKhoảnToolStripMenuItem
            // 
            this.thôngTinTàuKhoảnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiDoiMatKhau,
            this.smiCapNhatThongTin});
            this.thôngTinTàuKhoảnToolStripMenuItem.Name = "thôngTinTàuKhoảnToolStripMenuItem";
            this.thôngTinTàuKhoảnToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.thôngTinTàuKhoảnToolStripMenuItem.Text = "Tài &khoản";
            // 
            // smiDoiMatKhau
            // 
            this.smiDoiMatKhau.Name = "smiDoiMatKhau";
            this.smiDoiMatKhau.Size = new System.Drawing.Size(174, 22);
            this.smiDoiMatKhau.Text = "Đổi &mật khẩu";
            // 
            // smiCapNhatThongTin
            // 
            this.smiCapNhatThongTin.Name = "smiCapNhatThongTin";
            this.smiCapNhatThongTin.Size = new System.Drawing.Size(174, 22);
            this.smiCapNhatThongTin.Text = "&Cập nhật thông tin";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(243, 6);
            // 
            // smiDangXuat
            // 
            this.smiDangXuat.Name = "smiDangXuat";
            this.smiDangXuat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F4)));
            this.smiDangXuat.Size = new System.Drawing.Size(246, 22);
            this.smiDangXuat.Text = "Đăng &xuất";
            // 
            // smiThoatChuongTrinh
            // 
            this.smiThoatChuongTrinh.Name = "smiThoatChuongTrinh";
            this.smiThoatChuongTrinh.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.smiThoatChuongTrinh.Size = new System.Drawing.Size(246, 22);
            this.smiThoatChuongTrinh.Text = "&Thoát chương trình";
            this.smiThoatChuongTrinh.Click += new System.EventHandler(this.smiThoatChuongTrinh_Click);
            // 
            // nghiệpVụToolStripMenuItem
            // 
            this.nghiệpVụToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiInHoaDonBanLe,
            this.inhoáĐơnĐỏToolStripMenuItem,
            this.toolStripSeparator5,
            this.smiThongTinHangDaBan,
            this.doanhthuTrongNgàyToolStripMenuItem});
            this.nghiệpVụToolStripMenuItem.Name = "nghiệpVụToolStripMenuItem";
            this.nghiệpVụToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.nghiệpVụToolStripMenuItem.Text = "&Nghiệp vụ";
            // 
            // smiInHoaDonBanLe
            // 
            this.smiInHoaDonBanLe.Name = "smiInHoaDonBanLe";
            this.smiInHoaDonBanLe.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.smiInHoaDonBanLe.Size = new System.Drawing.Size(232, 22);
            this.smiInHoaDonBanLe.Text = "&In hoá đơn bán lẻ";
            // 
            // inhoáĐơnĐỏToolStripMenuItem
            // 
            this.inhoáĐơnĐỏToolStripMenuItem.Name = "inhoáĐơnĐỏToolStripMenuItem";
            this.inhoáĐơnĐỏToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.P)));
            this.inhoáĐơnĐỏToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.inhoáĐơnĐỏToolStripMenuItem.Text = "In &hoá đơn đỏ";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(229, 6);
            // 
            // smiThongTinHangDaBan
            // 
            this.smiThongTinHangDaBan.Name = "smiThongTinHangDaBan";
            this.smiThongTinHangDaBan.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.smiThongTinHangDaBan.Size = new System.Drawing.Size(232, 22);
            this.smiThongTinHangDaBan.Text = "Hoá đơn &bán lẻ";
            // 
            // doanhthuTrongNgàyToolStripMenuItem
            // 
            this.doanhthuTrongNgàyToolStripMenuItem.Name = "doanhthuTrongNgàyToolStripMenuItem";
            this.doanhthuTrongNgàyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.doanhthuTrongNgàyToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.doanhthuTrongNgàyToolStripMenuItem.Text = "Doanh &thu trong ngày";
            // 
            // tiệnÍchToolStripMenuItem
            // 
            this.tiệnÍchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiMayTinhMini,
            this.toolStripSeparator4,
            this.smiXemTiGia,
            this.smiDoiTien});
            this.tiệnÍchToolStripMenuItem.Name = "tiệnÍchToolStripMenuItem";
            this.tiệnÍchToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.tiệnÍchToolStripMenuItem.Text = "Tiện &ích";
            // 
            // smiMayTinhMini
            // 
            this.smiMayTinhMini.Name = "smiMayTinhMini";
            this.smiMayTinhMini.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.smiMayTinhMini.Size = new System.Drawing.Size(189, 22);
            this.smiMayTinhMini.Text = "&Máy tính mini";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(186, 6);
            // 
            // smiXemTiGia
            // 
            this.smiXemTiGia.Name = "smiXemTiGia";
            this.smiXemTiGia.Size = new System.Drawing.Size(189, 22);
            this.smiXemTiGia.Text = "Xem &tỉ giá";
            // 
            // smiDoiTien
            // 
            this.smiDoiTien.Name = "smiDoiTien";
            this.smiDoiTien.Size = new System.Drawing.Size(189, 22);
            this.smiDoiTien.Text = "Đổi tiề&n";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiHuongDanSuDung,
            this.toolStripSeparator2,
            this.smiCapNhatChuongTrinh,
            this.smiBaoCaoLoi,
            this.toolStripSeparator3,
            this.smiThongTinPhanMemBanHang,
            this.toolStripTextBox1});
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ &giúp";
            // 
            // smiHuongDanSuDung
            // 
            this.smiHuongDanSuDung.Name = "smiHuongDanSuDung";
            this.smiHuongDanSuDung.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.smiHuongDanSuDung.Size = new System.Drawing.Size(240, 22);
            this.smiHuongDanSuDung.Text = "Hướng dẫn &sử dụng";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(237, 6);
            // 
            // smiCapNhatChuongTrinh
            // 
            this.smiCapNhatChuongTrinh.Name = "smiCapNhatChuongTrinh";
            this.smiCapNhatChuongTrinh.Size = new System.Drawing.Size(240, 22);
            this.smiCapNhatChuongTrinh.Text = "&Cập nhật chương trình";
            // 
            // smiBaoCaoLoi
            // 
            this.smiBaoCaoLoi.Name = "smiBaoCaoLoi";
            this.smiBaoCaoLoi.Size = new System.Drawing.Size(240, 22);
            this.smiBaoCaoLoi.Text = "Báo cáo &lỗi";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(237, 6);
            // 
            // smiThongTinPhanMemBanHang
            // 
            this.smiThongTinPhanMemBanHang.Name = "smiThongTinPhanMemBanHang";
            this.smiThongTinPhanMemBanHang.Size = new System.Drawing.Size(240, 22);
            this.smiThongTinPhanMemBanHang.Text = "Thông tin phần mềm &bán hàng";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.BackColor = System.Drawing.Color.White;
            this.toolStripTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.toolStripTextBox1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(120, 12);
            this.toolStripTextBox1.Text = "© 2011 QLST – Version 1.0";
            // 
            // stasBH
            // 
            this.stasBH.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripProgressBar1});
            this.stasBH.Location = new System.Drawing.Point(0, 535);
            this.stasBH.Name = "stasBH";
            this.stasBH.Size = new System.Drawing.Size(762, 22);
            this.stasBH.TabIndex = 1;
            this.stasBH.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel1.Text = "Ready";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Margin = new System.Windows.Forms.Padding(5, 3, 1, 3);
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // pnlBHMainContainer
            // 
            this.pnlBHMainContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBHMainContainer.Controls.Add(this.tblpBHKhungThanhToan);
            this.pnlBHMainContainer.Controls.Add(this.grbBHThongTinHangMua);
            this.pnlBHMainContainer.Controls.Add(this.stasBH);
            this.pnlBHMainContainer.Location = new System.Drawing.Point(0, 24);
            this.pnlBHMainContainer.Name = "pnlBHMainContainer";
            this.pnlBHMainContainer.Size = new System.Drawing.Size(762, 557);
            this.pnlBHMainContainer.TabIndex = 1;
            // 
            // grbBHThongTinHangMua
            // 
            this.grbBHThongTinHangMua.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbBHThongTinHangMua.Controls.Add(this.pnlBHNutChucNang);
            this.grbBHThongTinHangMua.Controls.Add(this.dgvBHThongTinHangMua);
            this.grbBHThongTinHangMua.Location = new System.Drawing.Point(0, 234);
            this.grbBHThongTinHangMua.Name = "grbBHThongTinHangMua";
            this.grbBHThongTinHangMua.Size = new System.Drawing.Size(759, 296);
            this.grbBHThongTinHangMua.TabIndex = 3;
            this.grbBHThongTinHangMua.TabStop = false;
            this.grbBHThongTinHangMua.Text = "Thông tin các mặt hàng của khách hàng hiện tại";
            // 
            // pnlBHNutChucNang
            // 
            this.pnlBHNutChucNang.Controls.Add(this.btnCuoiDanhSach);
            this.pnlBHNutChucNang.Controls.Add(this.btnToi);
            this.pnlBHNutChucNang.Controls.Add(this.btnLui);
            this.pnlBHNutChucNang.Controls.Add(this.btnDauDanhSach);
            this.pnlBHNutChucNang.Controls.Add(this.txtLuu);
            this.pnlBHNutChucNang.Controls.Add(this.txtXoa);
            this.pnlBHNutChucNang.Controls.Add(this.txtSua);
            this.pnlBHNutChucNang.Controls.Add(this.txtThem);
            this.pnlBHNutChucNang.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBHNutChucNang.Location = new System.Drawing.Point(3, 258);
            this.pnlBHNutChucNang.Name = "pnlBHNutChucNang";
            this.pnlBHNutChucNang.Size = new System.Drawing.Size(753, 35);
            this.pnlBHNutChucNang.TabIndex = 1;
            // 
            // btnCuoiDanhSach
            // 
            this.btnCuoiDanhSach.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.next_green;
            this.btnCuoiDanhSach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCuoiDanhSach.Location = new System.Drawing.Point(112, 5);
            this.btnCuoiDanhSach.Name = "btnCuoiDanhSach";
            this.btnCuoiDanhSach.Size = new System.Drawing.Size(27, 27);
            this.btnCuoiDanhSach.TabIndex = 3;
            this.btnCuoiDanhSach.UseVisualStyleBackColor = true;
            // 
            // btnToi
            // 
            this.btnToi.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.play_green;
            this.btnToi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnToi.Location = new System.Drawing.Point(79, 5);
            this.btnToi.Name = "btnToi";
            this.btnToi.Size = new System.Drawing.Size(27, 27);
            this.btnToi.TabIndex = 2;
            this.btnToi.UseVisualStyleBackColor = true;
            // 
            // btnLui
            // 
            this.btnLui.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.reverse_green;
            this.btnLui.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLui.Location = new System.Drawing.Point(46, 5);
            this.btnLui.Name = "btnLui";
            this.btnLui.Size = new System.Drawing.Size(27, 27);
            this.btnLui.TabIndex = 1;
            this.btnLui.UseVisualStyleBackColor = true;
            // 
            // btnDauDanhSach
            // 
            this.btnDauDanhSach.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.previous_green;
            this.btnDauDanhSach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDauDanhSach.Location = new System.Drawing.Point(13, 5);
            this.btnDauDanhSach.Name = "btnDauDanhSach";
            this.btnDauDanhSach.Size = new System.Drawing.Size(27, 27);
            this.btnDauDanhSach.TabIndex = 0;
            this.btnDauDanhSach.UseVisualStyleBackColor = true;
            // 
            // txtLuu
            // 
            this.txtLuu.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.save_icon;
            this.txtLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtLuu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLuu.Location = new System.Drawing.Point(357, 5);
            this.txtLuu.Name = "txtLuu";
            this.txtLuu.Size = new System.Drawing.Size(86, 27);
            this.txtLuu.TabIndex = 6;
            this.txtLuu.Text = "&Lưu";
            this.txtLuu.UseVisualStyleBackColor = true;
            // 
            // txtXoa
            // 
            this.txtXoa.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.delete_Icon;
            this.txtXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtXoa.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXoa.Location = new System.Drawing.Point(451, 5);
            this.txtXoa.Name = "txtXoa";
            this.txtXoa.Size = new System.Drawing.Size(86, 27);
            this.txtXoa.TabIndex = 7;
            this.txtXoa.Text = "&Xoá";
            this.txtXoa.UseVisualStyleBackColor = true;
            // 
            // txtSua
            // 
            this.txtSua.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.icon_edit;
            this.txtSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtSua.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSua.Location = new System.Drawing.Point(263, 5);
            this.txtSua.Name = "txtSua";
            this.txtSua.Size = new System.Drawing.Size(86, 27);
            this.txtSua.TabIndex = 5;
            this.txtSua.Text = "&Sửa";
            this.txtSua.UseVisualStyleBackColor = true;
            // 
            // txtThem
            // 
            this.txtThem.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.ico;
            this.txtThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtThem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThem.Location = new System.Drawing.Point(169, 5);
            this.txtThem.Name = "txtThem";
            this.txtThem.Size = new System.Drawing.Size(86, 27);
            this.txtThem.TabIndex = 4;
            this.txtThem.Text = "&Thêm";
            this.txtThem.UseVisualStyleBackColor = true;
            // 
            // dgvBHThongTinHangMua
            // 
            this.dgvBHThongTinHangMua.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvBHThongTinHangMua.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBHThongTinHangMua.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBHThongTinHangMua.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvcSTT,
            this.dgvcMaHang,
            this.dgvcTenHang,
            this.dgvDonGia,
            this.dgvcSoLuong,
            this.dgvcDonViTinh,
            this.dgvcKhuyenMai,
            this.dgvcThanhTien});
            this.dgvBHThongTinHangMua.Location = new System.Drawing.Point(6, 19);
            this.dgvBHThongTinHangMua.Name = "dgvBHThongTinHangMua";
            this.dgvBHThongTinHangMua.Size = new System.Drawing.Size(747, 237);
            this.dgvBHThongTinHangMua.TabIndex = 0;
            // 
            // dgvcSTT
            // 
            this.dgvcSTT.FillWeight = 40F;
            this.dgvcSTT.HeaderText = "STT";
            this.dgvcSTT.Name = "dgvcSTT";
            // 
            // dgvcMaHang
            // 
            this.dgvcMaHang.FillWeight = 80F;
            this.dgvcMaHang.HeaderText = "Mã hàng";
            this.dgvcMaHang.Name = "dgvcMaHang";
            // 
            // dgvcTenHang
            // 
            this.dgvcTenHang.FillWeight = 120F;
            this.dgvcTenHang.HeaderText = "Tên Hàng";
            this.dgvcTenHang.Name = "dgvcTenHang";
            // 
            // dgvDonGia
            // 
            this.dgvDonGia.FillWeight = 70F;
            this.dgvDonGia.HeaderText = "Đơn giá";
            this.dgvDonGia.Name = "dgvDonGia";
            // 
            // dgvcSoLuong
            // 
            this.dgvcSoLuong.FillWeight = 40F;
            this.dgvcSoLuong.HeaderText = "Số lượng";
            this.dgvcSoLuong.Name = "dgvcSoLuong";
            // 
            // dgvcDonViTinh
            // 
            this.dgvcDonViTinh.FillWeight = 60F;
            this.dgvcDonViTinh.HeaderText = "ĐV Tính";
            this.dgvcDonViTinh.Name = "dgvcDonViTinh";
            // 
            // dgvcKhuyenMai
            // 
            this.dgvcKhuyenMai.FillWeight = 80F;
            this.dgvcKhuyenMai.HeaderText = "Khuyến Mãi";
            this.dgvcKhuyenMai.Name = "dgvcKhuyenMai";
            // 
            // dgvcThanhTien
            // 
            this.dgvcThanhTien.HeaderText = "Thành Tiền";
            this.dgvcThanhTien.Name = "dgvcThanhTien";
            // 
            // tblpBHKhungThanhToan
            // 
            this.tblpBHKhungThanhToan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tblpBHKhungThanhToan.AutoSize = true;
            this.tblpBHKhungThanhToan.ColumnCount = 2;
            this.tblpBHKhungThanhToan.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.90027F));
            this.tblpBHKhungThanhToan.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.09973F));
            this.tblpBHKhungThanhToan.Controls.Add(this.grbThongTinMatHang, 0, 0);
            this.tblpBHKhungThanhToan.Controls.Add(this.grbThanhTien, 1, 0);
            this.tblpBHKhungThanhToan.Location = new System.Drawing.Point(0, 0);
            this.tblpBHKhungThanhToan.Name = "tblpBHKhungThanhToan";
            this.tblpBHKhungThanhToan.RowCount = 1;
            this.tblpBHKhungThanhToan.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53F));
            this.tblpBHKhungThanhToan.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 231F));
            this.tblpBHKhungThanhToan.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 231F));
            this.tblpBHKhungThanhToan.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 231F));
            this.tblpBHKhungThanhToan.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 231F));
            this.tblpBHKhungThanhToan.Size = new System.Drawing.Size(759, 231);
            this.tblpBHKhungThanhToan.TabIndex = 2;
            // 
            // grbThongTinMatHang
            // 
            this.grbThongTinMatHang.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbThongTinMatHang.AutoSize = true;
            this.grbThongTinMatHang.Controls.Add(this.btnInHoaDon);
            this.grbThongTinMatHang.Controls.Add(lblMaHang);
            this.grbThongTinMatHang.Controls.Add(this.txtMaHang);
            this.grbThongTinMatHang.Controls.Add(lblLoai);
            this.grbThongTinMatHang.Controls.Add(this.txtLoai);
            this.grbThongTinMatHang.Controls.Add(lblTenHang);
            this.grbThongTinMatHang.Controls.Add(this.txtTenHang);
            this.grbThongTinMatHang.Controls.Add(lblGiaBan);
            this.grbThongTinMatHang.Controls.Add(this.txtGiaBan);
            this.grbThongTinMatHang.Controls.Add(lblDonViTinh);
            this.grbThongTinMatHang.Controls.Add(this.txtDonViTinh);
            this.grbThongTinMatHang.Controls.Add(this.lblSoLuong);
            this.grbThongTinMatHang.Controls.Add(this.txtSoLuong);
            this.grbThongTinMatHang.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinMatHang.Name = "grbThongTinMatHang";
            this.grbThongTinMatHang.Size = new System.Drawing.Size(349, 225);
            this.grbThongTinMatHang.TabIndex = 0;
            this.grbThongTinMatHang.TabStop = false;
            this.grbThongTinMatHang.Text = "Thông tin mặt hàng";
            // 
            // btnInHoaDon
            // 
            this.btnInHoaDon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInHoaDon.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInHoaDon.ForeColor = System.Drawing.Color.Red;
            this.btnInHoaDon.Location = new System.Drawing.Point(197, 162);
            this.btnInHoaDon.Margin = new System.Windows.Forms.Padding(0);
            this.btnInHoaDon.Name = "btnInHoaDon";
            this.btnInHoaDon.Size = new System.Drawing.Size(138, 47);
            this.btnInHoaDon.TabIndex = 12;
            this.btnInHoaDon.Text = "IN HOÁ ĐƠN";
            this.btnInHoaDon.UseVisualStyleBackColor = true;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(79, 159);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(112, 20);
            this.txtSoLuong.TabIndex = 11;
            // 
            // lblSoLuong
            // 
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Location = new System.Drawing.Point(10, 162);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(52, 13);
            this.lblSoLuong.TabIndex = 10;
            this.lblSoLuong.Text = "Số lượng:";
            // 
            // txtMaHang
            // 
            this.txtMaHang.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMaHang.Location = new System.Drawing.Point(79, 29);
            this.txtMaHang.Name = "txtMaHang";
            this.txtMaHang.Size = new System.Drawing.Size(251, 20);
            this.txtMaHang.TabIndex = 1;
            // 
            // txtLoai
            // 
            this.txtLoai.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLoai.Location = new System.Drawing.Point(79, 55);
            this.txtLoai.Name = "txtLoai";
            this.txtLoai.Size = new System.Drawing.Size(251, 20);
            this.txtLoai.TabIndex = 3;
            // 
            // txtTenHang
            // 
            this.txtTenHang.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenHang.Location = new System.Drawing.Point(79, 81);
            this.txtTenHang.Name = "txtTenHang";
            this.txtTenHang.Size = new System.Drawing.Size(251, 20);
            this.txtTenHang.TabIndex = 5;
            // 
            // txtGiaBan
            // 
            this.txtGiaBan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGiaBan.Location = new System.Drawing.Point(79, 107);
            this.txtGiaBan.Name = "txtGiaBan";
            this.txtGiaBan.Size = new System.Drawing.Size(251, 20);
            this.txtGiaBan.TabIndex = 7;
            // 
            // txtDonViTinh
            // 
            this.txtDonViTinh.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDonViTinh.Location = new System.Drawing.Point(79, 133);
            this.txtDonViTinh.Name = "txtDonViTinh";
            this.txtDonViTinh.Size = new System.Drawing.Size(251, 20);
            this.txtDonViTinh.TabIndex = 9;
            // 
            // grbThanhTien
            // 
            this.grbThanhTien.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbThanhTien.AutoSize = true;
            this.grbThanhTien.Controls.Add(this.lblThanhTien);
            this.grbThanhTien.Controls.Add(this.txtThanhTien);
            this.grbThanhTien.Controls.Add(this.lblKhachTra);
            this.grbThanhTien.Controls.Add(this.txtKhachTra);
            this.grbThanhTien.Controls.Add(this.lblThoiLai);
            this.grbThanhTien.Controls.Add(this.txtThoiLai);
            this.grbThanhTien.Location = new System.Drawing.Point(358, 3);
            this.grbThanhTien.Name = "grbThanhTien";
            this.grbThanhTien.Size = new System.Drawing.Size(398, 225);
            this.grbThanhTien.TabIndex = 1;
            this.grbThanhTien.TabStop = false;
            this.grbThanhTien.Text = "Thành tiền hoá đơn hiện tại";
            // 
            // txtThoiLai
            // 
            this.txtThoiLai.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtThoiLai.BackColor = System.Drawing.Color.DarkBlue;
            this.txtThoiLai.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThoiLai.ForeColor = System.Drawing.Color.Yellow;
            this.txtThoiLai.Location = new System.Drawing.Point(6, 169);
            this.txtThoiLai.Margin = new System.Windows.Forms.Padding(0);
            this.txtThoiLai.Name = "txtThoiLai";
            this.txtThoiLai.ReadOnly = true;
            this.txtThoiLai.Size = new System.Drawing.Size(383, 40);
            this.txtThoiLai.TabIndex = 0;
            this.txtThoiLai.Text = "0 VNĐ";
            this.txtThoiLai.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblThoiLai
            // 
            this.lblThoiLai.AutoSize = true;
            this.lblThoiLai.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblThoiLai.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThoiLai.Location = new System.Drawing.Point(6, 149);
            this.lblThoiLai.Name = "lblThoiLai";
            this.lblThoiLai.Size = new System.Drawing.Size(64, 17);
            this.lblThoiLai.TabIndex = 0;
            this.lblThoiLai.Text = "THỐI LẠI";
            // 
            // txtKhachTra
            // 
            this.txtKhachTra.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKhachTra.BackColor = System.Drawing.Color.DarkBlue;
            this.txtKhachTra.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKhachTra.ForeColor = System.Drawing.Color.Goldenrod;
            this.txtKhachTra.Location = new System.Drawing.Point(6, 106);
            this.txtKhachTra.Name = "txtKhachTra";
            this.txtKhachTra.ReadOnly = true;
            this.txtKhachTra.Size = new System.Drawing.Size(383, 40);
            this.txtKhachTra.TabIndex = 0;
            this.txtKhachTra.Text = "0 VNĐ";
            this.txtKhachTra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblKhachTra
            // 
            this.lblKhachTra.AutoSize = true;
            this.lblKhachTra.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblKhachTra.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKhachTra.Location = new System.Drawing.Point(6, 86);
            this.lblKhachTra.Name = "lblKhachTra";
            this.lblKhachTra.Size = new System.Drawing.Size(82, 17);
            this.lblKhachTra.TabIndex = 0;
            this.lblKhachTra.Text = "KHÁCH TRẢ";
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtThanhTien.BackColor = System.Drawing.Color.Lavender;
            this.txtThanhTien.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThanhTien.ForeColor = System.Drawing.Color.Red;
            this.txtThanhTien.Location = new System.Drawing.Point(6, 37);
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.ReadOnly = true;
            this.txtThanhTien.Size = new System.Drawing.Size(386, 43);
            this.txtThanhTien.TabIndex = 0;
            this.txtThanhTien.Text = "0 VNĐ";
            this.txtThanhTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblThanhTien
            // 
            this.lblThanhTien.AutoSize = true;
            this.lblThanhTien.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblThanhTien.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThanhTien.Location = new System.Drawing.Point(6, 16);
            this.lblThanhTien.Name = "lblThanhTien";
            this.lblThanhTien.Size = new System.Drawing.Size(88, 17);
            this.lblThanhTien.TabIndex = 0;
            this.lblThanhTien.Text = "THÀNH TIỀN";
            // 
            // frmBH
            // 
            this.AcceptButton = this.btnInHoaDon;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 581);
            this.Controls.Add(this.mnusBH);
            this.Controls.Add(this.pnlBHMainContainer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.mnusBH;
            this.MinimumSize = new System.Drawing.Size(767, 608);
            this.Name = "frmBH";
            this.Text = "SLST --- Bán hàng siêu thị";
            this.mnusBH.ResumeLayout(false);
            this.mnusBH.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hOADONLEBindingSource)).EndInit();
            this.stasBH.ResumeLayout(false);
            this.stasBH.PerformLayout();
            this.pnlBHMainContainer.ResumeLayout(false);
            this.pnlBHMainContainer.PerformLayout();
            this.grbBHThongTinHangMua.ResumeLayout(false);
            this.pnlBHNutChucNang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBHThongTinHangMua)).EndInit();
            this.tblpBHKhungThanhToan.ResumeLayout(false);
            this.tblpBHKhungThanhToan.PerformLayout();
            this.grbThongTinMatHang.ResumeLayout(false);
            this.grbThongTinMatHang.PerformLayout();
            this.grbThanhTien.ResumeLayout(false);
            this.grbThanhTien.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnusBH;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smtThongTinPhienLamViec;
        private System.Windows.Forms.ToolStripMenuItem thôngTinTàuKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smiDoiMatKhau;
        private System.Windows.Forms.ToolStripMenuItem smiCapNhatThongTin;
        private System.Windows.Forms.ToolStripMenuItem nghiệpVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiệnÍchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem smiDangXuat;
        private System.Windows.Forms.ToolStripMenuItem smiThoatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem smiThongTinHangDaBan;
        private System.Windows.Forms.ToolStripMenuItem smiInHoaDonBanLe;
        private System.Windows.Forms.ToolStripMenuItem smiMayTinhMini;
        private System.Windows.Forms.ToolStripMenuItem smiXemTiGia;
        private System.Windows.Forms.ToolStripMenuItem smiDoiTien;
        private System.Windows.Forms.ToolStripMenuItem smiHuongDanSuDung;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem smiCapNhatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem smiBaoCaoLoi;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem smiThongTinPhanMemBanHang;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.BindingSource hOADONLEBindingSource;
        private System.Windows.Forms.StatusStrip stasBH;
        private System.Windows.Forms.Panel pnlBHMainContainer;
        private System.Windows.Forms.TableLayoutPanel tblpBHKhungThanhToan;
        private System.Windows.Forms.GroupBox grbThongTinMatHang;
        private System.Windows.Forms.GroupBox grbThanhTien;
        private System.Windows.Forms.TextBox txtMaHang;
        private System.Windows.Forms.TextBox txtLoai;
        private System.Windows.Forms.TextBox txtTenHang;
        private System.Windows.Forms.TextBox txtGiaBan;
        private System.Windows.Forms.TextBox txtDonViTinh;
        private System.Windows.Forms.Button btnInHoaDon;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.TextBox txtThoiLai;
        private System.Windows.Forms.Label lblThoiLai;
        private System.Windows.Forms.TextBox txtKhachTra;
        private System.Windows.Forms.Label lblKhachTra;
        private System.Windows.Forms.TextBox txtThanhTien;
        private System.Windows.Forms.Label lblThanhTien;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.GroupBox grbBHThongTinHangMua;
        private System.Windows.Forms.DataGridView dgvBHThongTinHangMua;
        private System.Windows.Forms.Panel pnlBHNutChucNang;
        private System.Windows.Forms.Button txtLuu;
        private System.Windows.Forms.Button txtXoa;
        private System.Windows.Forms.Button txtSua;
        private System.Windows.Forms.Button txtThem;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcSTT;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcMaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcTenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvDonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcSoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcDonViTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcKhuyenMai;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcThanhTien;
        private System.Windows.Forms.Button btnDauDanhSach;
        private System.Windows.Forms.Button btnCuoiDanhSach;
        private System.Windows.Forms.Button btnToi;
        private System.Windows.Forms.Button btnLui;
        private System.Windows.Forms.ToolStripMenuItem inhoáĐơnĐỏToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem doanhthuTrongNgàyToolStripMenuItem;
    }
}

