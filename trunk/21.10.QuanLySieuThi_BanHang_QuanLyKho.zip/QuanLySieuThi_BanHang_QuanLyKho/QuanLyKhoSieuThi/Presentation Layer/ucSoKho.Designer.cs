﻿namespace QuanLyKhoSieuThi
{
    partial class ucSoKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucSoKho));
            this.grbThongTinSoKho = new System.Windows.Forms.GroupBox();
            this.tblpSoKho = new System.Windows.Forms.TableLayoutPanel();
            this.dgvThongTinSK = new System.Windows.Forms.DataGridView();
            this.MaChungTu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoaiChungTu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayTao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingNavigatorSK = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemSK = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemSK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemSK = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemPSK = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemSK = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemSK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemSK = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemSK = new System.Windows.Forms.ToolStripButton();
            this.grbThongTinSoKho.SuspendLayout();
            this.tblpSoKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinSK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSK)).BeginInit();
            this.bindingNavigatorSK.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbThongTinSoKho
            // 
            this.grbThongTinSoKho.Controls.Add(this.tblpSoKho);
            this.grbThongTinSoKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinSoKho.Location = new System.Drawing.Point(0, 0);
            this.grbThongTinSoKho.Name = "grbThongTinSoKho";
            this.grbThongTinSoKho.Size = new System.Drawing.Size(814, 244);
            this.grbThongTinSoKho.TabIndex = 5;
            this.grbThongTinSoKho.TabStop = false;
            this.grbThongTinSoKho.Text = "Thông tin sổ kho";
            // 
            // tblpSoKho
            // 
            this.tblpSoKho.ColumnCount = 1;
            this.tblpSoKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpSoKho.Controls.Add(this.bindingNavigatorSK, 0, 0);
            this.tblpSoKho.Controls.Add(this.dgvThongTinSK, 0, 1);
            this.tblpSoKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpSoKho.Location = new System.Drawing.Point(3, 16);
            this.tblpSoKho.Name = "tblpSoKho";
            this.tblpSoKho.RowCount = 2;
            this.tblpSoKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tblpSoKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpSoKho.Size = new System.Drawing.Size(808, 225);
            this.tblpSoKho.TabIndex = 0;
            // 
            // dgvThongTinSK
            // 
            this.dgvThongTinSK.AllowUserToOrderColumns = true;
            this.dgvThongTinSK.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinSK.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvThongTinSK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinSK.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaChungTu,
            this.LoaiChungTu,
            this.NgayTao});
            this.dgvThongTinSK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinSK.Location = new System.Drawing.Point(3, 27);
            this.dgvThongTinSK.Name = "dgvThongTinSK";
            this.dgvThongTinSK.Size = new System.Drawing.Size(802, 195);
            this.dgvThongTinSK.TabIndex = 9;
            // 
            // MaChungTu
            // 
            this.MaChungTu.HeaderText = "Mã chứng từ";
            this.MaChungTu.Name = "MaChungTu";
            // 
            // LoaiChungTu
            // 
            this.LoaiChungTu.HeaderText = "Loại chứng từ";
            this.LoaiChungTu.Name = "LoaiChungTu";
            // 
            // NgayTao
            // 
            this.NgayTao.HeaderText = "Ngày tạo";
            this.NgayTao.Name = "NgayTao";
            // 
            // bindingNavigatorSK
            // 
            this.bindingNavigatorSK.AddNewItem = this.tsbAddNewItemSK;
            this.bindingNavigatorSK.CountItem = this.tslCountItem;
            this.bindingNavigatorSK.DeleteItem = this.tsbDeleteItemSK;
            this.bindingNavigatorSK.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemSK,
            this.tsbMovePreviousItemPSK,
            this.tsSeparator,
            this.tstbPositionItemSK,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemSK,
            this.tsbMoveLastItemSK,
            this.tslSeparator2,
            this.tsbAddNewItemSK,
            this.tsbDeleteItemSK,
            this.tsbSaveNewItemSK});
            this.bindingNavigatorSK.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigatorSK.MoveFirstItem = this.tsbMoveFirstItemSK;
            this.bindingNavigatorSK.MoveLastItem = this.tsbMoveLastItemSK;
            this.bindingNavigatorSK.MoveNextItem = this.tsbMoveNextItemSK;
            this.bindingNavigatorSK.MovePreviousItem = this.tsbMovePreviousItemPSK;
            this.bindingNavigatorSK.Name = "bindingNavigatorSK";
            this.bindingNavigatorSK.PositionItem = this.tstbPositionItemSK;
            this.bindingNavigatorSK.Size = new System.Drawing.Size(808, 24);
            this.bindingNavigatorSK.TabIndex = 10;
            this.bindingNavigatorSK.Text = "bindingNavigator1";
            // 
            // tsbAddNewItemSK
            // 
            this.tsbAddNewItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemSK.Image")));
            this.tsbAddNewItemSK.Name = "tsbAddNewItemSK";
            this.tsbAddNewItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemSK.Size = new System.Drawing.Size(23, 21);
            this.tsbAddNewItemSK.Text = "Add new";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 21);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemSK
            // 
            this.tsbDeleteItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemSK.Image")));
            this.tsbDeleteItemSK.Name = "tsbDeleteItemSK";
            this.tsbDeleteItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemSK.Size = new System.Drawing.Size(23, 21);
            this.tsbDeleteItemSK.Text = "Delete";
            // 
            // tsbMoveFirstItemSK
            // 
            this.tsbMoveFirstItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemSK.Image")));
            this.tsbMoveFirstItemSK.Name = "tsbMoveFirstItemSK";
            this.tsbMoveFirstItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemSK.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveFirstItemSK.Text = "Move first";
            // 
            // tsbMovePreviousItemPSK
            // 
            this.tsbMovePreviousItemPSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemPSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemPSK.Image")));
            this.tsbMovePreviousItemPSK.Name = "tsbMovePreviousItemPSK";
            this.tsbMovePreviousItemPSK.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemPSK.Size = new System.Drawing.Size(23, 21);
            this.tsbMovePreviousItemPSK.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 24);
            // 
            // tstbPositionItemSK
            // 
            this.tstbPositionItemSK.AccessibleName = "Position";
            this.tstbPositionItemSK.AutoSize = false;
            this.tstbPositionItemSK.Name = "tstbPositionItemSK";
            this.tstbPositionItemSK.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemSK.Text = "0";
            this.tstbPositionItemSK.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbMoveNextItemSK
            // 
            this.tsbMoveNextItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemSK.Image")));
            this.tsbMoveNextItemSK.Name = "tsbMoveNextItemSK";
            this.tsbMoveNextItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemSK.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveNextItemSK.Text = "Move next";
            // 
            // tsbMoveLastItemSK
            // 
            this.tsbMoveLastItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemSK.Image")));
            this.tsbMoveLastItemSK.Name = "tsbMoveLastItemSK";
            this.tsbMoveLastItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemSK.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveLastItemSK.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbSaveNewItemSK
            // 
            this.tsbSaveNewItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemSK.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemSK.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemSK.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemSK.Name = "tsbSaveNewItemSK";
            this.tsbSaveNewItemSK.Size = new System.Drawing.Size(23, 21);
            this.tsbSaveNewItemSK.Text = "Save";
            // 
            // ucSoKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grbThongTinSoKho);
            this.Name = "ucSoKho";
            this.Size = new System.Drawing.Size(814, 244);
            this.grbThongTinSoKho.ResumeLayout(false);
            this.tblpSoKho.ResumeLayout(false);
            this.tblpSoKho.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinSK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSK)).EndInit();
            this.bindingNavigatorSK.ResumeLayout(false);
            this.bindingNavigatorSK.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbThongTinSoKho;
        private System.Windows.Forms.TableLayoutPanel tblpSoKho;
        private System.Windows.Forms.DataGridView dgvThongTinSK;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaChungTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaiChungTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayTao;
        private System.Windows.Forms.BindingNavigator bindingNavigatorSK;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemSK;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemSK;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemSK;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemPSK;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemSK;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemSK;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemSK;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemSK;
    }
}
