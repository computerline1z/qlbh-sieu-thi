﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucHangTonKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucHangTonKho));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorTK = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemTK = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemTK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemTK = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemTK = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemTK = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemTK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemTK = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemTK = new System.Windows.Forms.ToolStripButton();
            this.grbDanhMucHangTonKho = new System.Windows.Forms.GroupBox();
            this.dgvDanhMucHangTonKho = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNhom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ViTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinTonKho = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbDonViTinh = new System.Windows.Forms.ComboBox();
            this.lblDonViTinh = new System.Windows.Forms.Label();
            this.btnTimTenHang = new System.Windows.Forms.Button();
            this.btnTimMH = new System.Windows.Forms.Button();
            this.cbTenHang = new System.Windows.Forms.ComboBox();
            this.vboMaHang = new System.Windows.Forms.ComboBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.lblNCC = new System.Windows.Forms.Label();
            this.lblTenHang = new System.Windows.Forms.Label();
            this.lblMaHang = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cboMaLoai = new System.Windows.Forms.ComboBox();
            this.cboMaNhom = new System.Windows.Forms.ComboBox();
            this.txtViTriKho = new System.Windows.Forms.TextBox();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.lblMaLoai = new System.Windows.Forms.Label();
            this.lblMaNhom = new System.Windows.Forms.Label();
            this.lblViTriKho = new System.Windows.Forms.Label();
            this.lblDonGia = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.imgSP = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorTK)).BeginInit();
            this.bindingNavigatorTK.SuspendLayout();
            this.grbDanhMucHangTonKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHangTonKho)).BeginInit();
            this.grbThongTinTonKho.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.bindingNavigatorTK, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.grbDanhMucHangTonKho, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.grbThongTinTonKho, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(605, 463);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // bindingNavigatorTK
            // 
            this.bindingNavigatorTK.AddNewItem = this.tsbAddNewItemTK;
            this.bindingNavigatorTK.CountItem = this.tslCountItem;
            this.bindingNavigatorTK.DeleteItem = this.tsbDeleteItemTK;
            this.bindingNavigatorTK.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemTK,
            this.tsbMovePreviousItemTK,
            this.tsSeparator,
            this.tstbPositionItemTK,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemTK,
            this.tsbMoveLastItemTK,
            this.tslSeparator2,
            this.tsbAddNewItemTK,
            this.tsbDeleteItemTK,
            this.tsbSaveNewItemTK});
            this.bindingNavigatorTK.Location = new System.Drawing.Point(0, 435);
            this.bindingNavigatorTK.MoveFirstItem = this.tsbMoveFirstItemTK;
            this.bindingNavigatorTK.MoveLastItem = this.tsbMoveLastItemTK;
            this.bindingNavigatorTK.MoveNextItem = this.tsbMoveNextItemTK;
            this.bindingNavigatorTK.MovePreviousItem = this.tsbMovePreviousItemTK;
            this.bindingNavigatorTK.Name = "bindingNavigatorTK";
            this.bindingNavigatorTK.PositionItem = this.tstbPositionItemTK;
            this.bindingNavigatorTK.Size = new System.Drawing.Size(605, 25);
            this.bindingNavigatorTK.TabIndex = 13;
            this.bindingNavigatorTK.Text = "bindingNavigator1";
            // 
            // tsbAddNewItemTK
            // 
            this.tsbAddNewItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemTK.Image")));
            this.tsbAddNewItemTK.Name = "tsbAddNewItemTK";
            this.tsbAddNewItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbAddNewItemTK.Text = "Add new";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 22);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemTK
            // 
            this.tsbDeleteItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemTK.Image")));
            this.tsbDeleteItemTK.Name = "tsbDeleteItemTK";
            this.tsbDeleteItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbDeleteItemTK.Text = "Delete";
            // 
            // tsbMoveFirstItemTK
            // 
            this.tsbMoveFirstItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemTK.Image")));
            this.tsbMoveFirstItemTK.Name = "tsbMoveFirstItemTK";
            this.tsbMoveFirstItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveFirstItemTK.Text = "Move first";
            // 
            // tsbMovePreviousItemTK
            // 
            this.tsbMovePreviousItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemTK.Image")));
            this.tsbMovePreviousItemTK.Name = "tsbMovePreviousItemTK";
            this.tsbMovePreviousItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbMovePreviousItemTK.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // tstbPositionItemTK
            // 
            this.tstbPositionItemTK.AccessibleName = "Position";
            this.tstbPositionItemTK.AutoSize = false;
            this.tstbPositionItemTK.Name = "tstbPositionItemTK";
            this.tstbPositionItemTK.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemTK.Text = "0";
            this.tstbPositionItemTK.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbMoveNextItemTK
            // 
            this.tsbMoveNextItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemTK.Image")));
            this.tsbMoveNextItemTK.Name = "tsbMoveNextItemTK";
            this.tsbMoveNextItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveNextItemTK.Text = "Move next";
            // 
            // tsbMoveLastItemTK
            // 
            this.tsbMoveLastItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemTK.Image")));
            this.tsbMoveLastItemTK.Name = "tsbMoveLastItemTK";
            this.tsbMoveLastItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveLastItemTK.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbSaveNewItemTK
            // 
            this.tsbSaveNewItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemTK.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemTK.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemTK.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemTK.Name = "tsbSaveNewItemTK";
            this.tsbSaveNewItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbSaveNewItemTK.Text = "Save";
            // 
            // grbDanhMucHangTonKho
            // 
            this.grbDanhMucHangTonKho.Controls.Add(this.dgvDanhMucHangTonKho);
            this.grbDanhMucHangTonKho.Dock = System.Windows.Forms.DockStyle.Top;
            this.grbDanhMucHangTonKho.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDanhMucHangTonKho.Location = new System.Drawing.Point(3, 113);
            this.grbDanhMucHangTonKho.Name = "grbDanhMucHangTonKho";
            this.grbDanhMucHangTonKho.Size = new System.Drawing.Size(599, 319);
            this.grbDanhMucHangTonKho.TabIndex = 12;
            this.grbDanhMucHangTonKho.TabStop = false;
            this.grbDanhMucHangTonKho.Text = "Danh mục hàng tồn kho";
            // 
            // dgvDanhMucHangTonKho
            // 
            this.dgvDanhMucHangTonKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhMucHangTonKho.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvDanhMucHangTonKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhMucHangTonKho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.SoLuong,
            this.MaNhom,
            this.MaLoai,
            this.DonGia,
            this.DVT,
            this.ViTri});
            this.dgvDanhMucHangTonKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhMucHangTonKho.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhMucHangTonKho.Name = "dgvDanhMucHangTonKho";
            this.dgvDanhMucHangTonKho.Size = new System.Drawing.Size(593, 300);
            this.dgvDanhMucHangTonKho.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // SoLuong
            // 
            this.SoLuong.HeaderText = "Số lượng";
            this.SoLuong.Name = "SoLuong";
            // 
            // MaNhom
            // 
            this.MaNhom.HeaderText = "Mã nhóm";
            this.MaNhom.Name = "MaNhom";
            // 
            // MaLoai
            // 
            this.MaLoai.HeaderText = "Mã loại";
            this.MaLoai.Name = "MaLoai";
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Đơn giá";
            this.DonGia.Name = "DonGia";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // ViTri
            // 
            this.ViTri.HeaderText = "Vị trí kho";
            this.ViTri.Name = "ViTri";
            // 
            // grbThongTinTonKho
            // 
            this.grbThongTinTonKho.Controls.Add(this.tableLayoutPanel2);
            this.grbThongTinTonKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinTonKho.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinTonKho.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinTonKho.Name = "grbThongTinTonKho";
            this.grbThongTinTonKho.Size = new System.Drawing.Size(599, 104);
            this.grbThongTinTonKho.TabIndex = 0;
            this.grbThongTinTonKho.TabStop = false;
            this.grbThongTinTonKho.Text = "Thông tin hàng tồn kho";
            this.grbThongTinTonKho.Enter += new System.EventHandler(this.grbThongTinTonKho_Enter);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.17032F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.46037F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.19008F));
            this.tableLayoutPanel2.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel3, 2, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 85F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 85F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 85F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(593, 85);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbDonViTinh);
            this.panel1.Controls.Add(this.lblDonViTinh);
            this.panel1.Controls.Add(this.btnTimTenHang);
            this.panel1.Controls.Add(this.btnTimMH);
            this.panel1.Controls.Add(this.cbTenHang);
            this.panel1.Controls.Add(this.vboMaHang);
            this.panel1.Controls.Add(this.txtSoLuong);
            this.panel1.Controls.Add(this.lblNCC);
            this.panel1.Controls.Add(this.lblTenHang);
            this.panel1.Controls.Add(this.lblMaHang);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 79);
            this.panel1.TabIndex = 0;
            // 
            // cbDonViTinh
            // 
            this.cbDonViTinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbDonViTinh.FormattingEnabled = true;
            this.cbDonViTinh.Location = new System.Drawing.Point(178, 55);
            this.cbDonViTinh.Name = "cbDonViTinh";
            this.cbDonViTinh.Size = new System.Drawing.Size(72, 22);
            this.cbDonViTinh.TabIndex = 18;
            // 
            // lblDonViTinh
            // 
            this.lblDonViTinh.AutoSize = true;
            this.lblDonViTinh.Location = new System.Drawing.Point(112, 58);
            this.lblDonViTinh.Name = "lblDonViTinh";
            this.lblDonViTinh.Size = new System.Drawing.Size(66, 14);
            this.lblDonViTinh.TabIndex = 17;
            this.lblDonViTinh.Text = "Đơn vị tính";
            // 
            // btnTimTenHang
            // 
            this.btnTimTenHang.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnTimTenHang.Image = global::QuanLyKhoSieuThi.Properties.Resources.search;
            this.btnTimTenHang.Location = new System.Drawing.Point(224, 30);
            this.btnTimTenHang.Name = "btnTimTenHang";
            this.btnTimTenHang.Size = new System.Drawing.Size(26, 23);
            this.btnTimTenHang.TabIndex = 15;
            this.btnTimTenHang.UseVisualStyleBackColor = true;
            // 
            // btnTimMH
            // 
            this.btnTimMH.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnTimMH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTimMH.Image = global::QuanLyKhoSieuThi.Properties.Resources.search;
            this.btnTimMH.Location = new System.Drawing.Point(224, 3);
            this.btnTimMH.Name = "btnTimMH";
            this.btnTimMH.Size = new System.Drawing.Size(26, 23);
            this.btnTimMH.TabIndex = 16;
            this.btnTimMH.UseVisualStyleBackColor = true;
            // 
            // cbTenHang
            // 
            this.cbTenHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbTenHang.FormattingEnabled = true;
            this.cbTenHang.Location = new System.Drawing.Point(57, 30);
            this.cbTenHang.Name = "cbTenHang";
            this.cbTenHang.Size = new System.Drawing.Size(165, 22);
            this.cbTenHang.TabIndex = 14;
            // 
            // vboMaHang
            // 
            this.vboMaHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.vboMaHang.FormattingEnabled = true;
            this.vboMaHang.Location = new System.Drawing.Point(57, 4);
            this.vboMaHang.Name = "vboMaHang";
            this.vboMaHang.Size = new System.Drawing.Size(165, 22);
            this.vboMaHang.TabIndex = 13;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(57, 56);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(49, 20);
            this.txtSoLuong.TabIndex = 12;
            // 
            // lblNCC
            // 
            this.lblNCC.AutoSize = true;
            this.lblNCC.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNCC.Location = new System.Drawing.Point(-1, 59);
            this.lblNCC.Name = "lblNCC";
            this.lblNCC.Size = new System.Drawing.Size(57, 14);
            this.lblNCC.TabIndex = 9;
            this.lblNCC.Text = "Số lượng";
            // 
            // lblTenHang
            // 
            this.lblTenHang.AutoSize = true;
            this.lblTenHang.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenHang.Location = new System.Drawing.Point(-2, 33);
            this.lblTenHang.Name = "lblTenHang";
            this.lblTenHang.Size = new System.Drawing.Size(58, 14);
            this.lblTenHang.TabIndex = 10;
            this.lblTenHang.Text = "Tên Hàng";
            // 
            // lblMaHang
            // 
            this.lblMaHang.AutoSize = true;
            this.lblMaHang.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaHang.Location = new System.Drawing.Point(3, 8);
            this.lblMaHang.Name = "lblMaHang";
            this.lblMaHang.Size = new System.Drawing.Size(53, 14);
            this.lblMaHang.TabIndex = 11;
            this.lblMaHang.Text = "Mã hàng";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cboMaLoai);
            this.panel2.Controls.Add(this.cboMaNhom);
            this.panel2.Controls.Add(this.txtViTriKho);
            this.panel2.Controls.Add(this.txtDonGia);
            this.panel2.Controls.Add(this.lblMaLoai);
            this.panel2.Controls.Add(this.lblMaNhom);
            this.panel2.Controls.Add(this.lblViTriKho);
            this.panel2.Controls.Add(this.lblDonGia);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(259, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(228, 79);
            this.panel2.TabIndex = 0;
            // 
            // cboMaLoai
            // 
            this.cboMaLoai.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.cboMaLoai.FormattingEnabled = true;
            this.cboMaLoai.Location = new System.Drawing.Point(165, 4);
            this.cboMaLoai.Name = "cboMaLoai";
            this.cboMaLoai.Size = new System.Drawing.Size(62, 22);
            this.cboMaLoai.TabIndex = 10;
            // 
            // cboMaNhom
            // 
            this.cboMaNhom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboMaNhom.FormattingEnabled = true;
            this.cboMaNhom.Location = new System.Drawing.Point(60, 4);
            this.cboMaNhom.Name = "cboMaNhom";
            this.cboMaNhom.Size = new System.Drawing.Size(56, 22);
            this.cboMaNhom.TabIndex = 11;
            // 
            // txtViTriKho
            // 
            this.txtViTriKho.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtViTriKho.Location = new System.Drawing.Point(60, 55);
            this.txtViTriKho.Name = "txtViTriKho";
            this.txtViTriKho.Size = new System.Drawing.Size(162, 20);
            this.txtViTriKho.TabIndex = 8;
            // 
            // txtDonGia
            // 
            this.txtDonGia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDonGia.Location = new System.Drawing.Point(60, 31);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(162, 20);
            this.txtDonGia.TabIndex = 9;
            // 
            // lblMaLoai
            // 
            this.lblMaLoai.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblMaLoai.AutoSize = true;
            this.lblMaLoai.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaLoai.Location = new System.Drawing.Point(120, 7);
            this.lblMaLoai.Name = "lblMaLoai";
            this.lblMaLoai.Size = new System.Drawing.Size(45, 14);
            this.lblMaLoai.TabIndex = 5;
            this.lblMaLoai.Text = "Mã loại";
            // 
            // lblMaNhom
            // 
            this.lblMaNhom.AutoSize = true;
            this.lblMaNhom.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaNhom.Location = new System.Drawing.Point(0, 8);
            this.lblMaNhom.Name = "lblMaNhom";
            this.lblMaNhom.Size = new System.Drawing.Size(58, 14);
            this.lblMaNhom.TabIndex = 4;
            this.lblMaNhom.Text = "Mã nhóm";
            // 
            // lblViTriKho
            // 
            this.lblViTriKho.AutoSize = true;
            this.lblViTriKho.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViTriKho.Location = new System.Drawing.Point(2, 56);
            this.lblViTriKho.Name = "lblViTriKho";
            this.lblViTriKho.Size = new System.Drawing.Size(57, 14);
            this.lblViTriKho.TabIndex = 7;
            this.lblViTriKho.Text = "Vị trí kho";
            // 
            // lblDonGia
            // 
            this.lblDonGia.AutoSize = true;
            this.lblDonGia.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDonGia.Location = new System.Drawing.Point(3, 30);
            this.lblDonGia.Name = "lblDonGia";
            this.lblDonGia.Size = new System.Drawing.Size(49, 14);
            this.lblDonGia.TabIndex = 6;
            this.lblDonGia.Text = "Đơn giá";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.imgSP);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(493, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(97, 79);
            this.panel3.TabIndex = 0;
            // 
            // imgSP
            // 
            this.imgSP.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.imgSP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.imgSP.Location = new System.Drawing.Point(0, 11);
            this.imgSP.Name = "imgSP";
            this.imgSP.Size = new System.Drawing.Size(97, 68);
            this.imgSP.TabIndex = 7;
            this.imgSP.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, -3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 14);
            this.label1.TabIndex = 4;
            this.label1.Text = "Hình minh hoạ";
            // 
            // ucHangTonKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ucHangTonKho";
            this.Size = new System.Drawing.Size(605, 463);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorTK)).EndInit();
            this.bindingNavigatorTK.ResumeLayout(false);
            this.bindingNavigatorTK.PerformLayout();
            this.grbDanhMucHangTonKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHangTonKho)).EndInit();
            this.grbThongTinTonKho.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox grbThongTinTonKho;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbDonViTinh;
        private System.Windows.Forms.Label lblDonViTinh;
        private System.Windows.Forms.Button btnTimTenHang;
        private System.Windows.Forms.Button btnTimMH;
        private System.Windows.Forms.ComboBox cbTenHang;
        private System.Windows.Forms.ComboBox vboMaHang;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.Label lblNCC;
        private System.Windows.Forms.Label lblTenHang;
        private System.Windows.Forms.Label lblMaHang;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cboMaLoai;
        private System.Windows.Forms.ComboBox cboMaNhom;
        private System.Windows.Forms.TextBox txtViTriKho;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.Label lblMaLoai;
        private System.Windows.Forms.Label lblMaNhom;
        private System.Windows.Forms.Label lblViTriKho;
        private System.Windows.Forms.Label lblDonGia;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox imgSP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grbDanhMucHangTonKho;
        private System.Windows.Forms.DataGridView dgvDanhMucHangTonKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNhom;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn ViTri;
        private System.Windows.Forms.BindingNavigator bindingNavigatorTK;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemTK;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemTK;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemTK;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemTK;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemTK;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemTK;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemTK;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemTK;
    }
}
