﻿namespace QuanLyKhoSieuThi
{
    partial class ucSoKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbThongTinSoKho = new System.Windows.Forms.GroupBox();
            this.dgvThongTinSK = new System.Windows.Forms.DataGridView();
            this.MaChungTu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoaiChungTu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayTao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinSoKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinSK)).BeginInit();
            this.SuspendLayout();
            // 
            // grbThongTinSoKho
            // 
            this.grbThongTinSoKho.Controls.Add(this.dgvThongTinSK);
            this.grbThongTinSoKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinSoKho.Location = new System.Drawing.Point(0, 0);
            this.grbThongTinSoKho.Name = "grbThongTinSoKho";
            this.grbThongTinSoKho.Size = new System.Drawing.Size(814, 244);
            this.grbThongTinSoKho.TabIndex = 5;
            this.grbThongTinSoKho.TabStop = false;
            this.grbThongTinSoKho.Text = "Thông tin chứng từ";
            // 
            // dgvThongTinSK
            // 
            this.dgvThongTinSK.AllowUserToOrderColumns = true;
            this.dgvThongTinSK.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinSK.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvThongTinSK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinSK.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaChungTu,
            this.LoaiChungTu,
            this.NgayTao});
            this.dgvThongTinSK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinSK.Location = new System.Drawing.Point(3, 16);
            this.dgvThongTinSK.Name = "dgvThongTinSK";
            this.dgvThongTinSK.Size = new System.Drawing.Size(808, 225);
            this.dgvThongTinSK.TabIndex = 0;
            // 
            // MaChungTu
            // 
            this.MaChungTu.HeaderText = "Mã chứng từ";
            this.MaChungTu.Name = "MaChungTu";
            // 
            // LoaiChungTu
            // 
            this.LoaiChungTu.HeaderText = "Loại chứng từ";
            this.LoaiChungTu.Name = "LoaiChungTu";
            // 
            // NgayTao
            // 
            this.NgayTao.HeaderText = "Ngày tạo";
            this.NgayTao.Name = "NgayTao";
            // 
            // ucSoKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grbThongTinSoKho);
            this.Name = "ucSoKho";
            this.Size = new System.Drawing.Size(814, 244);
            this.grbThongTinSoKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinSK)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbThongTinSoKho;
        private System.Windows.Forms.DataGridView dgvThongTinSK;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaChungTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaiChungTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayTao;
    }
}
