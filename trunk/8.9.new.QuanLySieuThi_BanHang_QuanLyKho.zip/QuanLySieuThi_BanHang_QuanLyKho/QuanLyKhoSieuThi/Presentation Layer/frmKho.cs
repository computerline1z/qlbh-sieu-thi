﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLyKhoSieuThi
{
    public partial class frmKho : Form
    {
        private newTab MainTab = new newTab();
        public frmKho()
        {
            InitializeComponent();
            this.tblpMain.Controls.Add(this.MainTab, 0, 1);
        }
        //
        // Expand TreeNode khi load form
        //
        private void frmKho_Load(object sender, EventArgs e)
        {
            treKhoChucNang.ExpandAll();
        }
        //
        // Dong Tab
        //
        private void btnDongTabPage_Click(object sender, EventArgs e)
        {
            if (MainTab.TabCount > 0)
            {
                int i = this.MainTab.SelectedIndex;
                this.MainTab.Controls.Remove(MainTab.SelectedTab);
                this.MainTab.SelectedIndex = i;
            }
            else
                return;
        }
        //
        // Open Tree node
        //
        private void treKhoChucNang_AfterSelect(object sender, TreeViewEventArgs e)
        {
            switch (treKhoChucNang.SelectedNode.Name)
            {
                case "nodePhieuNhapKho":
                    {
                        ucPhieuNhapKho PN = new ucPhieuNhapKho();
                        int i = -1;
                        i = MainTab.isExists("Phiếu nhập kho");
                        if (i == -1)  //tab chưa tồn tại
                            MainTab.createtabPage("Phiếu nhập kho", PN);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nodePhieuXuatKho":
                    {
                        ucPhieuXuatKho PX = new ucPhieuXuatKho();
                        int i = -1;
                        i = MainTab.isExists("Phiếu xuất kho");
                        if (i == -1)  //tab chưa tồn tại
                            MainTab.createtabPage("Phiếu xuất kho", PX);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nodePhieuChuyenKho":
                    {
                        ucPhieuChuyenKho PC = new ucPhieuChuyenKho();
                        int i = -1;
                        i = MainTab.isExists("Phiếu chuyển kho");
                        if (i == -1)  //tab chưa tồn tại
                            MainTab.createtabPage("Phiếu chuyển kho", PC);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nodeSoKho":
                    {
                        ucSoKho SK = new ucSoKho();
                        int i = -1;
                        i = MainTab.isExists("Sổ kho");
                        if (i == -1)  //tab chưa tồn tại
                            MainTab.createtabPage("Sổ kho", SK);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nodeHangTonKho":
                    {
                        ucHangTonKho TK = new ucHangTonKho();
                        int i = -1;
                        i = MainTab.isExists("Hàng tồn kho");
                        if (i == -1)  //tab chưa tồn tại
                            MainTab.createtabPage("Hàng tồn kho",TK);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nodeHangHoaChiTiet":
                    {
                        ucDanhMucHang DM = new ucDanhMucHang();
                        int i = -1;
                        i = MainTab.isExists("Danh mục hàng");
                        if (i == -1)  //tab chưa tồn tại
                            MainTab.createtabPage("Phiếu chuyển kho", DM);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nodeThongTinHangVaoRa":
                    {
                        ucThongTinVaoRa VR = new ucThongTinVaoRa();
                        int i = -1;
                        i = MainTab.isExists("Thông tin vào ra");
                        if (i == -1)  //tab chưa tồn tại
                            MainTab.createtabPage("Thông tin vào ra", VR);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
            }
        }
    }
}
