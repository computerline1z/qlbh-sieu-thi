﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class formKhoNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Phiếu nhập kho");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Phiếu xuất kho");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Phiếu chuyển kho");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Sổ kho");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Chứng từ", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4});
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Hàng tồn kho");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Hàng hoá chi tiết");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Hàng hoá theo loại");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Danh mục", new System.Windows.Forms.TreeNode[] {
            treeNode7,
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Kho hàng");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Hàng hoá", new System.Windows.Forms.TreeNode[] {
            treeNode6,
            treeNode9,
            treeNode10});
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Thông tin hàng vào ra");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Top nhập");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Top xuất");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Báo cáo - thống kê", new System.Windows.Forms.TreeNode[] {
            treeNode12,
            treeNode13,
            treeNode14});
            this.mnusKho = new System.Windows.Forms.MenuStrip();
            this.tsmiKhoHeThong = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoThongTinPhienLamViec = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTaiKhoan = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoDoiMatKhau = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoCapNhatThongTin = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoSeparatorHeThong = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiKhoDangXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoThoatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoNghiepVu = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoThongTinHangDaBan = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTaoPhieuXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoInKiemKe = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTienIch = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoMayTinhMini = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoSeparatorTienIch = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiKhoLichLamViec = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTroGiup = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoHuongDanSuDung = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiCapNhatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoBaoCaoLoi = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoSeparatorTroGiup2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiKhoThongTinPhanQuanLiSieuThi = new System.Windows.Forms.ToolStripMenuItem();
            this.tstbKhoVersion = new System.Windows.Forms.ToolStripTextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treKhoChucNang = new System.Windows.Forms.TreeView();
            this.stasKho = new System.Windows.Forms.StatusStrip();
            this.tstlKhoReady = new System.Windows.Forms.ToolStripStatusLabel();
            this.tspbKhoProcess = new System.Windows.Forms.ToolStripProgressBar();
            this.mnusKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.stasKho.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnusKho
            // 
            this.mnusKho.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoHeThong,
            this.tsmiKhoNghiepVu,
            this.tsmiKhoTienIch,
            this.tsmiKhoTroGiup});
            this.mnusKho.Location = new System.Drawing.Point(0, 0);
            this.mnusKho.Name = "mnusKho";
            this.mnusKho.Size = new System.Drawing.Size(792, 24);
            this.mnusKho.TabIndex = 1;
            this.mnusKho.Text = "mnusKho";
            // 
            // tsmiKhoHeThong
            // 
            this.tsmiKhoHeThong.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoThongTinPhienLamViec,
            this.tsmiKhoTaiKhoan,
            this.tsmiKhoSeparatorHeThong,
            this.tsmiKhoDangXuat,
            this.tsmiKhoThoatChuongTrinh});
            this.tsmiKhoHeThong.Name = "tsmiKhoHeThong";
            this.tsmiKhoHeThong.Size = new System.Drawing.Size(69, 20);
            this.tsmiKhoHeThong.Text = "&Hệ thống";
            // 
            // tsmiKhoThongTinPhienLamViec
            // 
            this.tsmiKhoThongTinPhienLamViec.Name = "tsmiKhoThongTinPhienLamViec";
            this.tsmiKhoThongTinPhienLamViec.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.tsmiKhoThongTinPhienLamViec.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoThongTinPhienLamViec.Text = "Thông tin &phiên làm việc";
            // 
            // tsmiKhoTaiKhoan
            // 
            this.tsmiKhoTaiKhoan.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoDoiMatKhau,
            this.tsmiKhoCapNhatThongTin});
            this.tsmiKhoTaiKhoan.Name = "tsmiKhoTaiKhoan";
            this.tsmiKhoTaiKhoan.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoTaiKhoan.Text = "Tài &khoản";
            // 
            // tsmiKhoDoiMatKhau
            // 
            this.tsmiKhoDoiMatKhau.Name = "tsmiKhoDoiMatKhau";
            this.tsmiKhoDoiMatKhau.Size = new System.Drawing.Size(174, 22);
            this.tsmiKhoDoiMatKhau.Text = "Đổi &mật khẩu";
            // 
            // tsmiKhoCapNhatThongTin
            // 
            this.tsmiKhoCapNhatThongTin.Name = "tsmiKhoCapNhatThongTin";
            this.tsmiKhoCapNhatThongTin.Size = new System.Drawing.Size(174, 22);
            this.tsmiKhoCapNhatThongTin.Text = "&Cập nhật thông tin";
            // 
            // tsmiKhoSeparatorHeThong
            // 
            this.tsmiKhoSeparatorHeThong.Name = "tsmiKhoSeparatorHeThong";
            this.tsmiKhoSeparatorHeThong.Size = new System.Drawing.Size(243, 6);
            // 
            // tsmiKhoDangXuat
            // 
            this.tsmiKhoDangXuat.Name = "tsmiKhoDangXuat";
            this.tsmiKhoDangXuat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F4)));
            this.tsmiKhoDangXuat.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoDangXuat.Text = "Đăng &xuất";
            // 
            // tsmiKhoThoatChuongTrinh
            // 
            this.tsmiKhoThoatChuongTrinh.Name = "tsmiKhoThoatChuongTrinh";
            this.tsmiKhoThoatChuongTrinh.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.tsmiKhoThoatChuongTrinh.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoThoatChuongTrinh.Text = "&Thoát chương trình";
            // 
            // tsmiKhoNghiepVu
            // 
            this.tsmiKhoNghiepVu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoThongTinHangDaBan,
            this.tsmiKhoTaoPhieuXuat,
            this.tsmiKhoInKiemKe});
            this.tsmiKhoNghiepVu.Name = "tsmiKhoNghiepVu";
            this.tsmiKhoNghiepVu.Size = new System.Drawing.Size(74, 20);
            this.tsmiKhoNghiepVu.Text = "&Nghiệp vụ";
            // 
            // tsmiKhoThongTinHangDaBan
            // 
            this.tsmiKhoThongTinHangDaBan.Name = "tsmiKhoThongTinHangDaBan";
            this.tsmiKhoThongTinHangDaBan.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.tsmiKhoThongTinHangDaBan.Size = new System.Drawing.Size(192, 22);
            this.tsmiKhoThongTinHangDaBan.Text = "&Nhập hàng";
            // 
            // tsmiKhoTaoPhieuXuat
            // 
            this.tsmiKhoTaoPhieuXuat.Name = "tsmiKhoTaoPhieuXuat";
            this.tsmiKhoTaoPhieuXuat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.tsmiKhoTaoPhieuXuat.Size = new System.Drawing.Size(192, 22);
            this.tsmiKhoTaoPhieuXuat.Text = "Tạo phiếu &xuất";
            // 
            // tsmiKhoInKiemKe
            // 
            this.tsmiKhoInKiemKe.Name = "tsmiKhoInKiemKe";
            this.tsmiKhoInKiemKe.Size = new System.Drawing.Size(192, 22);
            this.tsmiKhoInKiemKe.Text = "In kiểm kê";
            // 
            // tsmiKhoTienIch
            // 
            this.tsmiKhoTienIch.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoMayTinhMini,
            this.tsmiKhoSeparatorTienIch,
            this.tsmiKhoLichLamViec});
            this.tsmiKhoTienIch.Name = "tsmiKhoTienIch";
            this.tsmiKhoTienIch.Size = new System.Drawing.Size(61, 20);
            this.tsmiKhoTienIch.Text = "Tiện &ích";
            // 
            // tsmiKhoMayTinhMini
            // 
            this.tsmiKhoMayTinhMini.Name = "tsmiKhoMayTinhMini";
            this.tsmiKhoMayTinhMini.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.tsmiKhoMayTinhMini.Size = new System.Drawing.Size(189, 22);
            this.tsmiKhoMayTinhMini.Text = "&Máy tính mini";
            // 
            // tsmiKhoSeparatorTienIch
            // 
            this.tsmiKhoSeparatorTienIch.Name = "tsmiKhoSeparatorTienIch";
            this.tsmiKhoSeparatorTienIch.Size = new System.Drawing.Size(186, 6);
            // 
            // tsmiKhoLichLamViec
            // 
            this.tsmiKhoLichLamViec.Name = "tsmiKhoLichLamViec";
            this.tsmiKhoLichLamViec.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.tsmiKhoLichLamViec.Size = new System.Drawing.Size(189, 22);
            this.tsmiKhoLichLamViec.Text = "&Lịch làm việc";
            // 
            // tsmiKhoTroGiup
            // 
            this.tsmiKhoTroGiup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoHuongDanSuDung,
            this.tsmiCapNhatChuongTrinh,
            this.tsmiKhoBaoCaoLoi,
            this.tsmiKhoSeparatorTroGiup2,
            this.tsmiKhoThongTinPhanQuanLiSieuThi,
            this.tstbKhoVersion});
            this.tsmiKhoTroGiup.Name = "tsmiKhoTroGiup";
            this.tsmiKhoTroGiup.Size = new System.Drawing.Size(64, 20);
            this.tsmiKhoTroGiup.Text = "Trợ &giúp";
            // 
            // tsmiKhoHuongDanSuDung
            // 
            this.tsmiKhoHuongDanSuDung.Name = "tsmiKhoHuongDanSuDung";
            this.tsmiKhoHuongDanSuDung.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.tsmiKhoHuongDanSuDung.Size = new System.Drawing.Size(267, 22);
            this.tsmiKhoHuongDanSuDung.Text = "Hướng dẫn &sử dụng";
            // 
            // tsmiCapNhatChuongTrinh
            // 
            this.tsmiCapNhatChuongTrinh.Name = "tsmiCapNhatChuongTrinh";
            this.tsmiCapNhatChuongTrinh.Size = new System.Drawing.Size(267, 22);
            this.tsmiCapNhatChuongTrinh.Text = "&Cập nhật chương trình";
            // 
            // tsmiKhoBaoCaoLoi
            // 
            this.tsmiKhoBaoCaoLoi.Name = "tsmiKhoBaoCaoLoi";
            this.tsmiKhoBaoCaoLoi.Size = new System.Drawing.Size(267, 22);
            this.tsmiKhoBaoCaoLoi.Text = "Báo cáo &lỗi";
            // 
            // tsmiKhoSeparatorTroGiup2
            // 
            this.tsmiKhoSeparatorTroGiup2.Name = "tsmiKhoSeparatorTroGiup2";
            this.tsmiKhoSeparatorTroGiup2.Size = new System.Drawing.Size(264, 6);
            // 
            // tsmiKhoThongTinPhanQuanLiSieuThi
            // 
            this.tsmiKhoThongTinPhanQuanLiSieuThi.Name = "tsmiKhoThongTinPhanQuanLiSieuThi";
            this.tsmiKhoThongTinPhanQuanLiSieuThi.Size = new System.Drawing.Size(267, 22);
            this.tsmiKhoThongTinPhanQuanLiSieuThi.Text = "Thông tin phần mềm &quản lí siêu thị";
            // 
            // tstbKhoVersion
            // 
            this.tstbKhoVersion.BackColor = System.Drawing.Color.White;
            this.tstbKhoVersion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tstbKhoVersion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.tstbKhoVersion.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.tstbKhoVersion.Name = "tstbKhoVersion";
            this.tstbKhoVersion.Size = new System.Drawing.Size(120, 12);
            this.tstbKhoVersion.Text = "© 2011 QLST – Version 1.0";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(792, 103);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 127);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treKhoChucNang);
            this.splitContainer1.Size = new System.Drawing.Size(792, 446);
            this.splitContainer1.SplitterDistance = 179;
            this.splitContainer1.TabIndex = 4;
            // 
            // treKhoChucNang
            // 
            this.treKhoChucNang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treKhoChucNang.Location = new System.Drawing.Point(0, 0);
            this.treKhoChucNang.Name = "treKhoChucNang";
            treeNode1.Name = "nodePhieuNhapKho";
            treeNode1.Text = "Phiếu nhập kho";
            treeNode2.Name = "nodePhieuXuatKho";
            treeNode2.Text = "Phiếu xuất kho";
            treeNode3.Name = "nodePhieuChuyenKho";
            treeNode3.Text = "Phiếu chuyển kho";
            treeNode4.Name = "nodeSoKho";
            treeNode4.Text = "Sổ kho";
            treeNode5.Checked = true;
            treeNode5.Name = "nodeChungTu";
            treeNode5.StateImageKey = "(none)";
            treeNode5.Text = "Chứng từ";
            treeNode5.ToolTipText = "Các loại chứng từ của quản lý kho";
            treeNode6.Name = "nodeHangTonKho";
            treeNode6.Text = "Hàng tồn kho";
            treeNode7.Name = "nodeHangHoaChiTiet";
            treeNode7.Text = "Hàng hoá chi tiết";
            treeNode8.Name = "nodeHangHoaTheoLoai";
            treeNode8.Text = "Hàng hoá theo loại";
            treeNode9.Name = "nodeDanhMuc";
            treeNode9.Text = "Danh mục";
            treeNode10.Name = "nodeKhoHang";
            treeNode10.Text = "Kho hàng";
            treeNode11.Name = "nodeHangHoa";
            treeNode11.Text = "Hàng hoá";
            treeNode12.Name = "nodeThongTinHangVaoRa";
            treeNode12.Text = "Thông tin hàng vào ra";
            treeNode13.Name = "nodeTopNhap";
            treeNode13.Text = "Top nhập";
            treeNode14.Name = "nodeTopXuat";
            treeNode14.Text = "Top xuất";
            treeNode15.Name = "nodeBaoCaoThongKe";
            treeNode15.Text = "Báo cáo - thống kê";
            this.treKhoChucNang.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode11,
            treeNode15});
            this.treKhoChucNang.Size = new System.Drawing.Size(179, 446);
            this.treKhoChucNang.TabIndex = 1;
            // 
            // stasKho
            // 
            this.stasKho.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstlKhoReady,
            this.tspbKhoProcess});
            this.stasKho.Location = new System.Drawing.Point(0, 551);
            this.stasKho.Name = "stasKho";
            this.stasKho.Size = new System.Drawing.Size(792, 22);
            this.stasKho.TabIndex = 10;
            this.stasKho.Text = "statusStrip1";
            // 
            // tstlKhoReady
            // 
            this.tstlKhoReady.Name = "tstlKhoReady";
            this.tstlKhoReady.Size = new System.Drawing.Size(39, 17);
            this.tstlKhoReady.Text = "Ready";
            // 
            // tspbKhoProcess
            // 
            this.tspbKhoProcess.Name = "tspbKhoProcess";
            this.tspbKhoProcess.Size = new System.Drawing.Size(100, 16);
            // 
            // formKhoNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 573);
            this.Controls.Add(this.stasKho);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.mnusKho);
            this.Name = "formKhoNew";
            this.Text = "formKhoNew";
            this.mnusKho.ResumeLayout(false);
            this.mnusKho.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.stasKho.ResumeLayout(false);
            this.stasKho.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnusKho;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoHeThong;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThongTinPhienLamViec;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTaiKhoan;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoDoiMatKhau;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoCapNhatThongTin;
        private System.Windows.Forms.ToolStripSeparator tsmiKhoSeparatorHeThong;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoDangXuat;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThoatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoNghiepVu;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThongTinHangDaBan;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTaoPhieuXuat;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoInKiemKe;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTienIch;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoMayTinhMini;
        private System.Windows.Forms.ToolStripSeparator tsmiKhoSeparatorTienIch;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoLichLamViec;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTroGiup;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoHuongDanSuDung;
        private System.Windows.Forms.ToolStripMenuItem tsmiCapNhatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoBaoCaoLoi;
        private System.Windows.Forms.ToolStripSeparator tsmiKhoSeparatorTroGiup2;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThongTinPhanQuanLiSieuThi;
        private System.Windows.Forms.ToolStripTextBox tstbKhoVersion;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView treKhoChucNang;
        private System.Windows.Forms.StatusStrip stasKho;
        private System.Windows.Forms.ToolStripStatusLabel tstlKhoReady;
        private System.Windows.Forms.ToolStripProgressBar tspbKhoProcess;
    }
}