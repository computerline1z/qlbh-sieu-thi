﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace QuanLyKhoSieuThi
{
    class newTab : TabControl
    {
        public newTab()
        {
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Location = new System.Drawing.Point(3, 31);
            this.SelectedIndex = 0;
            this.Size = new System.Drawing.Size(800, 573);
            this.TabIndex = 2;
            this.Visible = false;
        }
        public void createtabPage(string tabPageName, UserControl newUr)
        {
            this.Visible = true;
            TabPage tbPage = new TabPage();
            tbPage.Text = tabPageName;
            this.TabPages.Add(tbPage);
            tbPage.Controls.Add(newUr);
            tbPage.Show();
            this.SelectedTab = tbPage;
        }
        public int isExists(string tabName) // kiem tra tab co ton tai hay chua
        {
            for (int i = 0; i < this.TabPages.Count; i++)
            {
                if (this.TabPages[i].Text == tabName)
                    return i; // ton tai
            }
            return -1;
        }
    }
}
