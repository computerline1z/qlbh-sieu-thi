﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QuanLyKhoSieuThi.Data_Access_Layer
{
    class PHIEUNHAP_OBJ
    {
        public string Maphieunhap { get; set; }
        public string MaNCC { get; set; }
        public string Makho { get; set; }
        public string MaNV { get; set; }
        public string Ngaynhap { get; set; }
    }
}
