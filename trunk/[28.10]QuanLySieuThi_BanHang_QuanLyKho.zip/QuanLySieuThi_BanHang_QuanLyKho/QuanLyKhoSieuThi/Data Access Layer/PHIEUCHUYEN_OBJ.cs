﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QuanLyKhoSieuThi.Data_Access_Layer
{
    class PHIEUCHUYEN_OBJ
    {
        public string Maphieuchuyen { get; set; }
        public string MaNV { get; set; }
        public string Makhotu { get; set; } //Từ mã kho
        public string Makhoden { get; set; } //Đến mã kho
        public string Ngaychuyen { get; set; }
    }
}
