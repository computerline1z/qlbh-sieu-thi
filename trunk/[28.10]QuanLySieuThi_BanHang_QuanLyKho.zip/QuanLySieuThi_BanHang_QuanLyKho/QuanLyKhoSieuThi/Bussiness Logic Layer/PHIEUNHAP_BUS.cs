﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using QuanLyKhoSieuThi.Data_Access_Layer;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace QuanLyKhoSieuThi.Bussiness_Logic_Layer
{
    class PHIEUNHAP_BUS:Dataprovider
    {
        string sql = "";
        DataTable tempTable;

        public DataTable LayDSPhieuNhap()
        {
            tempTable = new DataTable();
            openConnection();
            sql = "select Maphieu from Phieunhap";
            tempTable = this.getDataTable(sql, true);
            closeConnection();
            return tempTable;
        }

        public bool ktTontaiPhieunhap(string Maphieu)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Phieunhap  where Maphieu='{0}'", Maphieu);
            kq = this.countQuantity(sql) == 1;
            closeConnection();
            return kq;
        }

        public bool ktNCCTontaiTrongPhieunhap(string MaNCC)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Phieunhap  where MaaNCC='{0}'", MaNCC);
            kq = this.countQuantity(sql) == 1;
            closeConnection();
            return kq;
        }

        public void Them(PHIEUNHAP_OBJ NewPhieunhap)
        {
            sql = string.Format("insert into Phieunhap values('{0}','{1}','{2}','{3}','{4}')", NewPhieunhap.Maphieunhap, NewPhieunhap.MaNCC, NewPhieunhap.Makho, NewPhieunhap.MaNV, NewPhieunhap.Ngaynhap);
            this.excuteNonQuery(sql);

        }

        public void XoaTheoMaphieu(PHIEUNHAP_OBJ Phieunhap)
        {
            sql = string.Format("delete Phieunhap where Maphieu='{0}'", Phieunhap.Maphieunhap);
            this.excuteNonQuery(sql);
        }

        public void XoaTheoNCC(string MaNCC)
        {
            sql = string.Format("delete Phieunhap where MaNCC='{0}'", MaNCC);
            this.excuteNonQuery(sql);
        }
        public void Sua(PHIEUNHAP_OBJ NewPhieunhap)
        {
            sql = string.Format("update Phieunhap set Maphieu='{0}', MaNCC='{1}',Makho='{2}', MaNV='{3}', Ngaylap='{4}'", NewPhieunhap.Maphieunhap, NewPhieunhap.MaNCC, NewPhieunhap.Makho, NewPhieunhap.MaNV, NewPhieunhap.Ngaynhap);
            this.excuteNonQuery(sql);
        }

        public int Save()
        {
            int rec = 0;
            openConnection();
            try
            {
                rec = this.SaveToDB();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }

            closeConnection();
            return rec;
        }
    }
}
