﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using QuanLyKhoSieuThi.Data_Access_Layer;
using System.Data;

namespace QuanLyKhoSieuThi.Bussiness_Logic_Layer
{
    class DANHMUCLOAIHANG_BUS:Dataprovider
    {
        string sql = "";
        DataTable tempTable;
        public DataTable LayLoaiHang()
        {
            tempTable = new DataTable();
            openConnection();
            sql = "select Loai, Tenloai from Loaihang";
            tempTable = this.getDataTable(sql);
            closeConnection();
            return tempTable;
        }

        public bool ktTontaiTrongLoaiHang(string Loai)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Loaihang where loai='{0}'", Loai);
            kq = this.countQuantity(sql) >= 1;
            return kq;
        }
    }
}
