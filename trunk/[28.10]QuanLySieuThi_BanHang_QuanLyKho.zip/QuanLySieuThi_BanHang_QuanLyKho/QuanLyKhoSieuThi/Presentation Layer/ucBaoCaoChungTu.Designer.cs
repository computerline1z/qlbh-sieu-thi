﻿namespace QuanLyKhoSieuThi
{
    partial class ucBaoCaoChungTu
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbLocThongTin = new System.Windows.Forms.GroupBox();
            this.tblpLocThongTin = new System.Windows.Forms.TableLayoutPanel();
            this.pnlThoiGianLap = new System.Windows.Forms.Panel();
            this.cbbChonKhoHang = new System.Windows.Forms.ComboBox();
            this.lblChonKhoHang = new System.Windows.Forms.Label();
            this.dtmpTuNgay = new System.Windows.Forms.DateTimePicker();
            this.dtmpDenNgay = new System.Windows.Forms.DateTimePicker();
            this.lblTuNgay = new System.Windows.Forms.Label();
            this.lblDenNgay = new System.Windows.Forms.Label();
            this.lblThoiGianLap = new System.Windows.Forms.Label();
            this.pnlChonLoaiChungTu = new System.Windows.Forms.Panel();
            this.chkbPhieuChuyenKHo = new System.Windows.Forms.CheckBox();
            this.chkbPhieuNhapKho = new System.Windows.Forms.CheckBox();
            this.chkbPhieuXuatKho = new System.Windows.Forms.CheckBox();
            this.lblChonLoaiChungTu = new System.Windows.Forms.Label();
            this.pnlGiaTriChungTu = new System.Windows.Forms.Panel();
            this.mtxtDenGiaTri = new System.Windows.Forms.MaskedTextBox();
            this.mtxtTuGiaTri = new System.Windows.Forms.MaskedTextBox();
            this.lblDenGiaTri = new System.Windows.Forms.Label();
            this.lblTuGiaTri = new System.Windows.Forms.Label();
            this.lblGiaTriChungTu = new System.Windows.Forms.Label();
            this.splcLocThongTin = new System.Windows.Forms.SplitContainer();
            this.grbNgayCoChungTu = new System.Windows.Forms.GroupBox();
            this.dgvNgayCoChungTu = new System.Windows.Forms.DataGridView();
            this.Ngay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongSoChungTu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongGiaTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbDanhSachChungTu = new System.Windows.Forms.GroupBox();
            this.dgvDanhSachChungTu = new System.Windows.Forms.DataGridView();
            this.STT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaChungTu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnXuatBaoCao = new System.Windows.Forms.Button();
            this.btnXem = new System.Windows.Forms.Button();
            this.grbLocThongTin.SuspendLayout();
            this.tblpLocThongTin.SuspendLayout();
            this.pnlThoiGianLap.SuspendLayout();
            this.pnlChonLoaiChungTu.SuspendLayout();
            this.pnlGiaTriChungTu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splcLocThongTin)).BeginInit();
            this.splcLocThongTin.Panel1.SuspendLayout();
            this.splcLocThongTin.Panel2.SuspendLayout();
            this.splcLocThongTin.SuspendLayout();
            this.grbNgayCoChungTu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNgayCoChungTu)).BeginInit();
            this.grbDanhSachChungTu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachChungTu)).BeginInit();
            this.SuspendLayout();
            // 
            // grbLocThongTin
            // 
            this.grbLocThongTin.Controls.Add(this.tblpLocThongTin);
            this.grbLocThongTin.Dock = System.Windows.Forms.DockStyle.Top;
            this.grbLocThongTin.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbLocThongTin.Location = new System.Drawing.Point(0, 0);
            this.grbLocThongTin.Name = "grbLocThongTin";
            this.grbLocThongTin.Size = new System.Drawing.Size(648, 131);
            this.grbLocThongTin.TabIndex = 0;
            this.grbLocThongTin.TabStop = false;
            this.grbLocThongTin.Text = "Lọc thông tin";
            // 
            // tblpLocThongTin
            // 
            this.tblpLocThongTin.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tblpLocThongTin.ColumnCount = 3;
            this.tblpLocThongTin.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 252F));
            this.tblpLocThongTin.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 124F));
            this.tblpLocThongTin.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpLocThongTin.Controls.Add(this.pnlThoiGianLap, 0, 0);
            this.tblpLocThongTin.Controls.Add(this.pnlChonLoaiChungTu, 1, 0);
            this.tblpLocThongTin.Controls.Add(this.pnlGiaTriChungTu, 2, 0);
            this.tblpLocThongTin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpLocThongTin.Location = new System.Drawing.Point(3, 16);
            this.tblpLocThongTin.Name = "tblpLocThongTin";
            this.tblpLocThongTin.RowCount = 1;
            this.tblpLocThongTin.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpLocThongTin.Size = new System.Drawing.Size(642, 112);
            this.tblpLocThongTin.TabIndex = 0;
            // 
            // pnlThoiGianLap
            // 
            this.pnlThoiGianLap.Controls.Add(this.cbbChonKhoHang);
            this.pnlThoiGianLap.Controls.Add(this.lblChonKhoHang);
            this.pnlThoiGianLap.Controls.Add(this.dtmpTuNgay);
            this.pnlThoiGianLap.Controls.Add(this.dtmpDenNgay);
            this.pnlThoiGianLap.Controls.Add(this.lblTuNgay);
            this.pnlThoiGianLap.Controls.Add(this.lblDenNgay);
            this.pnlThoiGianLap.Controls.Add(this.lblThoiGianLap);
            this.pnlThoiGianLap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlThoiGianLap.Location = new System.Drawing.Point(6, 6);
            this.pnlThoiGianLap.Name = "pnlThoiGianLap";
            this.pnlThoiGianLap.Size = new System.Drawing.Size(246, 100);
            this.pnlThoiGianLap.TabIndex = 0;
            // 
            // cbbChonKhoHang
            // 
            this.cbbChonKhoHang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbChonKhoHang.FormattingEnabled = true;
            this.cbbChonKhoHang.Location = new System.Drawing.Point(91, 74);
            this.cbbChonKhoHang.Name = "cbbChonKhoHang";
            this.cbbChonKhoHang.Size = new System.Drawing.Size(150, 23);
            this.cbbChonKhoHang.TabIndex = 5;
            // 
            // lblChonKhoHang
            // 
            this.lblChonKhoHang.AutoSize = true;
            this.lblChonKhoHang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChonKhoHang.Location = new System.Drawing.Point(-1, 77);
            this.lblChonKhoHang.Name = "lblChonKhoHang";
            this.lblChonKhoHang.Size = new System.Drawing.Size(91, 15);
            this.lblChonKhoHang.TabIndex = 4;
            this.lblChonKhoHang.Text = "Chọn kho hàng";
            // 
            // dtmpTuNgay
            // 
            this.dtmpTuNgay.CustomFormat = "ddd - dd/MM/yyyy | hh:mm tt";
            this.dtmpTuNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmpTuNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmpTuNgay.Location = new System.Drawing.Point(59, 20);
            this.dtmpTuNgay.Name = "dtmpTuNgay";
            this.dtmpTuNgay.Size = new System.Drawing.Size(182, 21);
            this.dtmpTuNgay.TabIndex = 2;
            this.dtmpTuNgay.Value = new System.DateTime(2011, 1, 10, 0, 0, 0, 0);
            // 
            // dtmpDenNgay
            // 
            this.dtmpDenNgay.CustomFormat = "ddd - dd/MM/yyyy | hh:mm tt";
            this.dtmpDenNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmpDenNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmpDenNgay.Location = new System.Drawing.Point(59, 47);
            this.dtmpDenNgay.Name = "dtmpDenNgay";
            this.dtmpDenNgay.Size = new System.Drawing.Size(182, 21);
            this.dtmpDenNgay.TabIndex = 3;
            this.dtmpDenNgay.Value = new System.DateTime(2011, 10, 21, 0, 0, 0, 0);
            // 
            // lblTuNgay
            // 
            this.lblTuNgay.AutoSize = true;
            this.lblTuNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTuNgay.Location = new System.Drawing.Point(-1, 23);
            this.lblTuNgay.Name = "lblTuNgay";
            this.lblTuNgay.Size = new System.Drawing.Size(53, 15);
            this.lblTuNgay.TabIndex = 0;
            this.lblTuNgay.Text = "Từ ngày";
            // 
            // lblDenNgay
            // 
            this.lblDenNgay.AutoSize = true;
            this.lblDenNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDenNgay.Location = new System.Drawing.Point(-1, 50);
            this.lblDenNgay.Name = "lblDenNgay";
            this.lblDenNgay.Size = new System.Drawing.Size(60, 15);
            this.lblDenNgay.TabIndex = 1;
            this.lblDenNgay.Text = "Đến ngày";
            // 
            // lblThoiGianLap
            // 
            this.lblThoiGianLap.AutoSize = true;
            this.lblThoiGianLap.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThoiGianLap.Location = new System.Drawing.Point(-1, 2);
            this.lblThoiGianLap.Name = "lblThoiGianLap";
            this.lblThoiGianLap.Size = new System.Drawing.Size(136, 15);
            this.lblThoiGianLap.TabIndex = 0;
            this.lblThoiGianLap.Text = "Thời gian lập chứng từ";
            // 
            // pnlChonLoaiChungTu
            // 
            this.pnlChonLoaiChungTu.Controls.Add(this.chkbPhieuChuyenKHo);
            this.pnlChonLoaiChungTu.Controls.Add(this.chkbPhieuNhapKho);
            this.pnlChonLoaiChungTu.Controls.Add(this.chkbPhieuXuatKho);
            this.pnlChonLoaiChungTu.Controls.Add(this.lblChonLoaiChungTu);
            this.pnlChonLoaiChungTu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlChonLoaiChungTu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlChonLoaiChungTu.Location = new System.Drawing.Point(261, 6);
            this.pnlChonLoaiChungTu.Name = "pnlChonLoaiChungTu";
            this.pnlChonLoaiChungTu.Size = new System.Drawing.Size(118, 100);
            this.pnlChonLoaiChungTu.TabIndex = 1;
            // 
            // chkbPhieuChuyenKHo
            // 
            this.chkbPhieuChuyenKHo.AutoSize = true;
            this.chkbPhieuChuyenKHo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbPhieuChuyenKHo.Location = new System.Drawing.Point(2, 79);
            this.chkbPhieuChuyenKHo.Name = "chkbPhieuChuyenKHo";
            this.chkbPhieuChuyenKHo.Size = new System.Drawing.Size(123, 19);
            this.chkbPhieuChuyenKHo.TabIndex = 2;
            this.chkbPhieuChuyenKHo.Text = "Phiếu chuyển kho";
            this.chkbPhieuChuyenKHo.UseVisualStyleBackColor = true;
            // 
            // chkbPhieuNhapKho
            // 
            this.chkbPhieuNhapKho.AutoSize = true;
            this.chkbPhieuNhapKho.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbPhieuNhapKho.Location = new System.Drawing.Point(2, 55);
            this.chkbPhieuNhapKho.Name = "chkbPhieuNhapKho";
            this.chkbPhieuNhapKho.Size = new System.Drawing.Size(112, 19);
            this.chkbPhieuNhapKho.TabIndex = 2;
            this.chkbPhieuNhapKho.Text = "Phiếu nhập kho";
            this.chkbPhieuNhapKho.UseVisualStyleBackColor = true;
            // 
            // chkbPhieuXuatKho
            // 
            this.chkbPhieuXuatKho.AutoSize = true;
            this.chkbPhieuXuatKho.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbPhieuXuatKho.Location = new System.Drawing.Point(2, 31);
            this.chkbPhieuXuatKho.Name = "chkbPhieuXuatKho";
            this.chkbPhieuXuatKho.Size = new System.Drawing.Size(106, 19);
            this.chkbPhieuXuatKho.TabIndex = 1;
            this.chkbPhieuXuatKho.Text = "Phiếu xuất kho";
            this.chkbPhieuXuatKho.UseVisualStyleBackColor = true;
            // 
            // lblChonLoaiChungTu
            // 
            this.lblChonLoaiChungTu.AutoSize = true;
            this.lblChonLoaiChungTu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChonLoaiChungTu.Location = new System.Drawing.Point(-1, 1);
            this.lblChonLoaiChungTu.Name = "lblChonLoaiChungTu";
            this.lblChonLoaiChungTu.Size = new System.Drawing.Size(60, 30);
            this.lblChonLoaiChungTu.TabIndex = 0;
            this.lblChonLoaiChungTu.Text = "Chọn loại\r\nchứng từ";
            // 
            // pnlGiaTriChungTu
            // 
            this.pnlGiaTriChungTu.Controls.Add(this.btnXuatBaoCao);
            this.pnlGiaTriChungTu.Controls.Add(this.btnXem);
            this.pnlGiaTriChungTu.Controls.Add(this.mtxtDenGiaTri);
            this.pnlGiaTriChungTu.Controls.Add(this.mtxtTuGiaTri);
            this.pnlGiaTriChungTu.Controls.Add(this.lblDenGiaTri);
            this.pnlGiaTriChungTu.Controls.Add(this.lblTuGiaTri);
            this.pnlGiaTriChungTu.Controls.Add(this.lblGiaTriChungTu);
            this.pnlGiaTriChungTu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGiaTriChungTu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlGiaTriChungTu.Location = new System.Drawing.Point(388, 6);
            this.pnlGiaTriChungTu.Name = "pnlGiaTriChungTu";
            this.pnlGiaTriChungTu.Size = new System.Drawing.Size(248, 100);
            this.pnlGiaTriChungTu.TabIndex = 2;
            // 
            // mtxtDenGiaTri
            // 
            this.mtxtDenGiaTri.Location = new System.Drawing.Point(39, 41);
            this.mtxtDenGiaTri.Mask = "___.___.___";
            this.mtxtDenGiaTri.Name = "mtxtDenGiaTri";
            this.mtxtDenGiaTri.Size = new System.Drawing.Size(107, 21);
            this.mtxtDenGiaTri.TabIndex = 4;
            this.mtxtDenGiaTri.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtxtTuGiaTri
            // 
            this.mtxtTuGiaTri.Location = new System.Drawing.Point(39, 17);
            this.mtxtTuGiaTri.Mask = "___.___.___";
            this.mtxtTuGiaTri.Name = "mtxtTuGiaTri";
            this.mtxtTuGiaTri.Size = new System.Drawing.Size(107, 21);
            this.mtxtTuGiaTri.TabIndex = 4;
            this.mtxtTuGiaTri.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblDenGiaTri
            // 
            this.lblDenGiaTri.AutoSize = true;
            this.lblDenGiaTri.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDenGiaTri.Location = new System.Drawing.Point(3, 44);
            this.lblDenGiaTri.Name = "lblDenGiaTri";
            this.lblDenGiaTri.Size = new System.Drawing.Size(30, 15);
            this.lblDenGiaTri.TabIndex = 2;
            this.lblDenGiaTri.Text = "Đến";
            // 
            // lblTuGiaTri
            // 
            this.lblTuGiaTri.AutoSize = true;
            this.lblTuGiaTri.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTuGiaTri.Location = new System.Drawing.Point(3, 20);
            this.lblTuGiaTri.Name = "lblTuGiaTri";
            this.lblTuGiaTri.Size = new System.Drawing.Size(23, 15);
            this.lblTuGiaTri.TabIndex = 1;
            this.lblTuGiaTri.Text = "Từ";
            // 
            // lblGiaTriChungTu
            // 
            this.lblGiaTriChungTu.AutoSize = true;
            this.lblGiaTriChungTu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGiaTriChungTu.Location = new System.Drawing.Point(3, 0);
            this.lblGiaTriChungTu.Name = "lblGiaTriChungTu";
            this.lblGiaTriChungTu.Size = new System.Drawing.Size(120, 15);
            this.lblGiaTriChungTu.TabIndex = 0;
            this.lblGiaTriChungTu.Text = "Giá trị của chứng từ";
            // 
            // splcLocThongTin
            // 
            this.splcLocThongTin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splcLocThongTin.Location = new System.Drawing.Point(0, 131);
            this.splcLocThongTin.Name = "splcLocThongTin";
            this.splcLocThongTin.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splcLocThongTin.Panel1
            // 
            this.splcLocThongTin.Panel1.Controls.Add(this.grbNgayCoChungTu);
            // 
            // splcLocThongTin.Panel2
            // 
            this.splcLocThongTin.Panel2.Controls.Add(this.grbDanhSachChungTu);
            this.splcLocThongTin.Size = new System.Drawing.Size(648, 285);
            this.splcLocThongTin.SplitterDistance = 122;
            this.splcLocThongTin.TabIndex = 1;
            // 
            // grbNgayCoChungTu
            // 
            this.grbNgayCoChungTu.Controls.Add(this.dgvNgayCoChungTu);
            this.grbNgayCoChungTu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbNgayCoChungTu.Location = new System.Drawing.Point(0, 0);
            this.grbNgayCoChungTu.Name = "grbNgayCoChungTu";
            this.grbNgayCoChungTu.Size = new System.Drawing.Size(648, 122);
            this.grbNgayCoChungTu.TabIndex = 0;
            this.grbNgayCoChungTu.TabStop = false;
            this.grbNgayCoChungTu.Text = "Ngày có chứng từ";
            // 
            // dgvNgayCoChungTu
            // 
            this.dgvNgayCoChungTu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNgayCoChungTu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNgayCoChungTu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Ngay,
            this.TongSoChungTu,
            this.TongGiaTri});
            this.dgvNgayCoChungTu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNgayCoChungTu.Location = new System.Drawing.Point(3, 16);
            this.dgvNgayCoChungTu.Name = "dgvNgayCoChungTu";
            this.dgvNgayCoChungTu.Size = new System.Drawing.Size(642, 103);
            this.dgvNgayCoChungTu.TabIndex = 1;
            // 
            // Ngay
            // 
            this.Ngay.HeaderText = "Ngày";
            this.Ngay.Name = "Ngay";
            // 
            // TongSoChungTu
            // 
            this.TongSoChungTu.HeaderText = "Tổng số chứng từ";
            this.TongSoChungTu.Name = "TongSoChungTu";
            // 
            // TongGiaTri
            // 
            this.TongGiaTri.HeaderText = "Tổng giá trị";
            this.TongGiaTri.Name = "TongGiaTri";
            // 
            // grbDanhSachChungTu
            // 
            this.grbDanhSachChungTu.Controls.Add(this.dgvDanhSachChungTu);
            this.grbDanhSachChungTu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhSachChungTu.Location = new System.Drawing.Point(0, 0);
            this.grbDanhSachChungTu.Name = "grbDanhSachChungTu";
            this.grbDanhSachChungTu.Size = new System.Drawing.Size(648, 159);
            this.grbDanhSachChungTu.TabIndex = 0;
            this.grbDanhSachChungTu.TabStop = false;
            this.grbDanhSachChungTu.Text = "Danh sách chứng từ theo ngày";
            // 
            // dgvDanhSachChungTu
            // 
            this.dgvDanhSachChungTu.AllowUserToOrderColumns = true;
            this.dgvDanhSachChungTu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSachChungTu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachChungTu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.STT,
            this.MaChungTu,
            this.NgayLap,
            this.MaKho,
            this.GiaTri});
            this.dgvDanhSachChungTu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSachChungTu.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhSachChungTu.Name = "dgvDanhSachChungTu";
            this.dgvDanhSachChungTu.Size = new System.Drawing.Size(642, 140);
            this.dgvDanhSachChungTu.TabIndex = 1;
            // 
            // STT
            // 
            this.STT.FillWeight = 50.76142F;
            this.STT.HeaderText = "STT";
            this.STT.Name = "STT";
            // 
            // MaChungTu
            // 
            this.MaChungTu.FillWeight = 112.3096F;
            this.MaChungTu.HeaderText = "Mã chứng từ";
            this.MaChungTu.Name = "MaChungTu";
            // 
            // NgayLap
            // 
            this.NgayLap.FillWeight = 112.3096F;
            this.NgayLap.HeaderText = "Ngày lập";
            this.NgayLap.Name = "NgayLap";
            // 
            // MaKho
            // 
            this.MaKho.FillWeight = 112.3096F;
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // GiaTri
            // 
            this.GiaTri.FillWeight = 112.3096F;
            this.GiaTri.HeaderText = "Giá Trị";
            this.GiaTri.Name = "GiaTri";
            // 
            // btnXuatBaoCao
            // 
            this.btnXuatBaoCao.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatBaoCao.Image = global::QuanLyKhoSieuThi.Properties.Resources.printer;
            this.btnXuatBaoCao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXuatBaoCao.Location = new System.Drawing.Point(81, 66);
            this.btnXuatBaoCao.Name = "btnXuatBaoCao";
            this.btnXuatBaoCao.Size = new System.Drawing.Size(104, 32);
            this.btnXuatBaoCao.TabIndex = 9;
            this.btnXuatBaoCao.Text = "&Xuất báo cáo";
            this.btnXuatBaoCao.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXuatBaoCao.UseVisualStyleBackColor = true;
            // 
            // btnXem
            // 
            this.btnXem.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXem.Location = new System.Drawing.Point(7, 66);
            this.btnXem.Name = "btnXem";
            this.btnXem.Size = new System.Drawing.Size(68, 32);
            this.btnXem.TabIndex = 8;
            this.btnXem.Text = "&Xem";
            this.btnXem.UseVisualStyleBackColor = true;
            // 
            // ucBaoCaoChungTu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.Controls.Add(this.splcLocThongTin);
            this.Controls.Add(this.grbLocThongTin);
            this.Name = "ucBaoCaoChungTu";
            this.Size = new System.Drawing.Size(648, 416);
            this.grbLocThongTin.ResumeLayout(false);
            this.tblpLocThongTin.ResumeLayout(false);
            this.pnlThoiGianLap.ResumeLayout(false);
            this.pnlThoiGianLap.PerformLayout();
            this.pnlChonLoaiChungTu.ResumeLayout(false);
            this.pnlChonLoaiChungTu.PerformLayout();
            this.pnlGiaTriChungTu.ResumeLayout(false);
            this.pnlGiaTriChungTu.PerformLayout();
            this.splcLocThongTin.Panel1.ResumeLayout(false);
            this.splcLocThongTin.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splcLocThongTin)).EndInit();
            this.splcLocThongTin.ResumeLayout(false);
            this.grbNgayCoChungTu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNgayCoChungTu)).EndInit();
            this.grbDanhSachChungTu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachChungTu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbLocThongTin;
        private System.Windows.Forms.SplitContainer splcLocThongTin;
        private System.Windows.Forms.TableLayoutPanel tblpLocThongTin;
        private System.Windows.Forms.Panel pnlThoiGianLap;
        private System.Windows.Forms.DateTimePicker dtmpDenNgay;
        private System.Windows.Forms.DateTimePicker dtmpTuNgay;
        private System.Windows.Forms.Label lblDenNgay;
        private System.Windows.Forms.Label lblTuNgay;
        private System.Windows.Forms.Panel pnlChonLoaiChungTu;
        private System.Windows.Forms.Panel pnlGiaTriChungTu;
        private System.Windows.Forms.CheckBox chkbPhieuChuyenKHo;
        private System.Windows.Forms.CheckBox chkbPhieuNhapKho;
        private System.Windows.Forms.CheckBox chkbPhieuXuatKho;
        private System.Windows.Forms.Label lblChonLoaiChungTu;
        private System.Windows.Forms.Label lblChonKhoHang;
        private System.Windows.Forms.Label lblDenGiaTri;
        private System.Windows.Forms.Label lblTuGiaTri;
        private System.Windows.Forms.Label lblGiaTriChungTu;
        private System.Windows.Forms.ComboBox cbbChonKhoHang;
        private System.Windows.Forms.GroupBox grbNgayCoChungTu;
        private System.Windows.Forms.DataGridView dgvNgayCoChungTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ngay;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongSoChungTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongGiaTri;
        private System.Windows.Forms.GroupBox grbDanhSachChungTu;
        private System.Windows.Forms.DataGridView dgvDanhSachChungTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn STT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaChungTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaTri;
        private System.Windows.Forms.Label lblThoiGianLap;
        private System.Windows.Forms.MaskedTextBox mtxtDenGiaTri;
        private System.Windows.Forms.MaskedTextBox mtxtTuGiaTri;
        private System.Windows.Forms.Button btnXuatBaoCao;
        private System.Windows.Forms.Button btnXem;
    }
}
