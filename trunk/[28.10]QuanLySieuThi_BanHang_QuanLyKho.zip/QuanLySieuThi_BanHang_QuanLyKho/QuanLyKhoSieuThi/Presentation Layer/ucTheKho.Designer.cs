﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucTheKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucTheKho));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.grbThongTinTheKho = new System.Windows.Forms.GroupBox();
            this.grbButton = new System.Windows.Forms.GroupBox();
            this.btnXem = new System.Windows.Forms.Button();
            this.cboTenHang = new System.Windows.Forms.ComboBox();
            this.cboMaHang = new System.Windows.Forms.ComboBox();
            this.mtxtNgayKT = new System.Windows.Forms.MaskedTextBox();
            this.lblNgayKT = new System.Windows.Forms.Label();
            this.mtxtNgayBD = new System.Windows.Forms.MaskedTextBox();
            this.lblNgayBD = new System.Windows.Forms.Label();
            this.lblTenHang = new System.Windows.Forms.Label();
            this.lblMaHang = new System.Windows.Forms.Label();
            this.grbChiTietTheKho = new System.Windows.Forms.GroupBox();
            this.dgvTheKho = new System.Windows.Forms.DataGridView();
            this.MaCT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayCT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DienGiai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingNavigatorSK = new System.Windows.Forms.BindingNavigator(this.components);
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemSK = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbAddNewItemSK = new System.Windows.Forms.ToolStripButton();
            this.tsbDeleteItemSK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemSK = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemPSK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveNextItemSK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemSK = new System.Windows.Forms.ToolStripButton();
            this.tsbSaveNewItemSK = new System.Windows.Forms.ToolStripButton();
            this.btnXuatBaoCao = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.grbThongTinTheKho.SuspendLayout();
            this.grbButton.SuspendLayout();
            this.grbChiTietTheKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheKho)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSK)).BeginInit();
            this.bindingNavigatorSK.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.bindingNavigatorSK, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.grbChiTietTheKho, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.grbThongTinTheKho, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 113F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(640, 416);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // grbThongTinTheKho
            // 
            this.grbThongTinTheKho.Controls.Add(this.grbButton);
            this.grbThongTinTheKho.Controls.Add(this.cboTenHang);
            this.grbThongTinTheKho.Controls.Add(this.cboMaHang);
            this.grbThongTinTheKho.Controls.Add(this.mtxtNgayKT);
            this.grbThongTinTheKho.Controls.Add(this.lblNgayKT);
            this.grbThongTinTheKho.Controls.Add(this.mtxtNgayBD);
            this.grbThongTinTheKho.Controls.Add(this.lblNgayBD);
            this.grbThongTinTheKho.Controls.Add(this.lblTenHang);
            this.grbThongTinTheKho.Controls.Add(this.lblMaHang);
            this.grbThongTinTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinTheKho.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinTheKho.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinTheKho.Name = "grbThongTinTheKho";
            this.grbThongTinTheKho.Size = new System.Drawing.Size(634, 107);
            this.grbThongTinTheKho.TabIndex = 2;
            this.grbThongTinTheKho.TabStop = false;
            this.grbThongTinTheKho.Text = "Thông tin thẻ kho";
            // 
            // grbButton
            // 
            this.grbButton.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.grbButton.Controls.Add(this.btnXuatBaoCao);
            this.grbButton.Controls.Add(this.btnXem);
            this.grbButton.Location = new System.Drawing.Point(461, 8);
            this.grbButton.Name = "grbButton";
            this.grbButton.Size = new System.Drawing.Size(135, 97);
            this.grbButton.TabIndex = 7;
            this.grbButton.TabStop = false;
            // 
            // btnXem
            // 
            this.btnXem.Location = new System.Drawing.Point(14, 13);
            this.btnXem.Name = "btnXem";
            this.btnXem.Size = new System.Drawing.Size(114, 34);
            this.btnXem.TabIndex = 5;
            this.btnXem.Text = "&Xem";
            this.btnXem.UseVisualStyleBackColor = true;
            // 
            // cboTenHang
            // 
            this.cboTenHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboTenHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTenHang.FormattingEnabled = true;
            this.cboTenHang.Location = new System.Drawing.Point(70, 52);
            this.cboTenHang.Name = "cboTenHang";
            this.cboTenHang.Size = new System.Drawing.Size(140, 23);
            this.cboTenHang.TabIndex = 6;
            // 
            // cboMaHang
            // 
            this.cboMaHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboMaHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaHang.FormattingEnabled = true;
            this.cboMaHang.Location = new System.Drawing.Point(70, 22);
            this.cboMaHang.Name = "cboMaHang";
            this.cboMaHang.Size = new System.Drawing.Size(140, 23);
            this.cboMaHang.TabIndex = 6;
            // 
            // mtxtNgayKT
            // 
            this.mtxtNgayKT.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.mtxtNgayKT.Location = new System.Drawing.Point(311, 23);
            this.mtxtNgayKT.Mask = "00/00/0000";
            this.mtxtNgayKT.Name = "mtxtNgayKT";
            this.mtxtNgayKT.Size = new System.Drawing.Size(121, 21);
            this.mtxtNgayKT.TabIndex = 4;
            this.mtxtNgayKT.ValidatingType = typeof(System.DateTime);
            // 
            // lblNgayKT
            // 
            this.lblNgayKT.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblNgayKT.AutoSize = true;
            this.lblNgayKT.Location = new System.Drawing.Point(241, 25);
            this.lblNgayKT.Name = "lblNgayKT";
            this.lblNgayKT.Size = new System.Drawing.Size(60, 15);
            this.lblNgayKT.TabIndex = 3;
            this.lblNgayKT.Text = "Đến ngày";
            // 
            // mtxtNgayBD
            // 
            this.mtxtNgayBD.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.mtxtNgayBD.Location = new System.Drawing.Point(311, 53);
            this.mtxtNgayBD.Mask = "00/00/0000";
            this.mtxtNgayBD.Name = "mtxtNgayBD";
            this.mtxtNgayBD.Size = new System.Drawing.Size(121, 21);
            this.mtxtNgayBD.TabIndex = 4;
            this.mtxtNgayBD.ValidatingType = typeof(System.DateTime);
            // 
            // lblNgayBD
            // 
            this.lblNgayBD.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblNgayBD.AutoSize = true;
            this.lblNgayBD.Location = new System.Drawing.Point(241, 54);
            this.lblNgayBD.Name = "lblNgayBD";
            this.lblNgayBD.Size = new System.Drawing.Size(53, 15);
            this.lblNgayBD.TabIndex = 3;
            this.lblNgayBD.Text = "Từ ngày";
            // 
            // lblTenHang
            // 
            this.lblTenHang.AutoSize = true;
            this.lblTenHang.Location = new System.Drawing.Point(9, 58);
            this.lblTenHang.Name = "lblTenHang";
            this.lblTenHang.Size = new System.Drawing.Size(59, 15);
            this.lblTenHang.TabIndex = 0;
            this.lblTenHang.Text = "Tên hàng";
            // 
            // lblMaHang
            // 
            this.lblMaHang.AutoSize = true;
            this.lblMaHang.Location = new System.Drawing.Point(9, 26);
            this.lblMaHang.Name = "lblMaHang";
            this.lblMaHang.Size = new System.Drawing.Size(55, 15);
            this.lblMaHang.TabIndex = 0;
            this.lblMaHang.Text = "Mã hàng";
            // 
            // grbChiTietTheKho
            // 
            this.grbChiTietTheKho.Controls.Add(this.dgvTheKho);
            this.grbChiTietTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietTheKho.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbChiTietTheKho.Location = new System.Drawing.Point(3, 116);
            this.grbChiTietTheKho.Name = "grbChiTietTheKho";
            this.grbChiTietTheKho.Size = new System.Drawing.Size(634, 274);
            this.grbChiTietTheKho.TabIndex = 3;
            this.grbChiTietTheKho.TabStop = false;
            this.grbChiTietTheKho.Text = "Chi tiết thẻ kho";
            // 
            // dgvTheKho
            // 
            this.dgvTheKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTheKho.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvTheKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTheKho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaCT,
            this.NgayCT,
            this.MaHang,
            this.MaKho,
            this.DienGiai,
            this.SL});
            this.dgvTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTheKho.Location = new System.Drawing.Point(3, 16);
            this.dgvTheKho.Name = "dgvTheKho";
            this.dgvTheKho.Size = new System.Drawing.Size(628, 255);
            this.dgvTheKho.TabIndex = 0;
            // 
            // MaCT
            // 
            this.MaCT.HeaderText = "Mã chứng từ";
            this.MaCT.Name = "MaCT";
            // 
            // NgayCT
            // 
            this.NgayCT.HeaderText = "Ngày lập chứng từ";
            this.NgayCT.Name = "NgayCT";
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho nhập/xuất";
            this.MaKho.Name = "MaKho";
            // 
            // DienGiai
            // 
            this.DienGiai.HeaderText = "Diễn giải";
            this.DienGiai.Name = "DienGiai";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // bindingNavigatorSK
            // 
            this.bindingNavigatorSK.AddNewItem = this.tsbAddNewItemSK;
            this.bindingNavigatorSK.CountItem = this.tslCountItem;
            this.bindingNavigatorSK.DeleteItem = this.tsbDeleteItemSK;
            this.bindingNavigatorSK.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigatorSK.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemSK,
            this.tsbMovePreviousItemPSK,
            this.tsSeparator,
            this.tstbPositionItemSK,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemSK,
            this.tsbMoveLastItemSK,
            this.tslSeparator2,
            this.tsbAddNewItemSK,
            this.tsbDeleteItemSK,
            this.tsbSaveNewItemSK});
            this.bindingNavigatorSK.Location = new System.Drawing.Point(0, 393);
            this.bindingNavigatorSK.MoveFirstItem = this.tsbMoveFirstItemSK;
            this.bindingNavigatorSK.MoveLastItem = this.tsbMoveLastItemSK;
            this.bindingNavigatorSK.MoveNextItem = this.tsbMoveNextItemSK;
            this.bindingNavigatorSK.MovePreviousItem = this.tsbMovePreviousItemPSK;
            this.bindingNavigatorSK.Name = "bindingNavigatorSK";
            this.bindingNavigatorSK.PositionItem = this.tstbPositionItemSK;
            this.bindingNavigatorSK.Size = new System.Drawing.Size(640, 23);
            this.bindingNavigatorSK.TabIndex = 11;
            this.bindingNavigatorSK.Text = "bindingNavigator1";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 20);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 23);
            // 
            // tstbPositionItemSK
            // 
            this.tstbPositionItemSK.AccessibleName = "Position";
            this.tstbPositionItemSK.AutoSize = false;
            this.tstbPositionItemSK.Name = "tstbPositionItemSK";
            this.tstbPositionItemSK.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemSK.Text = "0";
            this.tstbPositionItemSK.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 23);
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 23);
            // 
            // tsbAddNewItemSK
            // 
            this.tsbAddNewItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemSK.Image")));
            this.tsbAddNewItemSK.Name = "tsbAddNewItemSK";
            this.tsbAddNewItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemSK.Size = new System.Drawing.Size(23, 20);
            this.tsbAddNewItemSK.Text = "Add new";
            // 
            // tsbDeleteItemSK
            // 
            this.tsbDeleteItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemSK.Image")));
            this.tsbDeleteItemSK.Name = "tsbDeleteItemSK";
            this.tsbDeleteItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemSK.Size = new System.Drawing.Size(23, 20);
            this.tsbDeleteItemSK.Text = "Delete";
            // 
            // tsbMoveFirstItemSK
            // 
            this.tsbMoveFirstItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemSK.Image")));
            this.tsbMoveFirstItemSK.Name = "tsbMoveFirstItemSK";
            this.tsbMoveFirstItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemSK.Size = new System.Drawing.Size(23, 20);
            this.tsbMoveFirstItemSK.Text = "Move first";
            // 
            // tsbMovePreviousItemPSK
            // 
            this.tsbMovePreviousItemPSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemPSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemPSK.Image")));
            this.tsbMovePreviousItemPSK.Name = "tsbMovePreviousItemPSK";
            this.tsbMovePreviousItemPSK.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemPSK.Size = new System.Drawing.Size(23, 20);
            this.tsbMovePreviousItemPSK.Text = "Move previous";
            // 
            // tsbMoveNextItemSK
            // 
            this.tsbMoveNextItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemSK.Image")));
            this.tsbMoveNextItemSK.Name = "tsbMoveNextItemSK";
            this.tsbMoveNextItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemSK.Size = new System.Drawing.Size(23, 20);
            this.tsbMoveNextItemSK.Text = "Move next";
            // 
            // tsbMoveLastItemSK
            // 
            this.tsbMoveLastItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemSK.Image")));
            this.tsbMoveLastItemSK.Name = "tsbMoveLastItemSK";
            this.tsbMoveLastItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemSK.Size = new System.Drawing.Size(23, 20);
            this.tsbMoveLastItemSK.Text = "Move last";
            // 
            // tsbSaveNewItemSK
            // 
            this.tsbSaveNewItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemSK.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemSK.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemSK.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemSK.Name = "tsbSaveNewItemSK";
            this.tsbSaveNewItemSK.Size = new System.Drawing.Size(23, 20);
            this.tsbSaveNewItemSK.Text = "Save";
            // 
            // btnXuatBaoCao
            // 
            this.btnXuatBaoCao.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatBaoCao.Image = global::QuanLyKhoSieuThi.Properties.Resources.printer;
            this.btnXuatBaoCao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXuatBaoCao.Location = new System.Drawing.Point(14, 49);
            this.btnXuatBaoCao.Name = "btnXuatBaoCao";
            this.btnXuatBaoCao.Size = new System.Drawing.Size(114, 37);
            this.btnXuatBaoCao.TabIndex = 7;
            this.btnXuatBaoCao.Text = "&Xuất báo cáo";
            this.btnXuatBaoCao.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXuatBaoCao.UseVisualStyleBackColor = true;
            // 
            // ucTheKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ucTheKho";
            this.Size = new System.Drawing.Size(640, 416);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.grbThongTinTheKho.ResumeLayout(false);
            this.grbThongTinTheKho.PerformLayout();
            this.grbButton.ResumeLayout(false);
            this.grbChiTietTheKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheKho)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSK)).EndInit();
            this.bindingNavigatorSK.ResumeLayout(false);
            this.bindingNavigatorSK.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox grbChiTietTheKho;
        private System.Windows.Forms.DataGridView dgvTheKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaCT;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayCT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn DienGiai;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.GroupBox grbThongTinTheKho;
        private System.Windows.Forms.GroupBox grbButton;
        private System.Windows.Forms.Button btnXuatBaoCao;
        private System.Windows.Forms.Button btnXem;
        private System.Windows.Forms.ComboBox cboTenHang;
        private System.Windows.Forms.ComboBox cboMaHang;
        private System.Windows.Forms.MaskedTextBox mtxtNgayKT;
        private System.Windows.Forms.Label lblNgayKT;
        private System.Windows.Forms.MaskedTextBox mtxtNgayBD;
        private System.Windows.Forms.Label lblNgayBD;
        private System.Windows.Forms.Label lblTenHang;
        private System.Windows.Forms.Label lblMaHang;
        private System.Windows.Forms.BindingNavigator bindingNavigatorSK;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemSK;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemSK;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemSK;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemPSK;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemSK;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemSK;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemSK;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemSK;
    }
}
