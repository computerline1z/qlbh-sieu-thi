﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace quan_ly_ban_hang_sieu_thi.Data_Access_Layer
{
    class QUYDINH_OBJ
    {
        string SLDATTOITHIEU;
        string TGKMTOITHIEU;
        string SLTONTOITHIEU;
        string SLTONTOIDA;
        string TGKMTOIDA;
        string TENHIENTHI;
        string DIACHI;
        string DIENTHOAI;
        string FAX;
        string NAMTHANHLAP;
        string TIENTO_HH;
        string TIENTO_PN;
        string TIENTO_PX;
        string TIENTO_NCC;
        string TIENTO_DDH;
        string TIENTO_HDCTY;
        string TIENTO_HDLE;
        string TIENTI_KHCTY; 
        string TIENTO_KHLE;

    }
}
