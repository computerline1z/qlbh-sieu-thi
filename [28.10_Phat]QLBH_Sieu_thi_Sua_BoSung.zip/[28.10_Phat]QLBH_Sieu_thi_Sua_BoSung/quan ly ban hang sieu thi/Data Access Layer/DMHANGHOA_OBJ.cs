﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace quan_ly_ban_hang_sieu_thi.Data_Access_Layer
{
    public class DMHANGHOA_OBJ
    {   /*
        private string Manhom;
        private string Mahang;
        private string Tenhang;
        private string Dvtinh;
        private string Maloai;
        private string Giaban;
        private string Khuyenmai;
        private string MaNCC;
        */
        public string Manhom  { get; set; }
        public string Mahang { get; set; }
        public string Tenhang { get; set; }
        public string DVT { get; set; }
        public string Maloai { get; set; }
        public string Giaban { get; set; }
        public string Khuyenmai { get; set; }
        public string MaNCC { get; set; }

       

    }
}
