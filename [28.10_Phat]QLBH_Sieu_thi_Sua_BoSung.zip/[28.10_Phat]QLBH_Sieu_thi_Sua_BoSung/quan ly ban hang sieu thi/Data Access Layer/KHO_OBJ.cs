﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace quan_ly_ban_hang_sieu_thi.Data_Access_Layer
{
    public class KHO_OBJ
    {
        public string Makho { get; set; }
        public string Tenkho { get; set; }
        public string DiachiKho { get; set; }
    }
}
