﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;

namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class HOADONLE_BUS:DataProvider
    {
        string sql = "";
        public void LayDSHoaDonLe()
        { }

        public bool ktTontaiHoaDon(string SoHD)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Hoadonle whhere SOHDle='{0}'", SoHD);
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }

        public bool ktTontaiHangTrongHoaDon(string Mahang)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from HoadonLe HD, CTHDLe CTHD where HD.SOHDLe=CTHD.SoHDLe and CTHD.Mahang='{0}'", Mahang);
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }
    }
}
