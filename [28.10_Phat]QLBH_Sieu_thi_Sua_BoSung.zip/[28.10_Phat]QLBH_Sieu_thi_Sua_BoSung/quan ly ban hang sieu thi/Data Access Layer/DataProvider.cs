﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Windows.Forms;
namespace quan_ly_ban_hang_sieu_thi.Data_Access_Layer
{
    public class DataProvider
    {
        static SqlConnection connection;
        SqlCommand command;
        SqlDataAdapter adapter;
        DataSet dts;
        DataTable dt;
        public string messageErrors = null;
        static public string connStr = "server=.\\SQLEXPRESS;database=QLST_DB;Integrated security=true;";

        

        static public void openConnection()
        {
            connection = new SqlConnection(connStr);
            connection.Open();
                
        }

        static public void closeConnection()
        {
            connection.Close();
        }

        public bool excuteNonQuery(string sqlQuery)
        {
            try
            {

                if (connection.State == ConnectionState.Closed)
                    openConnection();
                command = new SqlCommand(sqlQuery, connection);
                command.ExecuteNonQuery();
                closeConnection();
                return true;
                
            }
            catch (Exception ex)
            {
                messageErrors = ex.Message;
                return false;
            }
                        
        }
        public int countQuantity(string sql)
        
        {
            openConnection();
            command = new SqlCommand(sql, connection);           
            return (Int32) command.ExecuteScalar();
            closeConnection();
        }

        public object excuteScalar(string sql)
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                    openConnection();
                command = new SqlCommand(sql, connection);
                return command.ExecuteScalar();
                closeConnection();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public DataTable getDataTable(string sql, bool setDataProperties = false)
        {
            if(setDataProperties)
            {
                adapter = new SqlDataAdapter(sql,connection);
                dt = new DataTable();
                adapter.Fill(dt);
                return dt;
            }
            else
            {
                SqlDataAdapter NewAdapter = new SqlDataAdapter(sql,connection);
                DataTable Newdt = new DataTable();
                NewAdapter.Fill(Newdt);
                return Newdt;

            }
        }

        public DataTable getDataSetTBl(string sql, bool setDataProperties = false, string name="")
        {
            if (setDataProperties)
            {
                adapter = new SqlDataAdapter(sql, connection);
                dts = new DataSet();
                adapter.Fill(dts,name);
                return dts.Tables[name];
            }
            else
            {
                SqlDataAdapter NewAdapter = new SqlDataAdapter(sql, connection);
                DataTable Newdt = new DataTable();
                NewAdapter.Fill(Newdt);
                return Newdt;

            }
        }
       
        // phuong thuc cap nhat dataGribView xuong CSDL
        public int SaveToDB(string name)
        {
            int numRecords=0;
          //  SqlTransaction objTrans = connection.BeginTransaction();
            
            try
            {
                
                if (connection.State == ConnectionState.Closed)
                    openConnection();
                
         //      adapter.SelectCommand.Transaction = objTrans;
                // doi tuong sqlCommandBuilder quan ly viec thay doi du lieu vao DB
                SqlCommandBuilder sBuilder = new SqlCommandBuilder(adapter);
                numRecords = adapter.Update(dts.Tables[name]);
               // objTrans.Commit();
            }
            catch (Exception ex)
            {
                
             //       objTrans.Rollback();
                messageErrors = ex.Message;
                throw;
            }

            if (connection.State == ConnectionState.Open)
                closeConnection();

            return numRecords;
        }
        public void fillExDataTable(DataTable dtb)
        {
            try
            {

                adapter.Fill(dtb);
            }
            catch (Exception ex)
            {
                messageErrors = ex.Message;
            }
        }

    }

}
