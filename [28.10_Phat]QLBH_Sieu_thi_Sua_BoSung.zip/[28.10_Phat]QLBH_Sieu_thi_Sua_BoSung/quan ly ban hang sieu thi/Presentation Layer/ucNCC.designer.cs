﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucNCC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbNCC = new System.Windows.Forms.GroupBox();
            this.tlpThongTinNCC = new System.Windows.Forms.TableLayoutPanel();
            this.picXeHang = new System.Windows.Forms.PictureBox();
            this.pnlThongTinNCC1 = new System.Windows.Forms.Panel();
            this.txtTenNCC = new System.Windows.Forms.TextBox();
            this.lblTenNCC = new System.Windows.Forms.Label();
            this.txtSoTk = new System.Windows.Forms.TextBox();
            this.lblSoTKNCC = new System.Windows.Forms.Label();
            this.txtMathue = new System.Windows.Forms.TextBox();
            this.lblSoThueNCC = new System.Windows.Forms.Label();
            this.txtMaNCC = new System.Windows.Forms.TextBox();
            this.lblMaNCC = new System.Windows.Forms.Label();
            this.pnlThongTinNCC2 = new System.Windows.Forms.Panel();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDiaChiNCC = new System.Windows.Forms.Label();
            this.txtDienthoai = new System.Windows.Forms.TextBox();
            this.lblSodtNCC = new System.Windows.Forms.Label();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.lblSoFaxNCC = new System.Windows.Forms.Label();
            this.dgvNCC = new System.Windows.Forms.DataGridView();
            this.grbDSNCC = new System.Windows.Forms.GroupBox();
            this.tbplNCC = new System.Windows.Forms.TableLayoutPanel();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.grbNCC.SuspendLayout();
            this.tlpThongTinNCC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picXeHang)).BeginInit();
            this.pnlThongTinNCC1.SuspendLayout();
            this.pnlThongTinNCC2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNCC)).BeginInit();
            this.grbDSNCC.SuspendLayout();
            this.tbplNCC.SuspendLayout();
            this.pnlButton.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbNCC
            // 
            this.grbNCC.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.grbNCC.Controls.Add(this.tlpThongTinNCC);
            this.grbNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbNCC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbNCC.Location = new System.Drawing.Point(3, 3);
            this.grbNCC.Name = "grbNCC";
            this.grbNCC.Size = new System.Drawing.Size(752, 161);
            this.grbNCC.TabIndex = 0;
            this.grbNCC.TabStop = false;
            this.grbNCC.Text = "Thông tin nhà cung cấp";
            // 
            // tlpThongTinNCC
            // 
            this.tlpThongTinNCC.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpThongTinNCC.ColumnCount = 3;
            this.tlpThongTinNCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpThongTinNCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpThongTinNCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 203F));
            this.tlpThongTinNCC.Controls.Add(this.picXeHang, 2, 0);
            this.tlpThongTinNCC.Controls.Add(this.pnlThongTinNCC1, 0, 0);
            this.tlpThongTinNCC.Controls.Add(this.pnlThongTinNCC2, 1, 0);
            this.tlpThongTinNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpThongTinNCC.Location = new System.Drawing.Point(3, 17);
            this.tlpThongTinNCC.Name = "tlpThongTinNCC";
            this.tlpThongTinNCC.RowCount = 1;
            this.tlpThongTinNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinNCC.Size = new System.Drawing.Size(746, 141);
            this.tlpThongTinNCC.TabIndex = 0;
            // 
            // picXeHang
            // 
            this.picXeHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picXeHang.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.xe_cho_hang;
            this.picXeHang.Location = new System.Drawing.Point(542, 6);
            this.picXeHang.Name = "picXeHang";
            this.picXeHang.Size = new System.Drawing.Size(198, 129);
            this.picXeHang.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picXeHang.TabIndex = 3;
            this.picXeHang.TabStop = false;
            // 
            // pnlThongTinNCC1
            // 
            this.pnlThongTinNCC1.Controls.Add(this.txtTenNCC);
            this.pnlThongTinNCC1.Controls.Add(this.lblTenNCC);
            this.pnlThongTinNCC1.Controls.Add(this.txtSoTk);
            this.pnlThongTinNCC1.Controls.Add(this.lblSoTKNCC);
            this.pnlThongTinNCC1.Controls.Add(this.txtMathue);
            this.pnlThongTinNCC1.Controls.Add(this.lblSoThueNCC);
            this.pnlThongTinNCC1.Controls.Add(this.txtMaNCC);
            this.pnlThongTinNCC1.Controls.Add(this.lblMaNCC);
            this.pnlThongTinNCC1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlThongTinNCC1.Location = new System.Drawing.Point(6, 6);
            this.pnlThongTinNCC1.Name = "pnlThongTinNCC1";
            this.pnlThongTinNCC1.Size = new System.Drawing.Size(259, 129);
            this.pnlThongTinNCC1.TabIndex = 0;
            // 
            // txtTenNCC
            // 
            this.txtTenNCC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenNCC.Location = new System.Drawing.Point(94, 39);
            this.txtTenNCC.Name = "txtTenNCC";
            this.txtTenNCC.Size = new System.Drawing.Size(148, 21);
            this.txtTenNCC.TabIndex = 6;
            // 
            // lblTenNCC
            // 
            this.lblTenNCC.AutoSize = true;
            this.lblTenNCC.Location = new System.Drawing.Point(33, 40);
            this.lblTenNCC.Name = "lblTenNCC";
            this.lblTenNCC.Size = new System.Drawing.Size(55, 15);
            this.lblTenNCC.TabIndex = 5;
            this.lblTenNCC.Text = "Tên NCC";
            // 
            // txtSoTk
            // 
            this.txtSoTk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSoTk.Location = new System.Drawing.Point(94, 70);
            this.txtSoTk.Name = "txtSoTk";
            this.txtSoTk.Size = new System.Drawing.Size(148, 21);
            this.txtSoTk.TabIndex = 8;
            // 
            // lblSoTKNCC
            // 
            this.lblSoTKNCC.AutoSize = true;
            this.lblSoTKNCC.Location = new System.Drawing.Point(11, 71);
            this.lblSoTKNCC.Name = "lblSoTKNCC";
            this.lblSoTKNCC.Size = new System.Drawing.Size(77, 15);
            this.lblSoTKNCC.TabIndex = 4;
            this.lblSoTKNCC.Text = "Số tài khoản";
            // 
            // txtMathue
            // 
            this.txtMathue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMathue.Location = new System.Drawing.Point(94, 97);
            this.txtMathue.Name = "txtMathue";
            this.txtMathue.Size = new System.Drawing.Size(148, 21);
            this.txtMathue.TabIndex = 9;
            // 
            // lblSoThueNCC
            // 
            this.lblSoThueNCC.AutoSize = true;
            this.lblSoThueNCC.Location = new System.Drawing.Point(19, 98);
            this.lblSoThueNCC.Name = "lblSoThueNCC";
            this.lblSoThueNCC.Size = new System.Drawing.Size(69, 15);
            this.lblSoThueNCC.TabIndex = 3;
            this.lblSoThueNCC.Text = "Mã số thuế";
            // 
            // txtMaNCC
            // 
            this.txtMaNCC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMaNCC.Location = new System.Drawing.Point(94, 8);
            this.txtMaNCC.Name = "txtMaNCC";
            this.txtMaNCC.Size = new System.Drawing.Size(148, 21);
            this.txtMaNCC.TabIndex = 7;
            // 
            // lblMaNCC
            // 
            this.lblMaNCC.AutoSize = true;
            this.lblMaNCC.Location = new System.Drawing.Point(37, 12);
            this.lblMaNCC.Name = "lblMaNCC";
            this.lblMaNCC.Size = new System.Drawing.Size(51, 15);
            this.lblMaNCC.TabIndex = 2;
            this.lblMaNCC.Text = "Mã NCC";
            // 
            // pnlThongTinNCC2
            // 
            this.pnlThongTinNCC2.Controls.Add(this.txtDiaChi);
            this.pnlThongTinNCC2.Controls.Add(this.lblDiaChiNCC);
            this.pnlThongTinNCC2.Controls.Add(this.txtDienthoai);
            this.pnlThongTinNCC2.Controls.Add(this.lblSodtNCC);
            this.pnlThongTinNCC2.Controls.Add(this.txtFax);
            this.pnlThongTinNCC2.Controls.Add(this.lblSoFaxNCC);
            this.pnlThongTinNCC2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlThongTinNCC2.Location = new System.Drawing.Point(274, 6);
            this.pnlThongTinNCC2.Name = "pnlThongTinNCC2";
            this.pnlThongTinNCC2.Size = new System.Drawing.Size(259, 129);
            this.pnlThongTinNCC2.TabIndex = 0;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDiaChi.Location = new System.Drawing.Point(60, 23);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(180, 21);
            this.txtDiaChi.TabIndex = 5;
            // 
            // lblDiaChiNCC
            // 
            this.lblDiaChiNCC.AutoSize = true;
            this.lblDiaChiNCC.Location = new System.Drawing.Point(8, 27);
            this.lblDiaChiNCC.Name = "lblDiaChiNCC";
            this.lblDiaChiNCC.Size = new System.Drawing.Size(46, 15);
            this.lblDiaChiNCC.TabIndex = 3;
            this.lblDiaChiNCC.Text = "Địa chỉ";
            // 
            // txtDienthoai
            // 
            this.txtDienthoai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDienthoai.Location = new System.Drawing.Point(60, 54);
            this.txtDienthoai.Name = "txtDienthoai";
            this.txtDienthoai.Size = new System.Drawing.Size(117, 21);
            this.txtDienthoai.TabIndex = 7;
            // 
            // lblSodtNCC
            // 
            this.lblSodtNCC.AutoSize = true;
            this.lblSodtNCC.Location = new System.Drawing.Point(13, 58);
            this.lblSodtNCC.Name = "lblSodtNCC";
            this.lblSodtNCC.Size = new System.Drawing.Size(41, 15);
            this.lblSodtNCC.TabIndex = 2;
            this.lblSodtNCC.Text = "Số ĐT";
            // 
            // txtFax
            // 
            this.txtFax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFax.Location = new System.Drawing.Point(60, 85);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(117, 21);
            this.txtFax.TabIndex = 6;
            // 
            // lblSoFaxNCC
            // 
            this.lblSoFaxNCC.AutoSize = true;
            this.lblSoFaxNCC.Location = new System.Drawing.Point(9, 89);
            this.lblSoFaxNCC.Name = "lblSoFaxNCC";
            this.lblSoFaxNCC.Size = new System.Drawing.Size(45, 15);
            this.lblSoFaxNCC.TabIndex = 4;
            this.lblSoFaxNCC.Text = "Số Fax";
            // 
            // dgvNCC
            // 
            this.dgvNCC.AllowUserToAddRows = false;
            this.dgvNCC.AllowUserToDeleteRows = false;
            this.dgvNCC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNCC.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvNCC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNCC.Location = new System.Drawing.Point(3, 16);
            this.dgvNCC.MultiSelect = false;
            this.dgvNCC.Name = "dgvNCC";
            this.dgvNCC.ReadOnly = true;
            this.dgvNCC.RowTemplate.Height = 24;
            this.dgvNCC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNCC.Size = new System.Drawing.Size(746, 253);
            this.dgvNCC.TabIndex = 0;
            // 
            // grbDSNCC
            // 
            this.grbDSNCC.Controls.Add(this.dgvNCC);
            this.grbDSNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDSNCC.Location = new System.Drawing.Point(3, 170);
            this.grbDSNCC.Name = "grbDSNCC";
            this.grbDSNCC.Size = new System.Drawing.Size(752, 272);
            this.grbDSNCC.TabIndex = 1;
            this.grbDSNCC.TabStop = false;
            this.grbDSNCC.Text = "Danh sách nhà cung cấp";
            // 
            // tbplNCC
            // 
            this.tbplNCC.ColumnCount = 1;
            this.tbplNCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplNCC.Controls.Add(this.grbDSNCC, 0, 1);
            this.tbplNCC.Controls.Add(this.pnlButton, 0, 2);
            this.tbplNCC.Controls.Add(this.grbNCC, 0, 0);
            this.tbplNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplNCC.Location = new System.Drawing.Point(0, 0);
            this.tbplNCC.Name = "tbplNCC";
            this.tbplNCC.RowCount = 3;
            this.tbplNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 167F));
            this.tbplNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tbplNCC.Size = new System.Drawing.Size(758, 485);
            this.tbplNCC.TabIndex = 2;
            // 
            // pnlButton
            // 
            this.pnlButton.Controls.Add(this.btnLuu);
            this.pnlButton.Controls.Add(this.btnXoa);
            this.pnlButton.Controls.Add(this.btnThem);
            this.pnlButton.Controls.Add(this.btnSua);
            this.pnlButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButton.Location = new System.Drawing.Point(3, 448);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(752, 34);
            this.pnlButton.TabIndex = 2;
            // 
            // btnLuu
            // 
            this.btnLuu.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(574, 6);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 18;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(500, 6);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 19;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(350, 6);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 16;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(425, 6);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 17;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // ucNCC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbplNCC);
            this.Name = "ucNCC";
            this.Size = new System.Drawing.Size(758, 485);
            this.grbNCC.ResumeLayout(false);
            this.tlpThongTinNCC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picXeHang)).EndInit();
            this.pnlThongTinNCC1.ResumeLayout(false);
            this.pnlThongTinNCC1.PerformLayout();
            this.pnlThongTinNCC2.ResumeLayout(false);
            this.pnlThongTinNCC2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNCC)).EndInit();
            this.grbDSNCC.ResumeLayout(false);
            this.tbplNCC.ResumeLayout(false);
            this.pnlButton.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbNCC;
        private System.Windows.Forms.TableLayoutPanel tlpThongTinNCC;
        private System.Windows.Forms.PictureBox picXeHang;
        private System.Windows.Forms.Panel pnlThongTinNCC1;
        private System.Windows.Forms.TextBox txtTenNCC;
        private System.Windows.Forms.Label lblTenNCC;
        private System.Windows.Forms.TextBox txtSoTk;
        private System.Windows.Forms.Label lblSoTKNCC;
        private System.Windows.Forms.TextBox txtMathue;
        private System.Windows.Forms.Label lblSoThueNCC;
        private System.Windows.Forms.TextBox txtMaNCC;
        private System.Windows.Forms.Label lblMaNCC;
        private System.Windows.Forms.Panel pnlThongTinNCC2;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblDiaChiNCC;
        private System.Windows.Forms.TextBox txtDienthoai;
        private System.Windows.Forms.Label lblSodtNCC;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Label lblSoFaxNCC;
        private System.Windows.Forms.DataGridView dgvNCC;
        private System.Windows.Forms.GroupBox grbDSNCC;
        private System.Windows.Forms.TableLayoutPanel tbplNCC;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;

    }
}
