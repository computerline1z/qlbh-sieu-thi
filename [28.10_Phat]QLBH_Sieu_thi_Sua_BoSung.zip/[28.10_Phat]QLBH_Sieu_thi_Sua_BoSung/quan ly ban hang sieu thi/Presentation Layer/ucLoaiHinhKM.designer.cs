﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucLoaiHinhKM
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnXoa = new System.Windows.Forms.Button();
            this.txtDienGiai = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.lblDienGiai = new System.Windows.Forms.Label();
            this.grbLoai = new System.Windows.Forms.GroupBox();
            this.dgvDanhSachLoaiKM = new System.Windows.Forms.DataGridView();
            this.LoaiKM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DienGiai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnLuu = new System.Windows.Forms.Button();
            this.grbLoaiKM = new System.Windows.Forms.GroupBox();
            this.txtLoaiKM = new System.Windows.Forms.TextBox();
            this.lblLoaiKM = new System.Windows.Forms.Label();
            this.tbplLoaiHinhKhuyenMai = new System.Windows.Forms.TableLayoutPanel();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.tlpLoaiHinhKhuyenMai = new System.Windows.Forms.TableLayoutPanel();
            this.grbLoai.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachLoaiKM)).BeginInit();
            this.grbLoaiKM.SuspendLayout();
            this.tbplLoaiHinhKhuyenMai.SuspendLayout();
            this.pnlButton.SuspendLayout();
            this.tlpLoaiHinhKhuyenMai.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnXoa
            // 
            this.btnXoa.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(498, 4);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 19;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // txtDienGiai
            // 
            this.txtDienGiai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDienGiai.Location = new System.Drawing.Point(123, 62);
            this.txtDienGiai.Name = "txtDienGiai";
            this.txtDienGiai.Size = new System.Drawing.Size(414, 21);
            this.txtDienGiai.TabIndex = 3;
            // 
            // btnThem
            // 
            this.btnThem.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(348, 4);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 16;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(423, 4);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 17;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // lblDienGiai
            // 
            this.lblDienGiai.AutoSize = true;
            this.lblDienGiai.Location = new System.Drawing.Point(62, 62);
            this.lblDienGiai.Name = "lblDienGiai";
            this.lblDienGiai.Size = new System.Drawing.Size(55, 15);
            this.lblDienGiai.TabIndex = 2;
            this.lblDienGiai.Text = "Diễn giải";
            // 
            // grbLoai
            // 
            this.grbLoai.Controls.Add(this.dgvDanhSachLoaiKM);
            this.grbLoai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbLoai.Location = new System.Drawing.Point(3, 123);
            this.grbLoai.Name = "grbLoai";
            this.grbLoai.Size = new System.Drawing.Size(750, 268);
            this.grbLoai.TabIndex = 10;
            this.grbLoai.TabStop = false;
            this.grbLoai.Text = "Danh sách loại khuyến mãi";
            // 
            // dgvDanhSachLoaiKM
            // 
            this.dgvDanhSachLoaiKM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSachLoaiKM.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvDanhSachLoaiKM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachLoaiKM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LoaiKM,
            this.DienGiai});
            this.dgvDanhSachLoaiKM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSachLoaiKM.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhSachLoaiKM.Name = "dgvDanhSachLoaiKM";
            this.dgvDanhSachLoaiKM.Size = new System.Drawing.Size(744, 249);
            this.dgvDanhSachLoaiKM.TabIndex = 0;
            // 
            // LoaiKM
            // 
            this.LoaiKM.HeaderText = "Loại khuyến mãi";
            this.LoaiKM.Name = "LoaiKM";
            // 
            // DienGiai
            // 
            this.DienGiai.HeaderText = "Diễn giải";
            this.DienGiai.Name = "DienGiai";
            // 
            // btnLuu
            // 
            this.btnLuu.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(572, 4);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 18;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // grbLoaiKM
            // 
            this.grbLoaiKM.Controls.Add(this.txtDienGiai);
            this.grbLoaiKM.Controls.Add(this.lblDienGiai);
            this.grbLoaiKM.Controls.Add(this.txtLoaiKM);
            this.grbLoaiKM.Controls.Add(this.lblLoaiKM);
            this.grbLoaiKM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbLoaiKM.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbLoaiKM.Location = new System.Drawing.Point(6, 6);
            this.grbLoaiKM.Name = "grbLoaiKM";
            this.grbLoaiKM.Size = new System.Drawing.Size(738, 102);
            this.grbLoaiKM.TabIndex = 5;
            this.grbLoaiKM.TabStop = false;
            this.grbLoaiKM.Text = "Thông tin loại khuyến mãi";
            // 
            // txtLoaiKM
            // 
            this.txtLoaiKM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLoaiKM.Location = new System.Drawing.Point(123, 24);
            this.txtLoaiKM.Name = "txtLoaiKM";
            this.txtLoaiKM.Size = new System.Drawing.Size(291, 21);
            this.txtLoaiKM.TabIndex = 1;
            // 
            // lblLoaiKM
            // 
            this.lblLoaiKM.AutoSize = true;
            this.lblLoaiKM.Location = new System.Drawing.Point(18, 30);
            this.lblLoaiKM.Name = "lblLoaiKM";
            this.lblLoaiKM.Size = new System.Drawing.Size(99, 15);
            this.lblLoaiKM.TabIndex = 0;
            this.lblLoaiKM.Text = "Loại khuyến mãi";
            // 
            // tbplLoaiHinhKhuyenMai
            // 
            this.tbplLoaiHinhKhuyenMai.ColumnCount = 1;
            this.tbplLoaiHinhKhuyenMai.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplLoaiHinhKhuyenMai.Controls.Add(this.grbLoai, 0, 1);
            this.tbplLoaiHinhKhuyenMai.Controls.Add(this.pnlButton, 0, 1);
            this.tbplLoaiHinhKhuyenMai.Controls.Add(this.tlpLoaiHinhKhuyenMai, 0, 0);
            this.tbplLoaiHinhKhuyenMai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplLoaiHinhKhuyenMai.Location = new System.Drawing.Point(0, 0);
            this.tbplLoaiHinhKhuyenMai.Name = "tbplLoaiHinhKhuyenMai";
            this.tbplLoaiHinhKhuyenMai.RowCount = 2;
            this.tbplLoaiHinhKhuyenMai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tbplLoaiHinhKhuyenMai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplLoaiHinhKhuyenMai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tbplLoaiHinhKhuyenMai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbplLoaiHinhKhuyenMai.Size = new System.Drawing.Size(756, 432);
            this.tbplLoaiHinhKhuyenMai.TabIndex = 2;
            // 
            // pnlButton
            // 
            this.pnlButton.Controls.Add(this.btnLuu);
            this.pnlButton.Controls.Add(this.btnXoa);
            this.pnlButton.Controls.Add(this.btnThem);
            this.pnlButton.Controls.Add(this.btnSua);
            this.pnlButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButton.Location = new System.Drawing.Point(3, 397);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(750, 32);
            this.pnlButton.TabIndex = 9;
            // 
            // tlpLoaiHinhKhuyenMai
            // 
            this.tlpLoaiHinhKhuyenMai.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpLoaiHinhKhuyenMai.ColumnCount = 1;
            this.tlpLoaiHinhKhuyenMai.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.70281F));
            this.tlpLoaiHinhKhuyenMai.Controls.Add(this.grbLoaiKM, 0, 0);
            this.tlpLoaiHinhKhuyenMai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpLoaiHinhKhuyenMai.Location = new System.Drawing.Point(3, 3);
            this.tlpLoaiHinhKhuyenMai.Name = "tlpLoaiHinhKhuyenMai";
            this.tlpLoaiHinhKhuyenMai.RowCount = 1;
            this.tlpLoaiHinhKhuyenMai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpLoaiHinhKhuyenMai.Size = new System.Drawing.Size(750, 114);
            this.tlpLoaiHinhKhuyenMai.TabIndex = 8;
            // 
            // ucLoaiHinhKM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbplLoaiHinhKhuyenMai);
            this.Name = "ucLoaiHinhKM";
            this.Size = new System.Drawing.Size(756, 432);
            this.grbLoai.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachLoaiKM)).EndInit();
            this.grbLoaiKM.ResumeLayout(false);
            this.grbLoaiKM.PerformLayout();
            this.tbplLoaiHinhKhuyenMai.ResumeLayout(false);
            this.pnlButton.ResumeLayout(false);
            this.tlpLoaiHinhKhuyenMai.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.TextBox txtDienGiai;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Label lblDienGiai;
        private System.Windows.Forms.GroupBox grbLoai;
        private System.Windows.Forms.DataGridView dgvDanhSachLoaiKM;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaiKM;
        private System.Windows.Forms.DataGridViewTextBoxColumn DienGiai;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.GroupBox grbLoaiKM;
        private System.Windows.Forms.TextBox txtLoaiKM;
        private System.Windows.Forms.Label lblLoaiKM;
        private System.Windows.Forms.TableLayoutPanel tbplLoaiHinhKhuyenMai;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.TableLayoutPanel tlpLoaiHinhKhuyenMai;

    }
}
