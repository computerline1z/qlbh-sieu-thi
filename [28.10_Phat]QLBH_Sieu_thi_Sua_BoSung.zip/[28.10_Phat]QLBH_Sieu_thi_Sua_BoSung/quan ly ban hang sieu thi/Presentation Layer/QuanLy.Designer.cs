﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class frmQL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Hàng hóa");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Đơn vị tính");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Loại Hàng");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Hóa đơn Công ty");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Hóa đơn lẻ");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Hóa đơn", new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Phiếu xuất");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Phiếu nhập");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Phiếu chuyển");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Danh mục", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9});
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Quản lý hàng tồn");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Lập Đơn đặt hàng");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Quản lý mặt hàng", new System.Windows.Forms.TreeNode[] {
            treeNode11,
            treeNode12});
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Quản lý giá cả");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Khách hàng Cty");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Nhà cung cấp");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Quản lý đối tác", new System.Windows.Forms.TreeNode[] {
            treeNode15,
            treeNode16});
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Tra cứu hàng hóa khuyến mãi");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Tạo chương trình KM");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Loại hình KM");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Quản lý khuyến mãi", new System.Windows.Forms.TreeNode[] {
            treeNode18,
            treeNode19,
            treeNode20});
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Nghiệp vụ", new System.Windows.Forms.TreeNode[] {
            treeNode13,
            treeNode14,
            treeNode17,
            treeNode21});
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Doanh thu theo thời gian");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Thống kê lượng hàng");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Báo cáo - Thống kê", new System.Windows.Forms.TreeNode[] {
            treeNode23,
            treeNode24});
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ItTuychinh = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýTàiKhoảnNgườiDùngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemThôngTinTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đổiMậtKhẩuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bộPhímTắtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hướngDẫnSửDụngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainMenuQL = new System.Windows.Forms.MenuStrip();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.grbNghiepVu = new System.Windows.Forms.GroupBox();
            this.tbpNghiepVu = new System.Windows.Forms.TableLayoutPanel();
            this.btnGiaca = new System.Windows.Forms.Button();
            this.btnQLMatHang = new System.Windows.Forms.Button();
            this.btnQLKhuyenMai = new System.Windows.Forms.Button();
            this.btnQuyDinh = new System.Windows.Forms.Button();
            this.btnQLDoiTac = new System.Windows.Forms.Button();
            this.grbDanhMuc = new System.Windows.Forms.GroupBox();
            this.tbpDM = new System.Windows.Forms.TableLayoutPanel();
            this.btnHoaDon = new System.Windows.Forms.Button();
            this.btnHangHoa = new System.Windows.Forms.Button();
            this.grbBaoCaoThongKe = new System.Windows.Forms.GroupBox();
            this.tbpBC_TK = new System.Windows.Forms.TableLayoutPanel();
            this.btnHang = new System.Windows.Forms.Button();
            this.btnDoanhThu = new System.Windows.Forms.Button();
            this.slcMain = new System.Windows.Forms.SplitContainer();
            this.treeMain = new System.Windows.Forms.TreeView();
            this.tblMain = new System.Windows.Forms.TableLayoutPanel();
            this.btnDongTab = new System.Windows.Forms.Button();
            this.mainMenuQL.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.grbNghiepVu.SuspendLayout();
            this.tbpNghiepVu.SuspendLayout();
            this.grbDanhMuc.SuspendLayout();
            this.tbpDM.SuspendLayout();
            this.grbBaoCaoThongKe.SuspendLayout();
            this.tbpBC_TK.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slcMain)).BeginInit();
            this.slcMain.Panel1.SuspendLayout();
            this.slcMain.Panel2.SuspendLayout();
            this.slcMain.SuspendLayout();
            this.tblMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ItTuychinh,
            this.quảnLýTàiKhoảnNgườiDùngToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.hệThốngToolStripMenuItem.Text = "Hệ thống";
            // 
            // ItTuychinh
            // 
            this.ItTuychinh.Name = "ItTuychinh";
            this.ItTuychinh.Size = new System.Drawing.Size(232, 22);
            this.ItTuychinh.Text = "Tùy chỉnh";
            // 
            // quảnLýTàiKhoảnNgườiDùngToolStripMenuItem
            // 
            this.quảnLýTàiKhoảnNgườiDùngToolStripMenuItem.Name = "quảnLýTàiKhoảnNgườiDùngToolStripMenuItem";
            this.quảnLýTàiKhoảnNgườiDùngToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.quảnLýTàiKhoảnNgườiDùngToolStripMenuItem.Text = "Quản lý tài khoản người dùng";
            this.quảnLýTàiKhoảnNgườiDùngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýTàiKhoảnNgườiDùngToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // tàiKhoảnToolStripMenuItem
            // 
            this.tàiKhoảnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xemThôngTinTàiKhoảnToolStripMenuItem,
            this.đổiMậtKhẩuToolStripMenuItem,
            this.đăngXuấtToolStripMenuItem});
            this.tàiKhoảnToolStripMenuItem.Name = "tàiKhoảnToolStripMenuItem";
            this.tàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.tàiKhoảnToolStripMenuItem.Text = "Tài khoản";
            // 
            // xemThôngTinTàiKhoảnToolStripMenuItem
            // 
            this.xemThôngTinTàiKhoảnToolStripMenuItem.Name = "xemThôngTinTàiKhoảnToolStripMenuItem";
            this.xemThôngTinTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.xemThôngTinTàiKhoảnToolStripMenuItem.Text = "Xem thông tin tài khoản";
            // 
            // đổiMậtKhẩuToolStripMenuItem
            // 
            this.đổiMậtKhẩuToolStripMenuItem.Name = "đổiMậtKhẩuToolStripMenuItem";
            this.đổiMậtKhẩuToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.đổiMậtKhẩuToolStripMenuItem.Text = "Đổi mật khẩu";
            this.đổiMậtKhẩuToolStripMenuItem.Click += new System.EventHandler(this.đổiMậtKhẩuToolStripMenuItem_Click);
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bộPhímTắtToolStripMenuItem,
            this.hướngDẫnSửDụngToolStripMenuItem,
            this.giớiThiệuToolStripMenuItem});
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ giúp";
            // 
            // bộPhímTắtToolStripMenuItem
            // 
            this.bộPhímTắtToolStripMenuItem.Name = "bộPhímTắtToolStripMenuItem";
            this.bộPhímTắtToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.bộPhímTắtToolStripMenuItem.Text = "Bộ phím tắt";
            // 
            // hướngDẫnSửDụngToolStripMenuItem
            // 
            this.hướngDẫnSửDụngToolStripMenuItem.Name = "hướngDẫnSửDụngToolStripMenuItem";
            this.hướngDẫnSửDụngToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.hướngDẫnSửDụngToolStripMenuItem.Text = "Hướng dẫn sử dụng";
            // 
            // giớiThiệuToolStripMenuItem
            // 
            this.giớiThiệuToolStripMenuItem.Name = "giớiThiệuToolStripMenuItem";
            this.giớiThiệuToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.giớiThiệuToolStripMenuItem.Text = "Liên hệ";
            // 
            // mainMenuQL
            // 
            this.mainMenuQL.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.mainMenuQL.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.tàiKhoảnToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.mainMenuQL.Location = new System.Drawing.Point(0, 0);
            this.mainMenuQL.Name = "mainMenuQL";
            this.mainMenuQL.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.mainMenuQL.Size = new System.Drawing.Size(752, 24);
            this.mainMenuQL.TabIndex = 0;
            this.mainMenuQL.Text = "menuStrip1";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.96819F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.96421F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.06759F));
            this.tableLayoutPanel1.Controls.Add(this.grbNghiepVu, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.grbDanhMuc, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.grbBaoCaoThongKe, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 76F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(752, 76);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // grbNghiepVu
            // 
            this.grbNghiepVu.Controls.Add(this.tbpNghiepVu);
            this.grbNghiepVu.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.grbNghiepVu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbNghiepVu.Location = new System.Drawing.Point(168, 3);
            this.grbNghiepVu.Name = "grbNghiepVu";
            this.grbNghiepVu.Size = new System.Drawing.Size(414, 70);
            this.grbNghiepVu.TabIndex = 1;
            this.grbNghiepVu.TabStop = false;
            this.grbNghiepVu.Text = "Nghiệp vụ";
            // 
            // tbpNghiepVu
            // 
            this.tbpNghiepVu.ColumnCount = 5;
            this.tbpNghiepVu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tbpNghiepVu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tbpNghiepVu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tbpNghiepVu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tbpNghiepVu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tbpNghiepVu.Controls.Add(this.btnGiaca, 1, 0);
            this.tbpNghiepVu.Controls.Add(this.btnQLMatHang, 0, 0);
            this.tbpNghiepVu.Controls.Add(this.btnQLKhuyenMai, 3, 0);
            this.tbpNghiepVu.Controls.Add(this.btnQuyDinh, 4, 0);
            this.tbpNghiepVu.Controls.Add(this.btnQLDoiTac, 2, 0);
            this.tbpNghiepVu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbpNghiepVu.Location = new System.Drawing.Point(3, 17);
            this.tbpNghiepVu.Name = "tbpNghiepVu";
            this.tbpNghiepVu.RowCount = 1;
            this.tbpNghiepVu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbpNghiepVu.Size = new System.Drawing.Size(408, 50);
            this.tbpNghiepVu.TabIndex = 0;
            // 
            // btnGiaca
            // 
            this.btnGiaca.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnGiaca.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnGiaca.Location = new System.Drawing.Point(84, 3);
            this.btnGiaca.Name = "btnGiaca";
            this.btnGiaca.Size = new System.Drawing.Size(75, 44);
            this.btnGiaca.TabIndex = 1;
            this.btnGiaca.Text = "Quản lý giá cả";
            this.btnGiaca.UseVisualStyleBackColor = true;
            this.btnGiaca.Click += new System.EventHandler(this.btnGiaca_Click);
            // 
            // btnQLMatHang
            // 
            this.btnQLMatHang.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnQLMatHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQLMatHang.Location = new System.Drawing.Point(3, 3);
            this.btnQLMatHang.Name = "btnQLMatHang";
            this.btnQLMatHang.Size = new System.Drawing.Size(75, 44);
            this.btnQLMatHang.TabIndex = 0;
            this.btnQLMatHang.Text = "Quản lý mặt hàng";
            this.btnQLMatHang.UseVisualStyleBackColor = true;
            this.btnQLMatHang.Click += new System.EventHandler(this.btnQLMatHang_Click);
            // 
            // btnQLKhuyenMai
            // 
            this.btnQLKhuyenMai.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnQLKhuyenMai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQLKhuyenMai.Location = new System.Drawing.Point(246, 3);
            this.btnQLKhuyenMai.Name = "btnQLKhuyenMai";
            this.btnQLKhuyenMai.Size = new System.Drawing.Size(75, 44);
            this.btnQLKhuyenMai.TabIndex = 3;
            this.btnQLKhuyenMai.Text = "Quản lý khuyến mãi";
            this.btnQLKhuyenMai.UseVisualStyleBackColor = true;
            this.btnQLKhuyenMai.Click += new System.EventHandler(this.btnQLKhuyenMai_Click);
            // 
            // btnQuyDinh
            // 
            this.btnQuyDinh.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnQuyDinh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQuyDinh.Location = new System.Drawing.Point(327, 3);
            this.btnQuyDinh.Name = "btnQuyDinh";
            this.btnQuyDinh.Size = new System.Drawing.Size(78, 44);
            this.btnQuyDinh.TabIndex = 4;
            this.btnQuyDinh.Text = "Quy định";
            this.btnQuyDinh.UseVisualStyleBackColor = true;
            this.btnQuyDinh.Click += new System.EventHandler(this.btnQuyDinh_Click);
            // 
            // btnQLDoiTac
            // 
            this.btnQLDoiTac.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnQLDoiTac.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQLDoiTac.Location = new System.Drawing.Point(165, 3);
            this.btnQLDoiTac.Name = "btnQLDoiTac";
            this.btnQLDoiTac.Size = new System.Drawing.Size(75, 44);
            this.btnQLDoiTac.TabIndex = 2;
            this.btnQLDoiTac.Text = "Quản lý đối tác";
            this.btnQLDoiTac.UseVisualStyleBackColor = true;
            this.btnQLDoiTac.Click += new System.EventHandler(this.btnQLDoiTac_Click);
            // 
            // grbDanhMuc
            // 
            this.grbDanhMuc.Controls.Add(this.tbpDM);
            this.grbDanhMuc.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.grbDanhMuc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhMuc.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDanhMuc.Location = new System.Drawing.Point(3, 3);
            this.grbDanhMuc.Name = "grbDanhMuc";
            this.grbDanhMuc.Size = new System.Drawing.Size(159, 70);
            this.grbDanhMuc.TabIndex = 0;
            this.grbDanhMuc.TabStop = false;
            this.grbDanhMuc.Text = "Danh mục";
            // 
            // tbpDM
            // 
            this.tbpDM.ColumnCount = 2;
            this.tbpDM.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tbpDM.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tbpDM.Controls.Add(this.btnHoaDon, 0, 0);
            this.tbpDM.Controls.Add(this.btnHangHoa, 0, 0);
            this.tbpDM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbpDM.Location = new System.Drawing.Point(3, 17);
            this.tbpDM.Name = "tbpDM";
            this.tbpDM.RowCount = 1;
            this.tbpDM.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbpDM.Size = new System.Drawing.Size(153, 50);
            this.tbpDM.TabIndex = 0;
            // 
            // btnHoaDon
            // 
            this.btnHoaDon.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnHoaDon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHoaDon.Location = new System.Drawing.Point(79, 3);
            this.btnHoaDon.Name = "btnHoaDon";
            this.btnHoaDon.Size = new System.Drawing.Size(71, 44);
            this.btnHoaDon.TabIndex = 1;
            this.btnHoaDon.Text = "Hóa đơn";
            this.btnHoaDon.UseVisualStyleBackColor = true;
            this.btnHoaDon.Click += new System.EventHandler(this.btnHoaDon_Click);
            // 
            // btnHangHoa
            // 
            this.btnHangHoa.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnHangHoa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHangHoa.Location = new System.Drawing.Point(3, 3);
            this.btnHangHoa.Name = "btnHangHoa";
            this.btnHangHoa.Size = new System.Drawing.Size(70, 44);
            this.btnHangHoa.TabIndex = 0;
            this.btnHangHoa.Text = "Hàng hóa";
            this.btnHangHoa.UseVisualStyleBackColor = true;
            this.btnHangHoa.Click += new System.EventHandler(this.btnHangHoa_Click);
            // 
            // grbBaoCaoThongKe
            // 
            this.grbBaoCaoThongKe.Controls.Add(this.tbpBC_TK);
            this.grbBaoCaoThongKe.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.grbBaoCaoThongKe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbBaoCaoThongKe.Location = new System.Drawing.Point(588, 3);
            this.grbBaoCaoThongKe.Name = "grbBaoCaoThongKe";
            this.grbBaoCaoThongKe.Size = new System.Drawing.Size(161, 70);
            this.grbBaoCaoThongKe.TabIndex = 2;
            this.grbBaoCaoThongKe.TabStop = false;
            this.grbBaoCaoThongKe.Text = "Báo cáo - thống kê";
            // 
            // tbpBC_TK
            // 
            this.tbpBC_TK.ColumnCount = 2;
            this.tbpBC_TK.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tbpBC_TK.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tbpBC_TK.Controls.Add(this.btnHang, 0, 0);
            this.tbpBC_TK.Controls.Add(this.btnDoanhThu, 0, 0);
            this.tbpBC_TK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbpBC_TK.Location = new System.Drawing.Point(3, 17);
            this.tbpBC_TK.Name = "tbpBC_TK";
            this.tbpBC_TK.RowCount = 1;
            this.tbpBC_TK.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbpBC_TK.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tbpBC_TK.Size = new System.Drawing.Size(155, 50);
            this.tbpBC_TK.TabIndex = 0;
            // 
            // btnHang
            // 
            this.btnHang.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHang.Location = new System.Drawing.Point(80, 3);
            this.btnHang.Name = "btnHang";
            this.btnHang.Size = new System.Drawing.Size(72, 44);
            this.btnHang.TabIndex = 1;
            this.btnHang.Text = "Hàng tồn";
            this.btnHang.UseVisualStyleBackColor = true;
            this.btnHang.Click += new System.EventHandler(this.btnHang_Click);
            // 
            // btnDoanhThu
            // 
            this.btnDoanhThu.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnDoanhThu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDoanhThu.Location = new System.Drawing.Point(3, 3);
            this.btnDoanhThu.Name = "btnDoanhThu";
            this.btnDoanhThu.Size = new System.Drawing.Size(71, 44);
            this.btnDoanhThu.TabIndex = 0;
            this.btnDoanhThu.Text = "Doanh thu";
            this.btnDoanhThu.UseVisualStyleBackColor = true;
            this.btnDoanhThu.Click += new System.EventHandler(this.btnDoanhThu_Click);
            // 
            // slcMain
            // 
            this.slcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.slcMain.Location = new System.Drawing.Point(0, 100);
            this.slcMain.Name = "slcMain";
            // 
            // slcMain.Panel1
            // 
            this.slcMain.Panel1.Controls.Add(this.treeMain);
            // 
            // slcMain.Panel2
            // 
            this.slcMain.Panel2.Controls.Add(this.tblMain);
            this.slcMain.Size = new System.Drawing.Size(752, 485);
            this.slcMain.SplitterDistance = 189;
            this.slcMain.TabIndex = 2;
            // 
            // treeMain
            // 
            this.treeMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeMain.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeMain.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.treeMain.Location = new System.Drawing.Point(0, 0);
            this.treeMain.Name = "treeMain";
            treeNode1.Checked = true;
            treeNode1.Name = "nnHangHoa";
            treeNode1.Text = "Hàng hóa";
            treeNode2.Name = "nnDVT";
            treeNode2.Text = "Đơn vị tính";
            treeNode3.Name = "nnLoaiHang";
            treeNode3.Text = "Loại Hàng";
            treeNode4.Name = "nnnHDCty";
            treeNode4.Text = "Hóa đơn Công ty";
            treeNode5.Name = "nnnHDle";
            treeNode5.Text = "Hóa đơn lẻ";
            treeNode6.Name = "nnHoaDon";
            treeNode6.Text = "Hóa đơn";
            treeNode7.Name = "nnPX";
            treeNode7.Text = "Phiếu xuất";
            treeNode8.Name = "nnPN";
            treeNode8.Text = "Phiếu nhập";
            treeNode9.Name = "nnPC";
            treeNode9.Text = "Phiếu chuyển";
            treeNode10.Checked = true;
            treeNode10.Name = "nDanhMuc";
            treeNode10.Text = "Danh mục";
            treeNode11.Name = "nnHangTon";
            treeNode11.Text = "Quản lý hàng tồn";
            treeNode12.Name = "nnLapDDH";
            treeNode12.Text = "Lập Đơn đặt hàng";
            treeNode13.Name = "nnQLMathang";
            treeNode13.Text = "Quản lý mặt hàng";
            treeNode14.Name = "nnQLGiaCa";
            treeNode14.Text = "Quản lý giá cả";
            treeNode15.Name = "nnnKHCTy";
            treeNode15.Text = "Khách hàng Cty";
            treeNode16.Name = "nnnNCC";
            treeNode16.Text = "Nhà cung cấp";
            treeNode17.Name = "nnQLĐoiTac";
            treeNode17.Text = "Quản lý đối tác";
            treeNode18.Name = "nnnDMKM";
            treeNode18.Text = "Tra cứu hàng hóa khuyến mãi";
            treeNode19.Name = "nnnCTKM";
            treeNode19.Text = "Tạo chương trình KM";
            treeNode20.Name = "nnnLoaiHinhKM";
            treeNode20.Text = "Loại hình KM";
            treeNode21.Name = "nnKhuyenMai";
            treeNode21.Text = "Quản lý khuyến mãi";
            treeNode22.Name = "nNghiepVu";
            treeNode22.Text = "Nghiệp vụ";
            treeNode23.Name = "nnDTTheoThoiGian";
            treeNode23.Text = "Doanh thu theo thời gian";
            treeNode24.Name = "nnThongKeHangHoa";
            treeNode24.Text = "Thống kê lượng hàng";
            treeNode25.Name = "nnBCTK";
            treeNode25.Text = "Báo cáo - Thống kê";
            this.treeMain.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode10,
            treeNode22,
            treeNode25});
            this.treeMain.Size = new System.Drawing.Size(189, 485);
            this.treeMain.TabIndex = 0;
            this.treeMain.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeMain_AfterSelect);
            // 
            // tblMain
            // 
            this.tblMain.ColumnCount = 1;
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblMain.Controls.Add(this.btnDongTab, 0, 0);
            this.tblMain.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tblMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblMain.Location = new System.Drawing.Point(0, 0);
            this.tblMain.Name = "tblMain";
            this.tblMain.RowCount = 2;
            this.tblMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.597536F));
            this.tblMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 92.40247F));
            this.tblMain.Size = new System.Drawing.Size(559, 485);
            this.tblMain.TabIndex = 0;
            // 
            // btnDongTab
            // 
            this.btnDongTab.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnDongTab.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnDongTab.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDongTab.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Close;
            this.btnDongTab.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDongTab.Location = new System.Drawing.Point(462, 3);
            this.btnDongTab.Name = "btnDongTab";
            this.btnDongTab.Size = new System.Drawing.Size(94, 30);
            this.btnDongTab.TabIndex = 1;
            this.btnDongTab.Text = "Đóng Tab";
            this.btnDongTab.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDongTab.UseVisualStyleBackColor = true;
            this.btnDongTab.Click += new System.EventHandler(this.btnDongTab_Click);
            // 
            // frmQL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(752, 585);
            this.Controls.Add(this.slcMain);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.mainMenuQL);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.MainMenuStrip = this.mainMenuQL;
            this.Name = "frmQL";
            this.Text = "GIAO DIỆN QUẢN LÝ";
            this.Load += new System.EventHandler(this.frmQL_Load);
            this.mainMenuQL.ResumeLayout(false);
            this.mainMenuQL.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.grbNghiepVu.ResumeLayout(false);
            this.tbpNghiepVu.ResumeLayout(false);
            this.grbDanhMuc.ResumeLayout(false);
            this.tbpDM.ResumeLayout(false);
            this.grbBaoCaoThongKe.ResumeLayout(false);
            this.tbpBC_TK.ResumeLayout(false);
            this.slcMain.Panel1.ResumeLayout(false);
            this.slcMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.slcMain)).EndInit();
            this.slcMain.ResumeLayout(false);
            this.tblMain.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ItTuychinh;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemThôngTinTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đổiMậtKhẩuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bộPhímTắtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hướngDẫnSửDụngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuToolStripMenuItem;
        private System.Windows.Forms.MenuStrip mainMenuQL;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox grbNghiepVu;
        private System.Windows.Forms.GroupBox grbDanhMuc;
        private System.Windows.Forms.GroupBox grbBaoCaoThongKe;
        private System.Windows.Forms.SplitContainer slcMain;
        private System.Windows.Forms.TreeView treeMain;
        private System.Windows.Forms.TableLayoutPanel tblMain;
        private System.Windows.Forms.Button btnDongTab;
        private System.Windows.Forms.TableLayoutPanel tbpNghiepVu;
        private System.Windows.Forms.Button btnQLKhuyenMai;
        private System.Windows.Forms.Button btnQuyDinh;
        private System.Windows.Forms.Button btnQLMatHang;
        private System.Windows.Forms.TableLayoutPanel tbpDM;
        private System.Windows.Forms.Button btnHoaDon;
        private System.Windows.Forms.Button btnHangHoa;
        private System.Windows.Forms.TableLayoutPanel tbpBC_TK;
        private System.Windows.Forms.Button btnHang;
        private System.Windows.Forms.Button btnDoanhThu;
        private System.Windows.Forms.Button btnGiaca;
        private System.Windows.Forms.Button btnQLDoiTac;
        private System.Windows.Forms.ToolStripMenuItem quảnLýTàiKhoảnNgườiDùngToolStripMenuItem;




    }
}

