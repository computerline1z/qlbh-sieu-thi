﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucQLGiaCa
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlpTheKho = new System.Windows.Forms.TableLayoutPanel();
            this.tbplThongTinTheKho = new System.Windows.Forms.TableLayoutPanel();
            this.pnlDanhMucHang = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.grbDanhSachTySuat = new System.Windows.Forms.GroupBox();
            this.dgvDanhSachTySuat = new System.Windows.Forms.DataGridView();
            this.MaNhom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TySuat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoMH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinGiaCa = new System.Windows.Forms.GroupBox();
            this.tblTheKho = new System.Windows.Forms.TableLayoutPanel();
            this.pnlTheKho1 = new System.Windows.Forms.Panel();
            this.txtTySuat = new System.Windows.Forms.TextBox();
            this.lblPhanTram = new System.Windows.Forms.Label();
            this.lblTySuat = new System.Windows.Forms.Label();
            this.cboMaNhom = new System.Windows.Forms.ComboBox();
            this.lblMaLoaiHang = new System.Windows.Forms.Label();
            this.pnlTheKho2 = new System.Windows.Forms.Panel();
            this.tlpTheKho.SuspendLayout();
            this.tbplThongTinTheKho.SuspendLayout();
            this.pnlDanhMucHang.SuspendLayout();
            this.grbDanhSachTySuat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachTySuat)).BeginInit();
            this.grbThongTinGiaCa.SuspendLayout();
            this.tblTheKho.SuspendLayout();
            this.pnlTheKho1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpTheKho
            // 
            this.tlpTheKho.ColumnCount = 1;
            this.tlpTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpTheKho.Controls.Add(this.tbplThongTinTheKho, 0, 1);
            this.tlpTheKho.Controls.Add(this.grbThongTinGiaCa, 0, 0);
            this.tlpTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpTheKho.Location = new System.Drawing.Point(0, 0);
            this.tlpTheKho.Name = "tlpTheKho";
            this.tlpTheKho.RowCount = 2;
            this.tlpTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tlpTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpTheKho.Size = new System.Drawing.Size(546, 382);
            this.tlpTheKho.TabIndex = 1;
            // 
            // tbplThongTinTheKho
            // 
            this.tbplThongTinTheKho.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tbplThongTinTheKho.ColumnCount = 1;
            this.tbplThongTinTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplThongTinTheKho.Controls.Add(this.pnlDanhMucHang, 0, 0);
            this.tbplThongTinTheKho.Controls.Add(this.grbDanhSachTySuat, 0, 0);
            this.tbplThongTinTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplThongTinTheKho.Location = new System.Drawing.Point(3, 126);
            this.tbplThongTinTheKho.Name = "tbplThongTinTheKho";
            this.tbplThongTinTheKho.RowCount = 1;
            this.tbplThongTinTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplThongTinTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tbplThongTinTheKho.Size = new System.Drawing.Size(540, 253);
            this.tbplThongTinTheKho.TabIndex = 2;
            // 
            // pnlDanhMucHang
            // 
            this.pnlDanhMucHang.Controls.Add(this.btnLuu);
            this.pnlDanhMucHang.Controls.Add(this.btnXoa);
            this.pnlDanhMucHang.Controls.Add(this.btnThem);
            this.pnlDanhMucHang.Controls.Add(this.btnSua);
            this.pnlDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDanhMucHang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlDanhMucHang.Location = new System.Drawing.Point(6, 215);
            this.pnlDanhMucHang.Name = "pnlDanhMucHang";
            this.pnlDanhMucHang.Size = new System.Drawing.Size(528, 32);
            this.pnlDanhMucHang.TabIndex = 5;
            // 
            // btnLuu
            // 
            this.btnLuu.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(432, 4);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 3;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(358, 4);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 2;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(208, 4);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnSua
            // 
            this.btnSua.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(283, 4);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 1;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // grbDanhSachTySuat
            // 
            this.grbDanhSachTySuat.Controls.Add(this.dgvDanhSachTySuat);
            this.grbDanhSachTySuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhSachTySuat.Location = new System.Drawing.Point(6, 6);
            this.grbDanhSachTySuat.Name = "grbDanhSachTySuat";
            this.grbDanhSachTySuat.Size = new System.Drawing.Size(528, 200);
            this.grbDanhSachTySuat.TabIndex = 4;
            this.grbDanhSachTySuat.TabStop = false;
            this.grbDanhSachTySuat.Text = "Danh sách nhóm giá cả";
            // 
            // dgvDanhSachTySuat
            // 
            this.dgvDanhSachTySuat.AllowUserToAddRows = false;
            this.dgvDanhSachTySuat.AllowUserToDeleteRows = false;
            this.dgvDanhSachTySuat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSachTySuat.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvDanhSachTySuat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachTySuat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaNhom,
            this.TySuat,
            this.SoMH});
            this.dgvDanhSachTySuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSachTySuat.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhSachTySuat.MultiSelect = false;
            this.dgvDanhSachTySuat.Name = "dgvDanhSachTySuat";
            this.dgvDanhSachTySuat.ReadOnly = true;
            this.dgvDanhSachTySuat.RowTemplate.Height = 24;
            this.dgvDanhSachTySuat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDanhSachTySuat.Size = new System.Drawing.Size(522, 181);
            this.dgvDanhSachTySuat.TabIndex = 1;
            // 
            // MaNhom
            // 
            this.MaNhom.DataPropertyName = "Nhomhang";
            this.MaNhom.HeaderText = "Mã nhóm";
            this.MaNhom.Name = "MaNhom";
            this.MaNhom.ReadOnly = true;
            // 
            // TySuat
            // 
            this.TySuat.DataPropertyName = "Tysuat";
            this.TySuat.HeaderText = "Tỷ Suất";
            this.TySuat.Name = "TySuat";
            this.TySuat.ReadOnly = true;
            // 
            // SoMH
            // 
            this.SoMH.HeaderText = "Số mặt hàng trong nhóm";
            this.SoMH.Name = "SoMH";
            this.SoMH.ReadOnly = true;
            // 
            // grbThongTinGiaCa
            // 
            this.grbThongTinGiaCa.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.grbThongTinGiaCa.Controls.Add(this.tblTheKho);
            this.grbThongTinGiaCa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinGiaCa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinGiaCa.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinGiaCa.Name = "grbThongTinGiaCa";
            this.grbThongTinGiaCa.Size = new System.Drawing.Size(540, 117);
            this.grbThongTinGiaCa.TabIndex = 1;
            this.grbThongTinGiaCa.TabStop = false;
            this.grbThongTinGiaCa.Text = "Thông tin giá cả";
            // 
            // tblTheKho
            // 
            this.tblTheKho.ColumnCount = 2;
            this.tblTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.1976F));
            this.tblTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.8024F));
            this.tblTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblTheKho.Controls.Add(this.pnlTheKho1, 0, 0);
            this.tblTheKho.Controls.Add(this.pnlTheKho2, 1, 0);
            this.tblTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblTheKho.Location = new System.Drawing.Point(3, 17);
            this.tblTheKho.Name = "tblTheKho";
            this.tblTheKho.RowCount = 1;
            this.tblTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblTheKho.Size = new System.Drawing.Size(534, 97);
            this.tblTheKho.TabIndex = 0;
            // 
            // pnlTheKho1
            // 
            this.pnlTheKho1.Controls.Add(this.txtTySuat);
            this.pnlTheKho1.Controls.Add(this.lblPhanTram);
            this.pnlTheKho1.Controls.Add(this.lblTySuat);
            this.pnlTheKho1.Controls.Add(this.cboMaNhom);
            this.pnlTheKho1.Controls.Add(this.lblMaLoaiHang);
            this.pnlTheKho1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTheKho1.Location = new System.Drawing.Point(3, 3);
            this.pnlTheKho1.Name = "pnlTheKho1";
            this.pnlTheKho1.Size = new System.Drawing.Size(251, 91);
            this.pnlTheKho1.TabIndex = 0;
            // 
            // txtTySuat
            // 
            this.txtTySuat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTySuat.Location = new System.Drawing.Point(76, 44);
            this.txtTySuat.Name = "txtTySuat";
            this.txtTySuat.Size = new System.Drawing.Size(113, 21);
            this.txtTySuat.TabIndex = 9;
            // 
            // lblPhanTram
            // 
            this.lblPhanTram.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblPhanTram.AutoSize = true;
            this.lblPhanTram.Location = new System.Drawing.Point(195, 47);
            this.lblPhanTram.Name = "lblPhanTram";
            this.lblPhanTram.Size = new System.Drawing.Size(16, 15);
            this.lblPhanTram.TabIndex = 8;
            this.lblPhanTram.Text = "%";
            // 
            // lblTySuat
            // 
            this.lblTySuat.AutoSize = true;
            this.lblTySuat.Location = new System.Drawing.Point(18, 47);
            this.lblTySuat.Name = "lblTySuat";
            this.lblTySuat.Size = new System.Drawing.Size(48, 15);
            this.lblTySuat.TabIndex = 7;
            this.lblTySuat.Text = "Tỷ suất";
            // 
            // cboMaNhom
            // 
            this.cboMaNhom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboMaNhom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaNhom.FormattingEnabled = true;
            this.cboMaNhom.Location = new System.Drawing.Point(76, 15);
            this.cboMaNhom.Name = "cboMaNhom";
            this.cboMaNhom.Size = new System.Drawing.Size(156, 23);
            this.cboMaNhom.TabIndex = 6;
            // 
            // lblMaLoaiHang
            // 
            this.lblMaLoaiHang.AutoSize = true;
            this.lblMaLoaiHang.Location = new System.Drawing.Point(7, 20);
            this.lblMaLoaiHang.Name = "lblMaLoaiHang";
            this.lblMaLoaiHang.Size = new System.Drawing.Size(59, 15);
            this.lblMaLoaiHang.TabIndex = 5;
            this.lblMaLoaiHang.Text = "Mã nhóm";
            // 
            // pnlTheKho2
            // 
            this.pnlTheKho2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTheKho2.Location = new System.Drawing.Point(260, 3);
            this.pnlTheKho2.Name = "pnlTheKho2";
            this.pnlTheKho2.Size = new System.Drawing.Size(271, 91);
            this.pnlTheKho2.TabIndex = 0;
            // 
            // ucQLGiaCa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.tlpTheKho);
            this.MaximumSize = new System.Drawing.Size(546, 382);
            this.Name = "ucQLGiaCa";
            this.Size = new System.Drawing.Size(546, 382);
            this.tlpTheKho.ResumeLayout(false);
            this.tbplThongTinTheKho.ResumeLayout(false);
            this.pnlDanhMucHang.ResumeLayout(false);
            this.grbDanhSachTySuat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachTySuat)).EndInit();
            this.grbThongTinGiaCa.ResumeLayout(false);
            this.tblTheKho.ResumeLayout(false);
            this.pnlTheKho1.ResumeLayout(false);
            this.pnlTheKho1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpTheKho;
        private System.Windows.Forms.TableLayoutPanel tbplThongTinTheKho;
        private System.Windows.Forms.Panel pnlDanhMucHang;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.GroupBox grbDanhSachTySuat;
        private System.Windows.Forms.DataGridView dgvDanhSachTySuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNhom;
        private System.Windows.Forms.DataGridViewTextBoxColumn TySuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoMH;
        private System.Windows.Forms.GroupBox grbThongTinGiaCa;
        private System.Windows.Forms.TableLayoutPanel tblTheKho;
        private System.Windows.Forms.Panel pnlTheKho1;
        private System.Windows.Forms.TextBox txtTySuat;
        private System.Windows.Forms.Label lblPhanTram;
        private System.Windows.Forms.Label lblTySuat;
        private System.Windows.Forms.ComboBox cboMaNhom;
        private System.Windows.Forms.Label lblMaLoaiHang;
        private System.Windows.Forms.Panel pnlTheKho2;

    }
}
