﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucQLGiaCa
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMaLoaiHang = new System.Windows.Forms.Label();
            this.lblTySuat = new System.Windows.Forms.Label();
            this.txtTySuat = new System.Windows.Forms.TextBox();
            this.grbThongTinGiaCa = new System.Windows.Forms.GroupBox();
            this.cboMaNhom = new System.Windows.Forms.ComboBox();
            this.lblPhanTram = new System.Windows.Forms.Label();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.grbDanhSachTySuat = new System.Windows.Forms.GroupBox();
            this.dgvDanhSachTySuat = new System.Windows.Forms.DataGridView();
            this.MaNhom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TySuat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoMH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.grbThongTinGiaCa.SuspendLayout();
            this.pnlButton.SuspendLayout();
            this.grbDanhSachTySuat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachTySuat)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMaLoaiHang
            // 
            this.lblMaLoaiHang.AutoSize = true;
            this.lblMaLoaiHang.Location = new System.Drawing.Point(40, 34);
            this.lblMaLoaiHang.Name = "lblMaLoaiHang";
            this.lblMaLoaiHang.Size = new System.Drawing.Size(59, 15);
            this.lblMaLoaiHang.TabIndex = 0;
            this.lblMaLoaiHang.Text = "Mã nhóm";
            // 
            // lblTySuat
            // 
            this.lblTySuat.AutoSize = true;
            this.lblTySuat.Location = new System.Drawing.Point(303, 37);
            this.lblTySuat.Name = "lblTySuat";
            this.lblTySuat.Size = new System.Drawing.Size(48, 15);
            this.lblTySuat.TabIndex = 0;
            this.lblTySuat.Text = "Tỷ suất";
            // 
            // txtTySuat
            // 
            this.txtTySuat.Location = new System.Drawing.Point(362, 32);
            this.txtTySuat.Name = "txtTySuat";
            this.txtTySuat.Size = new System.Drawing.Size(77, 21);
            this.txtTySuat.TabIndex = 1;
            // 
            // grbThongTinGiaCa
            // 
            this.grbThongTinGiaCa.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbThongTinGiaCa.AutoSize = true;
            this.grbThongTinGiaCa.Controls.Add(this.cboMaNhom);
            this.grbThongTinGiaCa.Controls.Add(this.txtTySuat);
            this.grbThongTinGiaCa.Controls.Add(this.lblPhanTram);
            this.grbThongTinGiaCa.Controls.Add(this.lblTySuat);
            this.grbThongTinGiaCa.Controls.Add(this.lblMaLoaiHang);
            this.grbThongTinGiaCa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinGiaCa.Location = new System.Drawing.Point(3, 0);
            this.grbThongTinGiaCa.Name = "grbThongTinGiaCa";
            this.grbThongTinGiaCa.Size = new System.Drawing.Size(540, 75);
            this.grbThongTinGiaCa.TabIndex = 5;
            this.grbThongTinGiaCa.TabStop = false;
            this.grbThongTinGiaCa.Text = "Thông tin giá cả";
            // 
            // cboMaNhom
            // 
            this.cboMaNhom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaNhom.FormattingEnabled = true;
            this.cboMaNhom.Location = new System.Drawing.Point(105, 26);
            this.cboMaNhom.Name = "cboMaNhom";
            this.cboMaNhom.Size = new System.Drawing.Size(120, 23);
            this.cboMaNhom.TabIndex = 4;
            // 
            // lblPhanTram
            // 
            this.lblPhanTram.AutoSize = true;
            this.lblPhanTram.Location = new System.Drawing.Point(443, 34);
            this.lblPhanTram.Name = "lblPhanTram";
            this.lblPhanTram.Size = new System.Drawing.Size(16, 15);
            this.lblPhanTram.TabIndex = 0;
            this.lblPhanTram.Text = "%";
            // 
            // pnlButton
            // 
            this.pnlButton.Controls.Add(this.btnLuu);
            this.pnlButton.Controls.Add(this.btnXoa);
            this.pnlButton.Controls.Add(this.btnThem);
            this.pnlButton.Controls.Add(this.btnSua);
            this.pnlButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButton.Location = new System.Drawing.Point(0, 344);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(546, 38);
            this.pnlButton.TabIndex = 6;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(459, 6);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 18;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(385, 6);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 19;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(235, 6);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 16;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(310, 6);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 17;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // grbDanhSachTySuat
            // 
            this.grbDanhSachTySuat.Controls.Add(this.dgvDanhSachTySuat);
            this.grbDanhSachTySuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhSachTySuat.Location = new System.Drawing.Point(0, 0);
            this.grbDanhSachTySuat.Name = "grbDanhSachTySuat";
            this.grbDanhSachTySuat.Size = new System.Drawing.Size(546, 245);
            this.grbDanhSachTySuat.TabIndex = 7;
            this.grbDanhSachTySuat.TabStop = false;
            this.grbDanhSachTySuat.Text = "Danh sách nhóm giá cả";
            // 
            // dgvDanhSachTySuat
            // 
            this.dgvDanhSachTySuat.AllowUserToAddRows = false;
            this.dgvDanhSachTySuat.AllowUserToDeleteRows = false;
            this.dgvDanhSachTySuat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSachTySuat.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvDanhSachTySuat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachTySuat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaNhom,
            this.TySuat,
            this.SoMH});
            this.dgvDanhSachTySuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSachTySuat.Location = new System.Drawing.Point(3, 15);
            this.dgvDanhSachTySuat.MultiSelect = false;
            this.dgvDanhSachTySuat.Name = "dgvDanhSachTySuat";
            this.dgvDanhSachTySuat.ReadOnly = true;
            this.dgvDanhSachTySuat.RowTemplate.Height = 24;
            this.dgvDanhSachTySuat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDanhSachTySuat.Size = new System.Drawing.Size(540, 227);
            this.dgvDanhSachTySuat.TabIndex = 0;
            this.dgvDanhSachTySuat.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDanhSachTySuat_CellClick);
            // 
            // MaNhom
            // 
            this.MaNhom.DataPropertyName = "Nhomhang";
            this.MaNhom.HeaderText = "Mã nhóm";
            this.MaNhom.Name = "MaNhom";
            this.MaNhom.ReadOnly = true;
            // 
            // TySuat
            // 
            this.TySuat.DataPropertyName = "Tysuat";
            this.TySuat.HeaderText = "Tỷ Suất";
            this.TySuat.Name = "TySuat";
            this.TySuat.ReadOnly = true;
            // 
            // SoMH
            // 
            this.SoMH.HeaderText = "Số mặt hàng trong nhóm";
            this.SoMH.Name = "SoMH";
            this.SoMH.ReadOnly = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grbDanhSachTySuat);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 99);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(546, 245);
            this.panel2.TabIndex = 8;
            // 
            // ucQLGiaCa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlButton);
            this.Controls.Add(this.grbThongTinGiaCa);
            this.MaximumSize = new System.Drawing.Size(546, 382);
            this.Name = "ucQLGiaCa";
            this.Size = new System.Drawing.Size(546, 382);
            this.grbThongTinGiaCa.ResumeLayout(false);
            this.grbThongTinGiaCa.PerformLayout();
            this.pnlButton.ResumeLayout(false);
            this.grbDanhSachTySuat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachTySuat)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMaLoaiHang;
        private System.Windows.Forms.Label lblTySuat;
        private System.Windows.Forms.TextBox txtTySuat;
        private System.Windows.Forms.GroupBox grbThongTinGiaCa;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.GroupBox grbDanhSachTySuat;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPhanTram;
        private System.Windows.Forms.DataGridView dgvDanhSachTySuat;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.ComboBox cboMaNhom;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNhom;
        private System.Windows.Forms.DataGridViewTextBoxColumn TySuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoMH;
    }
}
