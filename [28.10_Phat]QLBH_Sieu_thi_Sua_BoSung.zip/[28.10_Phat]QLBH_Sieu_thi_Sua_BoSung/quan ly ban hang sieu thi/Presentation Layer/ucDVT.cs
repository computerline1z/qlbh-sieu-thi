﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer;

namespace quan_ly_ban_hang_sieu_thi
{
    public partial class ucDVT : UserControl
    {
        DataProvider dataProvider = new DataProvider();
        DVTINH_BUS DvTinh_bus = new DVTINH_BUS();
        DVTINH_OBJ DvTinh_obj = new DVTINH_OBJ();
        BindingSource bindingSource = new BindingSource();

        public ucDVT()
        {
            InitializeComponent();
            bindingSource.DataSource = DvTinh_bus.layDanhSachDVT();
            LoadToListBox();
        }
        public void LoadToListBox()
        {
            lstDVT.DataSource = bindingSource;
            lstDVT.DisplayMember = "DVT";
            lstDVT.ValueMember = "DVT";
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (txtDVT.Text.Trim() != "")
            {
                DvTinh_obj.DVT = txtDVT.Text.Trim();
                DvTinh_bus.Them(DvTinh_obj);
                bindingSource.DataSource = DvTinh_bus.layDanhSachDVT();
                usrDMHang.DongboDulieu();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DvTinh_obj.DVT = lstDVT.SelectedValue.ToString();
            MessageBox.Show(DvTinh_obj.DVT);
            if (DvTinh_obj.DVT != "")
            {
                DvTinh_bus.Xoa(DvTinh_obj);
                bindingSource.DataSource = DvTinh_bus.layDanhSachDVT();
            }
        }

       

    }
}
