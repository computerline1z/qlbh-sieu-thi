﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class usrDMHang
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(usrDMHang));
            this.tlpDMHang = new System.Windows.Forms.TableLayoutPanel();
            this.grbDanhMucHang = new System.Windows.Forms.GroupBox();
            this.dgvHanghoa = new System.Windows.Forms.DataGridView();
            this.pnlDanhMucHang = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.gdbThongTinHangHoa = new System.Windows.Forms.GroupBox();
            this.tlpThongTinHangHoa = new System.Windows.Forms.TableLayoutPanel();
            this.imgSP = new System.Windows.Forms.PictureBox();
            this.pnlThongTin1 = new System.Windows.Forms.Panel();
            this.txtTenhang = new System.Windows.Forms.TextBox();
            this.txtMahang = new System.Windows.Forms.TextBox();
            this.btnThemLoaiHang = new System.Windows.Forms.Button();
            this.btnThemDVT = new System.Windows.Forms.Button();
            this.cboMaloai = new System.Windows.Forms.ComboBox();
            this.cboDVT = new System.Windows.Forms.ComboBox();
            this.lblLoaiHang = new System.Windows.Forms.Label();
            this.lblDonViTinh = new System.Windows.Forms.Label();
            this.lblTenHang = new System.Windows.Forms.Label();
            this.lblMaHang = new System.Windows.Forms.Label();
            this.pnlThongTin2 = new System.Windows.Forms.Panel();
            this.txtKM = new System.Windows.Forms.TextBox();
            this.lblKhuyenMai = new System.Windows.Forms.Label();
            this.cboNCC = new System.Windows.Forms.ComboBox();
            this.btnThemNCC = new System.Windows.Forms.Button();
            this.btnThemNhom = new System.Windows.Forms.Button();
            this.cboManhom = new System.Windows.Forms.ComboBox();
            this.txtGia = new System.Windows.Forms.TextBox();
            this.lblNCC = new System.Windows.Forms.Label();
            this.lblMaNhom = new System.Windows.Forms.Label();
            this.lblDonGia = new System.Windows.Forms.Label();
            this.tlpDMHang.SuspendLayout();
            this.grbDanhMucHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHanghoa)).BeginInit();
            this.pnlDanhMucHang.SuspendLayout();
            this.gdbThongTinHangHoa.SuspendLayout();
            this.tlpThongTinHangHoa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).BeginInit();
            this.pnlThongTin1.SuspendLayout();
            this.pnlThongTin2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpDMHang
            // 
            this.tlpDMHang.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpDMHang.ColumnCount = 1;
            this.tlpDMHang.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpDMHang.Controls.Add(this.grbDanhMucHang, 0, 1);
            this.tlpDMHang.Controls.Add(this.pnlDanhMucHang, 0, 1);
            this.tlpDMHang.Controls.Add(this.gdbThongTinHangHoa, 0, 0);
            this.tlpDMHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpDMHang.Location = new System.Drawing.Point(0, 0);
            this.tlpDMHang.Name = "tlpDMHang";
            this.tlpDMHang.RowCount = 2;
            this.tlpDMHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 161F));
            this.tlpDMHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpDMHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tlpDMHang.Size = new System.Drawing.Size(850, 500);
            this.tlpDMHang.TabIndex = 0;
            // 
            // grbDanhMucHang
            // 
            this.grbDanhMucHang.Controls.Add(this.dgvHanghoa);
            this.grbDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhMucHang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDanhMucHang.Location = new System.Drawing.Point(6, 170);
            this.grbDanhMucHang.Name = "grbDanhMucHang";
            this.grbDanhMucHang.Size = new System.Drawing.Size(838, 282);
            this.grbDanhMucHang.TabIndex = 1;
            this.grbDanhMucHang.TabStop = false;
            this.grbDanhMucHang.Text = "Danh mục hàng hóa";
            // 
            // dgvHanghoa
            // 
            this.dgvHanghoa.AllowUserToAddRows = false;
            this.dgvHanghoa.AllowUserToDeleteRows = false;
            this.dgvHanghoa.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHanghoa.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvHanghoa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHanghoa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvHanghoa.Location = new System.Drawing.Point(3, 17);
            this.dgvHanghoa.MultiSelect = false;
            this.dgvHanghoa.Name = "dgvHanghoa";
            this.dgvHanghoa.ReadOnly = true;
            this.dgvHanghoa.RowTemplate.Height = 24;
            this.dgvHanghoa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHanghoa.Size = new System.Drawing.Size(832, 262);
            this.dgvHanghoa.TabIndex = 0;
            // 
            // pnlDanhMucHang
            // 
            this.pnlDanhMucHang.Controls.Add(this.btnLuu);
            this.pnlDanhMucHang.Controls.Add(this.btnXoa);
            this.pnlDanhMucHang.Controls.Add(this.btnThem);
            this.pnlDanhMucHang.Controls.Add(this.btnSua);
            this.pnlDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDanhMucHang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlDanhMucHang.Location = new System.Drawing.Point(6, 461);
            this.pnlDanhMucHang.Name = "pnlDanhMucHang";
            this.pnlDanhMucHang.Size = new System.Drawing.Size(838, 33);
            this.pnlDanhMucHang.TabIndex = 2;
            // 
            // btnLuu
            // 
            this.btnLuu.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(742, 4);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 3;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(668, 4);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 2;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(518, 4);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(593, 4);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 1;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // gdbThongTinHangHoa
            // 
            this.gdbThongTinHangHoa.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gdbThongTinHangHoa.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.gdbThongTinHangHoa.Controls.Add(this.tlpThongTinHangHoa);
            this.gdbThongTinHangHoa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gdbThongTinHangHoa.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gdbThongTinHangHoa.Location = new System.Drawing.Point(6, 6);
            this.gdbThongTinHangHoa.Name = "gdbThongTinHangHoa";
            this.gdbThongTinHangHoa.Size = new System.Drawing.Size(838, 155);
            this.gdbThongTinHangHoa.TabIndex = 0;
            this.gdbThongTinHangHoa.TabStop = false;
            this.gdbThongTinHangHoa.Text = "Thông tin hàng hóa";
            // 
            // tlpThongTinHangHoa
            // 
            this.tlpThongTinHangHoa.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpThongTinHangHoa.ColumnCount = 3;
            this.tlpThongTinHangHoa.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpThongTinHangHoa.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpThongTinHangHoa.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tlpThongTinHangHoa.Controls.Add(this.imgSP, 2, 0);
            this.tlpThongTinHangHoa.Controls.Add(this.pnlThongTin1, 0, 0);
            this.tlpThongTinHangHoa.Controls.Add(this.pnlThongTin2, 1, 0);
            this.tlpThongTinHangHoa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpThongTinHangHoa.Location = new System.Drawing.Point(3, 17);
            this.tlpThongTinHangHoa.Name = "tlpThongTinHangHoa";
            this.tlpThongTinHangHoa.RowCount = 1;
            this.tlpThongTinHangHoa.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpThongTinHangHoa.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tlpThongTinHangHoa.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tlpThongTinHangHoa.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tlpThongTinHangHoa.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tlpThongTinHangHoa.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tlpThongTinHangHoa.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tlpThongTinHangHoa.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tlpThongTinHangHoa.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tlpThongTinHangHoa.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132F));
            this.tlpThongTinHangHoa.Size = new System.Drawing.Size(832, 135);
            this.tlpThongTinHangHoa.TabIndex = 0;
            this.tlpThongTinHangHoa.Paint += new System.Windows.Forms.PaintEventHandler(this.tlpThongTinHangHoa_Paint);
            // 
            // imgSP
            // 
            this.imgSP.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.imgSP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.imgSP.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.cart;
            this.imgSP.Location = new System.Drawing.Point(632, 6);
            this.imgSP.Name = "imgSP";
            this.imgSP.Size = new System.Drawing.Size(194, 123);
            this.imgSP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgSP.TabIndex = 8;
            this.imgSP.TabStop = false;
            // 
            // pnlThongTin1
            // 
            this.pnlThongTin1.Controls.Add(this.txtTenhang);
            this.pnlThongTin1.Controls.Add(this.txtMahang);
            this.pnlThongTin1.Controls.Add(this.btnThemLoaiHang);
            this.pnlThongTin1.Controls.Add(this.btnThemDVT);
            this.pnlThongTin1.Controls.Add(this.cboMaloai);
            this.pnlThongTin1.Controls.Add(this.cboDVT);
            this.pnlThongTin1.Controls.Add(this.lblLoaiHang);
            this.pnlThongTin1.Controls.Add(this.lblDonViTinh);
            this.pnlThongTin1.Controls.Add(this.lblTenHang);
            this.pnlThongTin1.Controls.Add(this.lblMaHang);
            this.pnlThongTin1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlThongTin1.Location = new System.Drawing.Point(6, 6);
            this.pnlThongTin1.Name = "pnlThongTin1";
            this.pnlThongTin1.Size = new System.Drawing.Size(304, 123);
            this.pnlThongTin1.TabIndex = 0;
            // 
            // txtTenhang
            // 
            this.txtTenhang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenhang.Location = new System.Drawing.Point(86, 32);
            this.txtTenhang.Name = "txtTenhang";
            this.txtTenhang.Size = new System.Drawing.Size(181, 21);
            this.txtTenhang.TabIndex = 1;
            // 
            // txtMahang
            // 
            this.txtMahang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMahang.Location = new System.Drawing.Point(86, 5);
            this.txtMahang.Name = "txtMahang";
            this.txtMahang.Size = new System.Drawing.Size(181, 21);
            this.txtMahang.TabIndex = 0;
            // 
            // btnThemLoaiHang
            // 
            this.btnThemLoaiHang.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThemLoaiHang.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnThemLoaiHang.BackgroundImage")));
            this.btnThemLoaiHang.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnThemLoaiHang.Location = new System.Drawing.Point(271, 88);
            this.btnThemLoaiHang.Name = "btnThemLoaiHang";
            this.btnThemLoaiHang.Size = new System.Drawing.Size(27, 24);
            this.btnThemLoaiHang.TabIndex = 5;
            this.btnThemLoaiHang.UseVisualStyleBackColor = true;
            // 
            // btnThemDVT
            // 
            this.btnThemDVT.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThemDVT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnThemDVT.BackgroundImage")));
            this.btnThemDVT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnThemDVT.Location = new System.Drawing.Point(271, 59);
            this.btnThemDVT.Name = "btnThemDVT";
            this.btnThemDVT.Size = new System.Drawing.Size(26, 25);
            this.btnThemDVT.TabIndex = 3;
            this.btnThemDVT.UseVisualStyleBackColor = true;
            // 
            // cboMaloai
            // 
            this.cboMaloai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboMaloai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaloai.FormattingEnabled = true;
            this.cboMaloai.Location = new System.Drawing.Point(86, 88);
            this.cboMaloai.Name = "cboMaloai";
            this.cboMaloai.Size = new System.Drawing.Size(181, 23);
            this.cboMaloai.TabIndex = 4;
            // 
            // cboDVT
            // 
            this.cboDVT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboDVT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDVT.FormattingEnabled = true;
            this.cboDVT.Location = new System.Drawing.Point(86, 59);
            this.cboDVT.Name = "cboDVT";
            this.cboDVT.Size = new System.Drawing.Size(181, 23);
            this.cboDVT.TabIndex = 2;
            // 
            // lblLoaiHang
            // 
            this.lblLoaiHang.AutoSize = true;
            this.lblLoaiHang.Location = new System.Drawing.Point(16, 96);
            this.lblLoaiHang.Name = "lblLoaiHang";
            this.lblLoaiHang.Size = new System.Drawing.Size(62, 15);
            this.lblLoaiHang.TabIndex = 10;
            this.lblLoaiHang.Text = "Loại hàng";
            // 
            // lblDonViTinh
            // 
            this.lblDonViTinh.AutoSize = true;
            this.lblDonViTinh.Location = new System.Drawing.Point(10, 67);
            this.lblDonViTinh.Name = "lblDonViTinh";
            this.lblDonViTinh.Size = new System.Drawing.Size(68, 15);
            this.lblDonViTinh.TabIndex = 9;
            this.lblDonViTinh.Text = "Đơn vị tính";
            // 
            // lblTenHang
            // 
            this.lblTenHang.AutoSize = true;
            this.lblTenHang.Location = new System.Drawing.Point(18, 39);
            this.lblTenHang.Name = "lblTenHang";
            this.lblTenHang.Size = new System.Drawing.Size(60, 15);
            this.lblTenHang.TabIndex = 12;
            this.lblTenHang.Text = "Tên Hàng";
            // 
            // lblMaHang
            // 
            this.lblMaHang.AutoSize = true;
            this.lblMaHang.Location = new System.Drawing.Point(23, 13);
            this.lblMaHang.Name = "lblMaHang";
            this.lblMaHang.Size = new System.Drawing.Size(55, 15);
            this.lblMaHang.TabIndex = 11;
            this.lblMaHang.Text = "Mã hàng";
            // 
            // pnlThongTin2
            // 
            this.pnlThongTin2.Controls.Add(this.txtKM);
            this.pnlThongTin2.Controls.Add(this.lblKhuyenMai);
            this.pnlThongTin2.Controls.Add(this.cboNCC);
            this.pnlThongTin2.Controls.Add(this.btnThemNCC);
            this.pnlThongTin2.Controls.Add(this.btnThemNhom);
            this.pnlThongTin2.Controls.Add(this.cboManhom);
            this.pnlThongTin2.Controls.Add(this.txtGia);
            this.pnlThongTin2.Controls.Add(this.lblNCC);
            this.pnlThongTin2.Controls.Add(this.lblMaNhom);
            this.pnlThongTin2.Controls.Add(this.lblDonGia);
            this.pnlThongTin2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlThongTin2.Location = new System.Drawing.Point(319, 6);
            this.pnlThongTin2.Name = "pnlThongTin2";
            this.pnlThongTin2.Size = new System.Drawing.Size(304, 123);
            this.pnlThongTin2.TabIndex = 1;
            // 
            // txtKM
            // 
            this.txtKM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKM.Location = new System.Drawing.Point(84, 62);
            this.txtKM.Margin = new System.Windows.Forms.Padding(2);
            this.txtKM.Name = "txtKM";
            this.txtKM.Size = new System.Drawing.Size(184, 21);
            this.txtKM.TabIndex = 3;
            // 
            // lblKhuyenMai
            // 
            this.lblKhuyenMai.AutoSize = true;
            this.lblKhuyenMai.Location = new System.Drawing.Point(6, 70);
            this.lblKhuyenMai.Name = "lblKhuyenMai";
            this.lblKhuyenMai.Size = new System.Drawing.Size(73, 15);
            this.lblKhuyenMai.TabIndex = 20;
            this.lblKhuyenMai.Text = "Khuyến mãi";
            // 
            // cboNCC
            // 
            this.cboNCC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboNCC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNCC.FormattingEnabled = true;
            this.cboNCC.Location = new System.Drawing.Point(84, 89);
            this.cboNCC.Name = "cboNCC";
            this.cboNCC.Size = new System.Drawing.Size(184, 23);
            this.cboNCC.TabIndex = 4;
            // 
            // btnThemNCC
            // 
            this.btnThemNCC.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThemNCC.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnThemNCC.BackgroundImage")));
            this.btnThemNCC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnThemNCC.Location = new System.Drawing.Point(272, 89);
            this.btnThemNCC.Name = "btnThemNCC";
            this.btnThemNCC.Size = new System.Drawing.Size(26, 24);
            this.btnThemNCC.TabIndex = 5;
            this.btnThemNCC.UseVisualStyleBackColor = true;
            // 
            // btnThemNhom
            // 
            this.btnThemNhom.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThemNhom.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnThemNhom.BackgroundImage")));
            this.btnThemNhom.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnThemNhom.Location = new System.Drawing.Point(272, 6);
            this.btnThemNhom.Name = "btnThemNhom";
            this.btnThemNhom.Size = new System.Drawing.Size(26, 24);
            this.btnThemNhom.TabIndex = 1;
            this.btnThemNhom.UseVisualStyleBackColor = true;
            // 
            // cboManhom
            // 
            this.cboManhom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboManhom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboManhom.FormattingEnabled = true;
            this.cboManhom.Location = new System.Drawing.Point(84, 6);
            this.cboManhom.Name = "cboManhom";
            this.cboManhom.Size = new System.Drawing.Size(184, 23);
            this.cboManhom.TabIndex = 0;
            // 
            // txtGia
            // 
            this.txtGia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGia.Location = new System.Drawing.Point(84, 35);
            this.txtGia.Name = "txtGia";
            this.txtGia.Size = new System.Drawing.Size(184, 21);
            this.txtGia.TabIndex = 2;
            // 
            // lblNCC
            // 
            this.lblNCC.AutoSize = true;
            this.lblNCC.Location = new System.Drawing.Point(31, 98);
            this.lblNCC.Name = "lblNCC";
            this.lblNCC.Size = new System.Drawing.Size(48, 15);
            this.lblNCC.TabIndex = 12;
            this.lblNCC.Text = "Nhà CC";
            // 
            // lblMaNhom
            // 
            this.lblMaNhom.AutoSize = true;
            this.lblMaNhom.Location = new System.Drawing.Point(20, 14);
            this.lblMaNhom.Name = "lblMaNhom";
            this.lblMaNhom.Size = new System.Drawing.Size(59, 15);
            this.lblMaNhom.TabIndex = 13;
            this.lblMaNhom.Text = "Mã nhóm";
            // 
            // lblDonGia
            // 
            this.lblDonGia.AutoSize = true;
            this.lblDonGia.Location = new System.Drawing.Point(27, 43);
            this.lblDonGia.Name = "lblDonGia";
            this.lblDonGia.Size = new System.Drawing.Size(52, 15);
            this.lblDonGia.TabIndex = 14;
            this.lblDonGia.Text = "Đơn giá";
            // 
            // usrDMHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tlpDMHang);
            this.Name = "usrDMHang";
            this.Size = new System.Drawing.Size(850, 500);
            this.tlpDMHang.ResumeLayout(false);
            this.grbDanhMucHang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHanghoa)).EndInit();
            this.pnlDanhMucHang.ResumeLayout(false);
            this.gdbThongTinHangHoa.ResumeLayout(false);
            this.tlpThongTinHangHoa.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).EndInit();
            this.pnlThongTin1.ResumeLayout(false);
            this.pnlThongTin1.PerformLayout();
            this.pnlThongTin2.ResumeLayout(false);
            this.pnlThongTin2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpDMHang;
        private System.Windows.Forms.GroupBox gdbThongTinHangHoa;
        private System.Windows.Forms.TableLayoutPanel tlpThongTinHangHoa;
        private System.Windows.Forms.PictureBox imgSP;
        private System.Windows.Forms.Panel pnlThongTin1;
        private System.Windows.Forms.TextBox txtTenhang;
        private System.Windows.Forms.TextBox txtMahang;
        private System.Windows.Forms.Button btnThemLoaiHang;
        private System.Windows.Forms.Button btnThemDVT;
        private System.Windows.Forms.ComboBox cboMaloai;
        private System.Windows.Forms.ComboBox cboDVT;
        private System.Windows.Forms.Label lblLoaiHang;
        private System.Windows.Forms.Label lblDonViTinh;
        private System.Windows.Forms.Label lblTenHang;
        private System.Windows.Forms.Label lblMaHang;
        private System.Windows.Forms.Panel pnlThongTin2;
        private System.Windows.Forms.TextBox txtKM;
        private System.Windows.Forms.Label lblKhuyenMai;
        private System.Windows.Forms.ComboBox cboNCC;
        private System.Windows.Forms.Button btnThemNCC;
        private System.Windows.Forms.Button btnThemNhom;
        private System.Windows.Forms.ComboBox cboManhom;
        private System.Windows.Forms.TextBox txtGia;
        private System.Windows.Forms.Label lblNCC;
        private System.Windows.Forms.Label lblMaNhom;
        private System.Windows.Forms.Label lblDonGia;
        private System.Windows.Forms.Panel pnlDanhMucHang;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.GroupBox grbDanhMucHang;
        private System.Windows.Forms.DataGridView dgvHanghoa;




    }
}
