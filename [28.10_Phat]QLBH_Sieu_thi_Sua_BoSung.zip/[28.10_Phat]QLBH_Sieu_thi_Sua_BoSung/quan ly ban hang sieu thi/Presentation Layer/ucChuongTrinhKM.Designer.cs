﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucChuongTrinhKM
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbMatHangKM = new System.Windows.Forms.GroupBox();
            this.dgvMatHangKM = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoaiKM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tlpChuongTrinhKM = new System.Windows.Forms.TableLayoutPanel();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.grbTimKiemKM = new System.Windows.Forms.GroupBox();
            this.tlpTaoChuongTrinh = new System.Windows.Forms.TableLayoutPanel();
            this.pnlThongTin1 = new System.Windows.Forms.Panel();
            this.txtTenHang = new System.Windows.Forms.TextBox();
            this.lblMaHang = new System.Windows.Forms.Label();
            this.cbMaHang = new System.Windows.Forms.ComboBox();
            this.lblTenHang = new System.Windows.Forms.Label();
            this.pnlThongTin2 = new System.Windows.Forms.Panel();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnThemLoaiKM = new System.Windows.Forms.Button();
            this.cbKhuyenMai = new System.Windows.Forms.ComboBox();
            this.lblLoaiKM = new System.Windows.Forms.Label();
            this.pnlThoiGianApDung = new System.Windows.Forms.Panel();
            this.grbThoiGianApDung = new System.Windows.Forms.GroupBox();
            this.dtpNgayHetHan = new System.Windows.Forms.DateTimePicker();
            this.dtpNgayAD = new System.Windows.Forms.DateTimePicker();
            this.lblDen = new System.Windows.Forms.Label();
            this.lblTu = new System.Windows.Forms.Label();
            this.grbMatHangKM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatHangKM)).BeginInit();
            this.tlpChuongTrinhKM.SuspendLayout();
            this.pnlButton.SuspendLayout();
            this.grbTimKiemKM.SuspendLayout();
            this.tlpTaoChuongTrinh.SuspendLayout();
            this.pnlThongTin1.SuspendLayout();
            this.pnlThongTin2.SuspendLayout();
            this.pnlThoiGianApDung.SuspendLayout();
            this.grbThoiGianApDung.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbMatHangKM
            // 
            this.grbMatHangKM.Controls.Add(this.dgvMatHangKM);
            this.grbMatHangKM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbMatHangKM.Location = new System.Drawing.Point(3, 110);
            this.grbMatHangKM.Name = "grbMatHangKM";
            this.grbMatHangKM.Size = new System.Drawing.Size(648, 350);
            this.grbMatHangKM.TabIndex = 1;
            this.grbMatHangKM.TabStop = false;
            this.grbMatHangKM.Text = "Mặt hàng khuyến mãi ";
            // 
            // dgvMatHangKM
            // 
            this.dgvMatHangKM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMatHangKM.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvMatHangKM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatHangKM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.DVT,
            this.LoaiKM});
            this.dgvMatHangKM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMatHangKM.Location = new System.Drawing.Point(3, 16);
            this.dgvMatHangKM.Name = "dgvMatHangKM";
            this.dgvMatHangKM.RowTemplate.Height = 24;
            this.dgvMatHangKM.Size = new System.Drawing.Size(642, 331);
            this.dgvMatHangKM.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.FillWeight = 50.76141F;
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.FillWeight = 202.5838F;
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // DVT
            // 
            this.DVT.FillWeight = 85.12911F;
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // LoaiKM
            // 
            this.LoaiKM.FillWeight = 61.5256F;
            this.LoaiKM.HeaderText = "Loại KM";
            this.LoaiKM.Name = "LoaiKM";
            // 
            // tlpChuongTrinhKM
            // 
            this.tlpChuongTrinhKM.ColumnCount = 1;
            this.tlpChuongTrinhKM.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpChuongTrinhKM.Controls.Add(this.pnlButton, 0, 2);
            this.tlpChuongTrinhKM.Controls.Add(this.grbMatHangKM, 0, 1);
            this.tlpChuongTrinhKM.Controls.Add(this.grbTimKiemKM, 0, 0);
            this.tlpChuongTrinhKM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpChuongTrinhKM.Location = new System.Drawing.Point(0, 0);
            this.tlpChuongTrinhKM.Name = "tlpChuongTrinhKM";
            this.tlpChuongTrinhKM.RowCount = 3;
            this.tlpChuongTrinhKM.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tlpChuongTrinhKM.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpChuongTrinhKM.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlpChuongTrinhKM.Size = new System.Drawing.Size(654, 503);
            this.tlpChuongTrinhKM.TabIndex = 4;
            // 
            // pnlButton
            // 
            this.pnlButton.Controls.Add(this.btnLuu);
            this.pnlButton.Controls.Add(this.btnXoa);
            this.pnlButton.Controls.Add(this.btnThem);
            this.pnlButton.Controls.Add(this.btnSua);
            this.pnlButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButton.Location = new System.Drawing.Point(3, 466);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(648, 34);
            this.pnlButton.TabIndex = 0;
            // 
            // btnLuu
            // 
            this.btnLuu.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(567, 5);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 3;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(493, 5);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 2;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(343, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(418, 5);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 1;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // grbTimKiemKM
            // 
            this.grbTimKiemKM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.grbTimKiemKM.Controls.Add(this.tlpTaoChuongTrinh);
            this.grbTimKiemKM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbTimKiemKM.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTimKiemKM.Location = new System.Drawing.Point(3, 3);
            this.grbTimKiemKM.Name = "grbTimKiemKM";
            this.grbTimKiemKM.Size = new System.Drawing.Size(648, 101);
            this.grbTimKiemKM.TabIndex = 0;
            this.grbTimKiemKM.TabStop = false;
            this.grbTimKiemKM.Text = "Tạo chương trình khuyến mãi";
            // 
            // tlpTaoChuongTrinh
            // 
            this.tlpTaoChuongTrinh.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpTaoChuongTrinh.ColumnCount = 3;
            this.tlpTaoChuongTrinh.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpTaoChuongTrinh.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpTaoChuongTrinh.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 201F));
            this.tlpTaoChuongTrinh.Controls.Add(this.pnlThongTin1, 0, 0);
            this.tlpTaoChuongTrinh.Controls.Add(this.pnlThongTin2, 1, 0);
            this.tlpTaoChuongTrinh.Controls.Add(this.pnlThoiGianApDung, 2, 0);
            this.tlpTaoChuongTrinh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpTaoChuongTrinh.Location = new System.Drawing.Point(3, 17);
            this.tlpTaoChuongTrinh.Name = "tlpTaoChuongTrinh";
            this.tlpTaoChuongTrinh.RowCount = 1;
            this.tlpTaoChuongTrinh.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpTaoChuongTrinh.Size = new System.Drawing.Size(642, 81);
            this.tlpTaoChuongTrinh.TabIndex = 0;
            // 
            // pnlThongTin1
            // 
            this.pnlThongTin1.Controls.Add(this.txtTenHang);
            this.pnlThongTin1.Controls.Add(this.lblMaHang);
            this.pnlThongTin1.Controls.Add(this.cbMaHang);
            this.pnlThongTin1.Controls.Add(this.lblTenHang);
            this.pnlThongTin1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlThongTin1.Location = new System.Drawing.Point(6, 6);
            this.pnlThongTin1.Name = "pnlThongTin1";
            this.pnlThongTin1.Size = new System.Drawing.Size(208, 69);
            this.pnlThongTin1.TabIndex = 0;
            // 
            // txtTenHang
            // 
            this.txtTenHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenHang.Location = new System.Drawing.Point(65, 38);
            this.txtTenHang.Name = "txtTenHang";
            this.txtTenHang.Size = new System.Drawing.Size(128, 21);
            this.txtTenHang.TabIndex = 1;
            // 
            // lblMaHang
            // 
            this.lblMaHang.AutoSize = true;
            this.lblMaHang.Location = new System.Drawing.Point(10, 14);
            this.lblMaHang.Name = "lblMaHang";
            this.lblMaHang.Size = new System.Drawing.Size(55, 15);
            this.lblMaHang.TabIndex = 8;
            this.lblMaHang.Text = "Mã hàng";
            // 
            // cbMaHang
            // 
            this.cbMaHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbMaHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMaHang.FormattingEnabled = true;
            this.cbMaHang.Location = new System.Drawing.Point(65, 9);
            this.cbMaHang.Name = "cbMaHang";
            this.cbMaHang.Size = new System.Drawing.Size(128, 23);
            this.cbMaHang.TabIndex = 0;
            // 
            // lblTenHang
            // 
            this.lblTenHang.AutoSize = true;
            this.lblTenHang.Location = new System.Drawing.Point(6, 40);
            this.lblTenHang.Name = "lblTenHang";
            this.lblTenHang.Size = new System.Drawing.Size(59, 15);
            this.lblTenHang.TabIndex = 7;
            this.lblTenHang.Text = "Tên hàng";
            // 
            // pnlThongTin2
            // 
            this.pnlThongTin2.Controls.Add(this.btnInsert);
            this.pnlThongTin2.Controls.Add(this.btnThemLoaiKM);
            this.pnlThongTin2.Controls.Add(this.cbKhuyenMai);
            this.pnlThongTin2.Controls.Add(this.lblLoaiKM);
            this.pnlThongTin2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlThongTin2.Location = new System.Drawing.Point(223, 6);
            this.pnlThongTin2.Name = "pnlThongTin2";
            this.pnlThongTin2.Size = new System.Drawing.Size(208, 69);
            this.pnlThongTin2.TabIndex = 1;
            // 
            // btnInsert
            // 
            this.btnInsert.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnInsert.Location = new System.Drawing.Point(169, 36);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(31, 25);
            this.btnInsert.TabIndex = 2;
            this.btnInsert.Text = ">>";
            this.btnInsert.UseVisualStyleBackColor = true;
            // 
            // btnThemLoaiKM
            // 
            this.btnThemLoaiKM.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThemLoaiKM.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThemLoaiKM.Location = new System.Drawing.Point(169, 7);
            this.btnThemLoaiKM.Name = "btnThemLoaiKM";
            this.btnThemLoaiKM.Size = new System.Drawing.Size(31, 26);
            this.btnThemLoaiKM.TabIndex = 1;
            this.btnThemLoaiKM.UseVisualStyleBackColor = true;
            // 
            // cbKhuyenMai
            // 
            this.cbKhuyenMai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbKhuyenMai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbKhuyenMai.FormattingEnabled = true;
            this.cbKhuyenMai.Location = new System.Drawing.Point(56, 9);
            this.cbKhuyenMai.Name = "cbKhuyenMai";
            this.cbKhuyenMai.Size = new System.Drawing.Size(107, 23);
            this.cbKhuyenMai.TabIndex = 0;
            // 
            // lblLoaiKM
            // 
            this.lblLoaiKM.AutoSize = true;
            this.lblLoaiKM.Location = new System.Drawing.Point(3, 13);
            this.lblLoaiKM.Name = "lblLoaiKM";
            this.lblLoaiKM.Size = new System.Drawing.Size(52, 15);
            this.lblLoaiKM.TabIndex = 8;
            this.lblLoaiKM.Text = "Loại KM";
            // 
            // pnlThoiGianApDung
            // 
            this.pnlThoiGianApDung.Controls.Add(this.grbThoiGianApDung);
            this.pnlThoiGianApDung.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlThoiGianApDung.Location = new System.Drawing.Point(440, 6);
            this.pnlThoiGianApDung.Name = "pnlThoiGianApDung";
            this.pnlThoiGianApDung.Size = new System.Drawing.Size(196, 69);
            this.pnlThoiGianApDung.TabIndex = 2;
            // 
            // grbThoiGianApDung
            // 
            this.grbThoiGianApDung.Controls.Add(this.dtpNgayHetHan);
            this.grbThoiGianApDung.Controls.Add(this.dtpNgayAD);
            this.grbThoiGianApDung.Controls.Add(this.lblDen);
            this.grbThoiGianApDung.Controls.Add(this.lblTu);
            this.grbThoiGianApDung.Dock = System.Windows.Forms.DockStyle.Right;
            this.grbThoiGianApDung.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThoiGianApDung.Location = new System.Drawing.Point(16, 0);
            this.grbThoiGianApDung.Name = "grbThoiGianApDung";
            this.grbThoiGianApDung.Size = new System.Drawing.Size(180, 69);
            this.grbThoiGianApDung.TabIndex = 0;
            this.grbThoiGianApDung.TabStop = false;
            this.grbThoiGianApDung.Text = "Thời gian áp dụng";
            // 
            // dtpNgayHetHan
            // 
            this.dtpNgayHetHan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpNgayHetHan.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayHetHan.Location = new System.Drawing.Point(41, 42);
            this.dtpNgayHetHan.Name = "dtpNgayHetHan";
            this.dtpNgayHetHan.Size = new System.Drawing.Size(132, 21);
            this.dtpNgayHetHan.TabIndex = 1;
            // 
            // dtpNgayAD
            // 
            this.dtpNgayAD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpNgayAD.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayAD.Location = new System.Drawing.Point(40, 17);
            this.dtpNgayAD.Name = "dtpNgayAD";
            this.dtpNgayAD.Size = new System.Drawing.Size(132, 21);
            this.dtpNgayAD.TabIndex = 0;
            // 
            // lblDen
            // 
            this.lblDen.AutoSize = true;
            this.lblDen.Location = new System.Drawing.Point(5, 45);
            this.lblDen.Name = "lblDen";
            this.lblDen.Size = new System.Drawing.Size(30, 15);
            this.lblDen.TabIndex = 0;
            this.lblDen.Text = "Đến";
            // 
            // lblTu
            // 
            this.lblTu.AutoSize = true;
            this.lblTu.Location = new System.Drawing.Point(12, 20);
            this.lblTu.Name = "lblTu";
            this.lblTu.Size = new System.Drawing.Size(23, 15);
            this.lblTu.TabIndex = 0;
            this.lblTu.Text = "Từ";
            // 
            // ucChuongTrinhKM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tlpChuongTrinhKM);
            this.Name = "ucChuongTrinhKM";
            this.Size = new System.Drawing.Size(654, 503);
            this.grbMatHangKM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatHangKM)).EndInit();
            this.tlpChuongTrinhKM.ResumeLayout(false);
            this.pnlButton.ResumeLayout(false);
            this.grbTimKiemKM.ResumeLayout(false);
            this.tlpTaoChuongTrinh.ResumeLayout(false);
            this.pnlThongTin1.ResumeLayout(false);
            this.pnlThongTin1.PerformLayout();
            this.pnlThongTin2.ResumeLayout(false);
            this.pnlThongTin2.PerformLayout();
            this.pnlThoiGianApDung.ResumeLayout(false);
            this.grbThoiGianApDung.ResumeLayout(false);
            this.grbThoiGianApDung.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbMatHangKM;
        private System.Windows.Forms.TableLayoutPanel tlpChuongTrinhKM;
        private System.Windows.Forms.GroupBox grbTimKiemKM;
        private System.Windows.Forms.TableLayoutPanel tlpTaoChuongTrinh;
        private System.Windows.Forms.Panel pnlThongTin1;
        private System.Windows.Forms.TextBox txtTenHang;
        private System.Windows.Forms.Label lblMaHang;
        private System.Windows.Forms.ComboBox cbMaHang;
        private System.Windows.Forms.Label lblTenHang;
        private System.Windows.Forms.Panel pnlThongTin2;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnThemLoaiKM;
        private System.Windows.Forms.ComboBox cbKhuyenMai;
        private System.Windows.Forms.Label lblLoaiKM;
        private System.Windows.Forms.Panel pnlThoiGianApDung;
        private System.Windows.Forms.GroupBox grbThoiGianApDung;
        private System.Windows.Forms.DateTimePicker dtpNgayHetHan;
        private System.Windows.Forms.DateTimePicker dtpNgayAD;
        private System.Windows.Forms.Label lblDen;
        private System.Windows.Forms.Label lblTu;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.DataGridView dgvMatHangKM;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaiKM;

    }
}
