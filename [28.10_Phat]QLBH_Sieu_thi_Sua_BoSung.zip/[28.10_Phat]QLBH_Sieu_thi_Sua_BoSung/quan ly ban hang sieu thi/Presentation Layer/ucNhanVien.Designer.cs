﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucNhanVien
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.MaNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GioiTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiaChi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DienThoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoaiNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblTenNV = new System.Windows.Forms.Label();
            this.pnlThongTinNV1 = new System.Windows.Forms.Panel();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.lblMaNV = new System.Windows.Forms.Label();
            this.pnlThongTinNV2 = new System.Windows.Forms.Panel();
            this.raNam = new System.Windows.Forms.RadioButton();
            this.raNu = new System.Windows.Forms.RadioButton();
            this.cboLoaiNV = new System.Windows.Forms.ComboBox();
            this.lblGioiTinh = new System.Windows.Forms.Label();
            this.lblLoaiNV = new System.Windows.Forms.Label();
            this.pnlCacNut = new System.Windows.Forms.Panel();
            this.btnLoc = new System.Windows.Forms.Button();
            this.tbplThongTinNV = new System.Windows.Forms.TableLayoutPanel();
            this.pnlDanhMucHang = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.tblHoidap = new System.Windows.Forms.TableLayoutPanel();
            this.grbThongTinNhanVien = new System.Windows.Forms.GroupBox();
            this.tlpThongTinNhanVien = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.pnlThongTinNV1.SuspendLayout();
            this.pnlThongTinNV2.SuspendLayout();
            this.pnlCacNut.SuspendLayout();
            this.tbplThongTinNV.SuspendLayout();
            this.pnlDanhMucHang.SuspendLayout();
            this.tblHoidap.SuspendLayout();
            this.grbThongTinNhanVien.SuspendLayout();
            this.tlpThongTinNhanVien.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNhanVien.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaNV,
            this.TenNV,
            this.GioiTinh,
            this.DiaChi,
            this.DienThoai,
            this.LoaiNV});
            this.dgvNhanVien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNhanVien.Location = new System.Drawing.Point(6, 6);
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.Size = new System.Drawing.Size(806, 341);
            this.dgvNhanVien.TabIndex = 1;
            // 
            // MaNV
            // 
            this.MaNV.HeaderText = "Mã nhân viên";
            this.MaNV.Name = "MaNV";
            // 
            // TenNV
            // 
            this.TenNV.HeaderText = "Họ tên";
            this.TenNV.Name = "TenNV";
            // 
            // GioiTinh
            // 
            this.GioiTinh.HeaderText = "Giới tính";
            this.GioiTinh.Name = "GioiTinh";
            // 
            // DiaChi
            // 
            this.DiaChi.HeaderText = "Địa chỉ";
            this.DiaChi.Name = "DiaChi";
            // 
            // DienThoai
            // 
            this.DienThoai.HeaderText = "Điện thoại";
            this.DienThoai.Name = "DienThoai";
            // 
            // LoaiNV
            // 
            this.LoaiNV.HeaderText = "Loại NV";
            this.LoaiNV.Name = "LoaiNV";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(62, 43);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(200, 21);
            this.txtHoTen.TabIndex = 4;
            // 
            // lblTenNV
            // 
            this.lblTenNV.AutoSize = true;
            this.lblTenNV.Location = new System.Drawing.Point(13, 43);
            this.lblTenNV.Name = "lblTenNV";
            this.lblTenNV.Size = new System.Drawing.Size(43, 15);
            this.lblTenNV.TabIndex = 3;
            this.lblTenNV.Text = "Họ tên";
            // 
            // pnlThongTinNV1
            // 
            this.pnlThongTinNV1.Controls.Add(this.txtHoTen);
            this.pnlThongTinNV1.Controls.Add(this.lblTenNV);
            this.pnlThongTinNV1.Controls.Add(this.txtMaNV);
            this.pnlThongTinNV1.Controls.Add(this.lblMaNV);
            this.pnlThongTinNV1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlThongTinNV1.Location = new System.Drawing.Point(6, 6);
            this.pnlThongTinNV1.Name = "pnlThongTinNV1";
            this.pnlThongTinNV1.Size = new System.Drawing.Size(323, 77);
            this.pnlThongTinNV1.TabIndex = 3;
            // 
            // txtMaNV
            // 
            this.txtMaNV.Location = new System.Drawing.Point(62, 10);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(200, 21);
            this.txtMaNV.TabIndex = 5;
            // 
            // lblMaNV
            // 
            this.lblMaNV.AutoSize = true;
            this.lblMaNV.Location = new System.Drawing.Point(13, 13);
            this.lblMaNV.Name = "lblMaNV";
            this.lblMaNV.Size = new System.Drawing.Size(43, 15);
            this.lblMaNV.TabIndex = 2;
            this.lblMaNV.Text = "Mã NV";
            // 
            // pnlThongTinNV2
            // 
            this.pnlThongTinNV2.Controls.Add(this.raNam);
            this.pnlThongTinNV2.Controls.Add(this.raNu);
            this.pnlThongTinNV2.Controls.Add(this.cboLoaiNV);
            this.pnlThongTinNV2.Controls.Add(this.lblGioiTinh);
            this.pnlThongTinNV2.Controls.Add(this.lblLoaiNV);
            this.pnlThongTinNV2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlThongTinNV2.Location = new System.Drawing.Point(338, 6);
            this.pnlThongTinNV2.Name = "pnlThongTinNV2";
            this.pnlThongTinNV2.Size = new System.Drawing.Size(323, 77);
            this.pnlThongTinNV2.TabIndex = 2;
            // 
            // raNam
            // 
            this.raNam.AutoSize = true;
            this.raNam.Location = new System.Drawing.Point(155, 44);
            this.raNam.Name = "raNam";
            this.raNam.Size = new System.Drawing.Size(51, 19);
            this.raNam.TabIndex = 9;
            this.raNam.TabStop = true;
            this.raNam.Text = "Nam";
            this.raNam.UseVisualStyleBackColor = true;
            // 
            // raNu
            // 
            this.raNu.AutoSize = true;
            this.raNu.Location = new System.Drawing.Point(98, 44);
            this.raNu.Name = "raNu";
            this.raNu.Size = new System.Drawing.Size(42, 19);
            this.raNu.TabIndex = 10;
            this.raNu.TabStop = true;
            this.raNu.Text = "Nữ";
            this.raNu.UseVisualStyleBackColor = true;
            // 
            // cboLoaiNV
            // 
            this.cboLoaiNV.FormattingEnabled = true;
            this.cboLoaiNV.Location = new System.Drawing.Point(83, 10);
            this.cboLoaiNV.Name = "cboLoaiNV";
            this.cboLoaiNV.Size = new System.Drawing.Size(194, 23);
            this.cboLoaiNV.TabIndex = 8;
            // 
            // lblGioiTinh
            // 
            this.lblGioiTinh.AutoSize = true;
            this.lblGioiTinh.Location = new System.Drawing.Point(18, 46);
            this.lblGioiTinh.Name = "lblGioiTinh";
            this.lblGioiTinh.Size = new System.Drawing.Size(54, 15);
            this.lblGioiTinh.TabIndex = 6;
            this.lblGioiTinh.Text = "Giới tính";
            // 
            // lblLoaiNV
            // 
            this.lblLoaiNV.AutoSize = true;
            this.lblLoaiNV.Location = new System.Drawing.Point(22, 14);
            this.lblLoaiNV.Name = "lblLoaiNV";
            this.lblLoaiNV.Size = new System.Drawing.Size(50, 15);
            this.lblLoaiNV.TabIndex = 7;
            this.lblLoaiNV.Text = "Loại NV";
            // 
            // pnlCacNut
            // 
            this.pnlCacNut.Controls.Add(this.btnLoc);
            this.pnlCacNut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCacNut.Location = new System.Drawing.Point(670, 6);
            this.pnlCacNut.Name = "pnlCacNut";
            this.pnlCacNut.Size = new System.Drawing.Size(136, 77);
            this.pnlCacNut.TabIndex = 3;
            // 
            // btnLoc
            // 
            this.btnLoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLoc.Location = new System.Drawing.Point(0, 0);
            this.btnLoc.Name = "btnLoc";
            this.btnLoc.Size = new System.Drawing.Size(136, 77);
            this.btnLoc.TabIndex = 4;
            this.btnLoc.Text = "&Tìm kiếm";
            this.btnLoc.UseVisualStyleBackColor = true;
            // 
            // tbplThongTinNV
            // 
            this.tbplThongTinNV.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tbplThongTinNV.ColumnCount = 1;
            this.tbplThongTinNV.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.375F));
            this.tbplThongTinNV.Controls.Add(this.pnlDanhMucHang, 0, 1);
            this.tbplThongTinNV.Controls.Add(this.dgvNhanVien, 0, 0);
            this.tbplThongTinNV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplThongTinNV.Location = new System.Drawing.Point(3, 118);
            this.tbplThongTinNV.Name = "tbplThongTinNV";
            this.tbplThongTinNV.RowCount = 2;
            this.tbplThongTinNV.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplThongTinNV.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tbplThongTinNV.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 299F));
            this.tbplThongTinNV.Size = new System.Drawing.Size(818, 391);
            this.tbplThongTinNV.TabIndex = 2;
            // 
            // pnlDanhMucHang
            // 
            this.pnlDanhMucHang.Controls.Add(this.btnLuu);
            this.pnlDanhMucHang.Controls.Add(this.btnXoa);
            this.pnlDanhMucHang.Controls.Add(this.btnThem);
            this.pnlDanhMucHang.Controls.Add(this.btnSua);
            this.pnlDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDanhMucHang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlDanhMucHang.Location = new System.Drawing.Point(6, 356);
            this.pnlDanhMucHang.Name = "pnlDanhMucHang";
            this.pnlDanhMucHang.Size = new System.Drawing.Size(806, 29);
            this.pnlDanhMucHang.TabIndex = 3;
            // 
            // btnLuu
            // 
            this.btnLuu.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(710, 2);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 3;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(636, 2);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 2;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(486, 2);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(561, 2);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 1;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // tblHoidap
            // 
            this.tblHoidap.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tblHoidap.ColumnCount = 3;
            this.tblHoidap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblHoidap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblHoidap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 141F));
            this.tblHoidap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblHoidap.Controls.Add(this.pnlThongTinNV1, 0, 0);
            this.tblHoidap.Controls.Add(this.pnlThongTinNV2, 1, 0);
            this.tblHoidap.Controls.Add(this.pnlCacNut, 2, 0);
            this.tblHoidap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblHoidap.Location = new System.Drawing.Point(3, 17);
            this.tblHoidap.Name = "tblHoidap";
            this.tblHoidap.RowCount = 1;
            this.tblHoidap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblHoidap.Size = new System.Drawing.Size(812, 89);
            this.tblHoidap.TabIndex = 0;
            // 
            // grbThongTinNhanVien
            // 
            this.grbThongTinNhanVien.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.grbThongTinNhanVien.Controls.Add(this.tblHoidap);
            this.grbThongTinNhanVien.Dock = System.Windows.Forms.DockStyle.Top;
            this.grbThongTinNhanVien.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinNhanVien.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinNhanVien.Name = "grbThongTinNhanVien";
            this.grbThongTinNhanVien.Size = new System.Drawing.Size(818, 109);
            this.grbThongTinNhanVien.TabIndex = 1;
            this.grbThongTinNhanVien.TabStop = false;
            this.grbThongTinNhanVien.Text = "Thông tin nhân viên";
            // 
            // tlpThongTinNhanVien
            // 
            this.tlpThongTinNhanVien.ColumnCount = 1;
            this.tlpThongTinNhanVien.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinNhanVien.Controls.Add(this.tbplThongTinNV, 0, 1);
            this.tlpThongTinNhanVien.Controls.Add(this.grbThongTinNhanVien, 0, 0);
            this.tlpThongTinNhanVien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpThongTinNhanVien.Location = new System.Drawing.Point(0, 0);
            this.tlpThongTinNhanVien.Name = "tlpThongTinNhanVien";
            this.tlpThongTinNhanVien.RowCount = 2;
            this.tlpThongTinNhanVien.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 115F));
            this.tlpThongTinNhanVien.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinNhanVien.Size = new System.Drawing.Size(824, 512);
            this.tlpThongTinNhanVien.TabIndex = 1;
            // 
            // ucNhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tlpThongTinNhanVien);
            this.Name = "ucNhanVien";
            this.Size = new System.Drawing.Size(824, 512);
            this.Load += new System.EventHandler(this.ucNhanVien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.pnlThongTinNV1.ResumeLayout(false);
            this.pnlThongTinNV1.PerformLayout();
            this.pnlThongTinNV2.ResumeLayout(false);
            this.pnlThongTinNV2.PerformLayout();
            this.pnlCacNut.ResumeLayout(false);
            this.tbplThongTinNV.ResumeLayout(false);
            this.pnlDanhMucHang.ResumeLayout(false);
            this.tblHoidap.ResumeLayout(false);
            this.grbThongTinNhanVien.ResumeLayout(false);
            this.tlpThongTinNhanVien.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvNhanVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn GioiTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiaChi;
        private System.Windows.Forms.DataGridViewTextBoxColumn DienThoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaiNV;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblTenNV;
        private System.Windows.Forms.Panel pnlThongTinNV1;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label lblMaNV;
        private System.Windows.Forms.Panel pnlThongTinNV2;
        private System.Windows.Forms.RadioButton raNam;
        private System.Windows.Forms.RadioButton raNu;
        private System.Windows.Forms.ComboBox cboLoaiNV;
        private System.Windows.Forms.Label lblGioiTinh;
        private System.Windows.Forms.Label lblLoaiNV;
        private System.Windows.Forms.Panel pnlCacNut;
        private System.Windows.Forms.Button btnLoc;
        private System.Windows.Forms.TableLayoutPanel tbplThongTinNV;
        private System.Windows.Forms.Panel pnlDanhMucHang;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.TableLayoutPanel tblHoidap;
        private System.Windows.Forms.GroupBox grbThongTinNhanVien;
        private System.Windows.Forms.TableLayoutPanel tlpThongTinNhanVien;

    }
}
