﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucDonDatHang
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucDonDatHang));
            this.tlpDonDatHang = new System.Windows.Forms.TableLayoutPanel();
            this.grbDanhSachCacHoaDon = new System.Windows.Forms.GroupBox();
            this.tlpDSDonDatHang = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.MaDDH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNCC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NVLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PTTT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bnaDanhSachDDH = new System.Windows.Forms.BindingNavigator(this.components);
            this.tbtnNewDS = new System.Windows.Forms.ToolStripButton();
            this.tlblTotalItemDS = new System.Windows.Forms.ToolStripLabel();
            this.tbtnDelDS = new System.Windows.Forms.ToolStripButton();
            this.tbtnFirstDS = new System.Windows.Forms.ToolStripButton();
            this.tbtnPrevDS = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.ttxtCurrPosDS = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tbtnNextDS = new System.Windows.Forms.ToolStripButton();
            this.tbtnLastDS = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.grbChiTietDonDatHang = new System.Windows.Forms.GroupBox();
            this.tlpChiTietDonDatHang = new System.Windows.Forms.TableLayoutPanel();
            this.dgvChiTietDonDatHang = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nbaChiTietDDH = new System.Windows.Forms.BindingNavigator(this.components);
            this.tbtnAddCT = new System.Windows.Forms.ToolStripButton();
            this.tlblTotalNoCT = new System.Windows.Forms.ToolStripLabel();
            this.tbtnDelCT = new System.Windows.Forms.ToolStripButton();
            this.tbtnFirstCT = new System.Windows.Forms.ToolStripButton();
            this.tbtnPrevCT = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ttxtCurrPosCT = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbtnNextCT = new System.Windows.Forms.ToolStripButton();
            this.tbtnLastCT = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.pnlBtn = new System.Windows.Forms.Panel();
            this.btnXuatDonDatHang = new System.Windows.Forms.Button();
            this.tlpDonDatHang.SuspendLayout();
            this.grbDanhSachCacHoaDon.SuspendLayout();
            this.tlpDSDonDatHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bnaDanhSachDDH)).BeginInit();
            this.bnaDanhSachDDH.SuspendLayout();
            this.grbChiTietDonDatHang.SuspendLayout();
            this.tlpChiTietDonDatHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietDonDatHang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbaChiTietDDH)).BeginInit();
            this.nbaChiTietDDH.SuspendLayout();
            this.pnlBtn.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpDonDatHang
            // 
            this.tlpDonDatHang.ColumnCount = 1;
            this.tlpDonDatHang.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpDonDatHang.Controls.Add(this.grbDanhSachCacHoaDon, 0, 0);
            this.tlpDonDatHang.Controls.Add(this.grbChiTietDonDatHang, 0, 1);
            this.tlpDonDatHang.Controls.Add(this.pnlBtn, 0, 2);
            this.tlpDonDatHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpDonDatHang.Location = new System.Drawing.Point(0, 0);
            this.tlpDonDatHang.Name = "tlpDonDatHang";
            this.tlpDonDatHang.RowCount = 3;
            this.tlpDonDatHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.85466F));
            this.tlpDonDatHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.14534F));
            this.tlpDonDatHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tlpDonDatHang.Size = new System.Drawing.Size(800, 522);
            this.tlpDonDatHang.TabIndex = 0;
            // 
            // grbDanhSachCacHoaDon
            // 
            this.grbDanhSachCacHoaDon.Controls.Add(this.tlpDSDonDatHang);
            this.grbDanhSachCacHoaDon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhSachCacHoaDon.Location = new System.Drawing.Point(3, 3);
            this.grbDanhSachCacHoaDon.Name = "grbDanhSachCacHoaDon";
            this.grbDanhSachCacHoaDon.Size = new System.Drawing.Size(794, 219);
            this.grbDanhSachCacHoaDon.TabIndex = 0;
            this.grbDanhSachCacHoaDon.TabStop = false;
            this.grbDanhSachCacHoaDon.Text = "Danh sách đơn đặt hàng";
            // 
            // tlpDSDonDatHang
            // 
            this.tlpDSDonDatHang.ColumnCount = 1;
            this.tlpDSDonDatHang.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpDSDonDatHang.Controls.Add(this.dataGridView1, 0, 1);
            this.tlpDSDonDatHang.Controls.Add(this.bnaDanhSachDDH, 0, 0);
            this.tlpDSDonDatHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpDSDonDatHang.Location = new System.Drawing.Point(3, 16);
            this.tlpDSDonDatHang.Name = "tlpDSDonDatHang";
            this.tlpDSDonDatHang.RowCount = 2;
            this.tlpDSDonDatHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tlpDSDonDatHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tlpDSDonDatHang.Size = new System.Drawing.Size(788, 200);
            this.tlpDSDonDatHang.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaDDH,
            this.MaNCC,
            this.NgayLap,
            this.NVLap,
            this.PTTT,
            this.GiaTri});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(782, 170);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // MaDDH
            // 
            this.MaDDH.HeaderText = "Mã ĐĐH";
            this.MaDDH.Name = "MaDDH";
            // 
            // MaNCC
            // 
            this.MaNCC.HeaderText = "MaNCC";
            this.MaNCC.Name = "MaNCC";
            // 
            // NgayLap
            // 
            this.NgayLap.HeaderText = "Ngày lập";
            this.NgayLap.Name = "NgayLap";
            // 
            // NVLap
            // 
            this.NVLap.HeaderText = "Mã NV Lập";
            this.NVLap.Name = "NVLap";
            // 
            // PTTT
            // 
            this.PTTT.HeaderText = "Phương thức thanh toán";
            this.PTTT.Name = "PTTT";
            // 
            // GiaTri
            // 
            this.GiaTri.HeaderText = "Giá trị ĐĐH";
            this.GiaTri.Name = "GiaTri";
            // 
            // bnaDanhSachDDH
            // 
            this.bnaDanhSachDDH.AddNewItem = this.tbtnNewDS;
            this.bnaDanhSachDDH.CountItem = this.tlblTotalItemDS;
            this.bnaDanhSachDDH.DeleteItem = this.tbtnDelDS;
            this.bnaDanhSachDDH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bnaDanhSachDDH.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tbtnFirstDS,
            this.tbtnPrevDS,
            this.bindingNavigatorSeparator,
            this.ttxtCurrPosDS,
            this.tlblTotalItemDS,
            this.bindingNavigatorSeparator1,
            this.tbtnNextDS,
            this.tbtnLastDS,
            this.bindingNavigatorSeparator2,
            this.tbtnNewDS,
            this.tbtnDelDS});
            this.bnaDanhSachDDH.Location = new System.Drawing.Point(0, 0);
            this.bnaDanhSachDDH.MoveFirstItem = this.tbtnFirstDS;
            this.bnaDanhSachDDH.MoveLastItem = this.tbtnLastDS;
            this.bnaDanhSachDDH.MoveNextItem = this.tbtnNextDS;
            this.bnaDanhSachDDH.MovePreviousItem = this.tbtnPrevDS;
            this.bnaDanhSachDDH.Name = "bnaDanhSachDDH";
            this.bnaDanhSachDDH.PositionItem = this.ttxtCurrPosDS;
            this.bnaDanhSachDDH.Size = new System.Drawing.Size(788, 24);
            this.bnaDanhSachDDH.TabIndex = 1;
            this.bnaDanhSachDDH.Text = "bindingNavigator1";
            // 
            // tbtnNewDS
            // 
            this.tbtnNewDS.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnNewDS.Image = ((System.Drawing.Image)(resources.GetObject("tbtnNewDS.Image")));
            this.tbtnNewDS.Name = "tbtnNewDS";
            this.tbtnNewDS.RightToLeftAutoMirrorImage = true;
            this.tbtnNewDS.Size = new System.Drawing.Size(23, 21);
            this.tbtnNewDS.Text = "Add new";
            // 
            // tlblTotalItemDS
            // 
            this.tlblTotalItemDS.Name = "tlblTotalItemDS";
            this.tlblTotalItemDS.Size = new System.Drawing.Size(35, 21);
            this.tlblTotalItemDS.Text = "of {0}";
            this.tlblTotalItemDS.ToolTipText = "Total number of items";
            // 
            // tbtnDelDS
            // 
            this.tbtnDelDS.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnDelDS.Image = ((System.Drawing.Image)(resources.GetObject("tbtnDelDS.Image")));
            this.tbtnDelDS.Name = "tbtnDelDS";
            this.tbtnDelDS.RightToLeftAutoMirrorImage = true;
            this.tbtnDelDS.Size = new System.Drawing.Size(23, 21);
            this.tbtnDelDS.Text = "Delete";
            // 
            // tbtnFirstDS
            // 
            this.tbtnFirstDS.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnFirstDS.Image = ((System.Drawing.Image)(resources.GetObject("tbtnFirstDS.Image")));
            this.tbtnFirstDS.Name = "tbtnFirstDS";
            this.tbtnFirstDS.RightToLeftAutoMirrorImage = true;
            this.tbtnFirstDS.Size = new System.Drawing.Size(23, 21);
            this.tbtnFirstDS.Text = "Move first";
            // 
            // tbtnPrevDS
            // 
            this.tbtnPrevDS.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnPrevDS.Image = ((System.Drawing.Image)(resources.GetObject("tbtnPrevDS.Image")));
            this.tbtnPrevDS.Name = "tbtnPrevDS";
            this.tbtnPrevDS.RightToLeftAutoMirrorImage = true;
            this.tbtnPrevDS.Size = new System.Drawing.Size(23, 21);
            this.tbtnPrevDS.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 24);
            // 
            // ttxtCurrPosDS
            // 
            this.ttxtCurrPosDS.AccessibleName = "Position";
            this.ttxtCurrPosDS.AutoSize = false;
            this.ttxtCurrPosDS.Name = "ttxtCurrPosDS";
            this.ttxtCurrPosDS.Size = new System.Drawing.Size(50, 21);
            this.ttxtCurrPosDS.Text = "0";
            this.ttxtCurrPosDS.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 24);
            // 
            // tbtnNextDS
            // 
            this.tbtnNextDS.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnNextDS.Image = ((System.Drawing.Image)(resources.GetObject("tbtnNextDS.Image")));
            this.tbtnNextDS.Name = "tbtnNextDS";
            this.tbtnNextDS.RightToLeftAutoMirrorImage = true;
            this.tbtnNextDS.Size = new System.Drawing.Size(23, 21);
            this.tbtnNextDS.Text = "Move next";
            // 
            // tbtnLastDS
            // 
            this.tbtnLastDS.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnLastDS.Image = ((System.Drawing.Image)(resources.GetObject("tbtnLastDS.Image")));
            this.tbtnLastDS.Name = "tbtnLastDS";
            this.tbtnLastDS.RightToLeftAutoMirrorImage = true;
            this.tbtnLastDS.Size = new System.Drawing.Size(23, 21);
            this.tbtnLastDS.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 24);
            // 
            // grbChiTietDonDatHang
            // 
            this.grbChiTietDonDatHang.Controls.Add(this.tlpChiTietDonDatHang);
            this.grbChiTietDonDatHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietDonDatHang.Location = new System.Drawing.Point(3, 228);
            this.grbChiTietDonDatHang.Name = "grbChiTietDonDatHang";
            this.grbChiTietDonDatHang.Size = new System.Drawing.Size(794, 249);
            this.grbChiTietDonDatHang.TabIndex = 0;
            this.grbChiTietDonDatHang.TabStop = false;
            this.grbChiTietDonDatHang.Text = "Chi tiết đơn đặt hàng";
            // 
            // tlpChiTietDonDatHang
            // 
            this.tlpChiTietDonDatHang.ColumnCount = 1;
            this.tlpChiTietDonDatHang.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpChiTietDonDatHang.Controls.Add(this.dgvChiTietDonDatHang, 0, 1);
            this.tlpChiTietDonDatHang.Controls.Add(this.nbaChiTietDDH, 0, 0);
            this.tlpChiTietDonDatHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpChiTietDonDatHang.Location = new System.Drawing.Point(3, 16);
            this.tlpChiTietDonDatHang.Name = "tlpChiTietDonDatHang";
            this.tlpChiTietDonDatHang.RowCount = 2;
            this.tlpChiTietDonDatHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.86957F));
            this.tlpChiTietDonDatHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 89.13043F));
            this.tlpChiTietDonDatHang.Size = new System.Drawing.Size(788, 230);
            this.tlpChiTietDonDatHang.TabIndex = 0;
            // 
            // dgvChiTietDonDatHang
            // 
            this.dgvChiTietDonDatHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietDonDatHang.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvChiTietDonDatHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietDonDatHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.SL,
            this.DVT,
            this.Gia});
            this.dgvChiTietDonDatHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChiTietDonDatHang.Location = new System.Drawing.Point(3, 28);
            this.dgvChiTietDonDatHang.Name = "dgvChiTietDonDatHang";
            this.dgvChiTietDonDatHang.Size = new System.Drawing.Size(782, 199);
            this.dgvChiTietDonDatHang.TabIndex = 0;
            this.dgvChiTietDonDatHang.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // Gia
            // 
            this.Gia.HeaderText = "Đơn giá";
            this.Gia.Name = "Gia";
            // 
            // nbaChiTietDDH
            // 
            this.nbaChiTietDDH.AddNewItem = this.tbtnAddCT;
            this.nbaChiTietDDH.CountItem = this.tlblTotalNoCT;
            this.nbaChiTietDDH.DeleteItem = this.tbtnDelCT;
            this.nbaChiTietDDH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nbaChiTietDDH.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tbtnFirstCT,
            this.tbtnPrevCT,
            this.toolStripSeparator1,
            this.ttxtCurrPosCT,
            this.tlblTotalNoCT,
            this.toolStripSeparator2,
            this.tbtnNextCT,
            this.tbtnLastCT,
            this.toolStripSeparator3,
            this.tbtnAddCT,
            this.tbtnDelCT});
            this.nbaChiTietDDH.Location = new System.Drawing.Point(0, 0);
            this.nbaChiTietDDH.MoveFirstItem = this.tbtnFirstCT;
            this.nbaChiTietDDH.MoveLastItem = this.tbtnLastCT;
            this.nbaChiTietDDH.MoveNextItem = this.tbtnNextCT;
            this.nbaChiTietDDH.MovePreviousItem = this.tbtnPrevCT;
            this.nbaChiTietDDH.Name = "nbaChiTietDDH";
            this.nbaChiTietDDH.PositionItem = this.ttxtCurrPosCT;
            this.nbaChiTietDDH.Size = new System.Drawing.Size(788, 25);
            this.nbaChiTietDDH.TabIndex = 1;
            this.nbaChiTietDDH.Text = "bindingNavigator1";
            // 
            // tbtnAddCT
            // 
            this.tbtnAddCT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnAddCT.Image = ((System.Drawing.Image)(resources.GetObject("tbtnAddCT.Image")));
            this.tbtnAddCT.Name = "tbtnAddCT";
            this.tbtnAddCT.RightToLeftAutoMirrorImage = true;
            this.tbtnAddCT.Size = new System.Drawing.Size(23, 22);
            this.tbtnAddCT.Text = "Add new";
            // 
            // tlblTotalNoCT
            // 
            this.tlblTotalNoCT.Name = "tlblTotalNoCT";
            this.tlblTotalNoCT.Size = new System.Drawing.Size(35, 22);
            this.tlblTotalNoCT.Text = "of {0}";
            this.tlblTotalNoCT.ToolTipText = "Total number of items";
            // 
            // tbtnDelCT
            // 
            this.tbtnDelCT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnDelCT.Image = ((System.Drawing.Image)(resources.GetObject("tbtnDelCT.Image")));
            this.tbtnDelCT.Name = "tbtnDelCT";
            this.tbtnDelCT.RightToLeftAutoMirrorImage = true;
            this.tbtnDelCT.Size = new System.Drawing.Size(23, 22);
            this.tbtnDelCT.Text = "Delete";
            // 
            // tbtnFirstCT
            // 
            this.tbtnFirstCT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnFirstCT.Image = ((System.Drawing.Image)(resources.GetObject("tbtnFirstCT.Image")));
            this.tbtnFirstCT.Name = "tbtnFirstCT";
            this.tbtnFirstCT.RightToLeftAutoMirrorImage = true;
            this.tbtnFirstCT.Size = new System.Drawing.Size(23, 22);
            this.tbtnFirstCT.Text = "Move first";
            // 
            // tbtnPrevCT
            // 
            this.tbtnPrevCT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnPrevCT.Image = ((System.Drawing.Image)(resources.GetObject("tbtnPrevCT.Image")));
            this.tbtnPrevCT.Name = "tbtnPrevCT";
            this.tbtnPrevCT.RightToLeftAutoMirrorImage = true;
            this.tbtnPrevCT.Size = new System.Drawing.Size(23, 22);
            this.tbtnPrevCT.Text = "Move previous";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // ttxtCurrPosCT
            // 
            this.ttxtCurrPosCT.AccessibleName = "Position";
            this.ttxtCurrPosCT.AutoSize = false;
            this.ttxtCurrPosCT.Name = "ttxtCurrPosCT";
            this.ttxtCurrPosCT.Size = new System.Drawing.Size(50, 21);
            this.ttxtCurrPosCT.Text = "0";
            this.ttxtCurrPosCT.ToolTipText = "Current position";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbtnNextCT
            // 
            this.tbtnNextCT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnNextCT.Image = ((System.Drawing.Image)(resources.GetObject("tbtnNextCT.Image")));
            this.tbtnNextCT.Name = "tbtnNextCT";
            this.tbtnNextCT.RightToLeftAutoMirrorImage = true;
            this.tbtnNextCT.Size = new System.Drawing.Size(23, 22);
            this.tbtnNextCT.Text = "Move next";
            // 
            // tbtnLastCT
            // 
            this.tbtnLastCT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbtnLastCT.Image = ((System.Drawing.Image)(resources.GetObject("tbtnLastCT.Image")));
            this.tbtnLastCT.Name = "tbtnLastCT";
            this.tbtnLastCT.RightToLeftAutoMirrorImage = true;
            this.tbtnLastCT.Size = new System.Drawing.Size(23, 22);
            this.tbtnLastCT.Text = "Move last";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // pnlBtn
            // 
            this.pnlBtn.Controls.Add(this.btnXuatDonDatHang);
            this.pnlBtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBtn.Location = new System.Drawing.Point(3, 483);
            this.pnlBtn.Name = "pnlBtn";
            this.pnlBtn.Size = new System.Drawing.Size(794, 36);
            this.pnlBtn.TabIndex = 1;
            // 
            // btnXuatDonDatHang
            // 
            this.btnXuatDonDatHang.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnXuatDonDatHang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatDonDatHang.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Print;
            this.btnXuatDonDatHang.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXuatDonDatHang.Location = new System.Drawing.Point(620, 3);
            this.btnXuatDonDatHang.Name = "btnXuatDonDatHang";
            this.btnXuatDonDatHang.Size = new System.Drawing.Size(152, 30);
            this.btnXuatDonDatHang.TabIndex = 10;
            this.btnXuatDonDatHang.Text = "Xuất đơn đặt hàng";
            this.btnXuatDonDatHang.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXuatDonDatHang.UseVisualStyleBackColor = true;
            // 
            // ucDonDatHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.tlpDonDatHang);
            this.Name = "ucDonDatHang";
            this.Size = new System.Drawing.Size(800, 522);
            this.tlpDonDatHang.ResumeLayout(false);
            this.grbDanhSachCacHoaDon.ResumeLayout(false);
            this.tlpDSDonDatHang.ResumeLayout(false);
            this.tlpDSDonDatHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bnaDanhSachDDH)).EndInit();
            this.bnaDanhSachDDH.ResumeLayout(false);
            this.bnaDanhSachDDH.PerformLayout();
            this.grbChiTietDonDatHang.ResumeLayout(false);
            this.tlpChiTietDonDatHang.ResumeLayout(false);
            this.tlpChiTietDonDatHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietDonDatHang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbaChiTietDDH)).EndInit();
            this.nbaChiTietDDH.ResumeLayout(false);
            this.nbaChiTietDDH.PerformLayout();
            this.pnlBtn.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpDonDatHang;
        private System.Windows.Forms.GroupBox grbDanhSachCacHoaDon;
        private System.Windows.Forms.TableLayoutPanel tlpDSDonDatHang;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingNavigator bnaDanhSachDDH;
        private System.Windows.Forms.ToolStripButton tbtnNewDS;
        private System.Windows.Forms.ToolStripLabel tlblTotalItemDS;
        private System.Windows.Forms.ToolStripButton tbtnDelDS;
        private System.Windows.Forms.ToolStripButton tbtnFirstDS;
        private System.Windows.Forms.ToolStripButton tbtnPrevDS;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox ttxtCurrPosDS;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton tbtnNextDS;
        private System.Windows.Forms.ToolStripButton tbtnLastDS;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.GroupBox grbChiTietDonDatHang;
        private System.Windows.Forms.TableLayoutPanel tlpChiTietDonDatHang;
        private System.Windows.Forms.DataGridView dgvChiTietDonDatHang;
        private System.Windows.Forms.BindingNavigator nbaChiTietDDH;
        private System.Windows.Forms.ToolStripButton tbtnAddCT;
        private System.Windows.Forms.ToolStripLabel tlblTotalNoCT;
        private System.Windows.Forms.ToolStripButton tbtnDelCT;
        private System.Windows.Forms.ToolStripButton tbtnFirstCT;
        private System.Windows.Forms.ToolStripButton tbtnPrevCT;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox ttxtCurrPosCT;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tbtnNextCT;
        private System.Windows.Forms.ToolStripButton tbtnLastCT;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.Panel pnlBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaDDH;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNCC;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn NVLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn PTTT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gia;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaTri;
        private System.Windows.Forms.Button btnXuatDonDatHang;

    }
}
