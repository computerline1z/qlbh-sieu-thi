﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer;
namespace quan_ly_ban_hang_sieu_thi
{


    public partial class ucNCC : UserControl
    {
        NHACUNGCAP_OBJ Nhacungcap_obj = new NHACUNGCAP_OBJ();
        NHACUNGCAP_BUS Nhacungcap_bus = new NHACUNGCAP_BUS();
        CUNGCAP_BUS Cungcap_bus = new CUNGCAP_BUS();
        PHIEUNHAP_BUS Phieunhap_bus = new PHIEUNHAP_BUS();
        DONDATHANG_BUS Dondathang_bus = new DONDATHANG_BUS();
        DMHANGHOA_BUS DMHang_bus = new DMHANGHOA_BUS();
        BindingSource bindingSource = new BindingSource();
        string tempValue = "";
        string flag = "";

        public ucNCC()
        {
            InitializeComponent();
            disableInput();
            bindingSource.DataSource = Nhacungcap_bus.LayDanhSachNCC();
            dgvNCC.DataSource = bindingSource;
        }



        public void enableInput()
        {

            txtDiaChi.ReadOnly = false;
            txtTenNCC.ReadOnly = false;
            txtSoTk.ReadOnly = false;
            txtMathue.ReadOnly = false;
            txtFax.ReadOnly = false;
            txtDienthoai.ReadOnly = false;

        }

        public void disableInput()
        {
            txtDiaChi.ReadOnly = true;
            txtTenNCC.ReadOnly = true;
            txtSoTk.ReadOnly = true;
            txtMathue.ReadOnly = true;
            txtFax.ReadOnly = true;
            txtDienthoai.ReadOnly = true;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            enableInput();
            grbNCC.Text = Nhacungcap_bus.LayIDTiepTheo();
            txtDiaChi.Focus();
            flag = "Them";

        }



        private void btnLuu_Click(object sender, EventArgs e)
        {
            //gan thong tin 
            Nhacungcap_obj.MaNCC = txtMaNCC.Text.Trim();
            Nhacungcap_obj.TenNCC = txtTenNCC.Text.Trim();
            Nhacungcap_obj.Diachi = txtDiaChi.Text.Trim();
            Nhacungcap_obj.Dienthoai = txtDienthoai.Text.Trim();
            Nhacungcap_obj.Fax = txtFax.Text.Trim();
            Nhacungcap_obj.Mathue = txtMathue.Text.Trim();
            Nhacungcap_obj.SotK = txtSoTk.Text.Trim();

            // kiem tra rong
            string[] nullErrMessages = { "Mã NCC rỗng",
                                     "Tên NCC rỗng",
                                     "Địa chỉ NCC rỗng ",
                                     "Mã thuế rỗng",
                                     "Điện thoại rỗng ",
                                     "Số TK rỗng",
                                     "Số Fax rỗng"
                                   };
            string[] lengthErrMessages = { "Chiều dài tên vượt quá quy định",
                                             "Chiều dài địa chỉ vượt quá quy định",
                                             "Chiều dài điện thoại vượt quá quy định",
                                             "Chiều dài Fax vượt quá quy định",
                                             "Chiều dài Mã thuế vượt quá quy định",
                                             "Chiều dài số TK vượt quá quy định"
                                          };

            int[] errArr = new int[7];
            errArr = Nhacungcap_bus.ktRong(Nhacungcap_obj);
            for (int i = 0; i < 7; i++)
            {
                if (errArr[i] > 0)
                {
                    MessageBox.Show(nullErrMessages[i]);
                    return;
                }
            }
            // kiem tra chieu dai chuoi 
            errArr = Nhacungcap_bus.ktChuoi(Nhacungcap_obj);
            for (int i = 0; i < 6; i++)
            {
                if (errArr[i] > 0)
                {
                    MessageBox.Show(lengthErrMessages[i]);
                    return;
                }
            }

            //ma tu tang 
            switch (flag)
            {
                case "Them":
                    {
                        Nhacungcap_bus.Them(Nhacungcap_obj);
                        break;
                    }
                case "Sua":
                    {
                        Nhacungcap_bus.Sua(Nhacungcap_obj);
                        // phieu nhap ko thay doi vi ma NCC la ma tu tang va ko cho thay doi  
                        break;
                    }
            }

            bindingSource.DataSource = Nhacungcap_bus.LayDanhSachNCC();
            usrDMHang.DongboDulieu();
            dgvNCC.DataSource = bindingSource;
            disableInput();
            flag = "";
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            flag = "Sua";
            enableInput();
            txtTenNCC.Focus();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            // xoa trong bang phu truoc 
            tempValue = grbNCC.Text;
            DialogResult kq = MessageBox.Show("Nếu xóa Nhà cung cấp này thì những mặt hàng được cung cấp của Nhà cung cấp này cũng sẽ bị xóa bỏ. Bạn có chắc chắn xóa ? ", "Chú ý", MessageBoxButtons.YesNo);
            if (kq == DialogResult.Yes)
            {
                Cungcap_bus.XoaTheoMaNCC(tempValue);   // voi y nghia la hang hoa ko con dc cung cap boi NCC nay nua, tuy nhien trong phieu nhap van co the ton tai MaNCC nay
                Nhacungcap_bus.Xoa(Nhacungcap_obj);
                bindingSource.DataSource = Nhacungcap_bus.LayDanhSachNCC();
                usrDMHang.DongboDulieu();
            }
        }

        private void dtGWNCC_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtMaNCC.DataBindings.Add("Text", bindingSource, "MaNCC");
                txtTenNCC.DataBindings.Add("Text", bindingSource, "TenNCC");
                txtDiaChi.DataBindings.Add("Text", bindingSource, "Diachi");
                txtDienthoai.DataBindings.Add("Text", bindingSource, "Dienthoai");
                txtFax.DataBindings.Add("Text", bindingSource, "Fax");
                txtMathue.DataBindings.Add("Text", bindingSource, "Mathue");
                txtSoTk.DataBindings.Add("Text", bindingSource, "SoTk");
            }
            catch (Exception ex)
            { }
        }

     



    }
}
