﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucPhieuXuat
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblPhieuXuat = new System.Windows.Forms.TableLayoutPanel();
            this.grbDanhSachPhieuXuat = new System.Windows.Forms.GroupBox();
            this.dgvDanhSachPhieuXuat = new System.Windows.Forms.DataGridView();
            this.MaPhieu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNVLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayXuat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbChiTietPhieuXuat = new System.Windows.Forms.GroupBox();
            this.dgvChiTietPhieuXuat = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoHDCty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblPhieuXuat.SuspendLayout();
            this.grbDanhSachPhieuXuat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachPhieuXuat)).BeginInit();
            this.grbChiTietPhieuXuat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuXuat)).BeginInit();
            this.SuspendLayout();
            // 
            // tblPhieuXuat
            // 
            this.tblPhieuXuat.ColumnCount = 1;
            this.tblPhieuXuat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblPhieuXuat.Controls.Add(this.grbDanhSachPhieuXuat, 0, 0);
            this.tblPhieuXuat.Controls.Add(this.grbChiTietPhieuXuat, 0, 1);
            this.tblPhieuXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPhieuXuat.Location = new System.Drawing.Point(0, 0);
            this.tblPhieuXuat.Name = "tblPhieuXuat";
            this.tblPhieuXuat.RowCount = 2;
            this.tblPhieuXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblPhieuXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 256F));
            this.tblPhieuXuat.Size = new System.Drawing.Size(800, 522);
            this.tblPhieuXuat.TabIndex = 0;
            // 
            // grbDanhSachPhieuXuat
            // 
            this.grbDanhSachPhieuXuat.Controls.Add(this.dgvDanhSachPhieuXuat);
            this.grbDanhSachPhieuXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhSachPhieuXuat.Location = new System.Drawing.Point(3, 3);
            this.grbDanhSachPhieuXuat.Name = "grbDanhSachPhieuXuat";
            this.grbDanhSachPhieuXuat.Size = new System.Drawing.Size(794, 260);
            this.grbDanhSachPhieuXuat.TabIndex = 0;
            this.grbDanhSachPhieuXuat.TabStop = false;
            this.grbDanhSachPhieuXuat.Text = "Danh sách phiếu xuất";
            // 
            // dgvDanhSachPhieuXuat
            // 
            this.dgvDanhSachPhieuXuat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSachPhieuXuat.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvDanhSachPhieuXuat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachPhieuXuat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPhieu,
            this.MaKho,
            this.MaNVLap,
            this.NgayXuat});
            this.dgvDanhSachPhieuXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSachPhieuXuat.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhSachPhieuXuat.Name = "dgvDanhSachPhieuXuat";
            this.dgvDanhSachPhieuXuat.Size = new System.Drawing.Size(788, 241);
            this.dgvDanhSachPhieuXuat.TabIndex = 0;
            // 
            // MaPhieu
            // 
            this.MaPhieu.HeaderText = "Mã Phiếu";
            this.MaPhieu.Name = "MaPhieu";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã Kho";
            this.MaKho.Name = "MaKho";
            // 
            // MaNVLap
            // 
            this.MaNVLap.HeaderText = "Nhân viên lập phiếu";
            this.MaNVLap.Name = "MaNVLap";
            // 
            // NgayXuat
            // 
            this.NgayXuat.HeaderText = "Ngày xuất";
            this.NgayXuat.Name = "NgayXuat";
            // 
            // grbChiTietPhieuXuat
            // 
            this.grbChiTietPhieuXuat.Controls.Add(this.dgvChiTietPhieuXuat);
            this.grbChiTietPhieuXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietPhieuXuat.Location = new System.Drawing.Point(3, 269);
            this.grbChiTietPhieuXuat.Name = "grbChiTietPhieuXuat";
            this.grbChiTietPhieuXuat.Size = new System.Drawing.Size(794, 250);
            this.grbChiTietPhieuXuat.TabIndex = 1;
            this.grbChiTietPhieuXuat.TabStop = false;
            this.grbChiTietPhieuXuat.Text = "Chi tiết phiếu xuất";
            // 
            // dgvChiTietPhieuXuat
            // 
            this.dgvChiTietPhieuXuat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPhieuXuat.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvChiTietPhieuXuat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPhieuXuat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.DVT,
            this.SoHDCty,
            this.SL});
            this.dgvChiTietPhieuXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChiTietPhieuXuat.Location = new System.Drawing.Point(3, 16);
            this.dgvChiTietPhieuXuat.Name = "dgvChiTietPhieuXuat";
            this.dgvChiTietPhieuXuat.Size = new System.Drawing.Size(788, 231);
            this.dgvChiTietPhieuXuat.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SoHDCty
            // 
            this.SoHDCty.HeaderText = "Số hóa đơn";
            this.SoHDCty.Name = "SoHDCty";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // ucPhieuXuat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.Controls.Add(this.tblPhieuXuat);
            this.MaximumSize = new System.Drawing.Size(800, 522);
            this.Name = "ucPhieuXuat";
            this.Size = new System.Drawing.Size(800, 522);
            this.tblPhieuXuat.ResumeLayout(false);
            this.grbDanhSachPhieuXuat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachPhieuXuat)).EndInit();
            this.grbChiTietPhieuXuat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuXuat)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblPhieuXuat;
        private System.Windows.Forms.GroupBox grbDanhSachPhieuXuat;
        private System.Windows.Forms.GroupBox grbChiTietPhieuXuat;
        private System.Windows.Forms.DataGridView dgvDanhSachPhieuXuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPhieu;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNVLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayXuat;
        private System.Windows.Forms.DataGridView dgvChiTietPhieuXuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoHDCty;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
    }
}
