﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
namespace quan_ly_ban_hang_sieu_thi
{
    public partial class ucQLGiaCa : UserControl
    {
        BindingSource bindingSource = new BindingSource();
        TYSUATGIACA_BUS TysuatGiaca_bus = new TYSUATGIACA_BUS();
        TYSUATGIACA_OBJ TyssuatGiaca_obj = new TYSUATGIACA_OBJ();
        string flag = "";
        public ucQLGiaCa()
        {
            InitializeComponent();
            bindingSource.DataSource = TysuatGiaca_bus.LayDSNhom();
            loadtoCombobox();
            dgvDanhSachTySuat.DataSource = bindingSource;
        }
        
        private  void loadtoCombobox()
        {
            cboMaNhom.DataSource = bindingSource;
            cboMaNhom.ValueMember = "Nhomhang";
            cboMaNhom.DisplayMember = "Tysuat";
        }

        private void disableInput()
        {
            cboMaNhom.Enabled = false;
            txtTySuat.ReadOnly = true;
        }

        private void enableInput()
        {
            cboMaNhom.Enabled = true;
            txtTySuat.ReadOnly = false;
        }

        

        private void dgvDanhSachTySuat_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                cboMaNhom.DataBindings.Add("SelectedValue", bindingSource, "Nhomhang");
                txtTySuat.DataBindings.Add("Text", bindingSource, "Tysuat");
            }
            catch(Exception ex)
            {}

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            flag = "Them";
            cboMaNhom.Text =  TysuatGiaca_bus.LayIDTiepTheo();
            txtTySuat.Focus();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            flag = "Sua";
            txtTySuat.Focus();
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if(txtTySuat.Text != "")
            {
                TyssuatGiaca_obj.Manhom = cboMaNhom.Text; 
                TyssuatGiaca_obj.Tysuat = txtTySuat.Text;
            }
            else
            {
                MessageBox.Show("Bạn phải nhập vào 1 tỷ suất giá cả ", "Chú ý");
                return;
            }
            switch (flag)
            {
                case "Them":
                    {
                        TysuatGiaca_bus.Them(TyssuatGiaca_obj);
                        bindingSource.DataSource = TysuatGiaca_bus.LayDSNhom();
                        usrDMHang.DongboDulieu();
                        break;
                    }
                case "Sua":
                    {
                        DialogResult kq = MessageBox.Show("Bạn có chắc chắn thay đổi Tỷ suất hàng hóa này không. Nếu thay đổi thì tất cả hàng hóa thuộc nhóm hàng này sẽ thay đổi tỷ suất ? ", "Chú ý", MessageBoxButtons.YesNo);
                        if (kq == DialogResult.Yes)
                        {
                            TysuatGiaca_bus.Sua(TyssuatGiaca_obj);
                            // cap nhat lai gia cua hang trong DMhang 
                        }
                        break;
                    }
            }
        }
    }
}
