﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucPhieuChuyen
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.grbChiTietPC = new System.Windows.Forms.GroupBox();
            this.dgvChiTietPC = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DienGiai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.grbDanhSachPhieuChuyen = new System.Windows.Forms.GroupBox();
            this.dgvThongTinPC = new System.Windows.Forms.DataGridView();
            this.MaPC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNVLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.grbChiTietPC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPC)).BeginInit();
            this.panel2.SuspendLayout();
            this.grbDanhSachPhieuChuyen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPC)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.grbChiTietPC);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 250);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 250);
            this.panel1.TabIndex = 0;
            // 
            // grbChiTietPC
            // 
            this.grbChiTietPC.Controls.Add(this.dgvChiTietPC);
            this.grbChiTietPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietPC.Location = new System.Drawing.Point(0, 0);
            this.grbChiTietPC.Name = "grbChiTietPC";
            this.grbChiTietPC.Size = new System.Drawing.Size(800, 250);
            this.grbChiTietPC.TabIndex = 0;
            this.grbChiTietPC.TabStop = false;
            this.grbChiTietPC.Text = "Chi tiết phiếu chuyển";
            // 
            // dgvChiTietPC
            // 
            this.dgvChiTietPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPC.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvChiTietPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.DVT,
            this.SL,
            this.DienGiai});
            this.dgvChiTietPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChiTietPC.Location = new System.Drawing.Point(3, 16);
            this.dgvChiTietPC.Name = "dgvChiTietPC";
            this.dgvChiTietPC.Size = new System.Drawing.Size(794, 231);
            this.dgvChiTietPC.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // DienGiai
            // 
            this.DienGiai.HeaderText = "Diễn giải";
            this.DienGiai.Name = "DienGiai";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grbDanhSachPhieuChuyen);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 244);
            this.panel2.TabIndex = 1;
            // 
            // grbDanhSachPhieuChuyen
            // 
            this.grbDanhSachPhieuChuyen.Controls.Add(this.dgvThongTinPC);
            this.grbDanhSachPhieuChuyen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhSachPhieuChuyen.Location = new System.Drawing.Point(0, 0);
            this.grbDanhSachPhieuChuyen.Name = "grbDanhSachPhieuChuyen";
            this.grbDanhSachPhieuChuyen.Size = new System.Drawing.Size(800, 244);
            this.grbDanhSachPhieuChuyen.TabIndex = 0;
            this.grbDanhSachPhieuChuyen.TabStop = false;
            this.grbDanhSachPhieuChuyen.Text = "Danh sách phiếu chuyển";
            // 
            // dgvThongTinPC
            // 
            this.dgvThongTinPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinPC.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvThongTinPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinPC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPC,
            this.MaKho,
            this.MaNVLap,
            this.NgayLap});
            this.dgvThongTinPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinPC.Location = new System.Drawing.Point(3, 16);
            this.dgvThongTinPC.Name = "dgvThongTinPC";
            this.dgvThongTinPC.Size = new System.Drawing.Size(794, 225);
            this.dgvThongTinPC.TabIndex = 0;
            // 
            // MaPC
            // 
            this.MaPC.HeaderText = "Mã phiếu chuyển";
            this.MaPC.Name = "MaPC";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // MaNVLap
            // 
            this.MaNVLap.HeaderText = "Mã NV lập ";
            this.MaNVLap.Name = "MaNVLap";
            // 
            // NgayLap
            // 
            this.NgayLap.HeaderText = "Ngày lập";
            this.NgayLap.Name = "NgayLap";
            // 
            // ucPhieuChuyen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "ucPhieuChuyen";
            this.Size = new System.Drawing.Size(800, 500);
            this.panel1.ResumeLayout(false);
            this.grbChiTietPC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPC)).EndInit();
            this.panel2.ResumeLayout(false);
            this.grbDanhSachPhieuChuyen.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox grbChiTietPC;
        private System.Windows.Forms.DataGridView dgvChiTietPC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.DataGridViewTextBoxColumn DienGiai;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox grbDanhSachPhieuChuyen;
        private System.Windows.Forms.DataGridView dgvThongTinPC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNVLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayLap;
    }
}
