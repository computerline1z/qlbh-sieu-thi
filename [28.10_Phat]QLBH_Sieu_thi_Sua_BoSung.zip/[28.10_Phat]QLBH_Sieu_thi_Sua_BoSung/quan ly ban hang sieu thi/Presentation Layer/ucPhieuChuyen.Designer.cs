﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucPhieuChuyen
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlpPhieuChuyen = new System.Windows.Forms.TableLayoutPanel();
            this.grbDanhSachPhieuChuyen = new System.Windows.Forms.GroupBox();
            this.dgvThongTinPC = new System.Windows.Forms.DataGridView();
            this.MaPC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNVLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbChiTietPC = new System.Windows.Forms.GroupBox();
            this.dgvChiTietPC = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DienGiai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tlpPhieuChuyen.SuspendLayout();
            this.grbDanhSachPhieuChuyen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPC)).BeginInit();
            this.grbChiTietPC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPC)).BeginInit();
            this.SuspendLayout();
            // 
            // tlpPhieuChuyen
            // 
            this.tlpPhieuChuyen.ColumnCount = 1;
            this.tlpPhieuChuyen.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpPhieuChuyen.Controls.Add(this.grbChiTietPC, 0, 1);
            this.tlpPhieuChuyen.Controls.Add(this.grbDanhSachPhieuChuyen, 0, 0);
            this.tlpPhieuChuyen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPhieuChuyen.Location = new System.Drawing.Point(0, 0);
            this.tlpPhieuChuyen.Name = "tlpPhieuChuyen";
            this.tlpPhieuChuyen.RowCount = 2;
            this.tlpPhieuChuyen.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpPhieuChuyen.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpPhieuChuyen.Size = new System.Drawing.Size(729, 368);
            this.tlpPhieuChuyen.TabIndex = 1;
            // 
            // grbDanhSachPhieuChuyen
            // 
            this.grbDanhSachPhieuChuyen.Controls.Add(this.dgvThongTinPC);
            this.grbDanhSachPhieuChuyen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhSachPhieuChuyen.Location = new System.Drawing.Point(3, 3);
            this.grbDanhSachPhieuChuyen.Name = "grbDanhSachPhieuChuyen";
            this.grbDanhSachPhieuChuyen.Size = new System.Drawing.Size(723, 178);
            this.grbDanhSachPhieuChuyen.TabIndex = 1;
            this.grbDanhSachPhieuChuyen.TabStop = false;
            this.grbDanhSachPhieuChuyen.Text = "Danh sách phiếu chuyển";
            // 
            // dgvThongTinPC
            // 
            this.dgvThongTinPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinPC.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvThongTinPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinPC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPC,
            this.MaKho,
            this.MaNVLap,
            this.NgayLap});
            this.dgvThongTinPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinPC.Location = new System.Drawing.Point(3, 16);
            this.dgvThongTinPC.Name = "dgvThongTinPC";
            this.dgvThongTinPC.Size = new System.Drawing.Size(717, 159);
            this.dgvThongTinPC.TabIndex = 0;
            // 
            // MaPC
            // 
            this.MaPC.HeaderText = "Mã phiếu chuyển";
            this.MaPC.Name = "MaPC";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // MaNVLap
            // 
            this.MaNVLap.HeaderText = "Mã NV lập ";
            this.MaNVLap.Name = "MaNVLap";
            // 
            // NgayLap
            // 
            this.NgayLap.HeaderText = "Ngày lập";
            this.NgayLap.Name = "NgayLap";
            // 
            // grbChiTietPC
            // 
            this.grbChiTietPC.Controls.Add(this.dgvChiTietPC);
            this.grbChiTietPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietPC.Location = new System.Drawing.Point(3, 187);
            this.grbChiTietPC.Name = "grbChiTietPC";
            this.grbChiTietPC.Size = new System.Drawing.Size(723, 178);
            this.grbChiTietPC.TabIndex = 2;
            this.grbChiTietPC.TabStop = false;
            this.grbChiTietPC.Text = "Chi tiết phiếu chuyển";
            // 
            // dgvChiTietPC
            // 
            this.dgvChiTietPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPC.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvChiTietPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.DVT,
            this.SL,
            this.DienGiai});
            this.dgvChiTietPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChiTietPC.Location = new System.Drawing.Point(3, 16);
            this.dgvChiTietPC.Name = "dgvChiTietPC";
            this.dgvChiTietPC.Size = new System.Drawing.Size(717, 159);
            this.dgvChiTietPC.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // DienGiai
            // 
            this.DienGiai.HeaderText = "Diễn giải";
            this.DienGiai.Name = "DienGiai";
            // 
            // ucPhieuChuyen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tlpPhieuChuyen);
            this.Name = "ucPhieuChuyen";
            this.Size = new System.Drawing.Size(729, 368);
            this.tlpPhieuChuyen.ResumeLayout(false);
            this.grbDanhSachPhieuChuyen.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPC)).EndInit();
            this.grbChiTietPC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpPhieuChuyen;
        private System.Windows.Forms.GroupBox grbChiTietPC;
        private System.Windows.Forms.DataGridView dgvChiTietPC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.DataGridViewTextBoxColumn DienGiai;
        private System.Windows.Forms.GroupBox grbDanhSachPhieuChuyen;
        private System.Windows.Forms.DataGridView dgvThongTinPC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNVLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayLap;

    }
}
