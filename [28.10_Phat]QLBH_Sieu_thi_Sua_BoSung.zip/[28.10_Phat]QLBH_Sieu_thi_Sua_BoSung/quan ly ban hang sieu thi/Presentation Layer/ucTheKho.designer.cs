﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucTheKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbpTheKho = new System.Windows.Forms.TableLayoutPanel();
            this.grbChiTietTheKho = new System.Windows.Forms.GroupBox();
            this.dgvTheKho = new System.Windows.Forms.DataGridView();
            this.MaCT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayCT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DienGiai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinTheKho = new System.Windows.Forms.GroupBox();
            this.grbButton = new System.Windows.Forms.GroupBox();
            this.btnXuatBaoCao = new System.Windows.Forms.Button();
            this.btnXem = new System.Windows.Forms.Button();
            this.cboTenHang = new System.Windows.Forms.ComboBox();
            this.cboMaHang = new System.Windows.Forms.ComboBox();
            this.mtxtNgayKT = new System.Windows.Forms.MaskedTextBox();
            this.lblNgayKT = new System.Windows.Forms.Label();
            this.mtxtNgayBD = new System.Windows.Forms.MaskedTextBox();
            this.lblNgayBD = new System.Windows.Forms.Label();
            this.lblTenHang = new System.Windows.Forms.Label();
            this.lblMaHang = new System.Windows.Forms.Label();
            this.tbpTheKho.SuspendLayout();
            this.grbChiTietTheKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheKho)).BeginInit();
            this.grbThongTinTheKho.SuspendLayout();
            this.grbButton.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbpTheKho
            // 
            this.tbpTheKho.ColumnCount = 1;
            this.tbpTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbpTheKho.Controls.Add(this.grbChiTietTheKho, 0, 1);
            this.tbpTheKho.Controls.Add(this.grbThongTinTheKho, 0, 0);
            this.tbpTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbpTheKho.Location = new System.Drawing.Point(0, 0);
            this.tbpTheKho.Name = "tbpTheKho";
            this.tbpTheKho.RowCount = 2;
            this.tbpTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23F));
            this.tbpTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77F));
            this.tbpTheKho.Size = new System.Drawing.Size(800, 500);
            this.tbpTheKho.TabIndex = 0;
            // 
            // grbChiTietTheKho
            // 
            this.grbChiTietTheKho.Controls.Add(this.dgvTheKho);
            this.grbChiTietTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietTheKho.Location = new System.Drawing.Point(3, 118);
            this.grbChiTietTheKho.Name = "grbChiTietTheKho";
            this.grbChiTietTheKho.Size = new System.Drawing.Size(794, 379);
            this.grbChiTietTheKho.TabIndex = 0;
            this.grbChiTietTheKho.TabStop = false;
            this.grbChiTietTheKho.Text = "Chi tiết thẻ kho";
            // 
            // dgvTheKho
            // 
            this.dgvTheKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTheKho.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvTheKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTheKho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaCT,
            this.NgayCT,
            this.MaHang,
            this.MaKho,
            this.DienGiai,
            this.SL});
            this.dgvTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTheKho.Location = new System.Drawing.Point(3, 16);
            this.dgvTheKho.Name = "dgvTheKho";
            this.dgvTheKho.Size = new System.Drawing.Size(788, 360);
            this.dgvTheKho.TabIndex = 0;
            // 
            // MaCT
            // 
            this.MaCT.HeaderText = "Mã chứng từ";
            this.MaCT.Name = "MaCT";
            // 
            // NgayCT
            // 
            this.NgayCT.HeaderText = "Ngày lập chứng từ";
            this.NgayCT.Name = "NgayCT";
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho nhập/xuất";
            this.MaKho.Name = "MaKho";
            // 
            // DienGiai
            // 
            this.DienGiai.HeaderText = "Diễn giải";
            this.DienGiai.Name = "DienGiai";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // grbThongTinTheKho
            // 
            this.grbThongTinTheKho.Controls.Add(this.grbButton);
            this.grbThongTinTheKho.Controls.Add(this.cboTenHang);
            this.grbThongTinTheKho.Controls.Add(this.cboMaHang);
            this.grbThongTinTheKho.Controls.Add(this.mtxtNgayKT);
            this.grbThongTinTheKho.Controls.Add(this.lblNgayKT);
            this.grbThongTinTheKho.Controls.Add(this.mtxtNgayBD);
            this.grbThongTinTheKho.Controls.Add(this.lblNgayBD);
            this.grbThongTinTheKho.Controls.Add(this.lblTenHang);
            this.grbThongTinTheKho.Controls.Add(this.lblMaHang);
            this.grbThongTinTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinTheKho.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinTheKho.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinTheKho.Name = "grbThongTinTheKho";
            this.grbThongTinTheKho.Size = new System.Drawing.Size(794, 109);
            this.grbThongTinTheKho.TabIndex = 1;
            this.grbThongTinTheKho.TabStop = false;
            this.grbThongTinTheKho.Text = "Thông tin thẻ kho";
            // 
            // grbButton
            // 
            this.grbButton.Controls.Add(this.btnXuatBaoCao);
            this.grbButton.Controls.Add(this.btnXem);
            this.grbButton.Location = new System.Drawing.Point(651, 11);
            this.grbButton.Name = "grbButton";
            this.grbButton.Size = new System.Drawing.Size(137, 92);
            this.grbButton.TabIndex = 7;
            this.grbButton.TabStop = false;
            // 
            // btnXuatBaoCao
            // 
            this.btnXuatBaoCao.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatBaoCao.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Notes;
            this.btnXuatBaoCao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXuatBaoCao.Location = new System.Drawing.Point(17, 49);
            this.btnXuatBaoCao.Name = "btnXuatBaoCao";
            this.btnXuatBaoCao.Size = new System.Drawing.Size(114, 37);
            this.btnXuatBaoCao.TabIndex = 7;
            this.btnXuatBaoCao.Text = "&Xuất báo cáo";
            this.btnXuatBaoCao.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXuatBaoCao.UseVisualStyleBackColor = true;
            // 
            // btnXem
            // 
            this.btnXem.Location = new System.Drawing.Point(17, 13);
            this.btnXem.Name = "btnXem";
            this.btnXem.Size = new System.Drawing.Size(114, 34);
            this.btnXem.TabIndex = 5;
            this.btnXem.Text = "&Xem";
            this.btnXem.UseVisualStyleBackColor = true;
            this.btnXem.Click += new System.EventHandler(this.btnXem_Click);
            // 
            // cboTenHang
            // 
            this.cboTenHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTenHang.FormattingEnabled = true;
            this.cboTenHang.Location = new System.Drawing.Point(340, 25);
            this.cboTenHang.Name = "cboTenHang";
            this.cboTenHang.Size = new System.Drawing.Size(121, 23);
            this.cboTenHang.TabIndex = 6;
            // 
            // cboMaHang
            // 
            this.cboMaHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaHang.FormattingEnabled = true;
            this.cboMaHang.Location = new System.Drawing.Point(80, 26);
            this.cboMaHang.Name = "cboMaHang";
            this.cboMaHang.Size = new System.Drawing.Size(125, 23);
            this.cboMaHang.TabIndex = 6;
            // 
            // mtxtNgayKT
            // 
            this.mtxtNgayKT.Location = new System.Drawing.Point(340, 67);
            this.mtxtNgayKT.Mask = "00/00/0000";
            this.mtxtNgayKT.Name = "mtxtNgayKT";
            this.mtxtNgayKT.Size = new System.Drawing.Size(121, 21);
            this.mtxtNgayKT.TabIndex = 4;
            this.mtxtNgayKT.ValidatingType = typeof(System.DateTime);
            // 
            // lblNgayKT
            // 
            this.lblNgayKT.AutoSize = true;
            this.lblNgayKT.Location = new System.Drawing.Point(275, 70);
            this.lblNgayKT.Name = "lblNgayKT";
            this.lblNgayKT.Size = new System.Drawing.Size(60, 15);
            this.lblNgayKT.TabIndex = 3;
            this.lblNgayKT.Text = "Đến ngày";
            // 
            // mtxtNgayBD
            // 
            this.mtxtNgayBD.Location = new System.Drawing.Point(80, 68);
            this.mtxtNgayBD.Mask = "00/00/0000";
            this.mtxtNgayBD.Name = "mtxtNgayBD";
            this.mtxtNgayBD.Size = new System.Drawing.Size(125, 21);
            this.mtxtNgayBD.TabIndex = 4;
            this.mtxtNgayBD.ValidatingType = typeof(System.DateTime);
            // 
            // lblNgayBD
            // 
            this.lblNgayBD.AutoSize = true;
            this.lblNgayBD.Location = new System.Drawing.Point(19, 71);
            this.lblNgayBD.Name = "lblNgayBD";
            this.lblNgayBD.Size = new System.Drawing.Size(53, 15);
            this.lblNgayBD.TabIndex = 3;
            this.lblNgayBD.Text = "Từ ngày";
            // 
            // lblTenHang
            // 
            this.lblTenHang.AutoSize = true;
            this.lblTenHang.Location = new System.Drawing.Point(275, 31);
            this.lblTenHang.Name = "lblTenHang";
            this.lblTenHang.Size = new System.Drawing.Size(59, 15);
            this.lblTenHang.TabIndex = 0;
            this.lblTenHang.Text = "Tên hàng";
            // 
            // lblMaHang
            // 
            this.lblMaHang.AutoSize = true;
            this.lblMaHang.Location = new System.Drawing.Point(19, 28);
            this.lblMaHang.Name = "lblMaHang";
            this.lblMaHang.Size = new System.Drawing.Size(55, 15);
            this.lblMaHang.TabIndex = 0;
            this.lblMaHang.Text = "Mã hàng";
            // 
            // ucTheKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.Controls.Add(this.tbpTheKho);
            this.MaximumSize = new System.Drawing.Size(1024, 768);
            this.Name = "ucTheKho";
            this.Size = new System.Drawing.Size(800, 500);
            this.tbpTheKho.ResumeLayout(false);
            this.grbChiTietTheKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheKho)).EndInit();
            this.grbThongTinTheKho.ResumeLayout(false);
            this.grbThongTinTheKho.PerformLayout();
            this.grbButton.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tbpTheKho;
        private System.Windows.Forms.GroupBox grbChiTietTheKho;
        private System.Windows.Forms.DataGridView dgvTheKho;
        private System.Windows.Forms.GroupBox grbThongTinTheKho;
        private System.Windows.Forms.Button btnXem;
        private System.Windows.Forms.MaskedTextBox mtxtNgayKT;
        private System.Windows.Forms.Label lblNgayKT;
        private System.Windows.Forms.MaskedTextBox mtxtNgayBD;
        private System.Windows.Forms.Label lblNgayBD;
        private System.Windows.Forms.Label lblTenHang;
        private System.Windows.Forms.Label lblMaHang;
        private System.Windows.Forms.ComboBox cboMaHang;
        private System.Windows.Forms.ComboBox cboTenHang;
        private System.Windows.Forms.GroupBox grbButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaCT;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayCT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn DienGiai;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.Button btnXuatBaoCao;
    }
}
