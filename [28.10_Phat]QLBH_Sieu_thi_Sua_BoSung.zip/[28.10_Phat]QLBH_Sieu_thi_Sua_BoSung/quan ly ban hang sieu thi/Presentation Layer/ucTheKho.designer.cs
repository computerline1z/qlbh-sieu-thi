﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucTheKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboMaHang = new System.Windows.Forms.ComboBox();
            this.lblNgayBD = new System.Windows.Forms.Label();
            this.mtxtNgayBD = new System.Windows.Forms.MaskedTextBox();
            this.tlpTheKho = new System.Windows.Forms.TableLayoutPanel();
            this.tbplThongTinTheKho = new System.Windows.Forms.TableLayoutPanel();
            this.pnlDanhMucHang = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.grbChiTietTheKho = new System.Windows.Forms.GroupBox();
            this.dgvTheKho = new System.Windows.Forms.DataGridView();
            this.MaCT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayCT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DienGiai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinTheKho = new System.Windows.Forms.GroupBox();
            this.tblTheKho = new System.Windows.Forms.TableLayoutPanel();
            this.pnlTheKho1 = new System.Windows.Forms.Panel();
            this.lblMaHang = new System.Windows.Forms.Label();
            this.pnlTheKho2 = new System.Windows.Forms.Panel();
            this.cboTenHang = new System.Windows.Forms.ComboBox();
            this.mtxtNgayKT = new System.Windows.Forms.MaskedTextBox();
            this.lblNgayKT = new System.Windows.Forms.Label();
            this.lblTenHang = new System.Windows.Forms.Label();
            this.pnlTheKho3 = new System.Windows.Forms.Panel();
            this.btnXuatBaoCao = new System.Windows.Forms.Button();
            this.btnXem = new System.Windows.Forms.Button();
            this.tlpTheKho.SuspendLayout();
            this.tbplThongTinTheKho.SuspendLayout();
            this.pnlDanhMucHang.SuspendLayout();
            this.grbChiTietTheKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheKho)).BeginInit();
            this.grbThongTinTheKho.SuspendLayout();
            this.tblTheKho.SuspendLayout();
            this.pnlTheKho1.SuspendLayout();
            this.pnlTheKho2.SuspendLayout();
            this.pnlTheKho3.SuspendLayout();
            this.SuspendLayout();
            // 
            // cboMaHang
            // 
            this.cboMaHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboMaHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaHang.FormattingEnabled = true;
            this.cboMaHang.Location = new System.Drawing.Point(78, 12);
            this.cboMaHang.Name = "cboMaHang";
            this.cboMaHang.Size = new System.Drawing.Size(154, 23);
            this.cboMaHang.TabIndex = 10;
            // 
            // lblNgayBD
            // 
            this.lblNgayBD.AutoSize = true;
            this.lblNgayBD.Location = new System.Drawing.Point(17, 49);
            this.lblNgayBD.Name = "lblNgayBD";
            this.lblNgayBD.Size = new System.Drawing.Size(53, 15);
            this.lblNgayBD.TabIndex = 8;
            this.lblNgayBD.Text = "Từ ngày";
            // 
            // mtxtNgayBD
            // 
            this.mtxtNgayBD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtNgayBD.Location = new System.Drawing.Point(78, 45);
            this.mtxtNgayBD.Mask = "00/00/0000";
            this.mtxtNgayBD.Name = "mtxtNgayBD";
            this.mtxtNgayBD.Size = new System.Drawing.Size(154, 21);
            this.mtxtNgayBD.TabIndex = 9;
            this.mtxtNgayBD.ValidatingType = typeof(System.DateTime);
            // 
            // tlpTheKho
            // 
            this.tlpTheKho.ColumnCount = 1;
            this.tlpTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpTheKho.Controls.Add(this.tbplThongTinTheKho, 0, 1);
            this.tlpTheKho.Controls.Add(this.grbThongTinTheKho, 0, 0);
            this.tlpTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpTheKho.Location = new System.Drawing.Point(0, 0);
            this.tlpTheKho.Name = "tlpTheKho";
            this.tlpTheKho.RowCount = 2;
            this.tlpTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tlpTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpTheKho.Size = new System.Drawing.Size(825, 500);
            this.tlpTheKho.TabIndex = 1;
            // 
            // tbplThongTinTheKho
            // 
            this.tbplThongTinTheKho.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tbplThongTinTheKho.ColumnCount = 1;
            this.tbplThongTinTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplThongTinTheKho.Controls.Add(this.pnlDanhMucHang, 0, 0);
            this.tbplThongTinTheKho.Controls.Add(this.grbChiTietTheKho, 0, 0);
            this.tbplThongTinTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplThongTinTheKho.Location = new System.Drawing.Point(3, 126);
            this.tbplThongTinTheKho.Name = "tbplThongTinTheKho";
            this.tbplThongTinTheKho.RowCount = 1;
            this.tbplThongTinTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplThongTinTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tbplThongTinTheKho.Size = new System.Drawing.Size(819, 371);
            this.tbplThongTinTheKho.TabIndex = 2;
            // 
            // pnlDanhMucHang
            // 
            this.pnlDanhMucHang.Controls.Add(this.btnLuu);
            this.pnlDanhMucHang.Controls.Add(this.btnXoa);
            this.pnlDanhMucHang.Controls.Add(this.btnThem);
            this.pnlDanhMucHang.Controls.Add(this.btnSua);
            this.pnlDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDanhMucHang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlDanhMucHang.Location = new System.Drawing.Point(6, 333);
            this.pnlDanhMucHang.Name = "pnlDanhMucHang";
            this.pnlDanhMucHang.Size = new System.Drawing.Size(807, 32);
            this.pnlDanhMucHang.TabIndex = 5;
            // 
            // btnLuu
            // 
            this.btnLuu.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(711, 4);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 3;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(637, 4);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 2;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(487, 4);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(562, 4);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 1;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // grbChiTietTheKho
            // 
            this.grbChiTietTheKho.Controls.Add(this.dgvTheKho);
            this.grbChiTietTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietTheKho.Location = new System.Drawing.Point(6, 6);
            this.grbChiTietTheKho.Name = "grbChiTietTheKho";
            this.grbChiTietTheKho.Size = new System.Drawing.Size(807, 318);
            this.grbChiTietTheKho.TabIndex = 4;
            this.grbChiTietTheKho.TabStop = false;
            this.grbChiTietTheKho.Text = "Chi tiết thẻ kho";
            // 
            // dgvTheKho
            // 
            this.dgvTheKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTheKho.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvTheKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTheKho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaCT,
            this.NgayCT,
            this.MaHang,
            this.MaKho,
            this.DienGiai,
            this.SL});
            this.dgvTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTheKho.Location = new System.Drawing.Point(3, 16);
            this.dgvTheKho.Name = "dgvTheKho";
            this.dgvTheKho.Size = new System.Drawing.Size(801, 299);
            this.dgvTheKho.TabIndex = 0;
            // 
            // MaCT
            // 
            this.MaCT.HeaderText = "Mã chứng từ";
            this.MaCT.Name = "MaCT";
            // 
            // NgayCT
            // 
            this.NgayCT.HeaderText = "Ngày lập chứng từ";
            this.NgayCT.Name = "NgayCT";
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho nhập/xuất";
            this.MaKho.Name = "MaKho";
            // 
            // DienGiai
            // 
            this.DienGiai.HeaderText = "Diễn giải";
            this.DienGiai.Name = "DienGiai";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // grbThongTinTheKho
            // 
            this.grbThongTinTheKho.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.grbThongTinTheKho.Controls.Add(this.tblTheKho);
            this.grbThongTinTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinTheKho.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinTheKho.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinTheKho.Name = "grbThongTinTheKho";
            this.grbThongTinTheKho.Size = new System.Drawing.Size(819, 117);
            this.grbThongTinTheKho.TabIndex = 1;
            this.grbThongTinTheKho.TabStop = false;
            this.grbThongTinTheKho.Text = "Thông tin thẻ kho";
            // 
            // tblTheKho
            // 
            this.tblTheKho.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tblTheKho.ColumnCount = 3;
            this.tblTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.26039F));
            this.tblTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.73961F));
            this.tblTheKho.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 217F));
            this.tblTheKho.Controls.Add(this.pnlTheKho1, 0, 0);
            this.tblTheKho.Controls.Add(this.pnlTheKho2, 1, 0);
            this.tblTheKho.Controls.Add(this.pnlTheKho3, 2, 0);
            this.tblTheKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblTheKho.Location = new System.Drawing.Point(3, 17);
            this.tblTheKho.Name = "tblTheKho";
            this.tblTheKho.RowCount = 1;
            this.tblTheKho.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblTheKho.Size = new System.Drawing.Size(813, 97);
            this.tblTheKho.TabIndex = 0;
            // 
            // pnlTheKho1
            // 
            this.pnlTheKho1.Controls.Add(this.cboMaHang);
            this.pnlTheKho1.Controls.Add(this.mtxtNgayBD);
            this.pnlTheKho1.Controls.Add(this.lblNgayBD);
            this.pnlTheKho1.Controls.Add(this.lblMaHang);
            this.pnlTheKho1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTheKho1.Location = new System.Drawing.Point(6, 6);
            this.pnlTheKho1.Name = "pnlTheKho1";
            this.pnlTheKho1.Size = new System.Drawing.Size(264, 85);
            this.pnlTheKho1.TabIndex = 0;
            // 
            // lblMaHang
            // 
            this.lblMaHang.AutoSize = true;
            this.lblMaHang.Location = new System.Drawing.Point(17, 15);
            this.lblMaHang.Name = "lblMaHang";
            this.lblMaHang.Size = new System.Drawing.Size(55, 15);
            this.lblMaHang.TabIndex = 7;
            this.lblMaHang.Text = "Mã hàng";
            // 
            // pnlTheKho2
            // 
            this.pnlTheKho2.Controls.Add(this.cboTenHang);
            this.pnlTheKho2.Controls.Add(this.mtxtNgayKT);
            this.pnlTheKho2.Controls.Add(this.lblNgayKT);
            this.pnlTheKho2.Controls.Add(this.lblTenHang);
            this.pnlTheKho2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTheKho2.Location = new System.Drawing.Point(279, 6);
            this.pnlTheKho2.Name = "pnlTheKho2";
            this.pnlTheKho2.Size = new System.Drawing.Size(307, 85);
            this.pnlTheKho2.TabIndex = 0;
            // 
            // cboTenHang
            // 
            this.cboTenHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboTenHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTenHang.FormattingEnabled = true;
            this.cboTenHang.Location = new System.Drawing.Point(90, 11);
            this.cboTenHang.Name = "cboTenHang";
            this.cboTenHang.Size = new System.Drawing.Size(169, 23);
            this.cboTenHang.TabIndex = 10;
            // 
            // mtxtNgayKT
            // 
            this.mtxtNgayKT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtNgayKT.Location = new System.Drawing.Point(90, 42);
            this.mtxtNgayKT.Mask = "00/00/0000";
            this.mtxtNgayKT.Name = "mtxtNgayKT";
            this.mtxtNgayKT.Size = new System.Drawing.Size(169, 21);
            this.mtxtNgayKT.TabIndex = 9;
            this.mtxtNgayKT.ValidatingType = typeof(System.DateTime);
            // 
            // lblNgayKT
            // 
            this.lblNgayKT.AutoSize = true;
            this.lblNgayKT.Location = new System.Drawing.Point(25, 46);
            this.lblNgayKT.Name = "lblNgayKT";
            this.lblNgayKT.Size = new System.Drawing.Size(60, 15);
            this.lblNgayKT.TabIndex = 8;
            this.lblNgayKT.Text = "Đến ngày";
            // 
            // lblTenHang
            // 
            this.lblTenHang.AutoSize = true;
            this.lblTenHang.Location = new System.Drawing.Point(25, 18);
            this.lblTenHang.Name = "lblTenHang";
            this.lblTenHang.Size = new System.Drawing.Size(59, 15);
            this.lblTenHang.TabIndex = 7;
            this.lblTenHang.Text = "Tên hàng";
            // 
            // pnlTheKho3
            // 
            this.pnlTheKho3.Controls.Add(this.btnXuatBaoCao);
            this.pnlTheKho3.Controls.Add(this.btnXem);
            this.pnlTheKho3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTheKho3.Location = new System.Drawing.Point(595, 6);
            this.pnlTheKho3.Name = "pnlTheKho3";
            this.pnlTheKho3.Size = new System.Drawing.Size(212, 85);
            this.pnlTheKho3.TabIndex = 0;
            // 
            // btnXuatBaoCao
            // 
            this.btnXuatBaoCao.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatBaoCao.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.Notes;
            this.btnXuatBaoCao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXuatBaoCao.Location = new System.Drawing.Point(20, 43);
            this.btnXuatBaoCao.Name = "btnXuatBaoCao";
            this.btnXuatBaoCao.Size = new System.Drawing.Size(114, 37);
            this.btnXuatBaoCao.TabIndex = 9;
            this.btnXuatBaoCao.Text = "&Xuất báo cáo";
            this.btnXuatBaoCao.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXuatBaoCao.UseVisualStyleBackColor = true;
            // 
            // btnXem
            // 
            this.btnXem.Location = new System.Drawing.Point(20, 7);
            this.btnXem.Name = "btnXem";
            this.btnXem.Size = new System.Drawing.Size(114, 34);
            this.btnXem.TabIndex = 8;
            this.btnXem.Text = "&Xem";
            this.btnXem.UseVisualStyleBackColor = true;
            // 
            // ucTheKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.Controls.Add(this.tlpTheKho);
            this.MaximumSize = new System.Drawing.Size(1024, 768);
            this.Name = "ucTheKho";
            this.Size = new System.Drawing.Size(825, 500);
            this.tlpTheKho.ResumeLayout(false);
            this.tbplThongTinTheKho.ResumeLayout(false);
            this.pnlDanhMucHang.ResumeLayout(false);
            this.grbChiTietTheKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheKho)).EndInit();
            this.grbThongTinTheKho.ResumeLayout(false);
            this.tblTheKho.ResumeLayout(false);
            this.pnlTheKho1.ResumeLayout(false);
            this.pnlTheKho1.PerformLayout();
            this.pnlTheKho2.ResumeLayout(false);
            this.pnlTheKho2.PerformLayout();
            this.pnlTheKho3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cboMaHang;
        private System.Windows.Forms.Label lblNgayBD;
        private System.Windows.Forms.MaskedTextBox mtxtNgayBD;
        private System.Windows.Forms.TableLayoutPanel tlpTheKho;
        private System.Windows.Forms.TableLayoutPanel tbplThongTinTheKho;
        private System.Windows.Forms.Panel pnlDanhMucHang;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.GroupBox grbChiTietTheKho;
        private System.Windows.Forms.DataGridView dgvTheKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaCT;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayCT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn DienGiai;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.GroupBox grbThongTinTheKho;
        private System.Windows.Forms.TableLayoutPanel tblTheKho;
        private System.Windows.Forms.Panel pnlTheKho1;
        private System.Windows.Forms.Label lblMaHang;
        private System.Windows.Forms.Panel pnlTheKho2;
        private System.Windows.Forms.ComboBox cboTenHang;
        private System.Windows.Forms.MaskedTextBox mtxtNgayKT;
        private System.Windows.Forms.Label lblNgayKT;
        private System.Windows.Forms.Label lblTenHang;
        private System.Windows.Forms.Panel pnlTheKho3;
        private System.Windows.Forms.Button btnXuatBaoCao;
        private System.Windows.Forms.Button btnXem;

    }
}
