﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
namespace quan_ly_ban_hang_sieu_thi
{
    public partial class ucLoaiHang : UserControl
    {
        BindingSource bindingSource = new BindingSource();
        LOAIHANG_BUS Loaihang_bus = new LOAIHANG_BUS();
        LOAIHANG_OBJ Loaihang_obj = new LOAIHANG_OBJ();
        DMHANGHOA_BUS DMhang_bus = new DMHANGHOA_BUS();
        string tempValue = ""; // gia tri luu tam 
        string flag = "";
        public ucLoaiHang()
        {
            InitializeComponent();
            bindingSource.DataSource = Loaihang_bus.LayLoaiHang();
            dgvDanhMucLoaiHang.DataSource = bindingSource;
            disableInput();
        }

        public void disableInput()
        {
            txtMaLoai.ReadOnly = true;
            txtTenLoai.ReadOnly = true;
        }
        public void enableInput()
        {
            txtMaLoai.ReadOnly = false;
            txtTenLoai.ReadOnly = false;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            flag = "Them";
            enableInput();
            txtMaLoai.Focus();

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            flag = "Sua";
            enableInput();
            txtMaLoai.Focus();
            tempValue = txtMaLoai.Text;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            Loaihang_obj.Maloai = txtMaLoai.Text;
            Loaihang_obj.Tenloai = txtTenLoai.Text;

            string[] errMessages = new string[2];
            int[] arrErrs = new int[2];
            errMessages[0] = "Mã loại không được rỗng ";
            errMessages[1] = "Tên loại không được rỗng ";

            arrErrs = Loaihang_bus.ktRong(Loaihang_obj);
            for (int i = 0; i < 2; i++)
            {
                if (arrErrs[i] > 0)
                    MessageBox.Show(errMessages[i]);
            }

            switch (flag)
            {

                case "Them":
                    {
                        Loaihang_bus.Them(Loaihang_obj);
                        bindingSource.DataSource = Loaihang_bus.LayLoaiHang();
                        usrDMHang.DongboDulieu();
                        break;
                    }

                case "Sua":
                    {   // kiem tra loai hang da ton tai trong danh muc hang thi tien hanh sua loai hang

                        //if (Loaihang_bus.ktLoaihangTonTaiTrongDanhMucHang(Loaihang_obj.Maloai))
                        // { 
                        // chuyen tam thoi ma loai DMHANG sang X

                        DMhang_bus.excuteNonQuery(string.Format("update DMHang set loai='{0}' where loai = '{1}'", "X", tempValue));
                        // sua maloai 
                        Loaihang_bus.Sua(Loaihang_obj, tempValue);
                        // cap nhat lai 
                        DMhang_bus.excuteNonQuery(string.Format("update DMHang set loai='{0}' where loai='{1}'", Loaihang_obj.Maloai, "X"));
                        bindingSource.DataSource = Loaihang_bus.LayLoaiHang();
                        usrDMHang.DongboDulieu();
                        //}
                        break;
                    }

            }
            flag = "";
            disableInput();

        }

        private void dtGWDanhMucLoaiHang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtMaLoai.DataBindings.Add("Text", bindingSource, "loai");
                txtTenLoai.DataBindings.Add("Text", bindingSource, "tenloai");
            }
            catch (Exception ex)
            { }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            tempValue = txtMaLoai.Text;
            if (Loaihang_bus.ktLoaihangTonTaiTrongDanhMucHang(tempValue))
            {
                DialogResult kq = MessageBox.Show("Loại hàng này đã được dùng trong Danh mục hàng hóa. Nếu xóa thì Danh mục hàng hóa liên quan đến loại hàng này cũng sẽ bị xóa ", "Chú ý", MessageBoxButtons.YesNo);
                if (kq == DialogResult.Yes)
                {
                    DMhang_bus.XoaTheoLoaiHang(tempValue);
                    Loaihang_bus.Xoa(tempValue);
                    bindingSource.DataSource = Loaihang_bus.LayLoaiHang();
                    usrDMHang.DongboDulieu();
                }

            }
        }


     
  
      


    }
}
