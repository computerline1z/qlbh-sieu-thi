﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using quan_ly_ban_hang_sieu_thi.Presentation_Layer;

namespace quan_ly_ban_hang_sieu_thi
{
    public partial class ucDonDatHang : UserControl
    {
        public ucDonDatHang()
        {
            InitializeComponent();
        }

        private void btnThemNCC_Click(object sender, EventArgs e)
        {
            TagForm newForm = new TagForm();
            newForm.Text = "ĐƠN ĐẶT HÀNG";
            ucNCC NCC = new ucNCC();
            newForm.Controls.Add(NCC);
            newForm.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
