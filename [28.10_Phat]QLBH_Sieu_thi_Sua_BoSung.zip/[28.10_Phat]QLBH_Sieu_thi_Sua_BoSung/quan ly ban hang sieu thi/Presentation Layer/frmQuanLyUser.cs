﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using quan_ly_ban_hang_sieu_thi.Presentation_Layer;
using quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer;

namespace quan_ly_ban_hang_sieu_thi.Presentation_Layer
{
    public partial class frmQuanLyUser : Form
    {
        QUANLYUSER_BUS QuanLyUser_Bus = new QUANLYUSER_BUS();
        public frmQuanLyUser()
        {
            InitializeComponent();
        }
    }
}
