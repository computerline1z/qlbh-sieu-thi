﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucHoaDonLe
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbChiTietHD = new System.Windows.Forms.GroupBox();
            this.dvgChiTietHD = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ThanhTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbDanhSachHD = new System.Windows.Forms.GroupBox();
            this.dgvDanhSachHD = new System.Windows.Forms.DataGridView();
            this.MaHD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NguoiLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongGT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbplHoaDonLe = new System.Windows.Forms.TableLayoutPanel();
            this.grbChiTietHD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgChiTietHD)).BeginInit();
            this.grbDanhSachHD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachHD)).BeginInit();
            this.tbplHoaDonLe.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbChiTietHD
            // 
            this.grbChiTietHD.Controls.Add(this.dvgChiTietHD);
            this.grbChiTietHD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietHD.Location = new System.Drawing.Point(3, 221);
            this.grbChiTietHD.Name = "grbChiTietHD";
            this.grbChiTietHD.Size = new System.Drawing.Size(778, 212);
            this.grbChiTietHD.TabIndex = 0;
            this.grbChiTietHD.TabStop = false;
            this.grbChiTietHD.Text = "Chi tiết hóa đơn";
            // 
            // dvgChiTietHD
            // 
            this.dvgChiTietHD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dvgChiTietHD.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dvgChiTietHD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgChiTietHD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.SoLuong,
            this.DVT,
            this.DonGia,
            this.ThanhTien});
            this.dvgChiTietHD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dvgChiTietHD.Location = new System.Drawing.Point(3, 16);
            this.dvgChiTietHD.Name = "dvgChiTietHD";
            this.dvgChiTietHD.Size = new System.Drawing.Size(772, 193);
            this.dvgChiTietHD.TabIndex = 1;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên Hàng";
            this.TenHang.Name = "TenHang";
            // 
            // SoLuong
            // 
            this.SoLuong.HeaderText = "Số Lượng";
            this.SoLuong.Name = "SoLuong";
            // 
            // DVT
            // 
            this.DVT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Đơn Giá";
            this.DonGia.Name = "DonGia";
            // 
            // ThanhTien
            // 
            this.ThanhTien.HeaderText = "Thành tiền";
            this.ThanhTien.Name = "ThanhTien";
            // 
            // grbDanhSachHD
            // 
            this.grbDanhSachHD.Controls.Add(this.dgvDanhSachHD);
            this.grbDanhSachHD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhSachHD.Location = new System.Drawing.Point(3, 3);
            this.grbDanhSachHD.Name = "grbDanhSachHD";
            this.grbDanhSachHD.Size = new System.Drawing.Size(778, 212);
            this.grbDanhSachHD.TabIndex = 0;
            this.grbDanhSachHD.TabStop = false;
            this.grbDanhSachHD.Text = "Danh sách hóa đơn";
            this.grbDanhSachHD.Enter += new System.EventHandler(this.grbDanhSachHD_Enter);
            // 
            // dgvDanhSachHD
            // 
            this.dgvDanhSachHD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSachHD.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvDanhSachHD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachHD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHD,
            this.NgayLap,
            this.NguoiLap,
            this.TongGT});
            this.dgvDanhSachHD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSachHD.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhSachHD.Name = "dgvDanhSachHD";
            this.dgvDanhSachHD.Size = new System.Drawing.Size(772, 193);
            this.dgvDanhSachHD.TabIndex = 0;
            // 
            // MaHD
            // 
            this.MaHD.HeaderText = "Mã HĐ";
            this.MaHD.Name = "MaHD";
            // 
            // NgayLap
            // 
            this.NgayLap.HeaderText = "Ngày lập";
            this.NgayLap.Name = "NgayLap";
            // 
            // NguoiLap
            // 
            this.NguoiLap.HeaderText = "Người Lập HĐ";
            this.NguoiLap.Name = "NguoiLap";
            // 
            // TongGT
            // 
            this.TongGT.HeaderText = "Tổng giá trị";
            this.TongGT.Name = "TongGT";
            // 
            // tbplHoaDonLe
            // 
            this.tbplHoaDonLe.ColumnCount = 1;
            this.tbplHoaDonLe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplHoaDonLe.Controls.Add(this.grbChiTietHD, 0, 1);
            this.tbplHoaDonLe.Controls.Add(this.grbDanhSachHD, 0, 0);
            this.tbplHoaDonLe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplHoaDonLe.Location = new System.Drawing.Point(0, 0);
            this.tbplHoaDonLe.Name = "tbplHoaDonLe";
            this.tbplHoaDonLe.RowCount = 2;
            this.tbplHoaDonLe.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbplHoaDonLe.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbplHoaDonLe.Size = new System.Drawing.Size(784, 436);
            this.tbplHoaDonLe.TabIndex = 3;
            // 
            // ucHoaDonLe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbplHoaDonLe);
            this.Name = "ucHoaDonLe";
            this.Size = new System.Drawing.Size(784, 436);
            this.grbChiTietHD.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dvgChiTietHD)).EndInit();
            this.grbDanhSachHD.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachHD)).EndInit();
            this.tbplHoaDonLe.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbChiTietHD;
        private System.Windows.Forms.GroupBox grbDanhSachHD;
        private System.Windows.Forms.DataGridView dgvDanhSachHD;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHD;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn NguoiLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongGT;
        private System.Windows.Forms.DataGridView dvgChiTietHD;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn ThanhTien;
        private System.Windows.Forms.TableLayoutPanel tbplHoaDonLe;
    }
}
