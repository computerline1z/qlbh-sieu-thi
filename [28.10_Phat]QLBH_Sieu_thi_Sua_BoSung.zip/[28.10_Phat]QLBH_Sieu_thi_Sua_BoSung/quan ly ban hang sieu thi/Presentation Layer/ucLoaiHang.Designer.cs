﻿namespace quan_ly_ban_hang_sieu_thi
{
    partial class ucLoaiHang
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbplLoaiHang = new System.Windows.Forms.TableLayoutPanel();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.dgvDanhMucLoaiHang = new System.Windows.Forms.DataGridView();
            this.MaLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tlpLoaiHang = new System.Windows.Forms.TableLayoutPanel();
            this.pnlMaLoai = new System.Windows.Forms.Panel();
            this.txtMaLoai = new System.Windows.Forms.TextBox();
            this.lblMaLoai = new System.Windows.Forms.Label();
            this.pnlTenLoai = new System.Windows.Forms.Panel();
            this.txtTenLoai = new System.Windows.Forms.TextBox();
            this.lblTenLoai = new System.Windows.Forms.Label();
            this.tbplLoaiHang.SuspendLayout();
            this.pnlButton.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucLoaiHang)).BeginInit();
            this.tlpLoaiHang.SuspendLayout();
            this.pnlMaLoai.SuspendLayout();
            this.pnlTenLoai.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbplLoaiHang
            // 
            this.tbplLoaiHang.ColumnCount = 1;
            this.tbplLoaiHang.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplLoaiHang.Controls.Add(this.pnlButton, 0, 2);
            this.tbplLoaiHang.Controls.Add(this.dgvDanhMucLoaiHang, 0, 1);
            this.tbplLoaiHang.Controls.Add(this.tlpLoaiHang, 0, 0);
            this.tbplLoaiHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplLoaiHang.Location = new System.Drawing.Point(0, 0);
            this.tbplLoaiHang.Name = "tbplLoaiHang";
            this.tbplLoaiHang.RowCount = 2;
            this.tbplLoaiHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 94F));
            this.tbplLoaiHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplLoaiHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tbplLoaiHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbplLoaiHang.Size = new System.Drawing.Size(714, 378);
            this.tbplLoaiHang.TabIndex = 2;
            // 
            // pnlButton
            // 
            this.pnlButton.Controls.Add(this.btnLuu);
            this.pnlButton.Controls.Add(this.btnXoa);
            this.pnlButton.Controls.Add(this.btnThem);
            this.pnlButton.Controls.Add(this.btnSua);
            this.pnlButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButton.Location = new System.Drawing.Point(3, 339);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(708, 36);
            this.pnlButton.TabIndex = 9;
            // 
            // btnLuu
            // 
            this.btnLuu.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(530, 7);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 18;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(456, 7);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 19;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(306, 7);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 16;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(381, 7);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 17;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // dgvDanhMucLoaiHang
            // 
            this.dgvDanhMucLoaiHang.AllowUserToAddRows = false;
            this.dgvDanhMucLoaiHang.AllowUserToDeleteRows = false;
            this.dgvDanhMucLoaiHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhMucLoaiHang.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvDanhMucLoaiHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhMucLoaiHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaLoai,
            this.TenLoai});
            this.dgvDanhMucLoaiHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhMucLoaiHang.Location = new System.Drawing.Point(3, 97);
            this.dgvDanhMucLoaiHang.MultiSelect = false;
            this.dgvDanhMucLoaiHang.Name = "dgvDanhMucLoaiHang";
            this.dgvDanhMucLoaiHang.ReadOnly = true;
            this.dgvDanhMucLoaiHang.RowTemplate.Height = 24;
            this.dgvDanhMucLoaiHang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDanhMucLoaiHang.Size = new System.Drawing.Size(708, 236);
            this.dgvDanhMucLoaiHang.TabIndex = 6;
            // 
            // MaLoai
            // 
            this.MaLoai.DataPropertyName = "loai";
            this.MaLoai.FillWeight = 50.76142F;
            this.MaLoai.HeaderText = "Mã loại";
            this.MaLoai.Name = "MaLoai";
            this.MaLoai.ReadOnly = true;
            // 
            // TenLoai
            // 
            this.TenLoai.DataPropertyName = "tenloai";
            this.TenLoai.FillWeight = 149.2386F;
            this.TenLoai.HeaderText = "Tên loại";
            this.TenLoai.Name = "TenLoai";
            this.TenLoai.ReadOnly = true;
            // 
            // tlpLoaiHang
            // 
            this.tlpLoaiHang.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpLoaiHang.ColumnCount = 2;
            this.tlpLoaiHang.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.70281F));
            this.tlpLoaiHang.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.29719F));
            this.tlpLoaiHang.Controls.Add(this.pnlMaLoai, 0, 0);
            this.tlpLoaiHang.Controls.Add(this.pnlTenLoai, 1, 0);
            this.tlpLoaiHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpLoaiHang.Location = new System.Drawing.Point(3, 3);
            this.tlpLoaiHang.Name = "tlpLoaiHang";
            this.tlpLoaiHang.RowCount = 1;
            this.tlpLoaiHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpLoaiHang.Size = new System.Drawing.Size(708, 88);
            this.tlpLoaiHang.TabIndex = 8;
            // 
            // pnlMaLoai
            // 
            this.pnlMaLoai.Controls.Add(this.txtMaLoai);
            this.pnlMaLoai.Controls.Add(this.lblMaLoai);
            this.pnlMaLoai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMaLoai.Location = new System.Drawing.Point(6, 6);
            this.pnlMaLoai.Name = "pnlMaLoai";
            this.pnlMaLoai.Size = new System.Drawing.Size(173, 76);
            this.pnlMaLoai.TabIndex = 0;
            // 
            // txtMaLoai
            // 
            this.txtMaLoai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMaLoai.Location = new System.Drawing.Point(17, 35);
            this.txtMaLoai.Name = "txtMaLoai";
            this.txtMaLoai.Size = new System.Drawing.Size(144, 20);
            this.txtMaLoai.TabIndex = 3;
            // 
            // lblMaLoai
            // 
            this.lblMaLoai.AutoSize = true;
            this.lblMaLoai.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaLoai.Location = new System.Drawing.Point(15, 12);
            this.lblMaLoai.Name = "lblMaLoai";
            this.lblMaLoai.Size = new System.Drawing.Size(51, 15);
            this.lblMaLoai.TabIndex = 2;
            this.lblMaLoai.Text = "Mã Loại";
            // 
            // pnlTenLoai
            // 
            this.pnlTenLoai.Controls.Add(this.txtTenLoai);
            this.pnlTenLoai.Controls.Add(this.lblTenLoai);
            this.pnlTenLoai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTenLoai.Location = new System.Drawing.Point(188, 6);
            this.pnlTenLoai.Name = "pnlTenLoai";
            this.pnlTenLoai.Size = new System.Drawing.Size(514, 76);
            this.pnlTenLoai.TabIndex = 1;
            // 
            // txtTenLoai
            // 
            this.txtTenLoai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenLoai.Location = new System.Drawing.Point(13, 35);
            this.txtTenLoai.Name = "txtTenLoai";
            this.txtTenLoai.Size = new System.Drawing.Size(394, 20);
            this.txtTenLoai.TabIndex = 3;
            // 
            // lblTenLoai
            // 
            this.lblTenLoai.AutoSize = true;
            this.lblTenLoai.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenLoai.Location = new System.Drawing.Point(10, 12);
            this.lblTenLoai.Name = "lblTenLoai";
            this.lblTenLoai.Size = new System.Drawing.Size(55, 15);
            this.lblTenLoai.TabIndex = 2;
            this.lblTenLoai.Text = "Tên Loại";
            // 
            // ucLoaiHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbplLoaiHang);
            this.Name = "ucLoaiHang";
            this.Size = new System.Drawing.Size(714, 378);
            this.tbplLoaiHang.ResumeLayout(false);
            this.pnlButton.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucLoaiHang)).EndInit();
            this.tlpLoaiHang.ResumeLayout(false);
            this.pnlMaLoai.ResumeLayout(false);
            this.pnlMaLoai.PerformLayout();
            this.pnlTenLoai.ResumeLayout(false);
            this.pnlTenLoai.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tbplLoaiHang;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.DataGridView dgvDanhMucLoaiHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenLoai;
        private System.Windows.Forms.TableLayoutPanel tlpLoaiHang;
        private System.Windows.Forms.Panel pnlMaLoai;
        private System.Windows.Forms.TextBox txtMaLoai;
        private System.Windows.Forms.Label lblMaLoai;
        private System.Windows.Forms.Panel pnlTenLoai;
        private System.Windows.Forms.TextBox txtTenLoai;
        private System.Windows.Forms.Label lblTenLoai;

    }
}
