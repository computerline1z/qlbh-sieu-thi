﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class KHUYENMAI_BUS:DataProvider
    {
        string sql = "";
        DataTable tempTable;

        public DataTable LayDSKM()
        {
            tempTable = new DataTable();
            openConnection();
            sql = "select LoaiKM, Diengiai from Khuyenmai";
            tempTable = this.getDataTable(sql);
            closeConnection();
            return tempTable;

        }
        public bool ktCTKhuyenmai(string LoaiKM)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) as SL from Khuyenmai where loaiKM='{0}'",LoaiKM);
            kq = this.countQuantity(sql)>=1;
            closeConnection();
            return kq;
        
        }
    }
}
