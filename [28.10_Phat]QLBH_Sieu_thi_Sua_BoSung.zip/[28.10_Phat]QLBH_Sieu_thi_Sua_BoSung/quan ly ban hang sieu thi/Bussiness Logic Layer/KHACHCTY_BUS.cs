﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer 
{
    public class KHACHCTY_BUS : DataProvider
    {
        string sql = "";
        DataTable tempTable;

        public DataTable LayDanhSachKH()
        {

            tempTable = new DataTable();
            openConnection();
            sql = "select MaKH, TenKH, DiaChi, Dienthoai, Fax, Mathue, SoTK from Khach_cty";
            tempTable = this.getDataTable(sql);
            closeConnection();
            return tempTable;

        }
    }
}
