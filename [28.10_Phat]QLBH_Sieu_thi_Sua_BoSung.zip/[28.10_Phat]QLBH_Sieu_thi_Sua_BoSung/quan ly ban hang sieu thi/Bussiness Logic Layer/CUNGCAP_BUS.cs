﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;

namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class CUNGCAP_BUS:DataProvider
    {
        string sql="";
        DataTable tempTable;

        public DataTable LayDSNCC()
        {
            tempTable = new DataTable();
            openConnection();
            tempTable = new DataTable();
            sql = "select distinct NCC.MaNCC,NCC.TenNCC from Nhacungcap NCC, Cungcap CC where NCC.MaNCC=CC.MaNCC";
            tempTable = this.getDataTable(sql);
            closeConnection();
            return tempTable;        

        }
        
        public void Them(CUNGCAP_OBJ Cungcap)
        {
            openConnection();      
            sql = string.Format("insert into CUNGCAP values('{0}','{1}')", Cungcap.MaNCC, Cungcap.Mahang);
            this.excuteNonQuery(sql);
            closeConnection();

        }
        public void Sua(CUNGCAP_OBJ Cungcap)  // thay doi Nha cung cap 
        {
            openConnection();
            sql = string.Format("update CUNGCAP set MaNCC='{0}' where MaHang='{1}'", Cungcap.MaNCC, Cungcap.Mahang);
            this.excuteNonQuery(sql);
            closeConnection();

        }
        
        public void XoaTheoMahang(string Mahang)
        {
            openConnection();
            sql = string.Format("delete CUNGCAP where Mahang='{0}'",Mahang);
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public void XoaTheoMaNCC(string MaNCC)
        {
            openConnection();
            sql = string.Format("delete CUNGCAP where MaNCC='{0}'", MaNCC);
            this.excuteNonQuery(sql);
            closeConnection();
        }
        
        public bool ktTontaiNCC_Mathang(CUNGCAP_OBJ Cungcap)  // 1 nha cung cap nao do da cung ung 1 mat hang nao do chua
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Cungcap where MaNCC='{0}' and Mahang='{1}'", Cungcap.MaNCC,Cungcap.Mahang);
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }

    }
}
