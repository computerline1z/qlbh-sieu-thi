﻿using System;
using System.Collections.Generic;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class DVTINH_BUS:DataProvider
    {
        string sql = "";
        DataTable tempTable;
        public DataTable layDanhSachDVT()
        {

            tempTable = new DataTable();
            openConnection();
            sql = "SELECT DVT FROM DVT";
            tempTable = this.getDataTable(sql);
            closeConnection();
            return tempTable;
        }

        public void Them(DVTINH_OBJ NewDVT)
        {
            openConnection();
            sql = string.Format("insert into DVT values('{0}')", NewDVT.DVT);
            excuteNonQuery(sql);
            closeConnection();
        }
        public void Xoa(DVTINH_OBJ OldDVT)
        {
            openConnection();
            sql = string.Format("delete DVT where DVT='{0}'", OldDVT.DVT);
            excuteNonQuery(sql);
            closeConnection();
        }

        public void Sua(DVTINH_OBJ NewDVT, string s)
        {
            openConnection();
            sql = string.Format("update DVT set DVT = '{0}' where DVT = '{1}'", NewDVT.DVT, s);
            excuteNonQuery(sql);
            closeConnection();
        }
    }
}
