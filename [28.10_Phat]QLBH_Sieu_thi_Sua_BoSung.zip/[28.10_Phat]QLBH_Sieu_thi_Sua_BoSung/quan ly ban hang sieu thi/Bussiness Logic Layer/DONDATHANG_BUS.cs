﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class DONDATHANG_BUS:DataProvider
    {
        
        string sql = "";

        public void LayDSDDH() 
        { 

        }
       
        public bool ktTontaiDDH(string MaDDH)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Dondathang where Dondathang.MaDDH='{0}'", MaDDH);
            kq =  this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }

        public bool ktNCCTontaiDDH(string MaNCC)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Dondathang where Dondathang.MaNCC='{0}'", MaNCC);
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }

        public void Them()
        { }
        public void Sua()
        { }
        public void Xoa()
        { }
        public void XoaTheoNCC(string MaNCC)
        {
            openConnection();
            sql = string.Format("delete Dondathang where MaNCC='{0}'", MaNCC);
            this.excuteNonQuery(sql);
            closeConnection();
        }

        
    }
}
