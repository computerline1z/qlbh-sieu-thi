﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Windows.Forms;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
   public class NHACUNGCAP_BUS:DataProvider
    {
        string  sql = "";
        DataTable tempTable;
        PHIEUNHAP_BUS Phieunhap_bus = new PHIEUNHAP_BUS();
        DONDATHANG_BUS Dondathang_bus = new DONDATHANG_BUS();

        public DataTable LayDanhSachNCC()
        {
            tempTable = new DataTable();
            openConnection();
            sql = "select MaNCC, TenNCC, DiaChi, Dienthoai, Fax, Mathue, SoTK from Nhacungcap where Trangthai = 'True' ";
            tempTable = this.getDataTable(sql);
            closeConnection();
            return tempTable;
            
        }

        public DataTable LayDanhSachRutGonNCC()
        {
            tempTable = new DataTable();
            openConnection();            
            sql = "select MaNCC, TenNCC from NHACUNGCAP";
            tempTable = this.getDataTable(sql);
            closeConnection();
            return tempTable;
        }

        public string LayIDTiepTheo()
        {
            int ID;
            string s;
            sql = "select MAX(CONVERT(int,RIGHT(MANCC,4))) from Nhacungcap";
            ID = (int)this.excuteScalar(sql);
            ID++;
            s = ID.ToString();
            for (int i = 0; i < 6 - s.Length; i++)
            {
                s = "0" + s;
            }
            s = "NCC" + s;
            return s;
        }
           
           
        public int[] ktRong(NHACUNGCAP_OBJ NewNCC)
        {
            int [] kq = new int[7]; 
            if (NewNCC.MaNCC=="")
                kq[0] = 0;
            if (NewNCC.TenNCC == "")
                kq[1] = 2;
            if (NewNCC.Diachi == "")
                kq[2] = 2;
            if (NewNCC.Mathue == "")
                kq[3] = 3;
            if (NewNCC.Dienthoai == "")
                kq[4] = 4;
            if (NewNCC.SotK== "")
                kq[5] = 5;
            if (NewNCC.Fax == "")
                kq[6] = 6;
            return kq;   
        }

      

        public int[] ktChuoi(NHACUNGCAP_OBJ Nhacungcap)
        {
            int[] kq = new int[6];

            if (Nhacungcap.TenNCC.Length > 30)
                kq[0] = 1;
            if (Nhacungcap.Diachi.Length > 30)
                kq[1] = 1;
            if (Nhacungcap.Dienthoai.Length > 12)
                kq[2] = 1;
            if (Nhacungcap.Fax.Length > 12)
                kq[3] = 1;
            if (Nhacungcap.Mathue.Length > 7)
                kq[4] = 1;
            if (Nhacungcap.SotK.Length > 7)
                kq[5] = 1;
            return kq;


        }

        public bool ktNCCTontaiNCC(string MaNCC)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Nhacungcap where MaNCC='{0}'", MaNCC);
            kq = this.countQuantity(sql)>=1;
            closeConnection();
            return kq;

        }

        public bool ktNCCTontaiPhieunhap(string MaNCC)
        {

            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Phieunhap  where MaNCC='{0}'", MaNCC);
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }

        public bool ktNCCTontaiCungcap(string MaNCC)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Cungcap where MaNCC='{0}'", MaNCC);
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }


        public bool ktTontaiTrongDDH(string MaNCC)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Dondathang where MaNCC='{0}'", MaNCC);
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }
        public bool ktTontaiTrongDanhMucHang(string MaNCC)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from DMHang where MaNCC='{0}'", MaNCC);
            kq = this.countQuantity(sql) >= 1;
            closeConnection();
            return kq;
        }
        
        public void Them(NHACUNGCAP_OBJ NewNCC)
        {
            openConnection();
            sql = string.Format("insert into NHACUNGCAP values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", NewNCC.MaNCC, NewNCC.TenNCC, NewNCC.Diachi, NewNCC.Dienthoai, NewNCC.Fax, NewNCC.Mathue, NewNCC.SotK, "True");
            this.excuteNonQuery(sql);
            closeConnection();

        }

        public void Sua(NHACUNGCAP_OBJ NewNCC)  
        {
            openConnection();
            sql = string.Format("update Nhacungcap set TenNCC='{0}',Diachi='{1}',Dienthoai='{2}',Fax='{3}',Mathue='{4}', Sotk='{5}' where MaNCC='{6}'", NewNCC.TenNCC, NewNCC.Diachi, NewNCC.Dienthoai, NewNCC.Fax, NewNCC.Mathue, NewNCC.SotK, NewNCC.MaNCC);
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public void Xoa(NHACUNGCAP_OBJ OldNCC)
        {
            openConnection();
            sql = string.Format("update NHACUNGCAP set Tinhtrang='false' where MaNCC='{0}'", OldNCC.MaNCC); // cap nhat lai trinh trang cua Nhà cung cấp la ko tồn tại nhưng thực ra 
            this.excuteNonQuery(sql);                                                                  // dữ liệu của NCC này vẫn còn trên CSDL vì dữ liệu này có liên quan đến các ràng buộc toàn vẹn
            closeConnection();
        }
        
    }
}
