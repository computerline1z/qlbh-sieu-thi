﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class LOAIHANG_BUS:DataProvider
    {
        string sql = "";
        DataTable tempTable;
        public DataTable LayLoaiHang()
        {
            tempTable = new DataTable();
            openConnection();
            sql = "select Loai, Tenloai from Loaihang where loai <> 'X' ";
            tempTable = this.getDataTable(sql);
            closeConnection();
            return tempTable;
        }

        public bool ktTontaiTrongLoaiHang(string Loai)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Loaihang where loai='{0}'", Loai);
            kq = this.countQuantity(sql)>=1;
            return kq;
        }

        public bool ktLoaihangTonTaiTrongDanhMucHang(string loai)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from DMHANG where loai='{0}'", loai);
            kq = this.countQuantity(sql)>=1;
            closeConnection();
            return kq;
        }

        public int[] ktRong(LOAIHANG_OBJ NewLoaihang)
        {
            int[] kq = new int[2];
            if (NewLoaihang.Maloai == "")
                 kq[0] = 1;
            if (NewLoaihang.Tenloai == "")
                kq[1] = 1;
            return kq;
        }

        public void Them(LOAIHANG_OBJ NewLoaihang)
        {
            openConnection();
            sql = string.Format("insert into Loaihang values('{0}','{1}')", NewLoaihang.Maloai, NewLoaihang.Tenloai);
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public void Sua(LOAIHANG_OBJ NewLoaihang, string Old)
        {
            openConnection();
            sql = string.Format("update Loaihang set loai = '{0}', Tenloai = '{1}' where loai='{2}'", NewLoaihang.Maloai, NewLoaihang.Tenloai,Old);
            this.excuteNonQuery(sql);
            closeConnection();
        }

        public void Xoa(string Old)
        {
            openConnection();
            sql = string.Format("delete Loaihang where loai = '{0}'", Old);
            this.excuteNonQuery(sql);
            closeConnection();
        }
    }
}
