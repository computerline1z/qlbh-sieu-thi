﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class TYSUATGIACA_BUS:DataProvider
    {

        string sql = "";
        DataTable tempTable = new DataTable();

        public DataTable LayDSNhom()
        {
            tempTable = new DataTable();
            openConnection();
            sql = "select Nhomhang, Tysuat from Tysuatgiaca";
            tempTable = this.getDataTable(sql);
            closeConnection();
            return tempTable;
        }

       
        public bool ktTontaiTrongTySuatGCa(string Manhom)
        {
            bool kq;
            openConnection();
            sql = string.Format("select count(*) from Tysuatgiaca where Nhomhang='{0}'", Manhom);
            kq = this.countQuantity(sql) == 1;
            closeConnection();
            return kq;
        }

        public string LayIDTiepTheo()
        {
            openConnection();
            sql = "select MAX(Nhomhang) form Tysuatgiaca";
            int ID = (int) this.excuteScalar(sql);
            ID++;
            closeConnection();
            return ID.ToString();
        }

        public void Them(TYSUATGIACA_OBJ NewTysuat)
        {
            openConnection();
            sql = string.Format("insert into Tysuatgiaca values('{0}','{1}')", NewTysuat.Manhom, NewTysuat.Tysuat);
            this.excuteNonQuery(sql);
            closeConnection();
        
        }

        public void Sua(TYSUATGIACA_OBJ NewTysuat)
        {
            openConnection();
            sql = string.Format("update Tysuatgiaca set Tysuat = '{0}' where Nhomhang='{1}'", NewTysuat.Tysuat, NewTysuat.Manhom);
            this.excuteNonQuery(sql);
            closeConnection();
        }

        

    }
}
