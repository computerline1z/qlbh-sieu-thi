﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    class LOGIN_BUS:DataProvider
    {
        string sql;
        public bool ktTaiKhoan(string username, string pass)
        {   bool kq; 
            openConnection();
            string hashPass = GetMD5Hash(pass);
            sql = string.Format("select count(*) from Taikhoan where Username = '{0}' and  Password='{1}'", username,hashPass);
            kq = this.countQuantity(sql) == 1;
            closeConnection();
            return kq;
        }

        public string GetMD5Hash(string input)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(input);
            bs = x.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (byte b in bs)
            {
                s.Append(b.ToString("x2").ToLower());
            }
            string password = s.ToString();
            return password;
        }


    }
}
