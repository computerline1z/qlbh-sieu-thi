﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using System.Data;
namespace quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer
{
    public class KHO_BUS:DataProvider
    {
        string sql = "";
        DataTable tempTable;
        public DataTable LayDSKho()
        {
            tempTable = new DataTable();
            openConnection();
            sql = "select Makho, TenKho, DiaChiKho from Kho";
            tempTable = this.getDataTable(sql);
            return tempTable;
        }
    }
}
