﻿namespace quan_ly_ban_hang_sieu_thi.Presentation_Layer
{
    partial class ucNCC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbplNCC = new System.Windows.Forms.TableLayoutPanel();
            this.grbDSNCC = new System.Windows.Forms.GroupBox();
            this.dgvNCC = new System.Windows.Forms.DataGridView();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.txtMaNCC = new System.Windows.Forms.GroupBox();
            this.picXeHang = new System.Windows.Forms.PictureBox();
            this.txtTenNCC = new System.Windows.Forms.TextBox();
            this.lblTenNCC = new System.Windows.Forms.Label();
            this.txtSoTk = new System.Windows.Forms.TextBox();
            this.lblSoTKNCC = new System.Windows.Forms.Label();
            this.txtMathue = new System.Windows.Forms.TextBox();
            this.lblSoThueNCC = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDiaChiNCC = new System.Windows.Forms.Label();
            this.txtDienthoai = new System.Windows.Forms.TextBox();
            this.lblSodtNCC = new System.Windows.Forms.Label();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.lblSoFaxNCC = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblMaNCC = new System.Windows.Forms.Label();
            this.tbplNCC.SuspendLayout();
            this.grbDSNCC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNCC)).BeginInit();
            this.pnlButton.SuspendLayout();
            this.txtMaNCC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picXeHang)).BeginInit();
            this.SuspendLayout();
            // 
            // tbplNCC
            // 
            this.tbplNCC.ColumnCount = 1;
            this.tbplNCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbplNCC.Controls.Add(this.grbDSNCC, 0, 1);
            this.tbplNCC.Controls.Add(this.pnlButton, 0, 2);
            this.tbplNCC.Controls.Add(this.txtMaNCC, 0, 0);
            this.tbplNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplNCC.Location = new System.Drawing.Point(0, 0);
            this.tbplNCC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbplNCC.Name = "tbplNCC";
            this.tbplNCC.RowCount = 3;
            this.tbplNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.02614F));
            this.tbplNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 67.97385F));
            this.tbplNCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tbplNCC.Size = new System.Drawing.Size(1067, 642);
            this.tbplNCC.TabIndex = 0;
            // 
            // grbDSNCC
            // 
            this.grbDSNCC.Controls.Add(this.dgvNCC);
            this.grbDSNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDSNCC.Location = new System.Drawing.Point(4, 193);
            this.grbDSNCC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grbDSNCC.Name = "grbDSNCC";
            this.grbDSNCC.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grbDSNCC.Size = new System.Drawing.Size(1059, 395);
            this.grbDSNCC.TabIndex = 1;
            this.grbDSNCC.TabStop = false;
            this.grbDSNCC.Text = "Danh sách nhà cung cấp";
            // 
            // dgvNCC
            // 
            this.dgvNCC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNCC.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvNCC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNCC.Location = new System.Drawing.Point(4, 20);
            this.dgvNCC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvNCC.Name = "dgvNCC";
            this.dgvNCC.RowTemplate.Height = 24;
            this.dgvNCC.Size = new System.Drawing.Size(1051, 372);
            this.dgvNCC.TabIndex = 0;
            // 
            // pnlButton
            // 
            this.pnlButton.Controls.Add(this.btnLuu);
            this.pnlButton.Controls.Add(this.btnXoa);
            this.pnlButton.Controls.Add(this.btnThem);
            this.pnlButton.Controls.Add(this.btnSua);
            this.pnlButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButton.Location = new System.Drawing.Point(4, 596);
            this.pnlButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(1059, 42);
            this.pnlButton.TabIndex = 2;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLuu.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.save_icon;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(919, 7);
            this.btnLuu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(87, 31);
            this.btnLuu.TabIndex = 18;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXoa.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.delete_Icon;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(820, 7);
            this.btnXoa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(87, 31);
            this.btnXoa.TabIndex = 19;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnThem.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.add_icon;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(620, 7);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(87, 31);
            this.btnThem.TabIndex = 16;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSua.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.icon_edit;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(720, 7);
            this.btnSua.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(87, 31);
            this.btnSua.TabIndex = 17;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // txtMaNCC
            // 
            this.txtMaNCC.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtMaNCC.Controls.Add(this.picXeHang);
            this.txtMaNCC.Controls.Add(this.txtTenNCC);
            this.txtMaNCC.Controls.Add(this.lblTenNCC);
            this.txtMaNCC.Controls.Add(this.txtSoTk);
            this.txtMaNCC.Controls.Add(this.lblSoTKNCC);
            this.txtMaNCC.Controls.Add(this.txtMathue);
            this.txtMaNCC.Controls.Add(this.lblSoThueNCC);
            this.txtMaNCC.Controls.Add(this.txtDiaChi);
            this.txtMaNCC.Controls.Add(this.lblDiaChiNCC);
            this.txtMaNCC.Controls.Add(this.txtDienthoai);
            this.txtMaNCC.Controls.Add(this.lblSodtNCC);
            this.txtMaNCC.Controls.Add(this.txtFax);
            this.txtMaNCC.Controls.Add(this.lblSoFaxNCC);
            this.txtMaNCC.Controls.Add(this.textBox1);
            this.txtMaNCC.Controls.Add(this.lblMaNCC);
            this.txtMaNCC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMaNCC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaNCC.Location = new System.Drawing.Point(4, 4);
            this.txtMaNCC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMaNCC.Name = "txtMaNCC";
            this.txtMaNCC.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMaNCC.Size = new System.Drawing.Size(1059, 181);
            this.txtMaNCC.TabIndex = 0;
            this.txtMaNCC.TabStop = false;
            this.txtMaNCC.Text = "Thông tin nhà cung cấp";
            // 
            // picXeHang
            // 
            this.picXeHang.Image = global::quan_ly_ban_hang_sieu_thi.Properties.Resources.xe_cho_hang;
            this.picXeHang.Location = new System.Drawing.Point(805, 21);
            this.picXeHang.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picXeHang.Name = "picXeHang";
            this.picXeHang.Size = new System.Drawing.Size(245, 154);
            this.picXeHang.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picXeHang.TabIndex = 2;
            this.picXeHang.TabStop = false;
            // 
            // txtTenNCC
            // 
            this.txtTenNCC.Location = new System.Drawing.Point(129, 59);
            this.txtTenNCC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTenNCC.Name = "txtTenNCC";
            this.txtTenNCC.Size = new System.Drawing.Size(211, 25);
            this.txtTenNCC.TabIndex = 1;
            // 
            // lblTenNCC
            // 
            this.lblTenNCC.AutoSize = true;
            this.lblTenNCC.Location = new System.Drawing.Point(48, 63);
            this.lblTenNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTenNCC.Name = "lblTenNCC";
            this.lblTenNCC.Size = new System.Drawing.Size(73, 18);
            this.lblTenNCC.TabIndex = 0;
            this.lblTenNCC.Text = "Tên NCC";
            // 
            // txtSoTk
            // 
            this.txtSoTk.Location = new System.Drawing.Point(129, 97);
            this.txtSoTk.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSoTk.Name = "txtSoTk";
            this.txtSoTk.Size = new System.Drawing.Size(211, 25);
            this.txtSoTk.TabIndex = 1;
            // 
            // lblSoTKNCC
            // 
            this.lblSoTKNCC.AutoSize = true;
            this.lblSoTKNCC.Location = new System.Drawing.Point(19, 101);
            this.lblSoTKNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSoTKNCC.Name = "lblSoTKNCC";
            this.lblSoTKNCC.Size = new System.Drawing.Size(95, 18);
            this.lblSoTKNCC.TabIndex = 0;
            this.lblSoTKNCC.Text = "Số tài khoản";
            // 
            // txtMathue
            // 
            this.txtMathue.Location = new System.Drawing.Point(129, 130);
            this.txtMathue.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMathue.Name = "txtMathue";
            this.txtMathue.Size = new System.Drawing.Size(211, 25);
            this.txtMathue.TabIndex = 1;
            // 
            // lblSoThueNCC
            // 
            this.lblSoThueNCC.AutoSize = true;
            this.lblSoThueNCC.Location = new System.Drawing.Point(29, 134);
            this.lblSoThueNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSoThueNCC.Name = "lblSoThueNCC";
            this.lblSoThueNCC.Size = new System.Drawing.Size(86, 18);
            this.lblSoThueNCC.TabIndex = 0;
            this.lblSoThueNCC.Text = "Mã số thuế";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(439, 21);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(275, 25);
            this.txtDiaChi.TabIndex = 1;
            // 
            // lblDiaChiNCC
            // 
            this.lblDiaChiNCC.AutoSize = true;
            this.lblDiaChiNCC.Location = new System.Drawing.Point(369, 28);
            this.lblDiaChiNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDiaChiNCC.Name = "lblDiaChiNCC";
            this.lblDiaChiNCC.Size = new System.Drawing.Size(56, 18);
            this.lblDiaChiNCC.TabIndex = 0;
            this.lblDiaChiNCC.Text = "Địa chỉ";
            // 
            // txtDienthoai
            // 
            this.txtDienthoai.Location = new System.Drawing.Point(439, 59);
            this.txtDienthoai.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDienthoai.Name = "txtDienthoai";
            this.txtDienthoai.Size = new System.Drawing.Size(163, 25);
            this.txtDienthoai.TabIndex = 1;
            // 
            // lblSodtNCC
            // 
            this.lblSodtNCC.AutoSize = true;
            this.lblSodtNCC.Location = new System.Drawing.Point(369, 66);
            this.lblSodtNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSodtNCC.Name = "lblSodtNCC";
            this.lblSodtNCC.Size = new System.Drawing.Size(52, 18);
            this.lblSodtNCC.TabIndex = 0;
            this.lblSodtNCC.Text = "Số ĐT";
            // 
            // txtFax
            // 
            this.txtFax.Location = new System.Drawing.Point(439, 97);
            this.txtFax.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(163, 25);
            this.txtFax.TabIndex = 1;
            // 
            // lblSoFaxNCC
            // 
            this.lblSoFaxNCC.AutoSize = true;
            this.lblSoFaxNCC.Location = new System.Drawing.Point(364, 105);
            this.lblSoFaxNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSoFaxNCC.Name = "lblSoFaxNCC";
            this.lblSoFaxNCC.Size = new System.Drawing.Size(56, 18);
            this.lblSoFaxNCC.TabIndex = 0;
            this.lblSoFaxNCC.Text = "Số Fax";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(129, 21);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(211, 25);
            this.textBox1.TabIndex = 1;
            // 
            // lblMaNCC
            // 
            this.lblMaNCC.AutoSize = true;
            this.lblMaNCC.Location = new System.Drawing.Point(48, 28);
            this.lblMaNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMaNCC.Name = "lblMaNCC";
            this.lblMaNCC.Size = new System.Drawing.Size(66, 18);
            this.lblMaNCC.TabIndex = 0;
            this.lblMaNCC.Text = "Mã NCC";
            // 
            // ucNCC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbplNCC);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ucNCC";
            this.Size = new System.Drawing.Size(1067, 642);
            this.tbplNCC.ResumeLayout(false);
            this.grbDSNCC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNCC)).EndInit();
            this.pnlButton.ResumeLayout(false);
            this.txtMaNCC.ResumeLayout(false);
            this.txtMaNCC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picXeHang)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tbplNCC;
        private System.Windows.Forms.GroupBox txtMaNCC;
        private System.Windows.Forms.GroupBox grbDSNCC;
        private System.Windows.Forms.DataGridView dgvNCC;
        private System.Windows.Forms.TextBox txtTenNCC;
        private System.Windows.Forms.Label lblTenNCC;
        private System.Windows.Forms.TextBox txtSoTk;
        private System.Windows.Forms.Label lblSoTKNCC;
        private System.Windows.Forms.TextBox txtMathue;
        private System.Windows.Forms.Label lblSoThueNCC;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblMaNCC;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Label lblSoFaxNCC;
        private System.Windows.Forms.TextBox txtDienthoai;
        private System.Windows.Forms.Label lblSodtNCC;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblDiaChiNCC;
        private System.Windows.Forms.PictureBox picXeHang;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
    }
}
