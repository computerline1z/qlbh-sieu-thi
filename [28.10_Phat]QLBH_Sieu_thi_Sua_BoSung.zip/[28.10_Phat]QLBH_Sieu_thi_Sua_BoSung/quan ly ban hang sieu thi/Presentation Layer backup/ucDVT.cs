﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer;

namespace quan_ly_ban_hang_sieu_thi
{
    public partial class ucDVT : UserControl
    {
        DataProvider dataProvider = new DataProvider();
        DVTINH_BUS DvTinh_bus = new DVTINH_BUS();
        DVTINH_OBJ DvTinh_obj = new DVTINH_OBJ();
        BindingSource bindingSource = new BindingSource();
        private string flag = "";
        public ucDVT()
        {
            InitializeComponent();
            bindingSource.DataSource=DvTinh_bus.layDanhSachDVT();
            LoadToListBox();
            lstDVT.SelectedIndex = 0;
            if(lstDVT.SelectedValue.ToString()!="")
                txtDVT.Text = lstDVT.SelectedValue.ToString();
        }
        public void LoadToListBox()
        {
           lstDVT.DataSource = DvTinh_bus.layDanhSachDVT();
           lstDVT.DisplayMember="DVT";
           lstDVT.ValueMember="DVT";
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            txtDVT.Text = "";
            flag = "Them";
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            txtDVT.Focus();
            flag = "Sua";
        }


        private void lstDVT_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDVT.Text = lstDVT.SelectedValue.ToString();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DvTinh_obj.DVT = txtDVT.Text.Trim();
            if (DvTinh_bus.ktXoaDVT(txtDVT.Text))
                MessageBox.Show("Tồn tại hàng hóa sử dụng đơn vị tính này.");
            else
            {
                DvTinh_bus.XoaDVT(txtDVT.Text);
                LoadToListBox(); 
            }
            flag = "";  
        }

        private void btnLưu_Click(object sender, EventArgs e)
        {
            DvTinh_obj.DVT = txtDVT.Text.Trim();
            switch (flag)
            {
                case "Them":
                    {
                        if (DvTinh_bus.ktTonTaiDVT(DvTinh_obj))
                            break;
                        DvTinh_bus.ThemDVT(DvTinh_obj);
                        break;
                    }
                case "Sua":
                    {
                        DvTinh_bus.SuaDVT(DvTinh_obj);
                        break;
                    }
            }
            LoadToListBox();
            flag = "";
        }

    }
}
