﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using quan_ly_ban_hang_sieu_thi.Presentation_Layer;

namespace quan_ly_ban_hang_sieu_thi
{
    public partial class frmQL : Form
    {
        private newTab MainTab = new newTab();
        public frmQL()
        {
            InitializeComponent();
            this.tblMain.Controls.Add(this.MainTab, 0, 1);
            usrDMHang DMH = new usrDMHang();
            MainTab.createtabPage("Hàng Hóa", DMH);
            treeMain.Nodes[0].Expand();
            
        }
        private void frmQL_Load(object sender, EventArgs e)
        {
            treeMain.ExpandAll();
            
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            if (MainTab.TabCount > 1)
            {
                MainTab.Controls.Remove(MainTab.SelectedTab);
                MainTab.SelectedIndex = MainTab.TabCount-1;
            }
            else
                MainTab.Visible = false;
        }

        private void treeMain_AfterSelect(object sender, TreeViewEventArgs e)
        {

            switch (treeMain.SelectedNode.Name)
            {
                case "nnHangHoa":
                    {
                        usrDMHang DMH = new usrDMHang();
                        int i=-1;
                        i = MainTab.isExists("Hàng Hóa");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Hàng Hóa", DMH);
                        else
                            MainTab.SelectedIndex = i;
                        break;

                    }
                case "nnDVT":
                    {
                        ucDVT DVT = new ucDVT();
                        int i=-1;

                        i = MainTab.isExists("Đơn vị tính");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Đơn vị tính", DVT);
                        else
                            MainTab.SelectedIndex = i;
                        
                        break;
                    }
                case "nnnNCC":
                    {
                        ucNCC NCC = new ucNCC();
                        int i = -1;
                        i = MainTab.isExists("Nhà cung cấp");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Nhà cung cấp", NCC);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnLoaiHang":
                    {
                        ucLoaiHang LoaiHang = new ucLoaiHang();
                        int i = -1;
                        i = MainTab.isExists("Loại hàng");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Loại hàng", LoaiHang);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnnKHCTy":
                    {
                        ucKhachHangCty KHCty = new ucKhachHangCty();
                        int i = -1;
                        i = MainTab.isExists("Khách hàng công ty");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Khách hàng công ty", KHCty);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnnHDCty":
                    {
                        ucHoaDonCty HDCty = new ucHoaDonCty();
                        int i = -1;
                        i = MainTab.isExists("Hóa đơn Cty");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Hóa đơn Cty", HDCty);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnnHDle":
                    {
                        ucHoaDonLe HDLe = new ucHoaDonLe();
                        int i = -1;
                        i = MainTab.isExists("Hóa đơn lẻ");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Hóa đơn lẻ", HDLe);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnLapDDH":
                    {
                        ucDonDatHang DDH = new ucDonDatHang();
                        int i = -1;
                        i = MainTab.isExists("Đơn đặt hàng");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Đơn đặt hàng", DDH);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnPN":
                    {
                        ucPhieuNhap PN = new ucPhieuNhap();
                        int i = -1;
                        i = MainTab.isExists("Phiếu nhập");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Phiếu nhập", PN);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnPC":
                    {
                        ucPhieuChuyen PC = new ucPhieuChuyen();
                        int i = -1;
                        i = MainTab.isExists("Phiếu chuyển");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Phiếu chuyển", PC);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnQLGiaCa":
                    {
                        ucQLGiaCa NhomGiaCa = new ucQLGiaCa();
                        int i = -1;
                        i = MainTab.isExists("Quản lý giá cả");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Quản lý giá cả", NhomGiaCa);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnHangTon":
                    {
                        ucQuanLyHangTon HangTon = new ucQuanLyHangTon();
                        int i = -1;
                        i = MainTab.isExists("Quản lý hàng tồn");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Quản lý hàng tồn", HangTon);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnPX":
                    {
                        ucPhieuXuat PX = new ucPhieuXuat();
                        int i = -1;
                        i = MainTab.isExists("Phiếu xuất");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Phiếu xuất", PX);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnDTTheoThoiGian":
                    {
                        ucDoanhThuThoiGian DTTG = new ucDoanhThuThoiGian();
                        int i = -1;
                        i = MainTab.isExists("Doanh thu theo thời gian");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Doanh thu theo thời gian", DTTG);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnThongKeHangHoa":
                    {
                        ucThongKeXuatNhap TKXN = new ucThongKeXuatNhap();
                        int i = -1;
                        i = MainTab.isExists("Thống kê hàng hóa");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Thống kê hàng hóa", TKXN);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnnDMKM":
                    {
                        ucMatHangKM MatHangKM = new ucMatHangKM();
                        int i = -1;
                        i = MainTab.isExists("Các mặt hàng khuyến mãi");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Các mặt hàng khuyến mãi", MatHangKM);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnnCTKM":
                    {
                        ucChuongTrinhKM CTKM = new ucChuongTrinhKM();
                        int i = -1;
                        i = MainTab.isExists("Chương trình khuyến mãi");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Chương trình khuyến mãi", CTKM);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
                case "nnnLoaiHinhKM":
                    {
                        ucLoaiHinhKM LoaiHinhKM = new ucLoaiHinhKM();
                        int i = -1;
                        i = MainTab.isExists("Loại hình khuyến mãi");
                        if (i == -1)  // chua co Tab moi 
                            MainTab.createtabPage("Loại hình khuyến mãi", LoaiHinhKM);
                        else
                            MainTab.SelectedIndex = i;
                        break;
                    }
       
            }

        }

        private void btnQuyDinh_Click(object sender, EventArgs e)
        {
            frmThayDoiQuyDinh QD = new frmThayDoiQuyDinh();
            QD.Show();

        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void đổiMậtKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDoiMatKhau DMK = new frmDoiMatKhau();
            DMK.ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thread threadDangNhap = new Thread(new ThreadStart(showDangNhap));
            threadDangNhap.Start();
            this.Close();
        }
        public void showDangNhap()
        {
            frmDangNhap DangNhap = new frmDangNhap();
            DangNhap.ShowDialog();
        }

        private void btnHangHoa_Click(object sender, EventArgs e)
        {
            treeMain.Nodes[0].Checked = true;
        }

        private void btnNhapXuat_Click(object sender, EventArgs e)
        {
            bool i=true;
            treeMain.SelectedNode = treeMain.Nodes[0].Nodes[3].Nodes[0];
            i= treeMain.Nodes[0].Nodes[3].Nodes[0].IsSelected;
            treeMain.PerformLayout();
        }


    }

}
