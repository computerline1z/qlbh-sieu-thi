﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using quan_ly_ban_hang_sieu_thi.Bussiness_Logic_Layer;
using quan_ly_ban_hang_sieu_thi.Data_Access_Layer;
using quan_ly_ban_hang_sieu_thi.Presentation_Layer;

namespace quan_ly_ban_hang_sieu_thi
{
    public partial class usrDMHang : UserControl
    {
        private DMHANGHOA_BUS Dmhh_bus = new DMHANGHOA_BUS();
        private DMHANGHOA_OBJ Hanghoa = new DMHANGHOA_OBJ();
        private CUNGCAP_OBJ Cungcap = new CUNGCAP_OBJ();
        private NHACUNGCAP_BUS Nhacungcap_bus = new NHACUNGCAP_BUS();
        private HANGKHUYENMAI_OBJ HangKM = new HANGKHUYENMAI_OBJ();
        private HANGKHUYENMAI_BUS HangKM_bus = new HANGKHUYENMAI_BUS();
        private KHUYENMAI_BUS Khuyenmai_bus = new KHUYENMAI_BUS();
        private LOAIHANG_BUS Loaihang_bus = new LOAIHANG_BUS();
        private TYSUATGIACA_BUS Tysuat_bus = new TYSUATGIACA_BUS();
        private CUNGCAP_BUS Cungcap_bus = new CUNGCAP_BUS();
        private BindingSource bindingSource = new BindingSource();
        private string flag = "";
        private string tempValue = "";


        public usrDMHang()
        {
            InitializeComponent();
            bindingSource.DataSource = Dmhh_bus.LayDanhSachHangHoa();
            dtGWHanghoa.DataSource = bindingSource;
            disableAllInput();
            loadToCombobox();
        }

        private void disableAllInput()
        {

            cboManhom.Enabled = false;
            txtMahang.ReadOnly = true;
            txtTenhang.ReadOnly = true;
            cboDVT.Enabled = false;
            cboMaloai.Enabled = false;
            txtGia.ReadOnly = true;
            cboNCC.Enabled = false;
            cboKM.Enabled = false;
        }

        private void enableAllInput()
        {
            cboManhom.Enabled = true;
            txtTenhang.ReadOnly = false;
            cboDVT.Enabled = true;
            cboMaloai.Enabled = true;
            cboNCC.Enabled = true;
            cboKM.Enabled = true;
        }

        private void clearAllInput()
        {
            cboManhom.Text = "";
            txtMahang.Text = "";
            txtTenhang.Text = "";
            cboDVT.Text = "";
            cboMaloai.Text = "";
            txtGia.Text = "";
            cboNCC.Text = "";
            cboKM.Text = "";
        }

        private void loadToCombobox()
        {

            cboDVT.DataSource = Dmhh_bus.LayDSDVT();
            cboDVT.ValueMember = "DVT";
            cboDVT.DisplayMember = "DVT";

            cboManhom.DataSource = Tysuat_bus.LayManhom();
            cboManhom.ValueMember = "Nhomhang";
            cboManhom.DisplayMember = "Nhomhang";

            cboNCC.DataSource = Nhacungcap_bus.LayDanhSachRutGonNCC();
            cboNCC.ValueMember = "MaNCC";
            cboNCC.DisplayMember = "TenNCC";

            cboMaloai.DataSource = Loaihang_bus.LayLoaiHang();
            cboMaloai.ValueMember = "Loai";
            cboMaloai.DisplayMember = "Tenloai";

            cboKM.DataSource = Khuyenmai_bus.LayDSKM();
            cboKM.ValueMember = "LoaiKM";
            cboKM.DisplayMember = "LoaiKM";

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            enableAllInput();
            txtMahang.ReadOnly = false;
            clearAllInput();
            txtMahang.Focus();
            flag = "Them";
        }


        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (flag != "")
            {

                TranferValueToObject();
                //step 1 : Kiem tra rong  

                switch (Dmhh_bus.ktRongHanghoa(Hanghoa))
                {
                    case 1:
                        {
                            MessageBox.Show("Mã hàng rỗng");
                            txtMahang.Focus();
                            return;
                        }
                    case 2:
                        {
                            MessageBox.Show("Tên hàng rỗng");
                            txtTenhang.Focus();
                            return;
                        }

                }
                

                
                int[] kqkt = Dmhh_bus.ktTontai(Hanghoa);
                if (kqkt[3]==1)
                {
                    MessageBox.Show("Chương trình khuyến mãi không tồn tại");
                    cboKM.Focus();
                    return;
                }


                // step 3 : xu ly 

                switch (flag)
                {
                    case "Them":
                        {
                            

                            Dmhh_bus.Them(Hanghoa);

                            // them vao cung cap   
                            Cungcap_bus.Them(Cungcap);

                            // them vao HangKM neu co           
                            if (cboKM.Text != "")
                                HangKM_bus.Them(HangKM);

                            break;
                        }

                    case "Sua":
                        {
                            //// Trigger ??????????????
                            Dmhh_bus.Sua(Hanghoa);
                            Cungcap_bus.Sua(Cungcap);

                            if (Hanghoa.Khuyenmai != "")
                                HangKM_bus.Sua(HangKM);

                            tempValue = "";
                            break;

                        }


                }

                bindingSource.DataSource = Dmhh_bus.LayDanhSachHangHoa();
                dtGWHanghoa.DataSource = bindingSource;
                disableAllInput();
                flag = "";

            }
        }

        public void TranferValueToObject()
        {
            Hanghoa.Mahang = txtMahang.Text.Trim();
            Hanghoa.Tenhang = txtTenhang.Text.Trim();
            Hanghoa.Dvtinh = cboDVT.Text.Trim();
            Hanghoa.Maloai = cboMaloai.SelectedValue.ToString().Trim();
            Hanghoa.Manhom = cboManhom.Text.Trim();
            Hanghoa.MaNCC = cboNCC.SelectedValue.ToString().Trim();
            try
            {
                Hanghoa.Khuyenmai = cboKM.SelectedValue.ToString().Trim();
            }
            catch
            {
                Hanghoa.Khuyenmai = "";
            }
            Cungcap.Mahang = Hanghoa.Mahang;
            Cungcap.MaNCC = Hanghoa.MaNCC;

            
            HangKM.LoaiKM = Hanghoa.Khuyenmai;
            HangKM.Mahang = Hanghoa.Mahang;

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            flag = "Sua";
            enableAllInput();
            txtMahang.ReadOnly = true;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {   /// kiem tra trong hoa don truoc 
            /// neu chua nam trong hoa don nao thi se xoa 
            /// neu da nam trong 1 hoa don thi se danh dau cho xoa 
            /// kiem tra trong phieu nhap
            ///     neu co ton == 0 thi se xoa 
            ///     neu co ton > 0 thi se danh dau cho den khi nao can se xoa
            ///  khi danh dau xoa ta se thay doi ma cua sp thanh Ma "RÁC" va thay doi trang thai cua san pham thanh false ( voi y nghia la hang nay da dc danh dau xoa)
            DialogResult kq = MessageBox.Show("Bạn có chắc chắn xóa sản phẩm này không ? ", "Chú ý", MessageBoxButtons.YesNo);
            if (kq == DialogResult.Yes)
            {
                TranferValueToObject();

                // xoa du lieu trong cac bang phu Khuyen mai 
                HangKM_bus.Xoa(Hanghoa.Mahang);

                // thay doi trang thai cua hang hoa 
                Dmhh_bus.Xoa(Hanghoa.Mahang); 

                bindingSource.DataSource = Dmhh_bus.LayDanhSachHangHoa();
                dtGWHanghoa.DataSource = bindingSource;
            }
        }
        private void btnThemNCC_Click(object sender, EventArgs e)
        {
            newForm NCC = new newForm("frmNCC", "NHÀ CUNG CẤP");
            ucNCC newNCC = new ucNCC();
            NCC.taoForm(newNCC);
        }
        private void btnThemDVT_Click(object sender, EventArgs e)
        {
            newForm DVT = new newForm("frmDVT", "ĐƠN VỊ TÍNH");
            ucDVT newDVT = new ucDVT();
            DVT.taoForm(newDVT);
        }
        private void btnThemLoaiHang_Click(object sender, EventArgs e)
        {
            newForm LoaiHang = new newForm("frmLoaiHang", "LOẠI MẶT HÀNG");
            ucLoaiHang newLoaiHang = new ucLoaiHang();
            LoaiHang.taoForm(newLoaiHang);

        }
        private void btnThemNhom_Click(object sender, EventArgs e)
        {
            newForm Nhom = new newForm("frmNhom", "NHÓM GIÁ CẢ");
            ucQLGiaCa newNhom = new ucQLGiaCa();
            Nhom.taoForm(newNhom);
        }

        private void dtGWHanghoa_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                cboManhom.Text = dtGWHanghoa.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtMahang.Text = dtGWHanghoa.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtTenhang.Text = dtGWHanghoa.Rows[e.RowIndex].Cells[2].Value.ToString();
                cboMaloai.Text = dtGWHanghoa.Rows[e.RowIndex].Cells[3].Value.ToString();
                cboDVT.Text = dtGWHanghoa.Rows[e.RowIndex].Cells[4].Value.ToString();
                txtGia.Text = dtGWHanghoa.Rows[e.RowIndex].Cells[5].Value.ToString();
                cboNCC.Text = dtGWHanghoa.Rows[e.RowIndex].Cells[6].Value.ToString();
                cboKM.Text = dtGWHanghoa.Rows[e.RowIndex].Cells[7].Value.ToString();


            }
            catch (Exception ex)
            {

            }
        }

    }
}
