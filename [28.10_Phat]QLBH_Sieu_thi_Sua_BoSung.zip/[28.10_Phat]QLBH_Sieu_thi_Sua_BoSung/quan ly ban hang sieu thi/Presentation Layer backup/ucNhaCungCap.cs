﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using QuanLyBanHang.Data_Access_Layer;
using QuanLyBanHang.Bussiness_Logic_Layer;
namespace QuanLyBanHang
{   
    

    public partial class ucNCC : UserControl
    {
        NHACUNGCAP_OBJ Nhacungcap = new NHACUNGCAP_OBJ();
        NHACUNGCAP_BUS Nhacungcap_bus = new NHACUNGCAP_BUS();
        CUNGCAP_BUS Cungcap_bus = new CUNGCAP_BUS();
        PHIEUNHAP_BUS Phieunhap_bus = new PHIEUNHAP_BUS();
        DONDATHANG_BUS Dondathang_bus = new DONDATHANG_BUS();
        BindingSource bindingSource = new BindingSource();

        string flag = "";

        public ucNCC()
        {
            InitializeComponent();
            disableAll();
            bindingSource.DataSource = Nhacungcap_bus.LayDanhSachNCC();
            dtGWNCC.DataSource = bindingSource;
        }

        



        public void enableAll()
        {
            
            txtDiaChi.ReadOnly = false;
            txtTenNCC.ReadOnly = false;
            txtSoTk.ReadOnly = false;
            txtMathue.ReadOnly = false;
            txtFax.ReadOnly = false;
            txtDienthoai.ReadOnly = false;
        
        }

        public void disableAll()
        {
            txtDiaChi.ReadOnly = true;
            txtTenNCC.ReadOnly = true;
            txtSoTk.ReadOnly = true;
            txtMathue.ReadOnly = true;
            txtFax.ReadOnly = true;
            txtDienthoai.ReadOnly = true;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            enableAll();
            txtMaNCC.Text = Nhacungcap_bus.LayIDTiepTheo();
            txtDiaChi.Focus();
            flag = "Them";

        }



        private void btnLuu_Click(object sender, EventArgs e)
        {
            //gan thong tin 
            Nhacungcap.MaNCC = txtMaNCC.Text.Trim();
            Nhacungcap.TenNCC = txtTenNCC.Text.Trim();
            Nhacungcap.Diachi = txtDiaChi.Text.Trim();
            Nhacungcap.Dienthoai = txtDienthoai.Text.Trim();
            Nhacungcap.Fax = txtFax.Text.Trim();
            Nhacungcap.Mathue = txtMathue.Text.Trim();
            Nhacungcap.SotK = txtSoTk.Text.Trim();
            
            // kiem tra rong
            string [] nullErrMessage = { "Mã NCC rỗng",
                                     "Tên NCC rỗng",
                                     "Địa chỉ NCC rỗng ",
                                     "Mã thuế rỗng",
                                     "Điện thoại rỗng ",
                                     "Số TK rỗng",
                                     "Số Fax rỗng"
                                   };
            string[] lengthErrMessage = { "Chiều dài tên vượt quá quy định",
                                             "Chiều dài địa chỉ vượt quá quy định",
                                             "Chiều dài điện thoại vượt quá quy định",
                                             "Chiều dài Fax vượt quá quy định",
                                             "Chiều dài Mã thuế vượt quá quy định",
                                             "Chiều dài số TK vượt quá quy định"
                                          }; 

            int [] errArr = new int[7];
            errArr = Nhacungcap_bus.ktRong(Nhacungcap);
            for (int i = 0; i < 7;i++)
            {
                if (errArr[i] > 0)
                {
                    MessageBox.Show(nullErrMessage[i]);
                    return;
                }
            }
            // kiem tra chieu dai chuoi 
            errArr = Nhacungcap_bus.ktChuoi(Nhacungcap);
            for (int i = 0; i < 6; i++)
            {
                if (errArr[i] > 0)
                {
                    MessageBox.Show(lengthErrMessage[i]);
                    return;
                }
            }

             //ma tu tang 
                switch (flag)
                {
                    case "Them":
                        {
                            Nhacungcap_bus.Them(Nhacungcap);
                            break;

                        }
                    case "Sua":
                        {

                            Nhacungcap_bus.Sua(Nhacungcap);
                            // phieu nhap ko thay doi vi ma NCC la ma tu tang va ko cho thay doi  
                            break;
                        }


                }
            bindingSource.DataSource = Nhacungcap_bus.LayDanhSachNCC();
            dtGWNCC.DataSource = bindingSource;
            disableAll();

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            flag = "Sua";
            enableAll();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            // xoa trong bang phu truoc 
            Cungcap_bus.XoaTheoMaNCC(Nhacungcap.MaNCC);   // voi y nghia la hang hoa ko con dc cung cap boi NCC nay nua, tuy nhien trong phieu nhap van co the ton tai MaNCC nay
            if(!Phieunhap_bus.ktNCCTontaiTrongPhieunhap(Nhacungcap.MaNCC)) // neu NCC ko ton tai trong bat ky phieu nhap nao 
            {
                // xoa 
                Phieunhap_bus.XoaTheoNCC(Nhacungcap.MaNCC);

            }

            if (!Dondathang_bus.ktNCCTontaiDDH(Nhacungcap.MaNCC))
            {
                Dondathang_bus.XoaTheoNCC(Nhacungcap.MaNCC);
            }

            Nhacungcap_bus.Xoa(Nhacungcap);

        }

        private void dtGWNCC_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtMaNCC.Text = dtGWNCC.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtTenNCC.Text = dtGWNCC.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtDiaChi.Text = dtGWNCC.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtDienthoai.Text = dtGWNCC.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtFax.Text = dtGWNCC.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtMathue.Text = dtGWNCC.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtSoTk.Text = dtGWNCC.Rows[e.RowIndex].Cells[6].Value.ToString();
        }

        



    }
}
