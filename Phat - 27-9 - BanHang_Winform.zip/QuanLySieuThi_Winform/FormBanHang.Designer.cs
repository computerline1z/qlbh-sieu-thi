﻿namespace QuanLySieuThi_Winform
{
    partial class FormBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label mAHANGLabel;
            System.Windows.Forms.Label lOAILabel;
            System.Windows.Forms.Label tENHANGLabel;
            System.Windows.Forms.Label gIABANLabel;
            System.Windows.Forms.Label dVTINHLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBanHang));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smtThongTinPhienLamViec = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinTàuKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiDoiMatKhau = new System.Windows.Forms.ToolStripMenuItem();
            this.smiCapNhatThongTin = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.smiDangXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.smiThoatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.nghiệpVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiThongTinHangDaBan = new System.Windows.Forms.ToolStripMenuItem();
            this.smiInHoaDonBanLe = new System.Windows.Forms.ToolStripMenuItem();
            this.tiệnÍchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiMayTinhMini = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.smiXemTiGia = new System.Windows.Forms.ToolStripMenuItem();
            this.smiDoiTien = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smiHuongDanSuDung = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.smiCapNhatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.smiBaoCaoLoi = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.smiThongTinPhanMemBanHang = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.hOADONLEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.NutChucNang = new System.Windows.Forms.Panel();
            this.btnCuoiDanhSach = new System.Windows.Forms.Button();
            this.btnToi = new System.Windows.Forms.Button();
            this.btnLui = new System.Windows.Forms.Button();
            this.btnDauDanhSach = new System.Windows.Forms.Button();
            this.txtLuu = new System.Windows.Forms.Button();
            this.txtXoa = new System.Windows.Forms.Button();
            this.txtSua = new System.Windows.Forms.Button();
            this.txtThem = new System.Windows.Forms.Button();
            this.hOADONLEDataGridView = new System.Windows.Forms.DataGridView();
            this.STT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvMaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvTenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvDonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvSoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvDonViTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvKhuyenMai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvThanhTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HienThiChinh = new System.Windows.Forms.TableLayoutPanel();
            this.ThongTinMatHang = new System.Windows.Forms.GroupBox();
            this.btnInHoaDon = new System.Windows.Forms.Button();
            this.soluongTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.mAHANGTextBox = new System.Windows.Forms.TextBox();
            this.lOAITextBox = new System.Windows.Forms.TextBox();
            this.dMHANGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tENHANGTextBox = new System.Windows.Forms.TextBox();
            this.gIABANTextBox = new System.Windows.Forms.TextBox();
            this.dVTINHTextBox = new System.Windows.Forms.TextBox();
            this.ThanhTien = new System.Windows.Forms.GroupBox();
            this.txThoiLai = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtKhachTra = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            mAHANGLabel = new System.Windows.Forms.Label();
            lOAILabel = new System.Windows.Forms.Label();
            tENHANGLabel = new System.Windows.Forms.Label();
            gIABANLabel = new System.Windows.Forms.Label();
            dVTINHLabel = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hOADONLEBindingSource)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.NutChucNang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hOADONLEDataGridView)).BeginInit();
            this.HienThiChinh.SuspendLayout();
            this.ThongTinMatHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dMHANGBindingSource)).BeginInit();
            this.ThanhTien.SuspendLayout();
            this.SuspendLayout();
            // 
            // mAHANGLabel
            // 
            mAHANGLabel.AutoSize = true;
            mAHANGLabel.Location = new System.Drawing.Point(10, 32);
            mAHANGLabel.Name = "mAHANGLabel";
            mAHANGLabel.Size = new System.Drawing.Size(52, 13);
            mAHANGLabel.TabIndex = 0;
            mAHANGLabel.Text = "Mã hàng:";
            // 
            // lOAILabel
            // 
            lOAILabel.AutoSize = true;
            lOAILabel.Location = new System.Drawing.Point(10, 58);
            lOAILabel.Name = "lOAILabel";
            lOAILabel.Size = new System.Drawing.Size(30, 13);
            lOAILabel.TabIndex = 1;
            lOAILabel.Text = "Loại:";
            // 
            // tENHANGLabel
            // 
            tENHANGLabel.AutoSize = true;
            tENHANGLabel.Location = new System.Drawing.Point(10, 84);
            tENHANGLabel.Name = "tENHANGLabel";
            tENHANGLabel.Size = new System.Drawing.Size(56, 13);
            tENHANGLabel.TabIndex = 4;
            tENHANGLabel.Text = "Tên hàng:";
            // 
            // gIABANLabel
            // 
            gIABANLabel.AutoSize = true;
            gIABANLabel.Location = new System.Drawing.Point(10, 110);
            gIABANLabel.Name = "gIABANLabel";
            gIABANLabel.Size = new System.Drawing.Size(47, 13);
            gIABANLabel.TabIndex = 6;
            gIABANLabel.Text = "Giá bán:";
            // 
            // dVTINHLabel
            // 
            dVTINHLabel.AutoSize = true;
            dVTINHLabel.Location = new System.Drawing.Point(10, 136);
            dVTINHLabel.Name = "dVTINHLabel";
            dVTINHLabel.Size = new System.Drawing.Size(63, 13);
            dVTINHLabel.TabIndex = 8;
            dVTINHLabel.Text = "Đơn vị tính:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.nghiệpVụToolStripMenuItem,
            this.tiệnÍchToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(759, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smtThongTinPhienLamViec,
            this.thôngTinTàuKhoảnToolStripMenuItem,
            this.toolStripSeparator1,
            this.smiDangXuat,
            this.smiThoatChuongTrinh});
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.hệThốngToolStripMenuItem.Text = "&Hệ thống";
            // 
            // smtThongTinPhienLamViec
            // 
            this.smtThongTinPhienLamViec.Name = "smtThongTinPhienLamViec";
            this.smtThongTinPhienLamViec.Size = new System.Drawing.Size(206, 22);
            this.smtThongTinPhienLamViec.Text = "Thông tin &phiên làm việc";
            // 
            // thôngTinTàuKhoảnToolStripMenuItem
            // 
            this.thôngTinTàuKhoảnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiDoiMatKhau,
            this.smiCapNhatThongTin});
            this.thôngTinTàuKhoảnToolStripMenuItem.Name = "thôngTinTàuKhoảnToolStripMenuItem";
            this.thôngTinTàuKhoảnToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.thôngTinTàuKhoảnToolStripMenuItem.Text = "Tài &khoản";
            // 
            // smiDoiMatKhau
            // 
            this.smiDoiMatKhau.Name = "smiDoiMatKhau";
            this.smiDoiMatKhau.Size = new System.Drawing.Size(174, 22);
            this.smiDoiMatKhau.Text = "Đổi &mật khẩu";
            // 
            // smiCapNhatThongTin
            // 
            this.smiCapNhatThongTin.Name = "smiCapNhatThongTin";
            this.smiCapNhatThongTin.Size = new System.Drawing.Size(174, 22);
            this.smiCapNhatThongTin.Text = "&Cập nhật thông tin";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(203, 6);
            // 
            // smiDangXuat
            // 
            this.smiDangXuat.Name = "smiDangXuat";
            this.smiDangXuat.Size = new System.Drawing.Size(206, 22);
            this.smiDangXuat.Text = "Đăng &xuất";
            // 
            // smiThoatChuongTrinh
            // 
            this.smiThoatChuongTrinh.Name = "smiThoatChuongTrinh";
            this.smiThoatChuongTrinh.Size = new System.Drawing.Size(206, 22);
            this.smiThoatChuongTrinh.Text = "&Thoát chương trình";
            this.smiThoatChuongTrinh.Click += new System.EventHandler(this.smiThoatChuongTrinh_Click);
            // 
            // nghiệpVụToolStripMenuItem
            // 
            this.nghiệpVụToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiThongTinHangDaBan,
            this.smiInHoaDonBanLe});
            this.nghiệpVụToolStripMenuItem.Name = "nghiệpVụToolStripMenuItem";
            this.nghiệpVụToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.nghiệpVụToolStripMenuItem.Text = "&Nghiệp vụ";
            // 
            // smiThongTinHangDaBan
            // 
            this.smiThongTinHangDaBan.Name = "smiThongTinHangDaBan";
            this.smiThongTinHangDaBan.Size = new System.Drawing.Size(195, 22);
            this.smiThongTinHangDaBan.Text = "&Thông tin hàng đã bán";
            // 
            // smiInHoaDonBanLe
            // 
            this.smiInHoaDonBanLe.Name = "smiInHoaDonBanLe";
            this.smiInHoaDonBanLe.Size = new System.Drawing.Size(195, 22);
            this.smiInHoaDonBanLe.Text = "&In hoá đơn bán lẻ";
            // 
            // tiệnÍchToolStripMenuItem
            // 
            this.tiệnÍchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiMayTinhMini,
            this.toolStripSeparator4,
            this.smiXemTiGia,
            this.smiDoiTien});
            this.tiệnÍchToolStripMenuItem.Name = "tiệnÍchToolStripMenuItem";
            this.tiệnÍchToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.tiệnÍchToolStripMenuItem.Text = "Tiện &ích";
            // 
            // smiMayTinhMini
            // 
            this.smiMayTinhMini.Name = "smiMayTinhMini";
            this.smiMayTinhMini.Size = new System.Drawing.Size(148, 22);
            this.smiMayTinhMini.Text = "&Máy tính mini";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(145, 6);
            // 
            // smiXemTiGia
            // 
            this.smiXemTiGia.Name = "smiXemTiGia";
            this.smiXemTiGia.Size = new System.Drawing.Size(148, 22);
            this.smiXemTiGia.Text = "Xem &tỉ giá";
            // 
            // smiDoiTien
            // 
            this.smiDoiTien.Name = "smiDoiTien";
            this.smiDoiTien.Size = new System.Drawing.Size(148, 22);
            this.smiDoiTien.Text = "Đổi tiề&n";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiHuongDanSuDung,
            this.toolStripSeparator2,
            this.smiCapNhatChuongTrinh,
            this.smiBaoCaoLoi,
            this.toolStripSeparator3,
            this.smiThongTinPhanMemBanHang,
            this.toolStripTextBox1});
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ &giúp";
            // 
            // smiHuongDanSuDung
            // 
            this.smiHuongDanSuDung.Name = "smiHuongDanSuDung";
            this.smiHuongDanSuDung.Size = new System.Drawing.Size(240, 22);
            this.smiHuongDanSuDung.Text = "Hướng dẫn &sử dụng";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(237, 6);
            // 
            // smiCapNhatChuongTrinh
            // 
            this.smiCapNhatChuongTrinh.Name = "smiCapNhatChuongTrinh";
            this.smiCapNhatChuongTrinh.Size = new System.Drawing.Size(240, 22);
            this.smiCapNhatChuongTrinh.Text = "&Cập nhật chương trình";
            // 
            // smiBaoCaoLoi
            // 
            this.smiBaoCaoLoi.Name = "smiBaoCaoLoi";
            this.smiBaoCaoLoi.Size = new System.Drawing.Size(240, 22);
            this.smiBaoCaoLoi.Text = "Báo cáo &lỗi";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(237, 6);
            // 
            // smiThongTinPhanMemBanHang
            // 
            this.smiThongTinPhanMemBanHang.Name = "smiThongTinPhanMemBanHang";
            this.smiThongTinPhanMemBanHang.Size = new System.Drawing.Size(240, 22);
            this.smiThongTinPhanMemBanHang.Text = "Thông tin phần mềm &bán hàng";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.BackColor = System.Drawing.Color.White;
            this.toolStripTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.toolStripTextBox1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(120, 12);
            this.toolStripTextBox1.Text = "© 2011 QLST – Version 1.0";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripProgressBar1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 535);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(762, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel1.Text = "Ready";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Margin = new System.Windows.Forms.Padding(5, 3, 1, 3);
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.HienThiChinh);
            this.panel1.Controls.Add(this.statusStrip1);
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(762, 557);
            this.panel1.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.NutChucNang);
            this.groupBox3.Controls.Add(this.hOADONLEDataGridView);
            this.groupBox3.Location = new System.Drawing.Point(0, 234);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(759, 296);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Thông tin các mặt hàng của khách hàng hiện tại";
            // 
            // NutChucNang
            // 
            this.NutChucNang.Controls.Add(this.btnCuoiDanhSach);
            this.NutChucNang.Controls.Add(this.btnToi);
            this.NutChucNang.Controls.Add(this.btnLui);
            this.NutChucNang.Controls.Add(this.btnDauDanhSach);
            this.NutChucNang.Controls.Add(this.txtLuu);
            this.NutChucNang.Controls.Add(this.txtXoa);
            this.NutChucNang.Controls.Add(this.txtSua);
            this.NutChucNang.Controls.Add(this.txtThem);
            this.NutChucNang.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.NutChucNang.Location = new System.Drawing.Point(3, 258);
            this.NutChucNang.Name = "NutChucNang";
            this.NutChucNang.Size = new System.Drawing.Size(753, 35);
            this.NutChucNang.TabIndex = 1;
            // 
            // btnCuoiDanhSach
            // 
            this.btnCuoiDanhSach.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.next_green;
            this.btnCuoiDanhSach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCuoiDanhSach.Location = new System.Drawing.Point(112, 5);
            this.btnCuoiDanhSach.Name = "btnCuoiDanhSach";
            this.btnCuoiDanhSach.Size = new System.Drawing.Size(27, 27);
            this.btnCuoiDanhSach.TabIndex = 3;
            this.btnCuoiDanhSach.UseVisualStyleBackColor = true;
            // 
            // btnToi
            // 
            this.btnToi.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.play_green;
            this.btnToi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnToi.Location = new System.Drawing.Point(79, 5);
            this.btnToi.Name = "btnToi";
            this.btnToi.Size = new System.Drawing.Size(27, 27);
            this.btnToi.TabIndex = 2;
            this.btnToi.UseVisualStyleBackColor = true;
            // 
            // btnLui
            // 
            this.btnLui.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.reverse_green;
            this.btnLui.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLui.Location = new System.Drawing.Point(46, 5);
            this.btnLui.Name = "btnLui";
            this.btnLui.Size = new System.Drawing.Size(27, 27);
            this.btnLui.TabIndex = 1;
            this.btnLui.UseVisualStyleBackColor = true;
            // 
            // btnDauDanhSach
            // 
            this.btnDauDanhSach.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.previous_green;
            this.btnDauDanhSach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDauDanhSach.Location = new System.Drawing.Point(13, 5);
            this.btnDauDanhSach.Name = "btnDauDanhSach";
            this.btnDauDanhSach.Size = new System.Drawing.Size(27, 27);
            this.btnDauDanhSach.TabIndex = 0;
            this.btnDauDanhSach.UseVisualStyleBackColor = true;
            // 
            // txtLuu
            // 
            this.txtLuu.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.save_icon;
            this.txtLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtLuu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLuu.Location = new System.Drawing.Point(357, 5);
            this.txtLuu.Name = "txtLuu";
            this.txtLuu.Size = new System.Drawing.Size(86, 27);
            this.txtLuu.TabIndex = 6;
            this.txtLuu.Text = "&Lưu";
            this.txtLuu.UseVisualStyleBackColor = true;
            // 
            // txtXoa
            // 
            this.txtXoa.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.delete_Icon;
            this.txtXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtXoa.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXoa.Location = new System.Drawing.Point(451, 5);
            this.txtXoa.Name = "txtXoa";
            this.txtXoa.Size = new System.Drawing.Size(86, 27);
            this.txtXoa.TabIndex = 7;
            this.txtXoa.Text = "&Xoá";
            this.txtXoa.UseVisualStyleBackColor = true;
            // 
            // txtSua
            // 
            this.txtSua.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.icon_edit;
            this.txtSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtSua.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSua.Location = new System.Drawing.Point(263, 5);
            this.txtSua.Name = "txtSua";
            this.txtSua.Size = new System.Drawing.Size(86, 27);
            this.txtSua.TabIndex = 5;
            this.txtSua.Text = "&Sửa";
            this.txtSua.UseVisualStyleBackColor = true;
            // 
            // txtThem
            // 
            this.txtThem.BackgroundImage = global::QuanLySieuThi_Winform.Properties.Resources.ico;
            this.txtThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.txtThem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThem.Location = new System.Drawing.Point(169, 5);
            this.txtThem.Name = "txtThem";
            this.txtThem.Size = new System.Drawing.Size(86, 27);
            this.txtThem.TabIndex = 4;
            this.txtThem.Text = "&Thêm";
            this.txtThem.UseVisualStyleBackColor = true;
            // 
            // hOADONLEDataGridView
            // 
            this.hOADONLEDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.hOADONLEDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.hOADONLEDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hOADONLEDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.STT,
            this.dgvMaHang,
            this.dgvTenHang,
            this.dgvDonGia,
            this.dgvSoLuong,
            this.dgvDonViTinh,
            this.dgvKhuyenMai,
            this.dgvThanhTien});
            this.hOADONLEDataGridView.Location = new System.Drawing.Point(6, 19);
            this.hOADONLEDataGridView.Name = "hOADONLEDataGridView";
            this.hOADONLEDataGridView.Size = new System.Drawing.Size(747, 237);
            this.hOADONLEDataGridView.TabIndex = 0;
            // 
            // STT
            // 
            this.STT.FillWeight = 40F;
            this.STT.HeaderText = "STT";
            this.STT.Name = "STT";
            // 
            // dgvMaHang
            // 
            this.dgvMaHang.FillWeight = 80F;
            this.dgvMaHang.HeaderText = "Mã hàng";
            this.dgvMaHang.Name = "dgvMaHang";
            // 
            // dgvTenHang
            // 
            this.dgvTenHang.FillWeight = 120F;
            this.dgvTenHang.HeaderText = "Tên Hàng";
            this.dgvTenHang.Name = "dgvTenHang";
            // 
            // dgvDonGia
            // 
            this.dgvDonGia.FillWeight = 70F;
            this.dgvDonGia.HeaderText = "Đơn giá";
            this.dgvDonGia.Name = "dgvDonGia";
            // 
            // dgvSoLuong
            // 
            this.dgvSoLuong.FillWeight = 40F;
            this.dgvSoLuong.HeaderText = "Số lượng";
            this.dgvSoLuong.Name = "dgvSoLuong";
            // 
            // dgvDonViTinh
            // 
            this.dgvDonViTinh.FillWeight = 60F;
            this.dgvDonViTinh.HeaderText = "ĐV Tính";
            this.dgvDonViTinh.Name = "dgvDonViTinh";
            // 
            // dgvKhuyenMai
            // 
            this.dgvKhuyenMai.FillWeight = 80F;
            this.dgvKhuyenMai.HeaderText = "Khuyến Mãi";
            this.dgvKhuyenMai.Name = "dgvKhuyenMai";
            // 
            // dgvThanhTien
            // 
            this.dgvThanhTien.HeaderText = "Thành Tiền";
            this.dgvThanhTien.Name = "dgvThanhTien";
            // 
            // HienThiChinh
            // 
            this.HienThiChinh.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.HienThiChinh.AutoSize = true;
            this.HienThiChinh.ColumnCount = 2;
            this.HienThiChinh.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.90027F));
            this.HienThiChinh.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.09973F));
            this.HienThiChinh.Controls.Add(this.ThongTinMatHang, 0, 0);
            this.HienThiChinh.Controls.Add(this.ThanhTien, 1, 0);
            this.HienThiChinh.Location = new System.Drawing.Point(0, 0);
            this.HienThiChinh.Name = "HienThiChinh";
            this.HienThiChinh.RowCount = 1;
            this.HienThiChinh.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53F));
            this.HienThiChinh.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 231F));
            this.HienThiChinh.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 231F));
            this.HienThiChinh.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 231F));
            this.HienThiChinh.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 231F));
            this.HienThiChinh.Size = new System.Drawing.Size(759, 231);
            this.HienThiChinh.TabIndex = 2;
            // 
            // ThongTinMatHang
            // 
            this.ThongTinMatHang.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ThongTinMatHang.AutoSize = true;
            this.ThongTinMatHang.Controls.Add(this.btnInHoaDon);
            this.ThongTinMatHang.Controls.Add(this.soluongTextBox);
            this.ThongTinMatHang.Controls.Add(this.label1);
            this.ThongTinMatHang.Controls.Add(mAHANGLabel);
            this.ThongTinMatHang.Controls.Add(this.mAHANGTextBox);
            this.ThongTinMatHang.Controls.Add(lOAILabel);
            this.ThongTinMatHang.Controls.Add(this.lOAITextBox);
            this.ThongTinMatHang.Controls.Add(tENHANGLabel);
            this.ThongTinMatHang.Controls.Add(this.tENHANGTextBox);
            this.ThongTinMatHang.Controls.Add(gIABANLabel);
            this.ThongTinMatHang.Controls.Add(this.gIABANTextBox);
            this.ThongTinMatHang.Controls.Add(dVTINHLabel);
            this.ThongTinMatHang.Controls.Add(this.dVTINHTextBox);
            this.ThongTinMatHang.Location = new System.Drawing.Point(3, 3);
            this.ThongTinMatHang.Name = "ThongTinMatHang";
            this.ThongTinMatHang.Size = new System.Drawing.Size(349, 225);
            this.ThongTinMatHang.TabIndex = 0;
            this.ThongTinMatHang.TabStop = false;
            this.ThongTinMatHang.Text = "Thông tin mặt hàng";
            // 
            // btnInHoaDon
            // 
            this.btnInHoaDon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInHoaDon.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInHoaDon.ForeColor = System.Drawing.Color.Red;
            this.btnInHoaDon.Location = new System.Drawing.Point(197, 162);
            this.btnInHoaDon.Margin = new System.Windows.Forms.Padding(0);
            this.btnInHoaDon.Name = "btnInHoaDon";
            this.btnInHoaDon.Size = new System.Drawing.Size(138, 47);
            this.btnInHoaDon.TabIndex = 12;
            this.btnInHoaDon.Text = "IN HOÁ ĐƠN";
            this.btnInHoaDon.UseVisualStyleBackColor = true;
            // 
            // soluongTextBox
            // 
            this.soluongTextBox.Location = new System.Drawing.Point(79, 159);
            this.soluongTextBox.Name = "soluongTextBox";
            this.soluongTextBox.Size = new System.Drawing.Size(112, 20);
            this.soluongTextBox.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Số lượng:";
            // 
            // mAHANGTextBox
            // 
            this.mAHANGTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.mAHANGTextBox.Location = new System.Drawing.Point(79, 29);
            this.mAHANGTextBox.Name = "mAHANGTextBox";
            this.mAHANGTextBox.Size = new System.Drawing.Size(251, 20);
            this.mAHANGTextBox.TabIndex = 1;
            // 
            // lOAITextBox
            // 
            this.lOAITextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lOAITextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dMHANGBindingSource, "LOAI", true));
            this.lOAITextBox.Location = new System.Drawing.Point(79, 55);
            this.lOAITextBox.Name = "lOAITextBox";
            this.lOAITextBox.Size = new System.Drawing.Size(251, 20);
            this.lOAITextBox.TabIndex = 3;
            // 
            // tENHANGTextBox
            // 
            this.tENHANGTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tENHANGTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dMHANGBindingSource, "TENHANG", true));
            this.tENHANGTextBox.Location = new System.Drawing.Point(79, 81);
            this.tENHANGTextBox.Name = "tENHANGTextBox";
            this.tENHANGTextBox.Size = new System.Drawing.Size(251, 20);
            this.tENHANGTextBox.TabIndex = 5;
            // 
            // gIABANTextBox
            // 
            this.gIABANTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gIABANTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dMHANGBindingSource, "GIABAN", true));
            this.gIABANTextBox.Location = new System.Drawing.Point(79, 107);
            this.gIABANTextBox.Name = "gIABANTextBox";
            this.gIABANTextBox.Size = new System.Drawing.Size(251, 20);
            this.gIABANTextBox.TabIndex = 7;
            // 
            // dVTINHTextBox
            // 
            this.dVTINHTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dVTINHTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dMHANGBindingSource, "DVTINH", true));
            this.dVTINHTextBox.Location = new System.Drawing.Point(79, 133);
            this.dVTINHTextBox.Name = "dVTINHTextBox";
            this.dVTINHTextBox.Size = new System.Drawing.Size(251, 20);
            this.dVTINHTextBox.TabIndex = 9;
            // 
            // ThanhTien
            // 
            this.ThanhTien.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ThanhTien.AutoSize = true;
            this.ThanhTien.Controls.Add(this.txThoiLai);
            this.ThanhTien.Controls.Add(this.label4);
            this.ThanhTien.Controls.Add(this.txtKhachTra);
            this.ThanhTien.Controls.Add(this.label3);
            this.ThanhTien.Controls.Add(this.txtThanhTien);
            this.ThanhTien.Controls.Add(this.label2);
            this.ThanhTien.Location = new System.Drawing.Point(358, 3);
            this.ThanhTien.Name = "ThanhTien";
            this.ThanhTien.Size = new System.Drawing.Size(398, 225);
            this.ThanhTien.TabIndex = 1;
            this.ThanhTien.TabStop = false;
            this.ThanhTien.Text = "Thành tiền hoá đơn hiện tại";
            // 
            // txThoiLai
            // 
            this.txThoiLai.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txThoiLai.BackColor = System.Drawing.Color.DarkBlue;
            this.txThoiLai.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txThoiLai.ForeColor = System.Drawing.Color.Yellow;
            this.txThoiLai.Location = new System.Drawing.Point(6, 169);
            this.txThoiLai.Margin = new System.Windows.Forms.Padding(0);
            this.txThoiLai.Name = "txThoiLai";
            this.txThoiLai.ReadOnly = true;
            this.txThoiLai.Size = new System.Drawing.Size(383, 40);
            this.txThoiLai.TabIndex = 0;
            this.txThoiLai.Text = "0 VNĐ";
            this.txThoiLai.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "THỐI LẠI";
            // 
            // txtKhachTra
            // 
            this.txtKhachTra.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKhachTra.BackColor = System.Drawing.Color.DarkBlue;
            this.txtKhachTra.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKhachTra.ForeColor = System.Drawing.Color.Goldenrod;
            this.txtKhachTra.Location = new System.Drawing.Point(6, 106);
            this.txtKhachTra.Name = "txtKhachTra";
            this.txtKhachTra.ReadOnly = true;
            this.txtKhachTra.Size = new System.Drawing.Size(383, 40);
            this.txtKhachTra.TabIndex = 0;
            this.txtKhachTra.Text = "0 VNĐ";
            this.txtKhachTra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "KHÁCH TRẢ";
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtThanhTien.BackColor = System.Drawing.Color.Lavender;
            this.txtThanhTien.Font = new System.Drawing.Font("Tahoma", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThanhTien.ForeColor = System.Drawing.Color.Red;
            this.txtThanhTien.Location = new System.Drawing.Point(3, 36);
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.ReadOnly = true;
            this.txtThanhTien.Size = new System.Drawing.Size(386, 43);
            this.txtThanhTien.TabIndex = 0;
            this.txtThanhTien.Text = "0 VNĐ";
            this.txtThanhTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "THÀNH TIỀN";
            // 
            // FormBanHang
            // 
            this.AcceptButton = this.btnInHoaDon;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 581);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(767, 608);
            this.Name = "FormBanHang";
            this.Text = "SLST --- Bán hàng siêu thị";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hOADONLEBindingSource)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.NutChucNang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.hOADONLEDataGridView)).EndInit();
            this.HienThiChinh.ResumeLayout(false);
            this.HienThiChinh.PerformLayout();
            this.ThongTinMatHang.ResumeLayout(false);
            this.ThongTinMatHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dMHANGBindingSource)).EndInit();
            this.ThanhTien.ResumeLayout(false);
            this.ThanhTien.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smtThongTinPhienLamViec;
        private System.Windows.Forms.ToolStripMenuItem thôngTinTàuKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smiDoiMatKhau;
        private System.Windows.Forms.ToolStripMenuItem smiCapNhatThongTin;
        private System.Windows.Forms.ToolStripMenuItem nghiệpVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiệnÍchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem smiDangXuat;
        private System.Windows.Forms.ToolStripMenuItem smiThoatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem smiThongTinHangDaBan;
        private System.Windows.Forms.ToolStripMenuItem smiInHoaDonBanLe;
        private System.Windows.Forms.ToolStripMenuItem smiMayTinhMini;
        private System.Windows.Forms.ToolStripMenuItem smiXemTiGia;
        private System.Windows.Forms.ToolStripMenuItem smiDoiTien;
        private System.Windows.Forms.ToolStripMenuItem smiHuongDanSuDung;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem smiCapNhatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem smiBaoCaoLoi;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem smiThongTinPhanMemBanHang;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.BindingSource hOADONLEBindingSource;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel HienThiChinh;
        private System.Windows.Forms.GroupBox ThongTinMatHang;
        private System.Windows.Forms.GroupBox ThanhTien;
        private System.Windows.Forms.BindingSource dMHANGBindingSource;
        private System.Windows.Forms.TextBox mAHANGTextBox;
        private System.Windows.Forms.TextBox lOAITextBox;
        private System.Windows.Forms.TextBox tENHANGTextBox;
        private System.Windows.Forms.TextBox gIABANTextBox;
        private System.Windows.Forms.TextBox dVTINHTextBox;
        private System.Windows.Forms.Button btnInHoaDon;
        private System.Windows.Forms.TextBox soluongTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txThoiLai;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtKhachTra;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtThanhTien;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView hOADONLEDataGridView;
        private System.Windows.Forms.Panel NutChucNang;
        private System.Windows.Forms.Button txtLuu;
        private System.Windows.Forms.Button txtXoa;
        private System.Windows.Forms.Button txtSua;
        private System.Windows.Forms.Button txtThem;
        private System.Windows.Forms.DataGridViewTextBoxColumn STT;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvMaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvTenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvDonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvSoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvDonViTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvKhuyenMai;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvThanhTien;
        private System.Windows.Forms.Button btnDauDanhSach;
        private System.Windows.Forms.Button btnCuoiDanhSach;
        private System.Windows.Forms.Button btnToi;
        private System.Windows.Forms.Button btnLui;
    }
}

