﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QuanLyKhoSieuThi.Presentation_Layer
{
    class DMHANG_OBJ
    {
        public string Manhom { get; set; }
        public string Mahang { get; set; }
        public string Tenhang { get; set; }
        public string Dvtinh { get; set; }
        public string Maloai { get; set; }
        public string Giaban { get; set; }
        public string Khuyenmai { get; set; }
        public string MaNCC { get; set; }
    }
}
