﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QuanLyKhoSieuThi.Data_Access_Layer
{
    class KHOHANG_OBJ
    {
        public string Makho { set; get; }
        public string Tenkho { set; get; }
        public string MaNV { set; get; }
        public string Diachi { set; get; }
        public string Dienthoai { set; get; }
    }
}
