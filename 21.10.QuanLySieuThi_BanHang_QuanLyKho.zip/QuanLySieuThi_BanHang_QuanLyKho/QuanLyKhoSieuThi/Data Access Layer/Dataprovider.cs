﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Windows.Forms;

namespace QuanLyKhoSieuThi.Data_Access_Layer
{
    class Dataprovider
    {
        SqlConnection connection;
        SqlCommand command;
        SqlDataAdapter adapter;
        DataTable dt;
        public string messageErrors = null;
        public string connStr = @"";
                
        public void openConnection()
        {
            connection = new SqlConnection(connStr);
            connection.Open();                
        }

        public void closeConnection()
        {
            connection.Close();
        }

        public bool excuteNonQuery(string sqlQuery)
        {
            try
            {
                command = new SqlCommand(sqlQuery, connection);
                command.ExecuteNonQuery();
                return true;

            }
            catch (Exception ex)
            {
                messageErrors = ex.Message;
                return false;
            }
                        
        }
        public int countQuantity(string sql)
        
        {
            command = new SqlCommand(sql, connection);           
            return (Int32) command.ExecuteScalar();
        }

        public object excuteScalar(string sql)
        {
            if (connection.State == ConnectionState.Closed)
                openConnection();
            command = new SqlCommand(sql, connection);
            return command.ExecuteScalar();
            closeConnection();
        }

        public DataTable getDataTable(string sql, bool setDataProperties = false)  ///Lay ve mot table trong CDSL roi tra ve cho cau lenh
        {
            if(setDataProperties)   //cờ cho phép fill dataTable vao adapter, luu tu Dgv xuong CSDL
            {
                adapter = new SqlDataAdapter(sql,connection);
                dt = new DataTable();
                adapter.Fill(dt);
                return dt;
            }
            else
            {
                SqlDataAdapter NewAdapter = new SqlDataAdapter(sql,connection);  //lay du lieu tu CSDL ra ngoai dgv
                DataTable Newdt = new DataTable();
                NewAdapter.Fill(Newdt);
                return Newdt;

            }
        }
       
        // phuong thuc cap nhat dataGribView xuong CSDL
        public int SaveToDB()
        {
            int numRecords=0;
         
            try
            {

                if (connection.State == ConnectionState.Closed)
                    openConnection();
                // doi tuong sqlCommandBuilder quan ly viec thay doi du lieu vao DB
                SqlCommandBuilder sBuilder = new SqlCommandBuilder(adapter);   //cho phep dong bo tu dgv vao CSDL
                numRecords = adapter.Update(dt);
            }
            catch (Exception ex)
            {
                throw;
            }

            if (connection.State == ConnectionState.Open)
                closeConnection();

            return numRecords;
        }
        //public void fillExDataTable(DataTable dtb)
        //{
        //    try
        //    {

        //        adapter.Fill(dtb);
        //    }
        //    catch (Exception ex)
        //    {
        //        messageErrors = ex.Message;
        //    }
        //}

    }
}
