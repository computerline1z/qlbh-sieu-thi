﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QuanLyKhoSieuThi.Data_Access_Layer
{
    class DANHMUCLOAIHANG_OBJ
    {
        public string Maloai { get; set; }
        public string Tenloai { get; set; }
    }
}
