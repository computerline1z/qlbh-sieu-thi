﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucDVT
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDVT = new System.Windows.Forms.TextBox();
            this.grbButton = new System.Windows.Forms.GroupBox();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.lblDVT = new System.Windows.Forms.Label();
            this.lstDVT = new System.Windows.Forms.ListBox();
            this.grbButton.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtDVT
            // 
            this.txtDVT.Location = new System.Drawing.Point(13, 29);
            this.txtDVT.Name = "txtDVT";
            this.txtDVT.Size = new System.Drawing.Size(151, 20);
            this.txtDVT.TabIndex = 17;
            // 
            // grbButton
            // 
            this.grbButton.Controls.Add(this.btnLuu);
            this.grbButton.Controls.Add(this.btnThem);
            this.grbButton.Controls.Add(this.btnSua);
            this.grbButton.Controls.Add(this.btnXoa);
            this.grbButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbButton.Location = new System.Drawing.Point(185, 58);
            this.grbButton.Name = "grbButton";
            this.grbButton.Size = new System.Drawing.Size(94, 199);
            this.grbButton.TabIndex = 16;
            this.grbButton.TabStop = false;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(15, 151);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(65, 25);
            this.btnLuu.TabIndex = 14;
            this.btnLuu.Text = "&Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            // 
            // btnThem
            // 
            this.btnThem.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.add_icon;
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(15, 22);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(65, 25);
            this.btnThem.TabIndex = 12;
            this.btnThem.Text = "  &Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.icon_edit;
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(15, 66);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(65, 25);
            this.btnSua.TabIndex = 13;
            this.btnSua.Text = "&Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.delete_Icon;
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(15, 109);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(65, 25);
            this.btnXoa.TabIndex = 15;
            this.btnXoa.Text = "&Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // lblDVT
            // 
            this.lblDVT.AutoSize = true;
            this.lblDVT.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDVT.Location = new System.Drawing.Point(10, 11);
            this.lblDVT.Name = "lblDVT";
            this.lblDVT.Size = new System.Drawing.Size(93, 15);
            this.lblDVT.TabIndex = 15;
            this.lblDVT.Text = "Tên đơn vị tính:";
            // 
            // lstDVT
            // 
            this.lstDVT.FormattingEnabled = true;
            this.lstDVT.Location = new System.Drawing.Point(13, 58);
            this.lstDVT.Name = "lstDVT";
            this.lstDVT.Size = new System.Drawing.Size(151, 199);
            this.lstDVT.TabIndex = 14;
            // 
            // usDVT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtDVT);
            this.Controls.Add(this.grbButton);
            this.Controls.Add(this.lblDVT);
            this.Controls.Add(this.lstDVT);
            this.Name = "usDVT";
            this.Size = new System.Drawing.Size(296, 279);
            this.grbButton.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDVT;
        private System.Windows.Forms.GroupBox grbButton;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Label lblDVT;
        private System.Windows.Forms.ListBox lstDVT;
    }
}
