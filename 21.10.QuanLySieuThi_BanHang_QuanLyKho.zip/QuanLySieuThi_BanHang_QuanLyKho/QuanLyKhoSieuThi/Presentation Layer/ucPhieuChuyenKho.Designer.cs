﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucPhieuChuyenKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucPhieuChuyenKho));
            this.grbThongTinPhieuChuyenKho = new System.Windows.Forms.GroupBox();
            this.tblpThongTinPhieuChuyen = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorPC = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemPC = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemPC = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemPC = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemPC = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemPC = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemPC = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemPC = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemPC = new System.Windows.Forms.ToolStripButton();
            this.dgvThongTinPC = new System.Windows.Forms.DataGridView();
            this.MaPC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NhanVienChuyen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ChuyenDenKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayChuyen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongSL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblpPhieuChuyen = new System.Windows.Forms.TableLayoutPanel();
            this.grbChiTietPhieuChuyenKho = new System.Windows.Forms.GroupBox();
            this.tblpChiTietPhieuChuyen = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorCTPC = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemCTPC = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem1 = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemCTPC = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemCTPC = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemCTPC = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemCTPC = new System.Windows.Forms.ToolStripTextBox();
            this.tsSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemCTPC = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemCTPC = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemCTPC = new System.Windows.Forms.ToolStripButton();
            this.dgvChiTietPhieuNhap = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinPhieuChuyenKho.SuspendLayout();
            this.tblpThongTinPhieuChuyen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorPC)).BeginInit();
            this.bindingNavigatorPC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPC)).BeginInit();
            this.tblpPhieuChuyen.SuspendLayout();
            this.grbChiTietPhieuChuyenKho.SuspendLayout();
            this.tblpChiTietPhieuChuyen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorCTPC)).BeginInit();
            this.bindingNavigatorCTPC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuNhap)).BeginInit();
            this.SuspendLayout();
            // 
            // grbThongTinPhieuChuyenKho
            // 
            this.grbThongTinPhieuChuyenKho.Controls.Add(this.tblpThongTinPhieuChuyen);
            this.grbThongTinPhieuChuyenKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinPhieuChuyenKho.Location = new System.Drawing.Point(6, 6);
            this.grbThongTinPhieuChuyenKho.Name = "grbThongTinPhieuChuyenKho";
            this.grbThongTinPhieuChuyenKho.Size = new System.Drawing.Size(686, 213);
            this.grbThongTinPhieuChuyenKho.TabIndex = 4;
            this.grbThongTinPhieuChuyenKho.TabStop = false;
            this.grbThongTinPhieuChuyenKho.Text = "Thông tin phiếu chuyển kho";
            // 
            // tblpThongTinPhieuChuyen
            // 
            this.tblpThongTinPhieuChuyen.ColumnCount = 1;
            this.tblpThongTinPhieuChuyen.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpThongTinPhieuChuyen.Controls.Add(this.bindingNavigatorPC, 0, 0);
            this.tblpThongTinPhieuChuyen.Controls.Add(this.dgvThongTinPC, 0, 1);
            this.tblpThongTinPhieuChuyen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpThongTinPhieuChuyen.Location = new System.Drawing.Point(3, 16);
            this.tblpThongTinPhieuChuyen.Name = "tblpThongTinPhieuChuyen";
            this.tblpThongTinPhieuChuyen.RowCount = 2;
            this.tblpThongTinPhieuChuyen.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tblpThongTinPhieuChuyen.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpThongTinPhieuChuyen.Size = new System.Drawing.Size(680, 194);
            this.tblpThongTinPhieuChuyen.TabIndex = 0;
            // 
            // bindingNavigatorPC
            // 
            this.bindingNavigatorPC.AddNewItem = this.tsbAddNewItemPC;
            this.bindingNavigatorPC.CountItem = this.tslCountItem;
            this.bindingNavigatorPC.DeleteItem = this.tsbDeleteItemPC;
            this.bindingNavigatorPC.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemPC,
            this.tsbMovePreviousItemPC,
            this.tsSeparator,
            this.tstbPositionItemPC,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemPC,
            this.tsbMoveLastItemPC,
            this.tslSeparator2,
            this.tsbAddNewItemPC,
            this.tsbDeleteItemPC,
            this.tsbSaveNewItemPC});
            this.bindingNavigatorPC.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigatorPC.MoveFirstItem = this.tsbMoveFirstItemPC;
            this.bindingNavigatorPC.MoveLastItem = this.tsbMoveLastItemPC;
            this.bindingNavigatorPC.MoveNextItem = this.tsbMoveNextItemPC;
            this.bindingNavigatorPC.MovePreviousItem = this.tsbMovePreviousItemPC;
            this.bindingNavigatorPC.Name = "bindingNavigatorPC";
            this.bindingNavigatorPC.PositionItem = this.tstbPositionItemPC;
            this.bindingNavigatorPC.Size = new System.Drawing.Size(680, 25);
            this.bindingNavigatorPC.TabIndex = 5;
            this.bindingNavigatorPC.Text = "bindingNavigator1";
            // 
            // tsbAddNewItemPC
            // 
            this.tsbAddNewItemPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemPC.Image")));
            this.tsbAddNewItemPC.Name = "tsbAddNewItemPC";
            this.tsbAddNewItemPC.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemPC.Size = new System.Drawing.Size(23, 22);
            this.tsbAddNewItemPC.Text = "Add new";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 22);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemPC
            // 
            this.tsbDeleteItemPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemPC.Image")));
            this.tsbDeleteItemPC.Name = "tsbDeleteItemPC";
            this.tsbDeleteItemPC.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemPC.Size = new System.Drawing.Size(23, 22);
            this.tsbDeleteItemPC.Text = "Delete";
            // 
            // tsbMoveFirstItemPC
            // 
            this.tsbMoveFirstItemPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemPC.Image")));
            this.tsbMoveFirstItemPC.Name = "tsbMoveFirstItemPC";
            this.tsbMoveFirstItemPC.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemPC.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveFirstItemPC.Text = "Move first";
            // 
            // tsbMovePreviousItemPC
            // 
            this.tsbMovePreviousItemPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemPC.Image")));
            this.tsbMovePreviousItemPC.Name = "tsbMovePreviousItemPC";
            this.tsbMovePreviousItemPC.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemPC.Size = new System.Drawing.Size(23, 22);
            this.tsbMovePreviousItemPC.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // tstbPositionItemPC
            // 
            this.tstbPositionItemPC.AccessibleName = "Position";
            this.tstbPositionItemPC.AutoSize = false;
            this.tstbPositionItemPC.Name = "tstbPositionItemPC";
            this.tstbPositionItemPC.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemPC.Text = "0";
            this.tstbPositionItemPC.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbMoveNextItemPC
            // 
            this.tsbMoveNextItemPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemPC.Image")));
            this.tsbMoveNextItemPC.Name = "tsbMoveNextItemPC";
            this.tsbMoveNextItemPC.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemPC.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveNextItemPC.Text = "Move next";
            // 
            // tsbMoveLastItemPC
            // 
            this.tsbMoveLastItemPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemPC.Image")));
            this.tsbMoveLastItemPC.Name = "tsbMoveLastItemPC";
            this.tsbMoveLastItemPC.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemPC.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveLastItemPC.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbSaveNewItemPC
            // 
            this.tsbSaveNewItemPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemPC.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemPC.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemPC.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemPC.Name = "tsbSaveNewItemPC";
            this.tsbSaveNewItemPC.Size = new System.Drawing.Size(23, 22);
            this.tsbSaveNewItemPC.Text = "Save";
            // 
            // dgvThongTinPC
            // 
            this.dgvThongTinPC.AllowUserToOrderColumns = true;
            this.dgvThongTinPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinPC.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvThongTinPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinPC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPC,
            this.NhanVienChuyen,
            this.ChuyenDenKho,
            this.MaKho,
            this.NgayChuyen,
            this.TongSL});
            this.dgvThongTinPC.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvThongTinPC.Location = new System.Drawing.Point(3, 28);
            this.dgvThongTinPC.Name = "dgvThongTinPC";
            this.dgvThongTinPC.Size = new System.Drawing.Size(674, 163);
            this.dgvThongTinPC.TabIndex = 4;
            // 
            // MaPC
            // 
            this.MaPC.HeaderText = "Mã phiếu Chuyển";
            this.MaPC.Name = "MaPC";
            // 
            // NhanVienChuyen
            // 
            this.NhanVienChuyen.HeaderText = "Nhân Viên Chuyển";
            this.NhanVienChuyen.Name = "NhanVienChuyen";
            // 
            // ChuyenDenKho
            // 
            this.ChuyenDenKho.HeaderText = "Chuyển đến kho";
            this.ChuyenDenKho.Name = "ChuyenDenKho";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // NgayChuyen
            // 
            this.NgayChuyen.HeaderText = "Ngày chuyển";
            this.NgayChuyen.Name = "NgayChuyen";
            // 
            // TongSL
            // 
            this.TongSL.HeaderText = "Tổng số lượng";
            this.TongSL.Name = "TongSL";
            // 
            // tblpPhieuChuyen
            // 
            this.tblpPhieuChuyen.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tblpPhieuChuyen.ColumnCount = 1;
            this.tblpPhieuChuyen.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpPhieuChuyen.Controls.Add(this.grbChiTietPhieuChuyenKho, 0, 1);
            this.tblpPhieuChuyen.Controls.Add(this.grbThongTinPhieuChuyenKho, 0, 0);
            this.tblpPhieuChuyen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpPhieuChuyen.Location = new System.Drawing.Point(0, 0);
            this.tblpPhieuChuyen.Name = "tblpPhieuChuyen";
            this.tblpPhieuChuyen.RowCount = 2;
            this.tblpPhieuChuyen.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblpPhieuChuyen.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblpPhieuChuyen.Size = new System.Drawing.Size(698, 447);
            this.tblpPhieuChuyen.TabIndex = 7;
            // 
            // grbChiTietPhieuChuyenKho
            // 
            this.grbChiTietPhieuChuyenKho.Controls.Add(this.tblpChiTietPhieuChuyen);
            this.grbChiTietPhieuChuyenKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietPhieuChuyenKho.Location = new System.Drawing.Point(6, 228);
            this.grbChiTietPhieuChuyenKho.Name = "grbChiTietPhieuChuyenKho";
            this.grbChiTietPhieuChuyenKho.Size = new System.Drawing.Size(686, 213);
            this.grbChiTietPhieuChuyenKho.TabIndex = 5;
            this.grbChiTietPhieuChuyenKho.TabStop = false;
            this.grbChiTietPhieuChuyenKho.Text = "Chi tiết phiếu chuyển kho";
            // 
            // tblpChiTietPhieuChuyen
            // 
            this.tblpChiTietPhieuChuyen.ColumnCount = 1;
            this.tblpChiTietPhieuChuyen.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpChiTietPhieuChuyen.Controls.Add(this.bindingNavigatorCTPC, 0, 0);
            this.tblpChiTietPhieuChuyen.Controls.Add(this.dgvChiTietPhieuNhap, 0, 1);
            this.tblpChiTietPhieuChuyen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpChiTietPhieuChuyen.Location = new System.Drawing.Point(3, 16);
            this.tblpChiTietPhieuChuyen.Name = "tblpChiTietPhieuChuyen";
            this.tblpChiTietPhieuChuyen.RowCount = 2;
            this.tblpChiTietPhieuChuyen.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tblpChiTietPhieuChuyen.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpChiTietPhieuChuyen.Size = new System.Drawing.Size(680, 194);
            this.tblpChiTietPhieuChuyen.TabIndex = 0;
            // 
            // bindingNavigatorCTPC
            // 
            this.bindingNavigatorCTPC.AddNewItem = this.tsbAddNewItemCTPC;
            this.bindingNavigatorCTPC.CountItem = this.tslCountItem1;
            this.bindingNavigatorCTPC.DeleteItem = this.tsbDeleteItemCTPC;
            this.bindingNavigatorCTPC.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemCTPC,
            this.tsbMovePreviousItemCTPC,
            this.tsSeparator3,
            this.tstbPositionItemCTPC,
            this.tslCountItem1,
            this.tsSeparator4,
            this.tsbMoveNextItemCTPC,
            this.tsbMoveLastItemCTPC,
            this.tsSeparator5,
            this.tsbAddNewItemCTPC,
            this.tsbDeleteItemCTPC,
            this.tsbSaveNewItemCTPC});
            this.bindingNavigatorCTPC.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigatorCTPC.MoveFirstItem = this.tsbMoveFirstItemCTPC;
            this.bindingNavigatorCTPC.MoveLastItem = this.tsbMoveLastItemCTPC;
            this.bindingNavigatorCTPC.MoveNextItem = this.tsbMoveNextItemCTPC;
            this.bindingNavigatorCTPC.MovePreviousItem = this.tsbMovePreviousItemCTPC;
            this.bindingNavigatorCTPC.Name = "bindingNavigatorCTPC";
            this.bindingNavigatorCTPC.PositionItem = this.tstbPositionItemCTPC;
            this.bindingNavigatorCTPC.Size = new System.Drawing.Size(680, 24);
            this.bindingNavigatorCTPC.TabIndex = 6;
            this.bindingNavigatorCTPC.Text = "bindingNavigator2";
            // 
            // tsbAddNewItemCTPC
            // 
            this.tsbAddNewItemCTPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemCTPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemCTPC.Image")));
            this.tsbAddNewItemCTPC.Name = "tsbAddNewItemCTPC";
            this.tsbAddNewItemCTPC.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemCTPC.Size = new System.Drawing.Size(23, 21);
            this.tsbAddNewItemCTPC.Text = "Add new";
            // 
            // tslCountItem1
            // 
            this.tslCountItem1.Name = "tslCountItem1";
            this.tslCountItem1.Size = new System.Drawing.Size(35, 21);
            this.tslCountItem1.Text = "of {0}";
            this.tslCountItem1.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemCTPC
            // 
            this.tsbDeleteItemCTPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemCTPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemCTPC.Image")));
            this.tsbDeleteItemCTPC.Name = "tsbDeleteItemCTPC";
            this.tsbDeleteItemCTPC.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemCTPC.Size = new System.Drawing.Size(23, 21);
            this.tsbDeleteItemCTPC.Text = "Delete";
            // 
            // tsbMoveFirstItemCTPC
            // 
            this.tsbMoveFirstItemCTPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemCTPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemCTPC.Image")));
            this.tsbMoveFirstItemCTPC.Name = "tsbMoveFirstItemCTPC";
            this.tsbMoveFirstItemCTPC.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemCTPC.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveFirstItemCTPC.Text = "Move first";
            // 
            // tsbMovePreviousItemCTPC
            // 
            this.tsbMovePreviousItemCTPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemCTPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemCTPC.Image")));
            this.tsbMovePreviousItemCTPC.Name = "tsbMovePreviousItemCTPC";
            this.tsbMovePreviousItemCTPC.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemCTPC.Size = new System.Drawing.Size(23, 21);
            this.tsbMovePreviousItemCTPC.Text = "Move previous";
            // 
            // tsSeparator3
            // 
            this.tsSeparator3.Name = "tsSeparator3";
            this.tsSeparator3.Size = new System.Drawing.Size(6, 24);
            // 
            // tstbPositionItemCTPC
            // 
            this.tstbPositionItemCTPC.AccessibleName = "Position";
            this.tstbPositionItemCTPC.AutoSize = false;
            this.tstbPositionItemCTPC.Name = "tstbPositionItemCTPC";
            this.tstbPositionItemCTPC.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemCTPC.Text = "0";
            this.tstbPositionItemCTPC.ToolTipText = "Current position";
            // 
            // tsSeparator4
            // 
            this.tsSeparator4.Name = "tsSeparator4";
            this.tsSeparator4.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbMoveNextItemCTPC
            // 
            this.tsbMoveNextItemCTPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemCTPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemCTPC.Image")));
            this.tsbMoveNextItemCTPC.Name = "tsbMoveNextItemCTPC";
            this.tsbMoveNextItemCTPC.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemCTPC.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveNextItemCTPC.Text = "Move next";
            // 
            // tsbMoveLastItemCTPC
            // 
            this.tsbMoveLastItemCTPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemCTPC.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemCTPC.Image")));
            this.tsbMoveLastItemCTPC.Name = "tsbMoveLastItemCTPC";
            this.tsbMoveLastItemCTPC.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemCTPC.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveLastItemCTPC.Text = "Move last";
            // 
            // tsSeparator5
            // 
            this.tsSeparator5.Name = "tsSeparator5";
            this.tsSeparator5.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbSaveNewItemCTPC
            // 
            this.tsbSaveNewItemCTPC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemCTPC.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemCTPC.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemCTPC.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemCTPC.Name = "tsbSaveNewItemCTPC";
            this.tsbSaveNewItemCTPC.Size = new System.Drawing.Size(23, 21);
            this.tsbSaveNewItemCTPC.Text = "toolStripButton1";
            // 
            // dgvChiTietPhieuNhap
            // 
            this.dgvChiTietPhieuNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPhieuNhap.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvChiTietPhieuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPhieuNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.DonGia,
            this.DVT,
            this.SL});
            this.dgvChiTietPhieuNhap.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvChiTietPhieuNhap.Location = new System.Drawing.Point(3, 27);
            this.dgvChiTietPhieuNhap.Name = "dgvChiTietPhieuNhap";
            this.dgvChiTietPhieuNhap.Size = new System.Drawing.Size(674, 164);
            this.dgvChiTietPhieuNhap.TabIndex = 5;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã Hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên Hàng";
            this.TenHang.Name = "TenHang";
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Đơn giá";
            this.DonGia.Name = "DonGia";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // ucPhieuChuyenKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblpPhieuChuyen);
            this.Name = "ucPhieuChuyenKho";
            this.Size = new System.Drawing.Size(698, 447);
            this.grbThongTinPhieuChuyenKho.ResumeLayout(false);
            this.tblpThongTinPhieuChuyen.ResumeLayout(false);
            this.tblpThongTinPhieuChuyen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorPC)).EndInit();
            this.bindingNavigatorPC.ResumeLayout(false);
            this.bindingNavigatorPC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPC)).EndInit();
            this.tblpPhieuChuyen.ResumeLayout(false);
            this.grbChiTietPhieuChuyenKho.ResumeLayout(false);
            this.tblpChiTietPhieuChuyen.ResumeLayout(false);
            this.tblpChiTietPhieuChuyen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorCTPC)).EndInit();
            this.bindingNavigatorCTPC.ResumeLayout(false);
            this.bindingNavigatorCTPC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuNhap)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbThongTinPhieuChuyenKho;
        private System.Windows.Forms.TableLayoutPanel tblpThongTinPhieuChuyen;
        private System.Windows.Forms.TableLayoutPanel tblpPhieuChuyen;
        private System.Windows.Forms.GroupBox grbChiTietPhieuChuyenKho;
        private System.Windows.Forms.TableLayoutPanel tblpChiTietPhieuChuyen;
        private System.Windows.Forms.BindingNavigator bindingNavigatorPC;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemPC;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemPC;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemPC;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemPC;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemPC;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemPC;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemPC;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemPC;
        private System.Windows.Forms.DataGridView dgvThongTinPC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPC;
        private System.Windows.Forms.DataGridViewTextBoxColumn NhanVienChuyen;
        private System.Windows.Forms.DataGridViewTextBoxColumn ChuyenDenKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayChuyen;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongSL;
        private System.Windows.Forms.BindingNavigator bindingNavigatorCTPC;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemCTPC;
        private System.Windows.Forms.ToolStripLabel tslCountItem1;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemCTPC;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemCTPC;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemCTPC;
        private System.Windows.Forms.ToolStripSeparator tsSeparator3;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemCTPC;
        private System.Windows.Forms.ToolStripSeparator tsSeparator4;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemCTPC;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemCTPC;
        private System.Windows.Forms.ToolStripSeparator tsSeparator5;
        private System.Windows.Forms.DataGridView dgvChiTietPhieuNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemCTPC;
    }
}
