﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLyKhoSieuThi.Presentation_Layer
{
    public partial class ucHangTonKho : UserControl
    {
        public ucHangTonKho()
        {
            InitializeComponent();
        }

        private void grbThongTinTonKho_Enter(object sender, EventArgs e)
        {

        }
    }
}
