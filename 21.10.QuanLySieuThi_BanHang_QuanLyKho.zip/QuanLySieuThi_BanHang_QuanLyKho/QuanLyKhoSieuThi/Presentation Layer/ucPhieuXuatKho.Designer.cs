﻿namespace QuanLyKhoSieuThi
{
    partial class ucPhieuXuatKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucPhieuXuatKho));
            this.tlpPhieuXuat = new System.Windows.Forms.TableLayoutPanel();
            this.grbChiTietPhieuXuatKho = new System.Windows.Forms.GroupBox();
            this.tblpChiTietPhieuXuat = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorCTPX = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemCTPX = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem1 = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemCTPX = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemCTPX = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemCTPX = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemCTPX = new System.Windows.Forms.ToolStripTextBox();
            this.tsSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemCTPX = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemCTPX = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemCTPX = new System.Windows.Forms.ToolStripButton();
            this.dgvChiTietPhieuXuatKho = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinPhieuXuatKho = new System.Windows.Forms.GroupBox();
            this.tblpThongTinPhieuXuat = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorPX = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemPX = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemPX = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemPX = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemPX = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemPX = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemPX = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemPX = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemPX = new System.Windows.Forms.ToolStripButton();
            this.dgvThongTinPX = new System.Windows.Forms.DataGridView();
            this.MaPX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NhanVienXuat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.XuatCho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayXuat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongSL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongGiaTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tlpPhieuXuat.SuspendLayout();
            this.grbChiTietPhieuXuatKho.SuspendLayout();
            this.tblpChiTietPhieuXuat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorCTPX)).BeginInit();
            this.bindingNavigatorCTPX.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuXuatKho)).BeginInit();
            this.grbThongTinPhieuXuatKho.SuspendLayout();
            this.tblpThongTinPhieuXuat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorPX)).BeginInit();
            this.bindingNavigatorPX.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPX)).BeginInit();
            this.SuspendLayout();
            // 
            // tlpPhieuXuat
            // 
            this.tlpPhieuXuat.ColumnCount = 1;
            this.tlpPhieuXuat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpPhieuXuat.Controls.Add(this.grbChiTietPhieuXuatKho, 0, 1);
            this.tlpPhieuXuat.Controls.Add(this.grbThongTinPhieuXuatKho, 0, 0);
            this.tlpPhieuXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPhieuXuat.Location = new System.Drawing.Point(0, 0);
            this.tlpPhieuXuat.Name = "tlpPhieuXuat";
            this.tlpPhieuXuat.RowCount = 2;
            this.tlpPhieuXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpPhieuXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpPhieuXuat.Size = new System.Drawing.Size(740, 400);
            this.tlpPhieuXuat.TabIndex = 5;
            // 
            // grbChiTietPhieuXuatKho
            // 
            this.grbChiTietPhieuXuatKho.Controls.Add(this.tblpChiTietPhieuXuat);
            this.grbChiTietPhieuXuatKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietPhieuXuatKho.Location = new System.Drawing.Point(3, 203);
            this.grbChiTietPhieuXuatKho.Name = "grbChiTietPhieuXuatKho";
            this.grbChiTietPhieuXuatKho.Size = new System.Drawing.Size(734, 194);
            this.grbChiTietPhieuXuatKho.TabIndex = 5;
            this.grbChiTietPhieuXuatKho.TabStop = false;
            this.grbChiTietPhieuXuatKho.Text = "Chi tiết phiếu xuất kho";
            // 
            // tblpChiTietPhieuXuat
            // 
            this.tblpChiTietPhieuXuat.ColumnCount = 1;
            this.tblpChiTietPhieuXuat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpChiTietPhieuXuat.Controls.Add(this.bindingNavigatorCTPX, 0, 0);
            this.tblpChiTietPhieuXuat.Controls.Add(this.dgvChiTietPhieuXuatKho, 0, 1);
            this.tblpChiTietPhieuXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpChiTietPhieuXuat.Location = new System.Drawing.Point(3, 16);
            this.tblpChiTietPhieuXuat.Name = "tblpChiTietPhieuXuat";
            this.tblpChiTietPhieuXuat.RowCount = 2;
            this.tblpChiTietPhieuXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tblpChiTietPhieuXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpChiTietPhieuXuat.Size = new System.Drawing.Size(728, 175);
            this.tblpChiTietPhieuXuat.TabIndex = 0;
            // 
            // bindingNavigatorCTPX
            // 
            this.bindingNavigatorCTPX.AddNewItem = this.tsbAddNewItemCTPX;
            this.bindingNavigatorCTPX.CountItem = this.tslCountItem1;
            this.bindingNavigatorCTPX.DeleteItem = this.tsbDeleteItemCTPX;
            this.bindingNavigatorCTPX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bindingNavigatorCTPX.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemCTPX,
            this.tsbMovePreviousItemCTPX,
            this.tsSeparator3,
            this.tstbPositionItemCTPX,
            this.tslCountItem1,
            this.tsSeparator4,
            this.tsbMoveNextItemCTPX,
            this.tsbMoveLastItemCTPX,
            this.tsSeparator5,
            this.tsbAddNewItemCTPX,
            this.tsbDeleteItemCTPX,
            this.tsbSaveNewItemCTPX});
            this.bindingNavigatorCTPX.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigatorCTPX.MoveFirstItem = this.tsbMoveFirstItemCTPX;
            this.bindingNavigatorCTPX.MoveLastItem = this.tsbMoveLastItemCTPX;
            this.bindingNavigatorCTPX.MoveNextItem = this.tsbMoveNextItemCTPX;
            this.bindingNavigatorCTPX.MovePreviousItem = this.tsbMovePreviousItemCTPX;
            this.bindingNavigatorCTPX.Name = "bindingNavigatorCTPX";
            this.bindingNavigatorCTPX.PositionItem = this.tstbPositionItemCTPX;
            this.bindingNavigatorCTPX.Size = new System.Drawing.Size(728, 24);
            this.bindingNavigatorCTPX.TabIndex = 5;
            this.bindingNavigatorCTPX.Text = "bindingNavigator2";
            // 
            // tsbAddNewItemCTPX
            // 
            this.tsbAddNewItemCTPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemCTPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemCTPX.Image")));
            this.tsbAddNewItemCTPX.Name = "tsbAddNewItemCTPX";
            this.tsbAddNewItemCTPX.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemCTPX.Size = new System.Drawing.Size(23, 21);
            this.tsbAddNewItemCTPX.Text = "Add new";
            // 
            // tslCountItem1
            // 
            this.tslCountItem1.Name = "tslCountItem1";
            this.tslCountItem1.Size = new System.Drawing.Size(35, 21);
            this.tslCountItem1.Text = "of {0}";
            this.tslCountItem1.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemCTPX
            // 
            this.tsbDeleteItemCTPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemCTPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemCTPX.Image")));
            this.tsbDeleteItemCTPX.Name = "tsbDeleteItemCTPX";
            this.tsbDeleteItemCTPX.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemCTPX.Size = new System.Drawing.Size(23, 21);
            this.tsbDeleteItemCTPX.Text = "Delete";
            // 
            // tsbMoveFirstItemCTPX
            // 
            this.tsbMoveFirstItemCTPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemCTPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemCTPX.Image")));
            this.tsbMoveFirstItemCTPX.Name = "tsbMoveFirstItemCTPX";
            this.tsbMoveFirstItemCTPX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemCTPX.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveFirstItemCTPX.Text = "Move first";
            // 
            // tsbMovePreviousItemCTPX
            // 
            this.tsbMovePreviousItemCTPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemCTPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemCTPX.Image")));
            this.tsbMovePreviousItemCTPX.Name = "tsbMovePreviousItemCTPX";
            this.tsbMovePreviousItemCTPX.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemCTPX.Size = new System.Drawing.Size(23, 21);
            this.tsbMovePreviousItemCTPX.Text = "Move previous";
            // 
            // tsSeparator3
            // 
            this.tsSeparator3.Name = "tsSeparator3";
            this.tsSeparator3.Size = new System.Drawing.Size(6, 24);
            // 
            // tstbPositionItemCTPX
            // 
            this.tstbPositionItemCTPX.AccessibleName = "Position";
            this.tstbPositionItemCTPX.AutoSize = false;
            this.tstbPositionItemCTPX.Name = "tstbPositionItemCTPX";
            this.tstbPositionItemCTPX.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemCTPX.Text = "0";
            this.tstbPositionItemCTPX.ToolTipText = "Current position";
            // 
            // tsSeparator4
            // 
            this.tsSeparator4.Name = "tsSeparator4";
            this.tsSeparator4.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbMoveNextItemCTPX
            // 
            this.tsbMoveNextItemCTPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemCTPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemCTPX.Image")));
            this.tsbMoveNextItemCTPX.Name = "tsbMoveNextItemCTPX";
            this.tsbMoveNextItemCTPX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemCTPX.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveNextItemCTPX.Text = "Move next";
            // 
            // tsbMoveLastItemCTPX
            // 
            this.tsbMoveLastItemCTPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemCTPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemCTPX.Image")));
            this.tsbMoveLastItemCTPX.Name = "tsbMoveLastItemCTPX";
            this.tsbMoveLastItemCTPX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemCTPX.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveLastItemCTPX.Text = "Move last";
            // 
            // tsSeparator5
            // 
            this.tsSeparator5.Name = "tsSeparator5";
            this.tsSeparator5.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbSaveNewItemCTPX
            // 
            this.tsbSaveNewItemCTPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemCTPX.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemCTPX.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemCTPX.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemCTPX.Name = "tsbSaveNewItemCTPX";
            this.tsbSaveNewItemCTPX.Size = new System.Drawing.Size(23, 21);
            this.tsbSaveNewItemCTPX.Text = "Save";
            // 
            // dgvChiTietPhieuXuatKho
            // 
            this.dgvChiTietPhieuXuatKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPhieuXuatKho.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvChiTietPhieuXuatKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPhieuXuatKho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.DonGia,
            this.DVT,
            this.SL});
            this.dgvChiTietPhieuXuatKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChiTietPhieuXuatKho.Location = new System.Drawing.Point(3, 27);
            this.dgvChiTietPhieuXuatKho.Name = "dgvChiTietPhieuXuatKho";
            this.dgvChiTietPhieuXuatKho.Size = new System.Drawing.Size(722, 145);
            this.dgvChiTietPhieuXuatKho.TabIndex = 4;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã Hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên Hàng";
            this.TenHang.Name = "TenHang";
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Đơn giá";
            this.DonGia.Name = "DonGia";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // grbThongTinPhieuXuatKho
            // 
            this.grbThongTinPhieuXuatKho.Controls.Add(this.tblpThongTinPhieuXuat);
            this.grbThongTinPhieuXuatKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinPhieuXuatKho.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinPhieuXuatKho.Name = "grbThongTinPhieuXuatKho";
            this.grbThongTinPhieuXuatKho.Size = new System.Drawing.Size(734, 194);
            this.grbThongTinPhieuXuatKho.TabIndex = 4;
            this.grbThongTinPhieuXuatKho.TabStop = false;
            this.grbThongTinPhieuXuatKho.Text = "Thông tin phiếu xuất kho";
            // 
            // tblpThongTinPhieuXuat
            // 
            this.tblpThongTinPhieuXuat.ColumnCount = 1;
            this.tblpThongTinPhieuXuat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpThongTinPhieuXuat.Controls.Add(this.bindingNavigatorPX, 0, 0);
            this.tblpThongTinPhieuXuat.Controls.Add(this.dgvThongTinPX, 0, 1);
            this.tblpThongTinPhieuXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpThongTinPhieuXuat.Location = new System.Drawing.Point(3, 16);
            this.tblpThongTinPhieuXuat.Name = "tblpThongTinPhieuXuat";
            this.tblpThongTinPhieuXuat.RowCount = 2;
            this.tblpThongTinPhieuXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tblpThongTinPhieuXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpThongTinPhieuXuat.Size = new System.Drawing.Size(728, 175);
            this.tblpThongTinPhieuXuat.TabIndex = 0;
            // 
            // bindingNavigatorPX
            // 
            this.bindingNavigatorPX.AddNewItem = this.tsbAddNewItemPX;
            this.bindingNavigatorPX.CountItem = this.tslCountItem;
            this.bindingNavigatorPX.DeleteItem = this.tsbDeleteItemPX;
            this.bindingNavigatorPX.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemPX,
            this.tsbMovePreviousItemPX,
            this.tsSeparator,
            this.tstbPositionItemPX,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemPX,
            this.tsbMoveLastItemPX,
            this.tslSeparator2,
            this.tsbAddNewItemPX,
            this.tsbDeleteItemPX,
            this.tsbSaveNewItemPX});
            this.bindingNavigatorPX.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigatorPX.MoveFirstItem = this.tsbMoveFirstItemPX;
            this.bindingNavigatorPX.MoveLastItem = this.tsbMoveLastItemPX;
            this.bindingNavigatorPX.MoveNextItem = this.tsbMoveNextItemPX;
            this.bindingNavigatorPX.MovePreviousItem = this.tsbMovePreviousItemPX;
            this.bindingNavigatorPX.Name = "bindingNavigatorPX";
            this.bindingNavigatorPX.PositionItem = this.tstbPositionItemPX;
            this.bindingNavigatorPX.Size = new System.Drawing.Size(728, 25);
            this.bindingNavigatorPX.TabIndex = 4;
            this.bindingNavigatorPX.Text = "bindingNavigator1";
            // 
            // tsbAddNewItemPX
            // 
            this.tsbAddNewItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemPX.Image")));
            this.tsbAddNewItemPX.Name = "tsbAddNewItemPX";
            this.tsbAddNewItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbAddNewItemPX.Text = "Add new";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 22);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemPX
            // 
            this.tsbDeleteItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemPX.Image")));
            this.tsbDeleteItemPX.Name = "tsbDeleteItemPX";
            this.tsbDeleteItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbDeleteItemPX.Text = "Delete";
            // 
            // tsbMoveFirstItemPX
            // 
            this.tsbMoveFirstItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemPX.Image")));
            this.tsbMoveFirstItemPX.Name = "tsbMoveFirstItemPX";
            this.tsbMoveFirstItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveFirstItemPX.Text = "Move first";
            // 
            // tsbMovePreviousItemPX
            // 
            this.tsbMovePreviousItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemPX.Image")));
            this.tsbMovePreviousItemPX.Name = "tsbMovePreviousItemPX";
            this.tsbMovePreviousItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbMovePreviousItemPX.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // tstbPositionItemPX
            // 
            this.tstbPositionItemPX.AccessibleName = "Position";
            this.tstbPositionItemPX.AutoSize = false;
            this.tstbPositionItemPX.Name = "tstbPositionItemPX";
            this.tstbPositionItemPX.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemPX.Text = "0";
            this.tstbPositionItemPX.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbMoveNextItemPX
            // 
            this.tsbMoveNextItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemPX.Image")));
            this.tsbMoveNextItemPX.Name = "tsbMoveNextItemPX";
            this.tsbMoveNextItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveNextItemPX.Text = "Move next";
            // 
            // tsbMoveLastItemPX
            // 
            this.tsbMoveLastItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemPX.Image")));
            this.tsbMoveLastItemPX.Name = "tsbMoveLastItemPX";
            this.tsbMoveLastItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveLastItemPX.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbSaveNewItemPX
            // 
            this.tsbSaveNewItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemPX.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemPX.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemPX.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemPX.Name = "tsbSaveNewItemPX";
            this.tsbSaveNewItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbSaveNewItemPX.Text = "Save";
            // 
            // dgvThongTinPX
            // 
            this.dgvThongTinPX.AllowUserToOrderColumns = true;
            this.dgvThongTinPX.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinPX.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvThongTinPX.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinPX.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPX,
            this.NhanVienXuat,
            this.XuatCho,
            this.MaKho,
            this.NgayXuat,
            this.TongSL,
            this.TongGiaTri});
            this.dgvThongTinPX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinPX.Location = new System.Drawing.Point(3, 28);
            this.dgvThongTinPX.Name = "dgvThongTinPX";
            this.dgvThongTinPX.Size = new System.Drawing.Size(722, 144);
            this.dgvThongTinPX.TabIndex = 3;
            // 
            // MaPX
            // 
            this.MaPX.HeaderText = "Mã phiếu xuất";
            this.MaPX.Name = "MaPX";
            // 
            // NhanVienXuat
            // 
            this.NhanVienXuat.HeaderText = "Nhân viên xuất";
            this.NhanVienXuat.Name = "NhanVienXuat";
            // 
            // XuatCho
            // 
            this.XuatCho.HeaderText = "Xuất cho";
            this.XuatCho.Name = "XuatCho";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // NgayXuat
            // 
            this.NgayXuat.HeaderText = "Ngày xuất";
            this.NgayXuat.Name = "NgayXuat";
            // 
            // TongSL
            // 
            this.TongSL.HeaderText = "Tổng số lượng";
            this.TongSL.Name = "TongSL";
            // 
            // TongGiaTri
            // 
            this.TongGiaTri.HeaderText = "Tổng giá trị";
            this.TongGiaTri.Name = "TongGiaTri";
            // 
            // ucPhieuXuatKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tlpPhieuXuat);
            this.Name = "ucPhieuXuatKho";
            this.Size = new System.Drawing.Size(740, 400);
            this.tlpPhieuXuat.ResumeLayout(false);
            this.grbChiTietPhieuXuatKho.ResumeLayout(false);
            this.tblpChiTietPhieuXuat.ResumeLayout(false);
            this.tblpChiTietPhieuXuat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorCTPX)).EndInit();
            this.bindingNavigatorCTPX.ResumeLayout(false);
            this.bindingNavigatorCTPX.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuXuatKho)).EndInit();
            this.grbThongTinPhieuXuatKho.ResumeLayout(false);
            this.tblpThongTinPhieuXuat.ResumeLayout(false);
            this.tblpThongTinPhieuXuat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorPX)).EndInit();
            this.bindingNavigatorPX.ResumeLayout(false);
            this.bindingNavigatorPX.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPX)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpPhieuXuat;
        private System.Windows.Forms.GroupBox grbChiTietPhieuXuatKho;
        private System.Windows.Forms.GroupBox grbThongTinPhieuXuatKho;
        private System.Windows.Forms.TableLayoutPanel tblpThongTinPhieuXuat;
        private System.Windows.Forms.BindingNavigator bindingNavigatorPX;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemPX;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemPX;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemPX;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemPX;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemPX;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemPX;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemPX;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemPX;
        private System.Windows.Forms.DataGridView dgvThongTinPX;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPX;
        private System.Windows.Forms.DataGridViewTextBoxColumn NhanVienXuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn XuatCho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayXuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongSL;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongGiaTri;
        private System.Windows.Forms.TableLayoutPanel tblpChiTietPhieuXuat;
        private System.Windows.Forms.BindingNavigator bindingNavigatorCTPX;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemCTPX;
        private System.Windows.Forms.ToolStripLabel tslCountItem1;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemCTPX;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemCTPX;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemCTPX;
        private System.Windows.Forms.ToolStripSeparator tsSeparator3;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemCTPX;
        private System.Windows.Forms.ToolStripSeparator tsSeparator4;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemCTPX;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemCTPX;
        private System.Windows.Forms.ToolStripSeparator tsSeparator5;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemCTPX;
        private System.Windows.Forms.DataGridView dgvChiTietPhieuXuatKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;

    }
}
