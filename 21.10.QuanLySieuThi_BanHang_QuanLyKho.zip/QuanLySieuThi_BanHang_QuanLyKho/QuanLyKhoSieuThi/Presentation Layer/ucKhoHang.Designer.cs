﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucKhoHang
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucKhoHang));
            this.tlpThongTinKhoHang = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorKH = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemKH = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemKH = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemKH = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemKH = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemKH = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemKH = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemKH = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemKH = new System.Windows.Forms.ToolStripButton();
            this.gdbThongTinKhoHang = new System.Windows.Forms.GroupBox();
            this.lblNhanVienKho = new System.Windows.Forms.Label();
            this.cbNhanVienKho = new System.Windows.Forms.ComboBox();
            this.cbTenKho = new System.Windows.Forms.ComboBox();
            this.cbMaKho = new System.Windows.Forms.ComboBox();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDienThoai = new System.Windows.Forms.Label();
            this.lblTenKho = new System.Windows.Forms.Label();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.lblMaKho = new System.Windows.Forms.Label();
            this.grbThongTinChiTietKho = new System.Windows.Forms.GroupBox();
            this.dgvDanhMucHang = new System.Windows.Forms.DataGridView();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NhanVienKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DienThoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiaChi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tlpThongTinKhoHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorKH)).BeginInit();
            this.bindingNavigatorKH.SuspendLayout();
            this.gdbThongTinKhoHang.SuspendLayout();
            this.grbThongTinChiTietKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHang)).BeginInit();
            this.SuspendLayout();
            // 
            // tlpThongTinKhoHang
            // 
            this.tlpThongTinKhoHang.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpThongTinKhoHang.ColumnCount = 1;
            this.tlpThongTinKhoHang.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinKhoHang.Controls.Add(this.bindingNavigatorKH, 0, 2);
            this.tlpThongTinKhoHang.Controls.Add(this.gdbThongTinKhoHang, 0, 0);
            this.tlpThongTinKhoHang.Controls.Add(this.grbThongTinChiTietKho, 0, 1);
            this.tlpThongTinKhoHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpThongTinKhoHang.Location = new System.Drawing.Point(0, 0);
            this.tlpThongTinKhoHang.Name = "tlpThongTinKhoHang";
            this.tlpThongTinKhoHang.RowCount = 3;
            this.tlpThongTinKhoHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tlpThongTinKhoHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinKhoHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tlpThongTinKhoHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpThongTinKhoHang.Size = new System.Drawing.Size(580, 307);
            this.tlpThongTinKhoHang.TabIndex = 0;
            // 
            // bindingNavigatorKH
            // 
            this.bindingNavigatorKH.AddNewItem = this.tsbAddNewItemKH;
            this.bindingNavigatorKH.CountItem = this.tslCountItem;
            this.bindingNavigatorKH.DeleteItem = this.tsbDeleteItemKH;
            this.bindingNavigatorKH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bindingNavigatorKH.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemKH,
            this.tsbMovePreviousItemKH,
            this.tsSeparator,
            this.tstbPositionItemKH,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemKH,
            this.tsbMoveLastItemKH,
            this.tslSeparator2,
            this.tsbAddNewItemKH,
            this.tsbDeleteItemKH,
            this.tsbSaveNewItemKH});
            this.bindingNavigatorKH.Location = new System.Drawing.Point(3, 280);
            this.bindingNavigatorKH.MoveFirstItem = this.tsbMoveFirstItemKH;
            this.bindingNavigatorKH.MoveLastItem = this.tsbMoveLastItemKH;
            this.bindingNavigatorKH.MoveNextItem = this.tsbMoveNextItemKH;
            this.bindingNavigatorKH.MovePreviousItem = this.tsbMovePreviousItemKH;
            this.bindingNavigatorKH.Name = "bindingNavigatorKH";
            this.bindingNavigatorKH.PositionItem = this.tstbPositionItemKH;
            this.bindingNavigatorKH.Size = new System.Drawing.Size(574, 24);
            this.bindingNavigatorKH.TabIndex = 13;
            this.bindingNavigatorKH.Text = "bindingNavigator1";
            // 
            // tsbAddNewItemKH
            // 
            this.tsbAddNewItemKH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemKH.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemKH.Image")));
            this.tsbAddNewItemKH.Name = "tsbAddNewItemKH";
            this.tsbAddNewItemKH.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemKH.Size = new System.Drawing.Size(23, 21);
            this.tsbAddNewItemKH.Text = "Add new";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 21);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemKH
            // 
            this.tsbDeleteItemKH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemKH.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemKH.Image")));
            this.tsbDeleteItemKH.Name = "tsbDeleteItemKH";
            this.tsbDeleteItemKH.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemKH.Size = new System.Drawing.Size(23, 21);
            this.tsbDeleteItemKH.Text = "Delete";
            // 
            // tsbMoveFirstItemKH
            // 
            this.tsbMoveFirstItemKH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemKH.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemKH.Image")));
            this.tsbMoveFirstItemKH.Name = "tsbMoveFirstItemKH";
            this.tsbMoveFirstItemKH.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemKH.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveFirstItemKH.Text = "Move first";
            // 
            // tsbMovePreviousItemKH
            // 
            this.tsbMovePreviousItemKH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemKH.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemKH.Image")));
            this.tsbMovePreviousItemKH.Name = "tsbMovePreviousItemKH";
            this.tsbMovePreviousItemKH.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemKH.Size = new System.Drawing.Size(23, 21);
            this.tsbMovePreviousItemKH.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 24);
            // 
            // tstbPositionItemKH
            // 
            this.tstbPositionItemKH.AccessibleName = "Position";
            this.tstbPositionItemKH.AutoSize = false;
            this.tstbPositionItemKH.Name = "tstbPositionItemKH";
            this.tstbPositionItemKH.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemKH.Text = "0";
            this.tstbPositionItemKH.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbMoveNextItemKH
            // 
            this.tsbMoveNextItemKH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemKH.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemKH.Image")));
            this.tsbMoveNextItemKH.Name = "tsbMoveNextItemKH";
            this.tsbMoveNextItemKH.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemKH.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveNextItemKH.Text = "Move next";
            // 
            // tsbMoveLastItemKH
            // 
            this.tsbMoveLastItemKH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemKH.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemKH.Image")));
            this.tsbMoveLastItemKH.Name = "tsbMoveLastItemKH";
            this.tsbMoveLastItemKH.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemKH.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveLastItemKH.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbSaveNewItemKH
            // 
            this.tsbSaveNewItemKH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemKH.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemKH.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemKH.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemKH.Name = "tsbSaveNewItemKH";
            this.tsbSaveNewItemKH.Size = new System.Drawing.Size(23, 21);
            this.tsbSaveNewItemKH.Text = "Save";
            // 
            // gdbThongTinKhoHang
            // 
            this.gdbThongTinKhoHang.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gdbThongTinKhoHang.Controls.Add(this.lblNhanVienKho);
            this.gdbThongTinKhoHang.Controls.Add(this.cbNhanVienKho);
            this.gdbThongTinKhoHang.Controls.Add(this.cbTenKho);
            this.gdbThongTinKhoHang.Controls.Add(this.cbMaKho);
            this.gdbThongTinKhoHang.Controls.Add(this.txtDienThoai);
            this.gdbThongTinKhoHang.Controls.Add(this.txtDiaChi);
            this.gdbThongTinKhoHang.Controls.Add(this.lblDienThoai);
            this.gdbThongTinKhoHang.Controls.Add(this.lblTenKho);
            this.gdbThongTinKhoHang.Controls.Add(this.lblDiaChi);
            this.gdbThongTinKhoHang.Controls.Add(this.lblMaKho);
            this.gdbThongTinKhoHang.Dock = System.Windows.Forms.DockStyle.Top;
            this.gdbThongTinKhoHang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gdbThongTinKhoHang.Location = new System.Drawing.Point(6, 6);
            this.gdbThongTinKhoHang.Name = "gdbThongTinKhoHang";
            this.gdbThongTinKhoHang.Size = new System.Drawing.Size(568, 101);
            this.gdbThongTinKhoHang.TabIndex = 11;
            this.gdbThongTinKhoHang.TabStop = false;
            this.gdbThongTinKhoHang.Text = "Thông tin kho hàng";
            // 
            // lblNhanVienKho
            // 
            this.lblNhanVienKho.AutoSize = true;
            this.lblNhanVienKho.Location = new System.Drawing.Point(1, 77);
            this.lblNhanVienKho.Name = "lblNhanVienKho";
            this.lblNhanVienKho.Size = new System.Drawing.Size(86, 15);
            this.lblNhanVienKho.TabIndex = 4;
            this.lblNhanVienKho.Text = "Nhân viên kho";
            // 
            // cbNhanVienKho
            // 
            this.cbNhanVienKho.FormattingEnabled = true;
            this.cbNhanVienKho.Location = new System.Drawing.Point(93, 73);
            this.cbNhanVienKho.Name = "cbNhanVienKho";
            this.cbNhanVienKho.Size = new System.Drawing.Size(169, 23);
            this.cbNhanVienKho.TabIndex = 3;
            // 
            // cbTenKho
            // 
            this.cbTenKho.FormattingEnabled = true;
            this.cbTenKho.Location = new System.Drawing.Point(93, 44);
            this.cbTenKho.Name = "cbTenKho";
            this.cbTenKho.Size = new System.Drawing.Size(169, 23);
            this.cbTenKho.TabIndex = 3;
            // 
            // cbMaKho
            // 
            this.cbMaKho.FormattingEnabled = true;
            this.cbMaKho.Location = new System.Drawing.Point(93, 15);
            this.cbMaKho.Name = "cbMaKho";
            this.cbMaKho.Size = new System.Drawing.Size(169, 23);
            this.cbMaKho.TabIndex = 3;
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Location = new System.Drawing.Point(347, 74);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(146, 21);
            this.txtDienThoai.TabIndex = 2;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(347, 15);
            this.txtDiaChi.Multiline = true;
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(170, 52);
            this.txtDiaChi.TabIndex = 2;
            // 
            // lblDienThoai
            // 
            this.lblDienThoai.AutoSize = true;
            this.lblDienThoai.Location = new System.Drawing.Point(277, 77);
            this.lblDienThoai.Name = "lblDienThoai";
            this.lblDienThoai.Size = new System.Drawing.Size(64, 15);
            this.lblDienThoai.TabIndex = 1;
            this.lblDienThoai.Text = "Điện thoại";
            // 
            // lblTenKho
            // 
            this.lblTenKho.AutoSize = true;
            this.lblTenKho.Location = new System.Drawing.Point(34, 47);
            this.lblTenKho.Name = "lblTenKho";
            this.lblTenKho.Size = new System.Drawing.Size(53, 15);
            this.lblTenKho.TabIndex = 1;
            this.lblTenKho.Text = "Tên Kho";
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(294, 17);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(46, 15);
            this.lblDiaChi.TabIndex = 1;
            this.lblDiaChi.Text = "Địa chỉ";
            // 
            // lblMaKho
            // 
            this.lblMaKho.AutoSize = true;
            this.lblMaKho.Location = new System.Drawing.Point(39, 20);
            this.lblMaKho.Name = "lblMaKho";
            this.lblMaKho.Size = new System.Drawing.Size(48, 15);
            this.lblMaKho.TabIndex = 1;
            this.lblMaKho.Text = "Mã kho";
            // 
            // grbThongTinChiTietKho
            // 
            this.grbThongTinChiTietKho.Controls.Add(this.dgvDanhMucHang);
            this.grbThongTinChiTietKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinChiTietKho.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinChiTietKho.Location = new System.Drawing.Point(6, 116);
            this.grbThongTinChiTietKho.Name = "grbThongTinChiTietKho";
            this.grbThongTinChiTietKho.Size = new System.Drawing.Size(568, 158);
            this.grbThongTinChiTietKho.TabIndex = 14;
            this.grbThongTinChiTietKho.TabStop = false;
            this.grbThongTinChiTietKho.Text = "Thông tin chi tiết kho";
            // 
            // dgvDanhMucHang
            // 
            this.dgvDanhMucHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhMucHang.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvDanhMucHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhMucHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaKho,
            this.TenKho,
            this.NhanVienKho,
            this.DienThoai,
            this.DiaChi});
            this.dgvDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhMucHang.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhMucHang.Name = "dgvDanhMucHang";
            this.dgvDanhMucHang.Size = new System.Drawing.Size(562, 139);
            this.dgvDanhMucHang.TabIndex = 1;
            // 
            // MaKho
            // 
            this.MaKho.FillWeight = 36.57629F;
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // TenKho
            // 
            this.TenKho.FillWeight = 170.9941F;
            this.TenKho.HeaderText = "Tên kho";
            this.TenKho.Name = "TenKho";
            // 
            // NhanVienKho
            // 
            this.NhanVienKho.FillWeight = 76.14214F;
            this.NhanVienKho.HeaderText = "Nhân viên kho";
            this.NhanVienKho.Name = "NhanVienKho";
            // 
            // DienThoai
            // 
            this.DienThoai.FillWeight = 45.2933F;
            this.DienThoai.HeaderText = "Điện Thoại";
            this.DienThoai.Name = "DienThoai";
            // 
            // DiaChi
            // 
            this.DiaChi.FillWeight = 170.9941F;
            this.DiaChi.HeaderText = "Địa chỉ";
            this.DiaChi.Name = "DiaChi";
            // 
            // ucKhoHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tlpThongTinKhoHang);
            this.Name = "ucKhoHang";
            this.Size = new System.Drawing.Size(580, 307);
            this.tlpThongTinKhoHang.ResumeLayout(false);
            this.tlpThongTinKhoHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorKH)).EndInit();
            this.bindingNavigatorKH.ResumeLayout(false);
            this.bindingNavigatorKH.PerformLayout();
            this.gdbThongTinKhoHang.ResumeLayout(false);
            this.gdbThongTinKhoHang.PerformLayout();
            this.grbThongTinChiTietKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHang)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpThongTinKhoHang;
        private System.Windows.Forms.GroupBox gdbThongTinKhoHang;
        private System.Windows.Forms.Label lblNhanVienKho;
        private System.Windows.Forms.ComboBox cbNhanVienKho;
        private System.Windows.Forms.ComboBox cbTenKho;
        private System.Windows.Forms.ComboBox cbMaKho;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblDienThoai;
        private System.Windows.Forms.Label lblTenKho;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.Label lblMaKho;
        private System.Windows.Forms.BindingNavigator bindingNavigatorKH;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemKH;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemKH;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemKH;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemKH;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemKH;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemKH;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemKH;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemKH;
        private System.Windows.Forms.GroupBox grbThongTinChiTietKho;
        private System.Windows.Forms.DataGridView dgvDanhMucHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn NhanVienKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn DienThoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiaChi;
    }
}
