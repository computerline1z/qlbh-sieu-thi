﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucPhieuNhapKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucPhieuNhapKho));
            this.grbThongTinPhieuNhapKho = new System.Windows.Forms.GroupBox();
            this.tlpThongTinPhieuNhap = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorPN = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemPN = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemPN = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemPN = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemPN = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemPN = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemPN = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemPN = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemPN = new System.Windows.Forms.ToolStripButton();
            this.dgvThongTinPN = new System.Windows.Forms.DataGridView();
            this.MaPN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNCC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NhanVienNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongGiaTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tlbChiTietPhieuNhap = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorCTPN = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemCTPN = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem1 = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemCTPN = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemCTPN = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemCTPN = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemCTPN = new System.Windows.Forms.ToolStripTextBox();
            this.tsSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemCTPN = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemCTPN = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemCTPN = new System.Windows.Forms.ToolStripButton();
            this.dgvChiTietPhieuNhap = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblpPhieuNhap = new System.Windows.Forms.TableLayoutPanel();
            this.grbChiTietPhieuNhapKho = new System.Windows.Forms.GroupBox();
            this.grbThongTinPhieuNhapKho.SuspendLayout();
            this.tlpThongTinPhieuNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorPN)).BeginInit();
            this.bindingNavigatorPN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPN)).BeginInit();
            this.tlbChiTietPhieuNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorCTPN)).BeginInit();
            this.bindingNavigatorCTPN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuNhap)).BeginInit();
            this.tblpPhieuNhap.SuspendLayout();
            this.grbChiTietPhieuNhapKho.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbThongTinPhieuNhapKho
            // 
            this.grbThongTinPhieuNhapKho.Controls.Add(this.tlpThongTinPhieuNhap);
            this.grbThongTinPhieuNhapKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinPhieuNhapKho.Location = new System.Drawing.Point(6, 6);
            this.grbThongTinPhieuNhapKho.Name = "grbThongTinPhieuNhapKho";
            this.grbThongTinPhieuNhapKho.Size = new System.Drawing.Size(715, 193);
            this.grbThongTinPhieuNhapKho.TabIndex = 4;
            this.grbThongTinPhieuNhapKho.TabStop = false;
            this.grbThongTinPhieuNhapKho.Text = "Thông tin phiếu nhập kho";
            // 
            // tlpThongTinPhieuNhap
            // 
            this.tlpThongTinPhieuNhap.ColumnCount = 1;
            this.tlpThongTinPhieuNhap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinPhieuNhap.Controls.Add(this.bindingNavigatorPN, 0, 0);
            this.tlpThongTinPhieuNhap.Controls.Add(this.dgvThongTinPN, 0, 1);
            this.tlpThongTinPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpThongTinPhieuNhap.Location = new System.Drawing.Point(3, 16);
            this.tlpThongTinPhieuNhap.Name = "tlpThongTinPhieuNhap";
            this.tlpThongTinPhieuNhap.RowCount = 2;
            this.tlpThongTinPhieuNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tlpThongTinPhieuNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinPhieuNhap.Size = new System.Drawing.Size(709, 174);
            this.tlpThongTinPhieuNhap.TabIndex = 0;
            // 
            // bindingNavigatorPN
            // 
            this.bindingNavigatorPN.AddNewItem = this.tsbAddNewItemPN;
            this.bindingNavigatorPN.CountItem = this.tslCountItem;
            this.bindingNavigatorPN.DeleteItem = this.tsbDeleteItemPN;
            this.bindingNavigatorPN.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemPN,
            this.tsbMovePreviousItemPN,
            this.tsSeparator,
            this.tstbPositionItemPN,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemPN,
            this.tsbMoveLastItemPN,
            this.tslSeparator2,
            this.tsbAddNewItemPN,
            this.tsbDeleteItemPN,
            this.tsbSaveNewItemPN});
            this.bindingNavigatorPN.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigatorPN.MoveFirstItem = this.tsbMoveFirstItemPN;
            this.bindingNavigatorPN.MoveLastItem = this.tsbMoveLastItemPN;
            this.bindingNavigatorPN.MoveNextItem = this.tsbMoveNextItemPN;
            this.bindingNavigatorPN.MovePreviousItem = this.tsbMovePreviousItemPN;
            this.bindingNavigatorPN.Name = "bindingNavigatorPN";
            this.bindingNavigatorPN.PositionItem = this.tstbPositionItemPN;
            this.bindingNavigatorPN.Size = new System.Drawing.Size(709, 25);
            this.bindingNavigatorPN.TabIndex = 3;
            this.bindingNavigatorPN.Text = "bindingNavigator1";
            // 
            // tsbAddNewItemPN
            // 
            this.tsbAddNewItemPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemPN.Image")));
            this.tsbAddNewItemPN.Name = "tsbAddNewItemPN";
            this.tsbAddNewItemPN.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemPN.Size = new System.Drawing.Size(23, 22);
            this.tsbAddNewItemPN.Text = "Add new";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 22);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemPN
            // 
            this.tsbDeleteItemPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemPN.Image")));
            this.tsbDeleteItemPN.Name = "tsbDeleteItemPN";
            this.tsbDeleteItemPN.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemPN.Size = new System.Drawing.Size(23, 22);
            this.tsbDeleteItemPN.Text = "Delete";
            // 
            // tsbMoveFirstItemPN
            // 
            this.tsbMoveFirstItemPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemPN.Image")));
            this.tsbMoveFirstItemPN.Name = "tsbMoveFirstItemPN";
            this.tsbMoveFirstItemPN.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemPN.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveFirstItemPN.Text = "Move first";
            // 
            // tsbMovePreviousItemPN
            // 
            this.tsbMovePreviousItemPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemPN.Image")));
            this.tsbMovePreviousItemPN.Name = "tsbMovePreviousItemPN";
            this.tsbMovePreviousItemPN.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemPN.Size = new System.Drawing.Size(23, 22);
            this.tsbMovePreviousItemPN.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // tstbPositionItemPN
            // 
            this.tstbPositionItemPN.AccessibleName = "Position";
            this.tstbPositionItemPN.AutoSize = false;
            this.tstbPositionItemPN.Name = "tstbPositionItemPN";
            this.tstbPositionItemPN.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemPN.Text = "0";
            this.tstbPositionItemPN.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbMoveNextItemPN
            // 
            this.tsbMoveNextItemPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemPN.Image")));
            this.tsbMoveNextItemPN.Name = "tsbMoveNextItemPN";
            this.tsbMoveNextItemPN.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemPN.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveNextItemPN.Text = "Move next";
            // 
            // tsbMoveLastItemPN
            // 
            this.tsbMoveLastItemPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemPN.Image")));
            this.tsbMoveLastItemPN.Name = "tsbMoveLastItemPN";
            this.tsbMoveLastItemPN.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemPN.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveLastItemPN.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbSaveNewItemPN
            // 
            this.tsbSaveNewItemPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemPN.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemPN.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemPN.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemPN.Name = "tsbSaveNewItemPN";
            this.tsbSaveNewItemPN.Size = new System.Drawing.Size(23, 22);
            this.tsbSaveNewItemPN.Text = "Save";
            // 
            // dgvThongTinPN
            // 
            this.dgvThongTinPN.AllowUserToOrderColumns = true;
            this.dgvThongTinPN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinPN.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvThongTinPN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinPN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPN,
            this.MaNCC,
            this.NhanVienNhap,
            this.MaKho,
            this.NgayNhap,
            this.TongGiaTri});
            this.dgvThongTinPN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinPN.Location = new System.Drawing.Point(3, 28);
            this.dgvThongTinPN.Name = "dgvThongTinPN";
            this.dgvThongTinPN.Size = new System.Drawing.Size(703, 143);
            this.dgvThongTinPN.TabIndex = 2;
            // 
            // MaPN
            // 
            this.MaPN.HeaderText = "Mã phiếu nhập";
            this.MaPN.Name = "MaPN";
            // 
            // MaNCC
            // 
            this.MaNCC.HeaderText = "Mã NCC";
            this.MaNCC.Name = "MaNCC";
            // 
            // NhanVienNhap
            // 
            this.NhanVienNhap.HeaderText = "Nhận viên nhập";
            this.NhanVienNhap.Name = "NhanVienNhap";
            // 
            // MaKho
            // 
            this.MaKho.HeaderText = "Mã kho";
            this.MaKho.Name = "MaKho";
            // 
            // NgayNhap
            // 
            this.NgayNhap.HeaderText = "Ngày nhập";
            this.NgayNhap.Name = "NgayNhap";
            // 
            // TongGiaTri
            // 
            this.TongGiaTri.HeaderText = "Tổng giá trị";
            this.TongGiaTri.Name = "TongGiaTri";
            // 
            // tlbChiTietPhieuNhap
            // 
            this.tlbChiTietPhieuNhap.ColumnCount = 1;
            this.tlbChiTietPhieuNhap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlbChiTietPhieuNhap.Controls.Add(this.bindingNavigatorCTPN, 0, 0);
            this.tlbChiTietPhieuNhap.Controls.Add(this.dgvChiTietPhieuNhap, 0, 1);
            this.tlbChiTietPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlbChiTietPhieuNhap.Location = new System.Drawing.Point(3, 16);
            this.tlbChiTietPhieuNhap.Name = "tlbChiTietPhieuNhap";
            this.tlbChiTietPhieuNhap.RowCount = 2;
            this.tlbChiTietPhieuNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tlbChiTietPhieuNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlbChiTietPhieuNhap.Size = new System.Drawing.Size(709, 174);
            this.tlbChiTietPhieuNhap.TabIndex = 0;
            // 
            // bindingNavigatorCTPN
            // 
            this.bindingNavigatorCTPN.AddNewItem = this.tsbAddNewItemCTPN;
            this.bindingNavigatorCTPN.CountItem = this.tslCountItem1;
            this.bindingNavigatorCTPN.DeleteItem = this.tsbDeleteItemCTPN;
            this.bindingNavigatorCTPN.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemCTPN,
            this.tsbMovePreviousItemCTPN,
            this.tsSeparator3,
            this.tstbPositionItemCTPN,
            this.tslCountItem1,
            this.tsSeparator4,
            this.tsbMoveNextItemCTPN,
            this.tsbMoveLastItemCTPN,
            this.tsSeparator5,
            this.tsbAddNewItemCTPN,
            this.tsbDeleteItemCTPN,
            this.tsbSaveNewItemCTPN});
            this.bindingNavigatorCTPN.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigatorCTPN.MoveFirstItem = this.tsbMoveFirstItemCTPN;
            this.bindingNavigatorCTPN.MoveLastItem = this.tsbMoveLastItemCTPN;
            this.bindingNavigatorCTPN.MoveNextItem = this.tsbMoveNextItemCTPN;
            this.bindingNavigatorCTPN.MovePreviousItem = this.tsbMovePreviousItemCTPN;
            this.bindingNavigatorCTPN.Name = "bindingNavigatorCTPN";
            this.bindingNavigatorCTPN.PositionItem = this.tstbPositionItemCTPN;
            this.bindingNavigatorCTPN.Size = new System.Drawing.Size(709, 24);
            this.bindingNavigatorCTPN.TabIndex = 4;
            this.bindingNavigatorCTPN.Text = "bindingNavigator2";
            // 
            // tsbAddNewItemCTPN
            // 
            this.tsbAddNewItemCTPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemCTPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemCTPN.Image")));
            this.tsbAddNewItemCTPN.Name = "tsbAddNewItemCTPN";
            this.tsbAddNewItemCTPN.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemCTPN.Size = new System.Drawing.Size(23, 21);
            this.tsbAddNewItemCTPN.Text = "Add new";
            // 
            // tslCountItem1
            // 
            this.tslCountItem1.Name = "tslCountItem1";
            this.tslCountItem1.Size = new System.Drawing.Size(35, 21);
            this.tslCountItem1.Text = "of {0}";
            this.tslCountItem1.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemCTPN
            // 
            this.tsbDeleteItemCTPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemCTPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemCTPN.Image")));
            this.tsbDeleteItemCTPN.Name = "tsbDeleteItemCTPN";
            this.tsbDeleteItemCTPN.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemCTPN.Size = new System.Drawing.Size(23, 21);
            this.tsbDeleteItemCTPN.Text = "Delete";
            // 
            // tsbMoveFirstItemCTPN
            // 
            this.tsbMoveFirstItemCTPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemCTPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemCTPN.Image")));
            this.tsbMoveFirstItemCTPN.Name = "tsbMoveFirstItemCTPN";
            this.tsbMoveFirstItemCTPN.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemCTPN.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveFirstItemCTPN.Text = "Move first";
            // 
            // tsbMovePreviousItemCTPN
            // 
            this.tsbMovePreviousItemCTPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemCTPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemCTPN.Image")));
            this.tsbMovePreviousItemCTPN.Name = "tsbMovePreviousItemCTPN";
            this.tsbMovePreviousItemCTPN.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemCTPN.Size = new System.Drawing.Size(23, 21);
            this.tsbMovePreviousItemCTPN.Text = "Move previous";
            // 
            // tsSeparator3
            // 
            this.tsSeparator3.Name = "tsSeparator3";
            this.tsSeparator3.Size = new System.Drawing.Size(6, 24);
            // 
            // tstbPositionItemCTPN
            // 
            this.tstbPositionItemCTPN.AccessibleName = "Position";
            this.tstbPositionItemCTPN.AutoSize = false;
            this.tstbPositionItemCTPN.Name = "tstbPositionItemCTPN";
            this.tstbPositionItemCTPN.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemCTPN.Text = "0";
            this.tstbPositionItemCTPN.ToolTipText = "Current position";
            // 
            // tsSeparator4
            // 
            this.tsSeparator4.Name = "tsSeparator4";
            this.tsSeparator4.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbMoveNextItemCTPN
            // 
            this.tsbMoveNextItemCTPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemCTPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemCTPN.Image")));
            this.tsbMoveNextItemCTPN.Name = "tsbMoveNextItemCTPN";
            this.tsbMoveNextItemCTPN.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemCTPN.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveNextItemCTPN.Text = "Move next";
            // 
            // tsbMoveLastItemCTPN
            // 
            this.tsbMoveLastItemCTPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemCTPN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemCTPN.Image")));
            this.tsbMoveLastItemCTPN.Name = "tsbMoveLastItemCTPN";
            this.tsbMoveLastItemCTPN.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemCTPN.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveLastItemCTPN.Text = "Move last";
            // 
            // tsSeparator5
            // 
            this.tsSeparator5.Name = "tsSeparator5";
            this.tsSeparator5.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbSaveNewItemCTPN
            // 
            this.tsbSaveNewItemCTPN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemCTPN.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemCTPN.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemCTPN.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemCTPN.Name = "tsbSaveNewItemCTPN";
            this.tsbSaveNewItemCTPN.Size = new System.Drawing.Size(23, 21);
            this.tsbSaveNewItemCTPN.Text = "Save";
            // 
            // dgvChiTietPhieuNhap
            // 
            this.dgvChiTietPhieuNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPhieuNhap.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvChiTietPhieuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPhieuNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.MaLoai,
            this.DVT,
            this.SL,
            this.GiaNhap});
            this.dgvChiTietPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChiTietPhieuNhap.Location = new System.Drawing.Point(3, 27);
            this.dgvChiTietPhieuNhap.Name = "dgvChiTietPhieuNhap";
            this.dgvChiTietPhieuNhap.Size = new System.Drawing.Size(703, 144);
            this.dgvChiTietPhieuNhap.TabIndex = 3;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã Hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên Hàng";
            this.TenHang.Name = "TenHang";
            // 
            // MaLoai
            // 
            this.MaLoai.HeaderText = "Mã loại";
            this.MaLoai.Name = "MaLoai";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // SL
            // 
            this.SL.HeaderText = "Số lượng";
            this.SL.Name = "SL";
            // 
            // GiaNhap
            // 
            this.GiaNhap.HeaderText = "Giá nhập";
            this.GiaNhap.Name = "GiaNhap";
            // 
            // tblpPhieuNhap
            // 
            this.tblpPhieuNhap.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tblpPhieuNhap.ColumnCount = 1;
            this.tblpPhieuNhap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpPhieuNhap.Controls.Add(this.grbChiTietPhieuNhapKho, 0, 1);
            this.tblpPhieuNhap.Controls.Add(this.grbThongTinPhieuNhapKho, 0, 0);
            this.tblpPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpPhieuNhap.Location = new System.Drawing.Point(0, 0);
            this.tblpPhieuNhap.Name = "tblpPhieuNhap";
            this.tblpPhieuNhap.RowCount = 2;
            this.tblpPhieuNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblpPhieuNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblpPhieuNhap.Size = new System.Drawing.Size(727, 407);
            this.tblpPhieuNhap.TabIndex = 6;
            // 
            // grbChiTietPhieuNhapKho
            // 
            this.grbChiTietPhieuNhapKho.Controls.Add(this.tlbChiTietPhieuNhap);
            this.grbChiTietPhieuNhapKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietPhieuNhapKho.Location = new System.Drawing.Point(6, 208);
            this.grbChiTietPhieuNhapKho.Name = "grbChiTietPhieuNhapKho";
            this.grbChiTietPhieuNhapKho.Size = new System.Drawing.Size(715, 193);
            this.grbChiTietPhieuNhapKho.TabIndex = 5;
            this.grbChiTietPhieuNhapKho.TabStop = false;
            this.grbChiTietPhieuNhapKho.Text = "Chi tiết phiếu nhập kho";
            // 
            // ucPhieuNhapKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblpPhieuNhap);
            this.Name = "ucPhieuNhapKho";
            this.Size = new System.Drawing.Size(727, 407);
            this.grbThongTinPhieuNhapKho.ResumeLayout(false);
            this.tlpThongTinPhieuNhap.ResumeLayout(false);
            this.tlpThongTinPhieuNhap.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorPN)).EndInit();
            this.bindingNavigatorPN.ResumeLayout(false);
            this.bindingNavigatorPN.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinPN)).EndInit();
            this.tlbChiTietPhieuNhap.ResumeLayout(false);
            this.tlbChiTietPhieuNhap.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorCTPN)).EndInit();
            this.bindingNavigatorCTPN.ResumeLayout(false);
            this.bindingNavigatorCTPN.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuNhap)).EndInit();
            this.tblpPhieuNhap.ResumeLayout(false);
            this.grbChiTietPhieuNhapKho.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbThongTinPhieuNhapKho;
        private System.Windows.Forms.TableLayoutPanel tlpThongTinPhieuNhap;
        private System.Windows.Forms.TableLayoutPanel tlbChiTietPhieuNhap;
        private System.Windows.Forms.TableLayoutPanel tblpPhieuNhap;
        private System.Windows.Forms.GroupBox grbChiTietPhieuNhapKho;
        private System.Windows.Forms.BindingNavigator bindingNavigatorPN;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemPN;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemPN;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemPN;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemPN;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemPN;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemPN;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemPN;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemPN;
        private System.Windows.Forms.DataGridView dgvThongTinPN;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPN;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNCC;
        private System.Windows.Forms.DataGridViewTextBoxColumn NhanVienNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongGiaTri;
        private System.Windows.Forms.BindingNavigator bindingNavigatorCTPN;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemCTPN;
        private System.Windows.Forms.ToolStripLabel tslCountItem1;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemCTPN;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemCTPN;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemCTPN;
        private System.Windows.Forms.ToolStripSeparator tsSeparator3;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemCTPN;
        private System.Windows.Forms.ToolStripSeparator tsSeparator4;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemCTPN;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemCTPN;
        private System.Windows.Forms.ToolStripSeparator tsSeparator5;
        private System.Windows.Forms.DataGridView dgvChiTietPhieuNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SL;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaNhap;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemCTPN;
    }
}
