﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucDanhMucLoaiHang
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucDanhMucLoaiHang));
            this.tlpDanhMucLoaiHang = new System.Windows.Forms.TableLayoutPanel();
            this.pnlDvgDanhMucHang = new System.Windows.Forms.Panel();
            this.dvgDanhMucLoaiHang = new System.Windows.Forms.DataGridView();
            this.MaLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbMaHang = new System.Windows.Forms.ComboBox();
            this.lblMaHang = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblTenHang = new System.Windows.Forms.Label();
            this.cbTenHang = new System.Windows.Forms.ComboBox();
            this.bindingNavigatorDMLH = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemDMLH = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemDMLH = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemDMLH = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemDMLH = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemDMLH = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemDMLH = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemDMLH = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemDMLH = new System.Windows.Forms.ToolStripButton();
            this.tlpDanhMucLoaiHang.SuspendLayout();
            this.pnlDvgDanhMucHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgDanhMucLoaiHang)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorDMLH)).BeginInit();
            this.bindingNavigatorDMLH.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpDanhMucLoaiHang
            // 
            this.tlpDanhMucLoaiHang.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpDanhMucLoaiHang.ColumnCount = 1;
            this.tlpDanhMucLoaiHang.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpDanhMucLoaiHang.Controls.Add(this.bindingNavigatorDMLH, 0, 2);
            this.tlpDanhMucLoaiHang.Controls.Add(this.pnlDvgDanhMucHang, 0, 1);
            this.tlpDanhMucLoaiHang.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tlpDanhMucLoaiHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpDanhMucLoaiHang.Location = new System.Drawing.Point(0, 0);
            this.tlpDanhMucLoaiHang.Name = "tlpDanhMucLoaiHang";
            this.tlpDanhMucLoaiHang.RowCount = 3;
            this.tlpDanhMucLoaiHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tlpDanhMucLoaiHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpDanhMucLoaiHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tlpDanhMucLoaiHang.Size = new System.Drawing.Size(603, 368);
            this.tlpDanhMucLoaiHang.TabIndex = 10;
            // 
            // pnlDvgDanhMucHang
            // 
            this.pnlDvgDanhMucHang.Controls.Add(this.dvgDanhMucLoaiHang);
            this.pnlDvgDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDvgDanhMucHang.Location = new System.Drawing.Point(6, 79);
            this.pnlDvgDanhMucHang.Name = "pnlDvgDanhMucHang";
            this.pnlDvgDanhMucHang.Size = new System.Drawing.Size(591, 255);
            this.pnlDvgDanhMucHang.TabIndex = 0;
            // 
            // dvgDanhMucLoaiHang
            // 
            this.dvgDanhMucLoaiHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dvgDanhMucLoaiHang.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dvgDanhMucLoaiHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgDanhMucLoaiHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaLoai,
            this.TenLoai});
            this.dvgDanhMucLoaiHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dvgDanhMucLoaiHang.Location = new System.Drawing.Point(0, 0);
            this.dvgDanhMucLoaiHang.Name = "dvgDanhMucLoaiHang";
            this.dvgDanhMucLoaiHang.Size = new System.Drawing.Size(591, 255);
            this.dvgDanhMucLoaiHang.TabIndex = 13;
            // 
            // MaLoai
            // 
            this.MaLoai.FillWeight = 50.76142F;
            this.MaLoai.HeaderText = "Mã loại";
            this.MaLoai.Name = "MaLoai";
            // 
            // TenLoai
            // 
            this.TenLoai.FillWeight = 149.2386F;
            this.TenLoai.HeaderText = "Tên loại";
            this.TenLoai.Name = "TenLoai";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(6, 6);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(591, 64);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cbMaHang);
            this.panel2.Controls.Add(this.lblMaHang);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(5, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(227, 54);
            this.panel2.TabIndex = 0;
            // 
            // cbMaHang
            // 
            this.cbMaHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbMaHang.FormattingEnabled = true;
            this.cbMaHang.Location = new System.Drawing.Point(9, 27);
            this.cbMaHang.Name = "cbMaHang";
            this.cbMaHang.Size = new System.Drawing.Size(185, 21);
            this.cbMaHang.TabIndex = 1;
            // 
            // lblMaHang
            // 
            this.lblMaHang.AutoSize = true;
            this.lblMaHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaHang.Location = new System.Drawing.Point(6, 8);
            this.lblMaHang.Name = "lblMaHang";
            this.lblMaHang.Size = new System.Drawing.Size(100, 15);
            this.lblMaHang.TabIndex = 0;
            this.lblMaHang.Text = "Chọn mã hàng";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.cbTenHang);
            this.panel3.Controls.Add(this.lblTenHang);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(240, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(346, 54);
            this.panel3.TabIndex = 1;
            // 
            // lblTenHang
            // 
            this.lblTenHang.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTenHang.AutoSize = true;
            this.lblTenHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenHang.Location = new System.Drawing.Point(12, 8);
            this.lblTenHang.Name = "lblTenHang";
            this.lblTenHang.Size = new System.Drawing.Size(67, 15);
            this.lblTenHang.TabIndex = 0;
            this.lblTenHang.Text = "Tên hàng";
            // 
            // cbTenHang
            // 
            this.cbTenHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbTenHang.FormattingEnabled = true;
            this.cbTenHang.Location = new System.Drawing.Point(15, 27);
            this.cbTenHang.Name = "cbTenHang";
            this.cbTenHang.Size = new System.Drawing.Size(258, 21);
            this.cbTenHang.TabIndex = 2;
            // 
            // bindingNavigatorDMLH
            // 
            this.bindingNavigatorDMLH.AddNewItem = this.tsbAddNewItemDMLH;
            this.bindingNavigatorDMLH.CountItem = this.tslCountItem;
            this.bindingNavigatorDMLH.DeleteItem = this.tsbDeleteItemDMLH;
            this.bindingNavigatorDMLH.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigatorDMLH.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemDMLH,
            this.tsbMovePreviousItemDMLH,
            this.tsSeparator,
            this.tstbPositionItemDMLH,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemDMLH,
            this.tsbMoveLastItemDMLH,
            this.tslSeparator2,
            this.tsbAddNewItemDMLH,
            this.tsbDeleteItemDMLH,
            this.tsbSaveNewItemDMLH});
            this.bindingNavigatorDMLH.Location = new System.Drawing.Point(3, 340);
            this.bindingNavigatorDMLH.MoveFirstItem = this.tsbMoveFirstItemDMLH;
            this.bindingNavigatorDMLH.MoveLastItem = this.tsbMoveLastItemDMLH;
            this.bindingNavigatorDMLH.MoveNextItem = this.tsbMoveNextItemDMLH;
            this.bindingNavigatorDMLH.MovePreviousItem = this.tsbMovePreviousItemDMLH;
            this.bindingNavigatorDMLH.Name = "bindingNavigatorDMLH";
            this.bindingNavigatorDMLH.PositionItem = this.tstbPositionItemDMLH;
            this.bindingNavigatorDMLH.Size = new System.Drawing.Size(597, 25);
            this.bindingNavigatorDMLH.TabIndex = 13;
            this.bindingNavigatorDMLH.Text = "bindingNavigator1";
            // 
            // tsbAddNewItemDMLH
            // 
            this.tsbAddNewItemDMLH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemDMLH.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemDMLH.Image")));
            this.tsbAddNewItemDMLH.Name = "tsbAddNewItemDMLH";
            this.tsbAddNewItemDMLH.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemDMLH.Size = new System.Drawing.Size(23, 22);
            this.tsbAddNewItemDMLH.Text = "Add new";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 22);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemDMLH
            // 
            this.tsbDeleteItemDMLH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemDMLH.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemDMLH.Image")));
            this.tsbDeleteItemDMLH.Name = "tsbDeleteItemDMLH";
            this.tsbDeleteItemDMLH.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemDMLH.Size = new System.Drawing.Size(23, 22);
            this.tsbDeleteItemDMLH.Text = "Delete";
            // 
            // tsbMoveFirstItemDMLH
            // 
            this.tsbMoveFirstItemDMLH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemDMLH.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemDMLH.Image")));
            this.tsbMoveFirstItemDMLH.Name = "tsbMoveFirstItemDMLH";
            this.tsbMoveFirstItemDMLH.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemDMLH.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveFirstItemDMLH.Text = "Move first";
            // 
            // tsbMovePreviousItemDMLH
            // 
            this.tsbMovePreviousItemDMLH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemDMLH.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemDMLH.Image")));
            this.tsbMovePreviousItemDMLH.Name = "tsbMovePreviousItemDMLH";
            this.tsbMovePreviousItemDMLH.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemDMLH.Size = new System.Drawing.Size(23, 22);
            this.tsbMovePreviousItemDMLH.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // tstbPositionItemDMLH
            // 
            this.tstbPositionItemDMLH.AccessibleName = "Position";
            this.tstbPositionItemDMLH.AutoSize = false;
            this.tstbPositionItemDMLH.Name = "tstbPositionItemDMLH";
            this.tstbPositionItemDMLH.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemDMLH.Text = "0";
            this.tstbPositionItemDMLH.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbMoveNextItemDMLH
            // 
            this.tsbMoveNextItemDMLH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemDMLH.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemDMLH.Image")));
            this.tsbMoveNextItemDMLH.Name = "tsbMoveNextItemDMLH";
            this.tsbMoveNextItemDMLH.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemDMLH.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveNextItemDMLH.Text = "Move next";
            // 
            // tsbMoveLastItemDMLH
            // 
            this.tsbMoveLastItemDMLH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemDMLH.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemDMLH.Image")));
            this.tsbMoveLastItemDMLH.Name = "tsbMoveLastItemDMLH";
            this.tsbMoveLastItemDMLH.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemDMLH.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveLastItemDMLH.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbSaveNewItemDMLH
            // 
            this.tsbSaveNewItemDMLH.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemDMLH.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemDMLH.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemDMLH.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemDMLH.Name = "tsbSaveNewItemDMLH";
            this.tsbSaveNewItemDMLH.Size = new System.Drawing.Size(23, 22);
            this.tsbSaveNewItemDMLH.Text = "Save";
            // 
            // ucDanhMucLoaiHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.tlpDanhMucLoaiHang);
            this.Name = "ucDanhMucLoaiHang";
            this.Size = new System.Drawing.Size(603, 368);
            this.tlpDanhMucLoaiHang.ResumeLayout(false);
            this.tlpDanhMucLoaiHang.PerformLayout();
            this.pnlDvgDanhMucHang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dvgDanhMucLoaiHang)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorDMLH)).EndInit();
            this.bindingNavigatorDMLH.ResumeLayout(false);
            this.bindingNavigatorDMLH.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpDanhMucLoaiHang;
        private System.Windows.Forms.Panel pnlDvgDanhMucHang;
        private System.Windows.Forms.DataGridView dvgDanhMucLoaiHang;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblMaHang;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox cbMaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenLoai;
        private System.Windows.Forms.Label lblTenHang;
        private System.Windows.Forms.ComboBox cbTenHang;
        private System.Windows.Forms.BindingNavigator bindingNavigatorDMLH;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemDMLH;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemDMLH;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemDMLH;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemDMLH;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemDMLH;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemDMLH;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemDMLH;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemDMLH;

    }
}
