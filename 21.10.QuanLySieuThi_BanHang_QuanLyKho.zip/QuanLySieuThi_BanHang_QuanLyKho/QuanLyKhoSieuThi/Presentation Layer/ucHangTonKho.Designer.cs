﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucHangTonKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucHangTonKho));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorTK = new System.Windows.Forms.BindingNavigator(this.components);
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemTK = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.grbDanhMucHangTonKho = new System.Windows.Forms.GroupBox();
            this.dgvDanhMucHangTonKho = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNhom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ViTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinTonKho = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbDonViTinh = new System.Windows.Forms.ComboBox();
            this.lblDonViTinh = new System.Windows.Forms.Label();
            this.cbTenHang = new System.Windows.Forms.ComboBox();
            this.vboMaHang = new System.Windows.Forms.ComboBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.lblNCC = new System.Windows.Forms.Label();
            this.lblTenHang = new System.Windows.Forms.Label();
            this.lblMaHang = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cboMaLoai = new System.Windows.Forms.ComboBox();
            this.cboMaNhom = new System.Windows.Forms.ComboBox();
            this.txtViTriKho = new System.Windows.Forms.TextBox();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.lblMaLoai = new System.Windows.Forms.Label();
            this.lblMaNhom = new System.Windows.Forms.Label();
            this.lblViTriKho = new System.Windows.Forms.Label();
            this.lblDonGia = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.chkHetHang = new System.Windows.Forms.CheckBox();
            this.chkKhuyenMai = new System.Windows.Forms.CheckBox();
            this.numDen = new System.Windows.Forms.NumericUpDown();
            this.numTu = new System.Windows.Forms.NumericUpDown();
            this.lblDen = new System.Windows.Forms.Label();
            this.lblTu = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.raNhoHon = new System.Windows.Forms.RadioButton();
            this.raLonHon = new System.Windows.Forms.RadioButton();
            this.btnXemTheKho = new System.Windows.Forms.Button();
            this.btnHienThiTatCa = new System.Windows.Forms.Button();
            this.tsbAddNewItemTK = new System.Windows.Forms.ToolStripButton();
            this.tsbDeleteItemTK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemTK = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemTK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveNextItemTK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemTK = new System.Windows.Forms.ToolStripButton();
            this.tsbSaveNewItemTK = new System.Windows.Forms.ToolStripButton();
            this.btnLoc = new System.Windows.Forms.Button();
            this.btnNhapLai = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorTK)).BeginInit();
            this.bindingNavigatorTK.SuspendLayout();
            this.grbDanhMucHangTonKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHangTonKho)).BeginInit();
            this.grbThongTinTonKho.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.bindingNavigatorTK, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.grbDanhMucHangTonKho, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.grbThongTinTonKho, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 162F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(605, 463);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // bindingNavigatorTK
            // 
            this.bindingNavigatorTK.AddNewItem = this.tsbAddNewItemTK;
            this.bindingNavigatorTK.CountItem = this.tslCountItem;
            this.bindingNavigatorTK.DeleteItem = this.tsbDeleteItemTK;
            this.bindingNavigatorTK.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemTK,
            this.tsbMovePreviousItemTK,
            this.tsSeparator,
            this.tstbPositionItemTK,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemTK,
            this.tsbMoveLastItemTK,
            this.tslSeparator2,
            this.tsbAddNewItemTK,
            this.tsbDeleteItemTK,
            this.tsbSaveNewItemTK});
            this.bindingNavigatorTK.Location = new System.Drawing.Point(0, 435);
            this.bindingNavigatorTK.MoveFirstItem = this.tsbMoveFirstItemTK;
            this.bindingNavigatorTK.MoveLastItem = this.tsbMoveLastItemTK;
            this.bindingNavigatorTK.MoveNextItem = this.tsbMoveNextItemTK;
            this.bindingNavigatorTK.MovePreviousItem = this.tsbMovePreviousItemTK;
            this.bindingNavigatorTK.Name = "bindingNavigatorTK";
            this.bindingNavigatorTK.PositionItem = this.tstbPositionItemTK;
            this.bindingNavigatorTK.Size = new System.Drawing.Size(605, 25);
            this.bindingNavigatorTK.TabIndex = 13;
            this.bindingNavigatorTK.Text = "bindingNavigator1";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 22);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // tstbPositionItemTK
            // 
            this.tstbPositionItemTK.AccessibleName = "Position";
            this.tstbPositionItemTK.AutoSize = false;
            this.tstbPositionItemTK.Name = "tstbPositionItemTK";
            this.tstbPositionItemTK.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemTK.Text = "0";
            this.tstbPositionItemTK.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // grbDanhMucHangTonKho
            // 
            this.grbDanhMucHangTonKho.Controls.Add(this.dgvDanhMucHangTonKho);
            this.grbDanhMucHangTonKho.Dock = System.Windows.Forms.DockStyle.Top;
            this.grbDanhMucHangTonKho.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDanhMucHangTonKho.Location = new System.Drawing.Point(3, 165);
            this.grbDanhMucHangTonKho.Name = "grbDanhMucHangTonKho";
            this.grbDanhMucHangTonKho.Size = new System.Drawing.Size(599, 267);
            this.grbDanhMucHangTonKho.TabIndex = 12;
            this.grbDanhMucHangTonKho.TabStop = false;
            this.grbDanhMucHangTonKho.Text = "Danh mục hàng tồn kho";
            // 
            // dgvDanhMucHangTonKho
            // 
            this.dgvDanhMucHangTonKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhMucHangTonKho.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvDanhMucHangTonKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhMucHangTonKho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.SoLuong,
            this.MaNhom,
            this.MaLoai,
            this.DonGia,
            this.DVT,
            this.ViTri});
            this.dgvDanhMucHangTonKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhMucHangTonKho.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhMucHangTonKho.Name = "dgvDanhMucHangTonKho";
            this.dgvDanhMucHangTonKho.Size = new System.Drawing.Size(593, 248);
            this.dgvDanhMucHangTonKho.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // SoLuong
            // 
            this.SoLuong.HeaderText = "Số lượng";
            this.SoLuong.Name = "SoLuong";
            // 
            // MaNhom
            // 
            this.MaNhom.HeaderText = "Mã nhóm";
            this.MaNhom.Name = "MaNhom";
            // 
            // MaLoai
            // 
            this.MaLoai.HeaderText = "Mã loại";
            this.MaLoai.Name = "MaLoai";
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Đơn giá";
            this.DonGia.Name = "DonGia";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // ViTri
            // 
            this.ViTri.HeaderText = "Vị trí kho";
            this.ViTri.Name = "ViTri";
            // 
            // grbThongTinTonKho
            // 
            this.grbThongTinTonKho.Controls.Add(this.tableLayoutPanel2);
            this.grbThongTinTonKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinTonKho.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinTonKho.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinTonKho.Name = "grbThongTinTonKho";
            this.grbThongTinTonKho.Size = new System.Drawing.Size(599, 156);
            this.grbThongTinTonKho.TabIndex = 0;
            this.grbThongTinTonKho.TabStop = false;
            this.grbThongTinTonKho.Text = "Thông tin hàng tồn kho";
            this.grbThongTinTonKho.Enter += new System.EventHandler(this.grbThongTinTonKho_Enter);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetPartial;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.6172F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.96627F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.58516F));
            this.tableLayoutPanel2.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel3, 2, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 137F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 137F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 137F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(593, 137);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chkKhuyenMai);
            this.panel1.Controls.Add(this.chkHetHang);
            this.panel1.Controls.Add(this.cbDonViTinh);
            this.panel1.Controls.Add(this.lblDonViTinh);
            this.panel1.Controls.Add(this.numDen);
            this.panel1.Controls.Add(this.lblDen);
            this.panel1.Controls.Add(this.cbTenHang);
            this.panel1.Controls.Add(this.numTu);
            this.panel1.Controls.Add(this.vboMaHang);
            this.panel1.Controls.Add(this.lblTu);
            this.panel1.Controls.Add(this.txtSoLuong);
            this.panel1.Controls.Add(this.lblNCC);
            this.panel1.Controls.Add(this.lblTenHang);
            this.panel1.Controls.Add(this.lblMaHang);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(217, 125);
            this.panel1.TabIndex = 0;
            // 
            // cbDonViTinh
            // 
            this.cbDonViTinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbDonViTinh.FormattingEnabled = true;
            this.cbDonViTinh.Location = new System.Drawing.Point(154, 53);
            this.cbDonViTinh.Name = "cbDonViTinh";
            this.cbDonViTinh.Size = new System.Drawing.Size(60, 22);
            this.cbDonViTinh.TabIndex = 18;
            // 
            // lblDonViTinh
            // 
            this.lblDonViTinh.AutoSize = true;
            this.lblDonViTinh.Location = new System.Drawing.Point(107, 58);
            this.lblDonViTinh.Name = "lblDonViTinh";
            this.lblDonViTinh.Size = new System.Drawing.Size(47, 14);
            this.lblDonViTinh.TabIndex = 17;
            this.lblDonViTinh.Text = "ĐV tính";
            // 
            // cbTenHang
            // 
            this.cbTenHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbTenHang.FormattingEnabled = true;
            this.cbTenHang.Location = new System.Drawing.Point(57, 27);
            this.cbTenHang.Name = "cbTenHang";
            this.cbTenHang.Size = new System.Drawing.Size(157, 22);
            this.cbTenHang.TabIndex = 14;
            // 
            // vboMaHang
            // 
            this.vboMaHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.vboMaHang.FormattingEnabled = true;
            this.vboMaHang.Location = new System.Drawing.Point(57, 1);
            this.vboMaHang.Name = "vboMaHang";
            this.vboMaHang.Size = new System.Drawing.Size(157, 22);
            this.vboMaHang.TabIndex = 13;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtSoLuong.Location = new System.Drawing.Point(57, 53);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(49, 20);
            this.txtSoLuong.TabIndex = 12;
            // 
            // lblNCC
            // 
            this.lblNCC.AutoSize = true;
            this.lblNCC.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNCC.Location = new System.Drawing.Point(-1, 59);
            this.lblNCC.Name = "lblNCC";
            this.lblNCC.Size = new System.Drawing.Size(57, 14);
            this.lblNCC.TabIndex = 9;
            this.lblNCC.Text = "Số lượng";
            // 
            // lblTenHang
            // 
            this.lblTenHang.AutoSize = true;
            this.lblTenHang.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenHang.Location = new System.Drawing.Point(-2, 33);
            this.lblTenHang.Name = "lblTenHang";
            this.lblTenHang.Size = new System.Drawing.Size(58, 14);
            this.lblTenHang.TabIndex = 10;
            this.lblTenHang.Text = "Tên Hàng";
            // 
            // lblMaHang
            // 
            this.lblMaHang.AutoSize = true;
            this.lblMaHang.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaHang.Location = new System.Drawing.Point(3, 8);
            this.lblMaHang.Name = "lblMaHang";
            this.lblMaHang.Size = new System.Drawing.Size(53, 14);
            this.lblMaHang.TabIndex = 11;
            this.lblMaHang.Text = "Mã hàng";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnLoc);
            this.panel2.Controls.Add(this.numericUpDown2);
            this.panel2.Controls.Add(this.numericUpDown1);
            this.panel2.Controls.Add(this.raNhoHon);
            this.panel2.Controls.Add(this.raLonHon);
            this.panel2.Controls.Add(this.cboMaLoai);
            this.panel2.Controls.Add(this.cboMaNhom);
            this.panel2.Controls.Add(this.txtViTriKho);
            this.panel2.Controls.Add(this.txtDonGia);
            this.panel2.Controls.Add(this.lblMaLoai);
            this.panel2.Controls.Add(this.lblMaNhom);
            this.panel2.Controls.Add(this.lblViTriKho);
            this.panel2.Controls.Add(this.lblDonGia);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(232, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(225, 125);
            this.panel2.TabIndex = 0;
            // 
            // cboMaLoai
            // 
            this.cboMaLoai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboMaLoai.FormattingEnabled = true;
            this.cboMaLoai.Location = new System.Drawing.Point(173, 1);
            this.cboMaLoai.Name = "cboMaLoai";
            this.cboMaLoai.Size = new System.Drawing.Size(46, 22);
            this.cboMaLoai.TabIndex = 10;
            // 
            // cboMaNhom
            // 
            this.cboMaNhom.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cboMaNhom.FormattingEnabled = true;
            this.cboMaNhom.Location = new System.Drawing.Point(60, 1);
            this.cboMaNhom.Name = "cboMaNhom";
            this.cboMaNhom.Size = new System.Drawing.Size(68, 22);
            this.cboMaNhom.TabIndex = 11;
            // 
            // txtViTriKho
            // 
            this.txtViTriKho.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtViTriKho.Location = new System.Drawing.Point(60, 52);
            this.txtViTriKho.Name = "txtViTriKho";
            this.txtViTriKho.Size = new System.Drawing.Size(159, 20);
            this.txtViTriKho.TabIndex = 8;
            // 
            // txtDonGia
            // 
            this.txtDonGia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDonGia.Location = new System.Drawing.Point(60, 28);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(159, 20);
            this.txtDonGia.TabIndex = 9;
            // 
            // lblMaLoai
            // 
            this.lblMaLoai.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblMaLoai.AutoSize = true;
            this.lblMaLoai.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaLoai.Location = new System.Drawing.Point(128, 5);
            this.lblMaLoai.Name = "lblMaLoai";
            this.lblMaLoai.Size = new System.Drawing.Size(45, 14);
            this.lblMaLoai.TabIndex = 5;
            this.lblMaLoai.Text = "Mã loại";
            // 
            // lblMaNhom
            // 
            this.lblMaNhom.AutoSize = true;
            this.lblMaNhom.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaNhom.Location = new System.Drawing.Point(3, 5);
            this.lblMaNhom.Name = "lblMaNhom";
            this.lblMaNhom.Size = new System.Drawing.Size(58, 14);
            this.lblMaNhom.TabIndex = 4;
            this.lblMaNhom.Text = "Mã nhóm";
            // 
            // lblViTriKho
            // 
            this.lblViTriKho.AutoSize = true;
            this.lblViTriKho.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViTriKho.Location = new System.Drawing.Point(2, 56);
            this.lblViTriKho.Name = "lblViTriKho";
            this.lblViTriKho.Size = new System.Drawing.Size(57, 14);
            this.lblViTriKho.TabIndex = 7;
            this.lblViTriKho.Text = "Vị trí kho";
            // 
            // lblDonGia
            // 
            this.lblDonGia.AutoSize = true;
            this.lblDonGia.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDonGia.Location = new System.Drawing.Point(3, 30);
            this.lblDonGia.Name = "lblDonGia";
            this.lblDonGia.Size = new System.Drawing.Size(49, 14);
            this.lblDonGia.TabIndex = 6;
            this.lblDonGia.Text = "Đơn giá";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnNhapLai);
            this.panel3.Controls.Add(this.btnXemTheKho);
            this.panel3.Controls.Add(this.btnHienThiTatCa);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(466, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(121, 125);
            this.panel3.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, -3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 14);
            this.label1.TabIndex = 4;
            this.label1.Text = "Hình minh hoạ";
            // 
            // chkHetHang
            // 
            this.chkHetHang.AutoSize = true;
            this.chkHetHang.Location = new System.Drawing.Point(6, 106);
            this.chkHetHang.Name = "chkHetHang";
            this.chkHetHang.Size = new System.Drawing.Size(74, 18);
            this.chkHetHang.TabIndex = 19;
            this.chkHetHang.Text = "Hết Hàng";
            this.chkHetHang.UseVisualStyleBackColor = true;
            // 
            // chkKhuyenMai
            // 
            this.chkKhuyenMai.AutoSize = true;
            this.chkKhuyenMai.Location = new System.Drawing.Point(106, 106);
            this.chkKhuyenMai.Name = "chkKhuyenMai";
            this.chkKhuyenMai.Size = new System.Drawing.Size(90, 18);
            this.chkKhuyenMai.TabIndex = 19;
            this.chkKhuyenMai.Text = "Khuyến mãi";
            this.chkKhuyenMai.UseVisualStyleBackColor = true;
            // 
            // numDen
            // 
            this.numDen.Location = new System.Drawing.Point(134, 81);
            this.numDen.Name = "numDen";
            this.numDen.Size = new System.Drawing.Size(62, 20);
            this.numDen.TabIndex = 14;
            // 
            // numTu
            // 
            this.numTu.Location = new System.Drawing.Point(29, 81);
            this.numTu.Name = "numTu";
            this.numTu.Size = new System.Drawing.Size(62, 20);
            this.numTu.TabIndex = 15;
            // 
            // lblDen
            // 
            this.lblDen.AutoSize = true;
            this.lblDen.Location = new System.Drawing.Point(106, 84);
            this.lblDen.Name = "lblDen";
            this.lblDen.Size = new System.Drawing.Size(29, 14);
            this.lblDen.TabIndex = 12;
            this.lblDen.Text = "Đến";
            // 
            // lblTu
            // 
            this.lblTu.AutoSize = true;
            this.lblTu.Location = new System.Drawing.Point(6, 84);
            this.lblTu.Name = "lblTu";
            this.lblTu.Size = new System.Drawing.Size(22, 14);
            this.lblTu.TabIndex = 13;
            this.lblTu.Text = "Từ";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(76, 103);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(62, 20);
            this.numericUpDown2.TabIndex = 18;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(76, 80);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(62, 20);
            this.numericUpDown1.TabIndex = 19;
            // 
            // raNhoHon
            // 
            this.raNhoHon.AutoSize = true;
            this.raNhoHon.Location = new System.Drawing.Point(4, 104);
            this.raNhoHon.Name = "raNhoHon";
            this.raNhoHon.Size = new System.Drawing.Size(71, 18);
            this.raNhoHon.TabIndex = 16;
            this.raNhoHon.TabStop = true;
            this.raNhoHon.Text = "Nhỏ hơn";
            this.raNhoHon.UseVisualStyleBackColor = true;
            // 
            // raLonHon
            // 
            this.raLonHon.AutoSize = true;
            this.raLonHon.Location = new System.Drawing.Point(4, 81);
            this.raLonHon.Name = "raLonHon";
            this.raLonHon.Size = new System.Drawing.Size(72, 18);
            this.raLonHon.TabIndex = 17;
            this.raLonHon.TabStop = true;
            this.raLonHon.Text = "Lớn hơn";
            this.raLonHon.UseVisualStyleBackColor = true;
            // 
            // btnXemTheKho
            // 
            this.btnXemTheKho.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.Next;
            this.btnXemTheKho.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnXemTheKho.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXemTheKho.Location = new System.Drawing.Point(6, 50);
            this.btnXemTheKho.Name = "btnXemTheKho";
            this.btnXemTheKho.Size = new System.Drawing.Size(112, 34);
            this.btnXemTheKho.TabIndex = 6;
            this.btnXemTheKho.Text = "&Xem thẻ kho";
            this.btnXemTheKho.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXemTheKho.UseVisualStyleBackColor = true;
            // 
            // btnHienThiTatCa
            // 
            this.btnHienThiTatCa.Location = new System.Drawing.Point(6, 12);
            this.btnHienThiTatCa.Name = "btnHienThiTatCa";
            this.btnHienThiTatCa.Size = new System.Drawing.Size(112, 34);
            this.btnHienThiTatCa.TabIndex = 5;
            this.btnHienThiTatCa.Text = "&Hiển thị tất cả";
            this.btnHienThiTatCa.UseVisualStyleBackColor = true;
            // 
            // tsbAddNewItemTK
            // 
            this.tsbAddNewItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemTK.Image")));
            this.tsbAddNewItemTK.Name = "tsbAddNewItemTK";
            this.tsbAddNewItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbAddNewItemTK.Text = "Add new";
            // 
            // tsbDeleteItemTK
            // 
            this.tsbDeleteItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemTK.Image")));
            this.tsbDeleteItemTK.Name = "tsbDeleteItemTK";
            this.tsbDeleteItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbDeleteItemTK.Text = "Delete";
            // 
            // tsbMoveFirstItemTK
            // 
            this.tsbMoveFirstItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemTK.Image")));
            this.tsbMoveFirstItemTK.Name = "tsbMoveFirstItemTK";
            this.tsbMoveFirstItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveFirstItemTK.Text = "Move first";
            // 
            // tsbMovePreviousItemTK
            // 
            this.tsbMovePreviousItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemTK.Image")));
            this.tsbMovePreviousItemTK.Name = "tsbMovePreviousItemTK";
            this.tsbMovePreviousItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbMovePreviousItemTK.Text = "Move previous";
            // 
            // tsbMoveNextItemTK
            // 
            this.tsbMoveNextItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemTK.Image")));
            this.tsbMoveNextItemTK.Name = "tsbMoveNextItemTK";
            this.tsbMoveNextItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveNextItemTK.Text = "Move next";
            // 
            // tsbMoveLastItemTK
            // 
            this.tsbMoveLastItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemTK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemTK.Image")));
            this.tsbMoveLastItemTK.Name = "tsbMoveLastItemTK";
            this.tsbMoveLastItemTK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveLastItemTK.Text = "Move last";
            // 
            // tsbSaveNewItemTK
            // 
            this.tsbSaveNewItemTK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemTK.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemTK.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemTK.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemTK.Name = "tsbSaveNewItemTK";
            this.tsbSaveNewItemTK.Size = new System.Drawing.Size(23, 22);
            this.tsbSaveNewItemTK.Text = "Save";
            // 
            // btnLoc
            // 
            this.btnLoc.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.Filter;
            this.btnLoc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLoc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoc.Location = new System.Drawing.Point(148, 81);
            this.btnLoc.Name = "btnLoc";
            this.btnLoc.Size = new System.Drawing.Size(75, 41);
            this.btnLoc.TabIndex = 20;
            this.btnLoc.Text = "&Lọc";
            this.btnLoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoc.UseVisualStyleBackColor = true;
            // 
            // btnNhapLai
            // 
            this.btnNhapLai.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.page_white;
            this.btnNhapLai.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnNhapLai.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNhapLai.Location = new System.Drawing.Point(8, 94);
            this.btnNhapLai.Name = "btnNhapLai";
            this.btnNhapLai.Size = new System.Drawing.Size(112, 29);
            this.btnNhapLai.TabIndex = 6;
            this.btnNhapLai.Text = "&Xoá nhập lại";
            this.btnNhapLai.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNhapLai.UseVisualStyleBackColor = true;
            // 
            // ucHangTonKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ucHangTonKho";
            this.Size = new System.Drawing.Size(605, 463);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorTK)).EndInit();
            this.bindingNavigatorTK.ResumeLayout(false);
            this.bindingNavigatorTK.PerformLayout();
            this.grbDanhMucHangTonKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHangTonKho)).EndInit();
            this.grbThongTinTonKho.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox grbThongTinTonKho;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbDonViTinh;
        private System.Windows.Forms.Label lblDonViTinh;
        private System.Windows.Forms.ComboBox cbTenHang;
        private System.Windows.Forms.ComboBox vboMaHang;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.Label lblNCC;
        private System.Windows.Forms.Label lblTenHang;
        private System.Windows.Forms.Label lblMaHang;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cboMaLoai;
        private System.Windows.Forms.ComboBox cboMaNhom;
        private System.Windows.Forms.TextBox txtViTriKho;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.Label lblMaLoai;
        private System.Windows.Forms.Label lblMaNhom;
        private System.Windows.Forms.Label lblViTriKho;
        private System.Windows.Forms.Label lblDonGia;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox grbDanhMucHangTonKho;
        private System.Windows.Forms.DataGridView dgvDanhMucHangTonKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNhom;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn ViTri;
        private System.Windows.Forms.BindingNavigator bindingNavigatorTK;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemTK;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemTK;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemTK;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemTK;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemTK;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemTK;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemTK;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemTK;
        private System.Windows.Forms.CheckBox chkKhuyenMai;
        private System.Windows.Forms.CheckBox chkHetHang;
        private System.Windows.Forms.NumericUpDown numDen;
        private System.Windows.Forms.Label lblDen;
        private System.Windows.Forms.NumericUpDown numTu;
        private System.Windows.Forms.Label lblTu;
        private System.Windows.Forms.Button btnLoc;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.RadioButton raNhoHon;
        private System.Windows.Forms.RadioButton raLonHon;
        private System.Windows.Forms.Button btnXemTheKho;
        private System.Windows.Forms.Button btnHienThiTatCa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnNhapLai;
    }
}
