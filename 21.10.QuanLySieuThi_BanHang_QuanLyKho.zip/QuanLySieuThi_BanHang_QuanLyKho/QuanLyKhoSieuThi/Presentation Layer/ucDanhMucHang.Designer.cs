﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucDanhMucHang
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucDanhMucHang));
            this.tblpThongTinHang = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorPX = new System.Windows.Forms.BindingNavigator(this.components);
            this.tsbAddNewItemPX = new System.Windows.Forms.ToolStripButton();
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbDeleteItemPX = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveFirstItemPX = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemPX = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemPX = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemPX = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemPX = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSaveNewItemPX = new System.Windows.Forms.ToolStripButton();
            this.grbDanhMucHang = new System.Windows.Forms.GroupBox();
            this.dgvDanhMucHang = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNhom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNCC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinHang = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnThemDVT = new System.Windows.Forms.Button();
            this.btnTimTenHang = new System.Windows.Forms.Button();
            this.btnThemMH = new System.Windows.Forms.Button();
            this.btnTimMH = new System.Windows.Forms.Button();
            this.cbTenHang = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnThemNCC = new System.Windows.Forms.Button();
            this.btnThemLoai = new System.Windows.Forms.Button();
            this.btnThemNhom = new System.Windows.Forms.Button();
            this.cboMaLoai = new System.Windows.Forms.ComboBox();
            this.cboMaNhom = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblNCC = new System.Windows.Forms.Label();
            this.lblMaLoai = new System.Windows.Forms.Label();
            this.lblMaNhom = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.imgSP = new System.Windows.Forms.PictureBox();
            this.lblHinhMinhHoa = new System.Windows.Forms.Label();
            this.tblpThongTinHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorPX)).BeginInit();
            this.bindingNavigatorPX.SuspendLayout();
            this.grbDanhMucHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHang)).BeginInit();
            this.grbThongTinHang.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).BeginInit();
            this.SuspendLayout();
            // 
            // tblpThongTinHang
            // 
            this.tblpThongTinHang.ColumnCount = 1;
            this.tblpThongTinHang.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpThongTinHang.Controls.Add(this.bindingNavigatorPX, 0, 2);
            this.tblpThongTinHang.Controls.Add(this.grbDanhMucHang, 0, 1);
            this.tblpThongTinHang.Controls.Add(this.grbThongTinHang, 0, 0);
            this.tblpThongTinHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpThongTinHang.Location = new System.Drawing.Point(0, 0);
            this.tblpThongTinHang.Name = "tblpThongTinHang";
            this.tblpThongTinHang.RowCount = 3;
            this.tblpThongTinHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 109F));
            this.tblpThongTinHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpThongTinHang.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tblpThongTinHang.Size = new System.Drawing.Size(799, 436);
            this.tblpThongTinHang.TabIndex = 0;
            // 
            // bindingNavigatorPX
            // 
            this.bindingNavigatorPX.AddNewItem = this.tsbAddNewItemPX;
            this.bindingNavigatorPX.CountItem = this.tslCountItem;
            this.bindingNavigatorPX.DeleteItem = this.tsbDeleteItemPX;
            this.bindingNavigatorPX.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemPX,
            this.tsbMovePreviousItemPX,
            this.tsSeparator,
            this.tstbPositionItemPX,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemPX,
            this.tsbMoveLastItemPX,
            this.tslSeparator2,
            this.tsbAddNewItemPX,
            this.tsbDeleteItemPX,
            this.tsbSaveNewItemPX});
            this.bindingNavigatorPX.Location = new System.Drawing.Point(0, 411);
            this.bindingNavigatorPX.MoveFirstItem = this.tsbMoveFirstItemPX;
            this.bindingNavigatorPX.MoveLastItem = this.tsbMoveLastItemPX;
            this.bindingNavigatorPX.MoveNextItem = this.tsbMoveNextItemPX;
            this.bindingNavigatorPX.MovePreviousItem = this.tsbMovePreviousItemPX;
            this.bindingNavigatorPX.Name = "bindingNavigatorPX";
            this.bindingNavigatorPX.PositionItem = this.tstbPositionItemPX;
            this.bindingNavigatorPX.Size = new System.Drawing.Size(799, 25);
            this.bindingNavigatorPX.TabIndex = 12;
            this.bindingNavigatorPX.Text = "bindingNavigator1";
            // 
            // tsbAddNewItemPX
            // 
            this.tsbAddNewItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddNewItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddNewItemPX.Image")));
            this.tsbAddNewItemPX.Name = "tsbAddNewItemPX";
            this.tsbAddNewItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbAddNewItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbAddNewItemPX.Text = "Add new";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 22);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbDeleteItemPX
            // 
            this.tsbDeleteItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeleteItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeleteItemPX.Image")));
            this.tsbDeleteItemPX.Name = "tsbDeleteItemPX";
            this.tsbDeleteItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbDeleteItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbDeleteItemPX.Text = "Delete";
            // 
            // tsbMoveFirstItemPX
            // 
            this.tsbMoveFirstItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemPX.Image")));
            this.tsbMoveFirstItemPX.Name = "tsbMoveFirstItemPX";
            this.tsbMoveFirstItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveFirstItemPX.Text = "Move first";
            // 
            // tsbMovePreviousItemPX
            // 
            this.tsbMovePreviousItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemPX.Image")));
            this.tsbMovePreviousItemPX.Name = "tsbMovePreviousItemPX";
            this.tsbMovePreviousItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbMovePreviousItemPX.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // tstbPositionItemPX
            // 
            this.tstbPositionItemPX.AccessibleName = "Position";
            this.tstbPositionItemPX.AutoSize = false;
            this.tstbPositionItemPX.Name = "tstbPositionItemPX";
            this.tstbPositionItemPX.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemPX.Text = "0";
            this.tstbPositionItemPX.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbMoveNextItemPX
            // 
            this.tsbMoveNextItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemPX.Image")));
            this.tsbMoveNextItemPX.Name = "tsbMoveNextItemPX";
            this.tsbMoveNextItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveNextItemPX.Text = "Move next";
            // 
            // tsbMoveLastItemPX
            // 
            this.tsbMoveLastItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemPX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemPX.Image")));
            this.tsbMoveLastItemPX.Name = "tsbMoveLastItemPX";
            this.tsbMoveLastItemPX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbMoveLastItemPX.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbSaveNewItemPX
            // 
            this.tsbSaveNewItemPX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSaveNewItemPX.Image = global::QuanLyKhoSieuThi.Properties.Resources.save_icon;
            this.tsbSaveNewItemPX.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbSaveNewItemPX.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSaveNewItemPX.Name = "tsbSaveNewItemPX";
            this.tsbSaveNewItemPX.Size = new System.Drawing.Size(23, 22);
            this.tsbSaveNewItemPX.Text = "Save";
            // 
            // grbDanhMucHang
            // 
            this.grbDanhMucHang.Controls.Add(this.dgvDanhMucHang);
            this.grbDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhMucHang.Location = new System.Drawing.Point(3, 112);
            this.grbDanhMucHang.Name = "grbDanhMucHang";
            this.grbDanhMucHang.Size = new System.Drawing.Size(793, 296);
            this.grbDanhMucHang.TabIndex = 10;
            this.grbDanhMucHang.TabStop = false;
            this.grbDanhMucHang.Text = "Danh mục hàng hóa";
            // 
            // dgvDanhMucHang
            // 
            this.dgvDanhMucHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhMucHang.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvDanhMucHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhMucHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.MaNhom,
            this.MaLoai,
            this.DVT,
            this.DonGia,
            this.MaNCC});
            this.dgvDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhMucHang.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhMucHang.Name = "dgvDanhMucHang";
            this.dgvDanhMucHang.Size = new System.Drawing.Size(787, 277);
            this.dgvDanhMucHang.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // MaNhom
            // 
            this.MaNhom.HeaderText = "Mã nhóm";
            this.MaNhom.Name = "MaNhom";
            // 
            // MaLoai
            // 
            this.MaLoai.HeaderText = "Mã loại";
            this.MaLoai.Name = "MaLoai";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Đơn giá";
            this.DonGia.Name = "DonGia";
            // 
            // MaNCC
            // 
            this.MaNCC.HeaderText = "Mã NCC";
            this.MaNCC.Name = "MaNCC";
            // 
            // grbThongTinHang
            // 
            this.grbThongTinHang.Controls.Add(this.tableLayoutPanel2);
            this.grbThongTinHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinHang.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinHang.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinHang.Name = "grbThongTinHang";
            this.grbThongTinHang.Size = new System.Drawing.Size(793, 103);
            this.grbThongTinHang.TabIndex = 0;
            this.grbThongTinHang.TabStop = false;
            this.grbThongTinHang.Text = "Thông tin hàng";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.67582F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.26923F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.91758F));
            this.tableLayoutPanel2.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel3, 2, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(787, 84);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnThemDVT);
            this.panel1.Controls.Add(this.btnTimTenHang);
            this.panel1.Controls.Add(this.btnThemMH);
            this.panel1.Controls.Add(this.btnTimMH);
            this.panel1.Controls.Add(this.cbTenHang);
            this.panel1.Controls.Add(this.comboBox3);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(283, 78);
            this.panel1.TabIndex = 0;
            // 
            // btnThemDVT
            // 
            this.btnThemDVT.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThemDVT.Image = ((System.Drawing.Image)(resources.GetObject("btnThemDVT.Image")));
            this.btnThemDVT.Location = new System.Drawing.Point(246, 54);
            this.btnThemDVT.Name = "btnThemDVT";
            this.btnThemDVT.Size = new System.Drawing.Size(26, 23);
            this.btnThemDVT.TabIndex = 12;
            this.btnThemDVT.UseVisualStyleBackColor = true;
            // 
            // btnTimTenHang
            // 
            this.btnTimTenHang.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnTimTenHang.Image = global::QuanLyKhoSieuThi.Properties.Resources.search;
            this.btnTimTenHang.Location = new System.Drawing.Point(246, 26);
            this.btnTimTenHang.Name = "btnTimTenHang";
            this.btnTimTenHang.Size = new System.Drawing.Size(26, 23);
            this.btnTimTenHang.TabIndex = 11;
            this.btnTimTenHang.UseVisualStyleBackColor = true;
            // 
            // btnThemMH
            // 
            this.btnThemMH.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThemMH.Image = global::QuanLyKhoSieuThi.Properties.Resources.add_icon;
            this.btnThemMH.Location = new System.Drawing.Point(247, 0);
            this.btnThemMH.Name = "btnThemMH";
            this.btnThemMH.Size = new System.Drawing.Size(26, 23);
            this.btnThemMH.TabIndex = 14;
            this.btnThemMH.UseVisualStyleBackColor = true;
            // 
            // btnTimMH
            // 
            this.btnTimMH.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnTimMH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTimMH.Image = global::QuanLyKhoSieuThi.Properties.Resources.search;
            this.btnTimMH.Location = new System.Drawing.Point(216, 0);
            this.btnTimMH.Name = "btnTimMH";
            this.btnTimMH.Size = new System.Drawing.Size(26, 23);
            this.btnTimMH.TabIndex = 13;
            this.btnTimMH.UseVisualStyleBackColor = true;
            // 
            // cbTenHang
            // 
            this.cbTenHang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbTenHang.FormattingEnabled = true;
            this.cbTenHang.Location = new System.Drawing.Point(54, 27);
            this.cbTenHang.Name = "cbTenHang";
            this.cbTenHang.Size = new System.Drawing.Size(189, 22);
            this.cbTenHang.TabIndex = 10;
            // 
            // comboBox3
            // 
            this.comboBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(54, 0);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(157, 22);
            this.comboBox3.TabIndex = 8;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(54, 54);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(189, 22);
            this.comboBox1.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(-3, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 14);
            this.label3.TabIndex = 5;
            this.label3.Text = "ĐV tính";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-3, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 14);
            this.label2.TabIndex = 6;
            this.label2.Text = "Tên Hàng";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 14);
            this.label1.TabIndex = 7;
            this.label1.Text = "Mã hàng";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnThemNCC);
            this.panel2.Controls.Add(this.btnThemLoai);
            this.panel2.Controls.Add(this.btnThemNhom);
            this.panel2.Controls.Add(this.cboMaLoai);
            this.panel2.Controls.Add(this.cboMaNhom);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.lblNCC);
            this.panel2.Controls.Add(this.lblMaLoai);
            this.panel2.Controls.Add(this.lblMaNhom);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(292, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(334, 78);
            this.panel2.TabIndex = 0;
            // 
            // btnThemNCC
            // 
            this.btnThemNCC.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThemNCC.Image = ((System.Drawing.Image)(resources.GetObject("btnThemNCC.Image")));
            this.btnThemNCC.Location = new System.Drawing.Point(281, 53);
            this.btnThemNCC.Name = "btnThemNCC";
            this.btnThemNCC.Size = new System.Drawing.Size(26, 23);
            this.btnThemNCC.TabIndex = 13;
            this.btnThemNCC.UseVisualStyleBackColor = true;
            // 
            // btnThemLoai
            // 
            this.btnThemLoai.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThemLoai.Image = ((System.Drawing.Image)(resources.GetObject("btnThemLoai.Image")));
            this.btnThemLoai.Location = new System.Drawing.Point(305, 0);
            this.btnThemLoai.Name = "btnThemLoai";
            this.btnThemLoai.Size = new System.Drawing.Size(26, 23);
            this.btnThemLoai.TabIndex = 14;
            this.btnThemLoai.UseVisualStyleBackColor = true;
            // 
            // btnThemNhom
            // 
            this.btnThemNhom.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThemNhom.Image = global::QuanLyKhoSieuThi.Properties.Resources.add_icon;
            this.btnThemNhom.Location = new System.Drawing.Point(158, 0);
            this.btnThemNhom.Name = "btnThemNhom";
            this.btnThemNhom.Size = new System.Drawing.Size(26, 23);
            this.btnThemNhom.TabIndex = 15;
            this.btnThemNhom.UseVisualStyleBackColor = true;
            // 
            // cboMaLoai
            // 
            this.cboMaLoai.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.cboMaLoai.FormattingEnabled = true;
            this.cboMaLoai.Location = new System.Drawing.Point(233, 0);
            this.cboMaLoai.Name = "cboMaLoai";
            this.cboMaLoai.Size = new System.Drawing.Size(71, 22);
            this.cboMaLoai.TabIndex = 11;
            // 
            // cboMaNhom
            // 
            this.cboMaNhom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cboMaNhom.FormattingEnabled = true;
            this.cboMaNhom.Location = new System.Drawing.Point(67, 0);
            this.cboMaNhom.Name = "cboMaNhom";
            this.cboMaNhom.Size = new System.Drawing.Size(88, 22);
            this.cboMaNhom.TabIndex = 12;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.Location = new System.Drawing.Point(67, 54);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(211, 20);
            this.textBox1.TabIndex = 10;
            // 
            // textBox3
            // 
            this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox3.Location = new System.Drawing.Point(67, 28);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(211, 20);
            this.textBox3.TabIndex = 9;
            // 
            // lblNCC
            // 
            this.lblNCC.AutoSize = true;
            this.lblNCC.Location = new System.Drawing.Point(3, 57);
            this.lblNCC.Name = "lblNCC";
            this.lblNCC.Size = new System.Drawing.Size(46, 14);
            this.lblNCC.TabIndex = 6;
            this.lblNCC.Text = "Nhà CC";
            // 
            // lblMaLoai
            // 
            this.lblMaLoai.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblMaLoai.AutoSize = true;
            this.lblMaLoai.Location = new System.Drawing.Point(188, 4);
            this.lblMaLoai.Name = "lblMaLoai";
            this.lblMaLoai.Size = new System.Drawing.Size(45, 14);
            this.lblMaLoai.TabIndex = 5;
            this.lblMaLoai.Text = "Mã loại";
            // 
            // lblMaNhom
            // 
            this.lblMaNhom.AutoSize = true;
            this.lblMaNhom.Location = new System.Drawing.Point(3, 3);
            this.lblMaNhom.Name = "lblMaNhom";
            this.lblMaNhom.Size = new System.Drawing.Size(58, 14);
            this.lblMaNhom.TabIndex = 8;
            this.lblMaNhom.Text = "Mã nhóm";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 14);
            this.label5.TabIndex = 7;
            this.label5.Text = "Đơn giá";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.imgSP);
            this.panel3.Controls.Add(this.lblHinhMinhHoa);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(632, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(152, 78);
            this.panel3.TabIndex = 0;
            // 
            // imgSP
            // 
            this.imgSP.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.imgSP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.imgSP.Location = new System.Drawing.Point(0, 20);
            this.imgSP.Name = "imgSP";
            this.imgSP.Size = new System.Drawing.Size(152, 58);
            this.imgSP.TabIndex = 7;
            this.imgSP.TabStop = false;
            // 
            // lblHinhMinhHoa
            // 
            this.lblHinhMinhHoa.AutoSize = true;
            this.lblHinhMinhHoa.Location = new System.Drawing.Point(17, 3);
            this.lblHinhMinhHoa.Name = "lblHinhMinhHoa";
            this.lblHinhMinhHoa.Size = new System.Drawing.Size(108, 14);
            this.lblHinhMinhHoa.TabIndex = 8;
            this.lblHinhMinhHoa.Text = "Hình ảnh minh hoạ";
            // 
            // ucDanhMucHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblpThongTinHang);
            this.Name = "ucDanhMucHang";
            this.Size = new System.Drawing.Size(799, 436);
            this.tblpThongTinHang.ResumeLayout(false);
            this.tblpThongTinHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorPX)).EndInit();
            this.bindingNavigatorPX.ResumeLayout(false);
            this.bindingNavigatorPX.PerformLayout();
            this.grbDanhMucHang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHang)).EndInit();
            this.grbThongTinHang.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblpThongTinHang;
        private System.Windows.Forms.GroupBox grbThongTinHang;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnThemDVT;
        private System.Windows.Forms.Button btnTimTenHang;
        private System.Windows.Forms.Button btnThemMH;
        private System.Windows.Forms.Button btnTimMH;
        private System.Windows.Forms.ComboBox cbTenHang;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnThemNCC;
        private System.Windows.Forms.Button btnThemLoai;
        private System.Windows.Forms.Button btnThemNhom;
        private System.Windows.Forms.ComboBox cboMaLoai;
        private System.Windows.Forms.ComboBox cboMaNhom;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lblNCC;
        private System.Windows.Forms.Label lblMaLoai;
        private System.Windows.Forms.Label lblMaNhom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox imgSP;
        private System.Windows.Forms.Label lblHinhMinhHoa;
        private System.Windows.Forms.GroupBox grbDanhMucHang;
        private System.Windows.Forms.DataGridView dgvDanhMucHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNhom;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNCC;
        private System.Windows.Forms.BindingNavigator bindingNavigatorPX;
        private System.Windows.Forms.ToolStripButton tsbAddNewItemPX;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbDeleteItemPX;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemPX;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemPX;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemPX;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemPX;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemPX;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSaveNewItemPX;
    }
}
