﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucSoKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucSoKho));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorSK = new System.Windows.Forms.BindingNavigator(this.components);
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbMoveFirstItemSK = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemPSK = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemSK = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemSK = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemSK = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.dgvThongTinSK = new System.Windows.Forms.DataGridView();
            this.MaChungTu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoaiChungTu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayTao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbThongTinSoKho = new System.Windows.Forms.GroupBox();
            this.grbButton = new System.Windows.Forms.GroupBox();
            this.btnXuatBaoCao = new System.Windows.Forms.Button();
            this.btnXem = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.grbChonNgayTao = new System.Windows.Forms.GroupBox();
            this.mtxtNgayKT = new System.Windows.Forms.MaskedTextBox();
            this.lblNgayKT = new System.Windows.Forms.Label();
            this.mtxtNgayBD = new System.Windows.Forms.MaskedTextBox();
            this.lblNgayBD = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSK)).BeginInit();
            this.bindingNavigatorSK.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinSK)).BeginInit();
            this.grbThongTinSoKho.SuspendLayout();
            this.grbButton.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.grbChonNgayTao.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.bindingNavigatorSK, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.dgvThongTinSK, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.grbThongTinSoKho, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(651, 328);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // bindingNavigatorSK
            // 
            this.bindingNavigatorSK.AddNewItem = null;
            this.bindingNavigatorSK.CountItem = this.tslCountItem;
            this.bindingNavigatorSK.DeleteItem = null;
            this.bindingNavigatorSK.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigatorSK.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemSK,
            this.tsbMovePreviousItemPSK,
            this.tsSeparator,
            this.tstbPositionItemSK,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemSK,
            this.tsbMoveLastItemSK,
            this.tslSeparator2});
            this.bindingNavigatorSK.Location = new System.Drawing.Point(0, 304);
            this.bindingNavigatorSK.MoveFirstItem = this.tsbMoveFirstItemSK;
            this.bindingNavigatorSK.MoveLastItem = this.tsbMoveLastItemSK;
            this.bindingNavigatorSK.MoveNextItem = this.tsbMoveNextItemSK;
            this.bindingNavigatorSK.MovePreviousItem = this.tsbMovePreviousItemPSK;
            this.bindingNavigatorSK.Name = "bindingNavigatorSK";
            this.bindingNavigatorSK.PositionItem = this.tstbPositionItemSK;
            this.bindingNavigatorSK.Size = new System.Drawing.Size(651, 24);
            this.bindingNavigatorSK.TabIndex = 13;
            this.bindingNavigatorSK.Text = "bindingNavigator1";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 21);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbMoveFirstItemSK
            // 
            this.tsbMoveFirstItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemSK.Image")));
            this.tsbMoveFirstItemSK.Name = "tsbMoveFirstItemSK";
            this.tsbMoveFirstItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemSK.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveFirstItemSK.Text = "Move first";
            // 
            // tsbMovePreviousItemPSK
            // 
            this.tsbMovePreviousItemPSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemPSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemPSK.Image")));
            this.tsbMovePreviousItemPSK.Name = "tsbMovePreviousItemPSK";
            this.tsbMovePreviousItemPSK.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemPSK.Size = new System.Drawing.Size(23, 21);
            this.tsbMovePreviousItemPSK.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 24);
            // 
            // tstbPositionItemSK
            // 
            this.tstbPositionItemSK.AccessibleName = "Position";
            this.tstbPositionItemSK.AutoSize = false;
            this.tstbPositionItemSK.Name = "tstbPositionItemSK";
            this.tstbPositionItemSK.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemSK.Text = "0";
            this.tstbPositionItemSK.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 24);
            // 
            // tsbMoveNextItemSK
            // 
            this.tsbMoveNextItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemSK.Image")));
            this.tsbMoveNextItemSK.Name = "tsbMoveNextItemSK";
            this.tsbMoveNextItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemSK.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveNextItemSK.Text = "Move next";
            // 
            // tsbMoveLastItemSK
            // 
            this.tsbMoveLastItemSK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemSK.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemSK.Image")));
            this.tsbMoveLastItemSK.Name = "tsbMoveLastItemSK";
            this.tsbMoveLastItemSK.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemSK.Size = new System.Drawing.Size(23, 21);
            this.tsbMoveLastItemSK.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 24);
            // 
            // dgvThongTinSK
            // 
            this.dgvThongTinSK.AllowUserToOrderColumns = true;
            this.dgvThongTinSK.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongTinSK.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvThongTinSK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinSK.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaChungTu,
            this.LoaiChungTu,
            this.NgayTao});
            this.dgvThongTinSK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinSK.Location = new System.Drawing.Point(3, 126);
            this.dgvThongTinSK.Name = "dgvThongTinSK";
            this.dgvThongTinSK.Size = new System.Drawing.Size(645, 175);
            this.dgvThongTinSK.TabIndex = 12;
            // 
            // MaChungTu
            // 
            this.MaChungTu.HeaderText = "Mã chứng từ";
            this.MaChungTu.Name = "MaChungTu";
            // 
            // LoaiChungTu
            // 
            this.LoaiChungTu.HeaderText = "Loại chứng từ";
            this.LoaiChungTu.Name = "LoaiChungTu";
            // 
            // NgayTao
            // 
            this.NgayTao.HeaderText = "Ngày tạo";
            this.NgayTao.Name = "NgayTao";
            // 
            // grbThongTinSoKho
            // 
            this.grbThongTinSoKho.Controls.Add(this.tableLayoutPanel2);
            this.grbThongTinSoKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinSoKho.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinSoKho.Location = new System.Drawing.Point(3, 3);
            this.grbThongTinSoKho.Name = "grbThongTinSoKho";
            this.grbThongTinSoKho.Size = new System.Drawing.Size(645, 117);
            this.grbThongTinSoKho.TabIndex = 3;
            this.grbThongTinSoKho.TabStop = false;
            this.grbThongTinSoKho.Text = "Thông tin sổ kho";
            // 
            // grbButton
            // 
            this.grbButton.Controls.Add(this.btnXuatBaoCao);
            this.grbButton.Controls.Add(this.btnXem);
            this.grbButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbButton.Location = new System.Drawing.Point(308, 3);
            this.grbButton.Name = "grbButton";
            this.grbButton.Size = new System.Drawing.Size(328, 91);
            this.grbButton.TabIndex = 7;
            this.grbButton.TabStop = false;
            this.grbButton.Text = "Nút chức năng";
            // 
            // btnXuatBaoCao
            // 
            this.btnXuatBaoCao.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatBaoCao.Image = global::QuanLyKhoSieuThi.Properties.Resources.printer;
            this.btnXuatBaoCao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXuatBaoCao.Location = new System.Drawing.Point(109, 51);
            this.btnXuatBaoCao.Name = "btnXuatBaoCao";
            this.btnXuatBaoCao.Size = new System.Drawing.Size(114, 37);
            this.btnXuatBaoCao.TabIndex = 7;
            this.btnXuatBaoCao.Text = "&Xuất báo cáo";
            this.btnXuatBaoCao.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXuatBaoCao.UseVisualStyleBackColor = true;
            // 
            // btnXem
            // 
            this.btnXem.Location = new System.Drawing.Point(109, 15);
            this.btnXem.Name = "btnXem";
            this.btnXem.Size = new System.Drawing.Size(114, 34);
            this.btnXem.TabIndex = 5;
            this.btnXem.Text = "&Xem";
            this.btnXem.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.73083F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.26917F));
            this.tableLayoutPanel2.Controls.Add(this.grbButton, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.grbChonNgayTao, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(639, 97);
            this.tableLayoutPanel2.TabIndex = 8;
            // 
            // grbChonNgayTao
            // 
            this.grbChonNgayTao.Controls.Add(this.mtxtNgayKT);
            this.grbChonNgayTao.Controls.Add(this.lblNgayKT);
            this.grbChonNgayTao.Controls.Add(this.mtxtNgayBD);
            this.grbChonNgayTao.Controls.Add(this.lblNgayBD);
            this.grbChonNgayTao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChonNgayTao.Location = new System.Drawing.Point(3, 3);
            this.grbChonNgayTao.Name = "grbChonNgayTao";
            this.grbChonNgayTao.Size = new System.Drawing.Size(299, 91);
            this.grbChonNgayTao.TabIndex = 0;
            this.grbChonNgayTao.TabStop = false;
            this.grbChonNgayTao.Text = "Chọn ngày tạo";
            // 
            // mtxtNgayKT
            // 
            this.mtxtNgayKT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtNgayKT.Location = new System.Drawing.Point(78, 27);
            this.mtxtNgayKT.Mask = "00/00/0000";
            this.mtxtNgayKT.Name = "mtxtNgayKT";
            this.mtxtNgayKT.Size = new System.Drawing.Size(121, 21);
            this.mtxtNgayKT.TabIndex = 7;
            this.mtxtNgayKT.ValidatingType = typeof(System.DateTime);
            // 
            // lblNgayKT
            // 
            this.lblNgayKT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNgayKT.AutoSize = true;
            this.lblNgayKT.Location = new System.Drawing.Point(8, 29);
            this.lblNgayKT.Name = "lblNgayKT";
            this.lblNgayKT.Size = new System.Drawing.Size(60, 15);
            this.lblNgayKT.TabIndex = 6;
            this.lblNgayKT.Text = "Đến ngày";
            // 
            // mtxtNgayBD
            // 
            this.mtxtNgayBD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtNgayBD.Location = new System.Drawing.Point(78, 57);
            this.mtxtNgayBD.Mask = "00/00/0000";
            this.mtxtNgayBD.Name = "mtxtNgayBD";
            this.mtxtNgayBD.Size = new System.Drawing.Size(121, 21);
            this.mtxtNgayBD.TabIndex = 8;
            this.mtxtNgayBD.ValidatingType = typeof(System.DateTime);
            // 
            // lblNgayBD
            // 
            this.lblNgayBD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNgayBD.AutoSize = true;
            this.lblNgayBD.Location = new System.Drawing.Point(8, 58);
            this.lblNgayBD.Name = "lblNgayBD";
            this.lblNgayBD.Size = new System.Drawing.Size(53, 15);
            this.lblNgayBD.TabIndex = 5;
            this.lblNgayBD.Text = "Từ ngày";
            // 
            // ucSoKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ucSoKho";
            this.Size = new System.Drawing.Size(651, 328);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorSK)).EndInit();
            this.bindingNavigatorSK.ResumeLayout(false);
            this.bindingNavigatorSK.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinSK)).EndInit();
            this.grbThongTinSoKho.ResumeLayout(false);
            this.grbButton.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.grbChonNgayTao.ResumeLayout(false);
            this.grbChonNgayTao.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox grbThongTinSoKho;
        private System.Windows.Forms.GroupBox grbButton;
        private System.Windows.Forms.Button btnXuatBaoCao;
        private System.Windows.Forms.Button btnXem;
        private System.Windows.Forms.DataGridView dgvThongTinSK;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaChungTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaiChungTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayTao;
        private System.Windows.Forms.BindingNavigator bindingNavigatorSK;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemSK;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemPSK;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemSK;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemSK;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemSK;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox grbChonNgayTao;
        private System.Windows.Forms.MaskedTextBox mtxtNgayKT;
        private System.Windows.Forms.Label lblNgayKT;
        private System.Windows.Forms.MaskedTextBox mtxtNgayBD;
        private System.Windows.Forms.Label lblNgayBD;
    }
}
