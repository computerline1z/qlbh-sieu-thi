﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucTopNhap
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucTopNhap));
            this.tlpThongTinTopNhap = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorTN = new System.Windows.Forms.BindingNavigator(this.components);
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbMoveFirstItemTN = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemTN = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemTN = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemTN = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemTN = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.grbThongTinTopNhap = new System.Windows.Forms.GroupBox();
            this.tlpThongtibTopNhap = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblChonThoiGian = new System.Windows.Forms.Label();
            this.dtmpTuNgay = new System.Windows.Forms.DateTimePicker();
            this.dtmpDenNgay = new System.Windows.Forms.DateTimePicker();
            this.lblDenNgay = new System.Windows.Forms.Label();
            this.lblTuNgay = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rbtnTheoGiaTri = new System.Windows.Forms.RadioButton();
            this.rbtnTheoSoLuong = new System.Windows.Forms.RadioButton();
            this.lblChonCachTinh = new System.Windows.Forms.Label();
            this.grbChiTietTopNhap = new System.Windows.Forms.GroupBox();
            this.grvChiTietTopNhap = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ngay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongGiaTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NhomHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tlpThongTinTopNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorTN)).BeginInit();
            this.bindingNavigatorTN.SuspendLayout();
            this.grbThongTinTopNhap.SuspendLayout();
            this.tlpThongtibTopNhap.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.grbChiTietTopNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grvChiTietTopNhap)).BeginInit();
            this.SuspendLayout();
            // 
            // tlpThongTinTopNhap
            // 
            this.tlpThongTinTopNhap.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpThongTinTopNhap.ColumnCount = 1;
            this.tlpThongTinTopNhap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinTopNhap.Controls.Add(this.bindingNavigatorTN, 0, 2);
            this.tlpThongTinTopNhap.Controls.Add(this.grbThongTinTopNhap, 0, 0);
            this.tlpThongTinTopNhap.Controls.Add(this.grbChiTietTopNhap, 0, 1);
            this.tlpThongTinTopNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpThongTinTopNhap.Location = new System.Drawing.Point(0, 0);
            this.tlpThongTinTopNhap.Name = "tlpThongTinTopNhap";
            this.tlpThongTinTopNhap.RowCount = 3;
            this.tlpThongTinTopNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tlpThongTinTopNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinTopNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tlpThongTinTopNhap.Size = new System.Drawing.Size(564, 352);
            this.tlpThongTinTopNhap.TabIndex = 0;
            // 
            // bindingNavigatorTN
            // 
            this.bindingNavigatorTN.AddNewItem = null;
            this.bindingNavigatorTN.CountItem = this.tslCountItem;
            this.bindingNavigatorTN.DeleteItem = null;
            this.bindingNavigatorTN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bindingNavigatorTN.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemTN,
            this.tsbMovePreviousItemTN,
            this.tsSeparator,
            this.tstbPositionItemTN,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemTN,
            this.tsbMoveLastItemTN,
            this.tslSeparator2});
            this.bindingNavigatorTN.Location = new System.Drawing.Point(3, 323);
            this.bindingNavigatorTN.MoveFirstItem = this.tsbMoveFirstItemTN;
            this.bindingNavigatorTN.MoveLastItem = this.tsbMoveLastItemTN;
            this.bindingNavigatorTN.MoveNextItem = this.tsbMoveNextItemTN;
            this.bindingNavigatorTN.MovePreviousItem = this.tsbMovePreviousItemTN;
            this.bindingNavigatorTN.Name = "bindingNavigatorTN";
            this.bindingNavigatorTN.PositionItem = this.tstbPositionItemTN;
            this.bindingNavigatorTN.Size = new System.Drawing.Size(558, 26);
            this.bindingNavigatorTN.TabIndex = 14;
            this.bindingNavigatorTN.Text = "bindingNavigator1";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 23);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbMoveFirstItemTN
            // 
            this.tsbMoveFirstItemTN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemTN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemTN.Image")));
            this.tsbMoveFirstItemTN.Name = "tsbMoveFirstItemTN";
            this.tsbMoveFirstItemTN.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemTN.Size = new System.Drawing.Size(23, 23);
            this.tsbMoveFirstItemTN.Text = "Move first";
            // 
            // tsbMovePreviousItemTN
            // 
            this.tsbMovePreviousItemTN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemTN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemTN.Image")));
            this.tsbMovePreviousItemTN.Name = "tsbMovePreviousItemTN";
            this.tsbMovePreviousItemTN.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemTN.Size = new System.Drawing.Size(23, 23);
            this.tsbMovePreviousItemTN.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 26);
            // 
            // tstbPositionItemTN
            // 
            this.tstbPositionItemTN.AccessibleName = "Position";
            this.tstbPositionItemTN.AutoSize = false;
            this.tstbPositionItemTN.Name = "tstbPositionItemTN";
            this.tstbPositionItemTN.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemTN.Text = "0";
            this.tstbPositionItemTN.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 26);
            // 
            // tsbMoveNextItemTN
            // 
            this.tsbMoveNextItemTN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemTN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemTN.Image")));
            this.tsbMoveNextItemTN.Name = "tsbMoveNextItemTN";
            this.tsbMoveNextItemTN.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemTN.Size = new System.Drawing.Size(23, 23);
            this.tsbMoveNextItemTN.Text = "Move next";
            // 
            // tsbMoveLastItemTN
            // 
            this.tsbMoveLastItemTN.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemTN.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemTN.Image")));
            this.tsbMoveLastItemTN.Name = "tsbMoveLastItemTN";
            this.tsbMoveLastItemTN.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemTN.Size = new System.Drawing.Size(23, 23);
            this.tsbMoveLastItemTN.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 26);
            // 
            // grbThongTinTopNhap
            // 
            this.grbThongTinTopNhap.Controls.Add(this.tlpThongtibTopNhap);
            this.grbThongTinTopNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinTopNhap.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinTopNhap.Location = new System.Drawing.Point(6, 6);
            this.grbThongTinTopNhap.Name = "grbThongTinTopNhap";
            this.grbThongTinTopNhap.Size = new System.Drawing.Size(552, 106);
            this.grbThongTinTopNhap.TabIndex = 0;
            this.grbThongTinTopNhap.TabStop = false;
            this.grbThongTinTopNhap.Text = "Thông tin top nhập";
            // 
            // tlpThongtibTopNhap
            // 
            this.tlpThongtibTopNhap.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tlpThongtibTopNhap.ColumnCount = 2;
            this.tlpThongtibTopNhap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 290F));
            this.tlpThongtibTopNhap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongtibTopNhap.Controls.Add(this.panel1, 0, 0);
            this.tlpThongtibTopNhap.Controls.Add(this.panel2, 1, 0);
            this.tlpThongtibTopNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpThongtibTopNhap.Location = new System.Drawing.Point(3, 16);
            this.tlpThongtibTopNhap.Name = "tlpThongtibTopNhap";
            this.tlpThongtibTopNhap.RowCount = 1;
            this.tlpThongtibTopNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongtibTopNhap.Size = new System.Drawing.Size(546, 87);
            this.tlpThongtibTopNhap.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblChonThoiGian);
            this.panel1.Controls.Add(this.dtmpTuNgay);
            this.panel1.Controls.Add(this.dtmpDenNgay);
            this.panel1.Controls.Add(this.lblDenNgay);
            this.panel1.Controls.Add(this.lblTuNgay);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(284, 77);
            this.panel1.TabIndex = 0;
            // 
            // lblChonThoiGian
            // 
            this.lblChonThoiGian.AutoSize = true;
            this.lblChonThoiGian.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChonThoiGian.Location = new System.Drawing.Point(3, 6);
            this.lblChonThoiGian.Name = "lblChonThoiGian";
            this.lblChonThoiGian.Size = new System.Drawing.Size(89, 15);
            this.lblChonThoiGian.TabIndex = 12;
            this.lblChonThoiGian.Text = "Chọn thời gian";
            // 
            // dtmpTuNgay
            // 
            this.dtmpTuNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmpTuNgay.Location = new System.Drawing.Point(64, 24);
            this.dtmpTuNgay.Name = "dtmpTuNgay";
            this.dtmpTuNgay.Size = new System.Drawing.Size(212, 21);
            this.dtmpTuNgay.TabIndex = 10;
            // 
            // dtmpDenNgay
            // 
            this.dtmpDenNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmpDenNgay.Location = new System.Drawing.Point(64, 51);
            this.dtmpDenNgay.Name = "dtmpDenNgay";
            this.dtmpDenNgay.Size = new System.Drawing.Size(212, 21);
            this.dtmpDenNgay.TabIndex = 11;
            // 
            // lblDenNgay
            // 
            this.lblDenNgay.AutoSize = true;
            this.lblDenNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDenNgay.Location = new System.Drawing.Point(-2, 51);
            this.lblDenNgay.Name = "lblDenNgay";
            this.lblDenNgay.Size = new System.Drawing.Size(60, 15);
            this.lblDenNgay.TabIndex = 9;
            this.lblDenNgay.Text = "Đến ngày";
            // 
            // lblTuNgay
            // 
            this.lblTuNgay.AutoSize = true;
            this.lblTuNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTuNgay.Location = new System.Drawing.Point(-2, 27);
            this.lblTuNgay.Name = "lblTuNgay";
            this.lblTuNgay.Size = new System.Drawing.Size(53, 15);
            this.lblTuNgay.TabIndex = 8;
            this.lblTuNgay.Text = "Từ ngày";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rbtnTheoGiaTri);
            this.panel2.Controls.Add(this.rbtnTheoSoLuong);
            this.panel2.Controls.Add(this.lblChonCachTinh);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(297, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(244, 77);
            this.panel2.TabIndex = 1;
            // 
            // rbtnTheoGiaTri
            // 
            this.rbtnTheoGiaTri.AutoSize = true;
            this.rbtnTheoGiaTri.Location = new System.Drawing.Point(21, 48);
            this.rbtnTheoGiaTri.Name = "rbtnTheoGiaTri";
            this.rbtnTheoGiaTri.Size = new System.Drawing.Size(87, 18);
            this.rbtnTheoGiaTri.TabIndex = 14;
            this.rbtnTheoGiaTri.TabStop = true;
            this.rbtnTheoGiaTri.Text = "Theo giá trị";
            this.rbtnTheoGiaTri.UseVisualStyleBackColor = true;
            // 
            // rbtnTheoSoLuong
            // 
            this.rbtnTheoSoLuong.AutoSize = true;
            this.rbtnTheoSoLuong.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnTheoSoLuong.Location = new System.Drawing.Point(21, 27);
            this.rbtnTheoSoLuong.Name = "rbtnTheoSoLuong";
            this.rbtnTheoSoLuong.Size = new System.Drawing.Size(106, 18);
            this.rbtnTheoSoLuong.TabIndex = 13;
            this.rbtnTheoSoLuong.TabStop = true;
            this.rbtnTheoSoLuong.Text = "Theo số lượng";
            this.rbtnTheoSoLuong.UseVisualStyleBackColor = true;
            // 
            // lblChonCachTinh
            // 
            this.lblChonCachTinh.AutoSize = true;
            this.lblChonCachTinh.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChonCachTinh.Location = new System.Drawing.Point(8, 9);
            this.lblChonCachTinh.Name = "lblChonCachTinh";
            this.lblChonCachTinh.Size = new System.Drawing.Size(91, 15);
            this.lblChonCachTinh.TabIndex = 12;
            this.lblChonCachTinh.Text = "Chọn cách tính";
            // 
            // grbChiTietTopNhap
            // 
            this.grbChiTietTopNhap.Controls.Add(this.grvChiTietTopNhap);
            this.grbChiTietTopNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietTopNhap.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbChiTietTopNhap.Location = new System.Drawing.Point(6, 121);
            this.grbChiTietTopNhap.Name = "grbChiTietTopNhap";
            this.grbChiTietTopNhap.Size = new System.Drawing.Size(552, 196);
            this.grbChiTietTopNhap.TabIndex = 0;
            this.grbChiTietTopNhap.TabStop = false;
            this.grbChiTietTopNhap.Text = "Chi tiết top nhập";
            // 
            // grvChiTietTopNhap
            // 
            this.grvChiTietTopNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grvChiTietTopNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grvChiTietTopNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.Ngay,
            this.SoLuong,
            this.TongGiaTri,
            this.NhomHang});
            this.grvChiTietTopNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grvChiTietTopNhap.Location = new System.Drawing.Point(3, 16);
            this.grvChiTietTopNhap.Name = "grvChiTietTopNhap";
            this.grvChiTietTopNhap.Size = new System.Drawing.Size(546, 177);
            this.grvChiTietTopNhap.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            this.MaHang.ReadOnly = true;
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            this.TenHang.ReadOnly = true;
            // 
            // Ngay
            // 
            this.Ngay.HeaderText = "Ngày";
            this.Ngay.Name = "Ngay";
            this.Ngay.ReadOnly = true;
            // 
            // SoLuong
            // 
            this.SoLuong.HeaderText = "Số lượng";
            this.SoLuong.Name = "SoLuong";
            this.SoLuong.ReadOnly = true;
            // 
            // TongGiaTri
            // 
            this.TongGiaTri.HeaderText = "Tổng giá trị";
            this.TongGiaTri.Name = "TongGiaTri";
            this.TongGiaTri.ReadOnly = true;
            // 
            // NhomHang
            // 
            this.NhomHang.HeaderText = "Nhóm hàng";
            this.NhomHang.Name = "NhomHang";
            this.NhomHang.ReadOnly = true;
            // 
            // ucTopNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tlpThongTinTopNhap);
            this.Name = "ucTopNhap";
            this.Size = new System.Drawing.Size(564, 352);
            this.tlpThongTinTopNhap.ResumeLayout(false);
            this.tlpThongTinTopNhap.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorTN)).EndInit();
            this.bindingNavigatorTN.ResumeLayout(false);
            this.bindingNavigatorTN.PerformLayout();
            this.grbThongTinTopNhap.ResumeLayout(false);
            this.tlpThongtibTopNhap.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.grbChiTietTopNhap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grvChiTietTopNhap)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpThongTinTopNhap;
        private System.Windows.Forms.GroupBox grbThongTinTopNhap;
        private System.Windows.Forms.GroupBox grbChiTietTopNhap;
        private System.Windows.Forms.BindingNavigator bindingNavigatorTN;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemTN;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemTN;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemTN;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemTN;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemTN;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.DataGridView grvChiTietTopNhap;
        private System.Windows.Forms.TableLayoutPanel tlpThongtibTopNhap;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dtmpTuNgay;
        private System.Windows.Forms.DateTimePicker dtmpDenNgay;
        private System.Windows.Forms.Label lblDenNgay;
        private System.Windows.Forms.Label lblTuNgay;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ngay;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongGiaTri;
        private System.Windows.Forms.DataGridViewTextBoxColumn NhomHang;
        private System.Windows.Forms.Label lblChonThoiGian;
        private System.Windows.Forms.Label lblChonCachTinh;
        private System.Windows.Forms.RadioButton rbtnTheoGiaTri;
        private System.Windows.Forms.RadioButton rbtnTheoSoLuong;
    }
}
