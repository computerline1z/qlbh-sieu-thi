﻿namespace QuanLyKhoSieuThi
{
    partial class frmKho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Phiếu nhập kho");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Phiếu xuất kho");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Phiếu chuyển kho");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Sổ kho");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Thẻ kho");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Chứng từ", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Hàng tồn kho");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Hàng hoá chi tiết");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Loại Hàng");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Danh mục", new System.Windows.Forms.TreeNode[] {
            treeNode8,
            treeNode9});
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Kho hàng");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Hàng hoá", new System.Windows.Forms.TreeNode[] {
            treeNode7,
            treeNode10,
            treeNode11});
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Thông tin hàng vào ra");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Top nhập");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Top xuất");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Báo cáo - thống kê", new System.Windows.Forms.TreeNode[] {
            treeNode13,
            treeNode14,
            treeNode15});
            this.mnusKho = new System.Windows.Forms.MenuStrip();
            this.tsmiKhoHeThong = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoThongTinPhienLamViec = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTaiKhoan = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoDoiMatKhau = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoCapNhatThongTin = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoSeparatorHeThong = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiKhoDangXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoThoatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoNghiepVu = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoThongTinHangDaBan = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTaoPhieuXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoInKiemKe = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTienIch = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoMayTinhMini = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoSeparatorTienIch = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiKhoLichLamViec = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoTroGiup = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoHuongDanSuDung = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiCapNhatChuongTrinh = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoBaoCaoLoi = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiKhoSeparatorTroGiup2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiKhoThongTinPhanQuanLiSieuThi = new System.Windows.Forms.ToolStripMenuItem();
            this.tstbKhoVersion = new System.Windows.Forms.ToolStripTextBox();
            this.stasKho = new System.Windows.Forms.StatusStrip();
            this.tstlKhoReady = new System.Windows.Forms.ToolStripStatusLabel();
            this.tspbKhoProcess = new System.Windows.Forms.ToolStripProgressBar();
            this.tblpKhoMainContainer = new System.Windows.Forms.TableLayoutPanel();
            this.splcKhoContainer = new System.Windows.Forms.SplitContainer();
            this.treKhoChucNang = new System.Windows.Forms.TreeView();
            this.tblpMain = new System.Windows.Forms.TableLayoutPanel();
            this.btnDongTabPage = new System.Windows.Forms.Button();
            this.tbplKhoMainButton = new System.Windows.Forms.TableLayoutPanel();
            this.grbBaoCaoThongKe = new System.Windows.Forms.GroupBox();
            this.tblpBaoCaoThongKe = new System.Windows.Forms.TableLayoutPanel();
            this.btnTopXuat = new System.Windows.Forms.Button();
            this.btnTopNhap = new System.Windows.Forms.Button();
            this.btnThongTinVaoRa = new System.Windows.Forms.Button();
            this.grbNghiepVu = new System.Windows.Forms.GroupBox();
            this.tblpNghiepVu = new System.Windows.Forms.TableLayoutPanel();
            this.btnDanhMucHang = new System.Windows.Forms.Button();
            this.btnHangTonKho = new System.Windows.Forms.Button();
            this.btnKhoHang = new System.Windows.Forms.Button();
            this.grbDanhMuc = new System.Windows.Forms.GroupBox();
            this.tblpDanhMuc = new System.Windows.Forms.TableLayoutPanel();
            this.btnSoKho = new System.Windows.Forms.Button();
            this.btnDSPhieuXuat = new System.Windows.Forms.Button();
            this.btnDSPhieuNhap = new System.Windows.Forms.Button();
            this.grbTienIch = new System.Windows.Forms.GroupBox();
            this.tblpTienIch = new System.Windows.Forms.TableLayoutPanel();
            this.btnLichLamViec = new System.Windows.Forms.Button();
            this.xemquyĐịnhNghiệpVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnusKho.SuspendLayout();
            this.stasKho.SuspendLayout();
            this.tblpKhoMainContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splcKhoContainer)).BeginInit();
            this.splcKhoContainer.Panel1.SuspendLayout();
            this.splcKhoContainer.Panel2.SuspendLayout();
            this.splcKhoContainer.SuspendLayout();
            this.tblpMain.SuspendLayout();
            this.tbplKhoMainButton.SuspendLayout();
            this.grbBaoCaoThongKe.SuspendLayout();
            this.tblpBaoCaoThongKe.SuspendLayout();
            this.grbNghiepVu.SuspendLayout();
            this.tblpNghiepVu.SuspendLayout();
            this.grbDanhMuc.SuspendLayout();
            this.tblpDanhMuc.SuspendLayout();
            this.grbTienIch.SuspendLayout();
            this.tblpTienIch.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnusKho
            // 
            this.mnusKho.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoHeThong,
            this.tsmiKhoNghiepVu,
            this.tsmiKhoTienIch,
            this.tsmiKhoTroGiup});
            this.mnusKho.Location = new System.Drawing.Point(0, 0);
            this.mnusKho.Name = "mnusKho";
            this.mnusKho.Size = new System.Drawing.Size(877, 24);
            this.mnusKho.TabIndex = 0;
            this.mnusKho.Text = "mnusKho";
            // 
            // tsmiKhoHeThong
            // 
            this.tsmiKhoHeThong.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoThongTinPhienLamViec,
            this.tsmiKhoTaiKhoan,
            this.tsmiKhoSeparatorHeThong,
            this.tsmiKhoDangXuat,
            this.tsmiKhoThoatChuongTrinh});
            this.tsmiKhoHeThong.Name = "tsmiKhoHeThong";
            this.tsmiKhoHeThong.Size = new System.Drawing.Size(69, 20);
            this.tsmiKhoHeThong.Text = "&Hệ thống";
            // 
            // tsmiKhoThongTinPhienLamViec
            // 
            this.tsmiKhoThongTinPhienLamViec.Name = "tsmiKhoThongTinPhienLamViec";
            this.tsmiKhoThongTinPhienLamViec.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.tsmiKhoThongTinPhienLamViec.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoThongTinPhienLamViec.Text = "Thông tin &phiên làm việc";
            // 
            // tsmiKhoTaiKhoan
            // 
            this.tsmiKhoTaiKhoan.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoDoiMatKhau,
            this.tsmiKhoCapNhatThongTin});
            this.tsmiKhoTaiKhoan.Name = "tsmiKhoTaiKhoan";
            this.tsmiKhoTaiKhoan.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoTaiKhoan.Text = "Tài &khoản";
            // 
            // tsmiKhoDoiMatKhau
            // 
            this.tsmiKhoDoiMatKhau.Name = "tsmiKhoDoiMatKhau";
            this.tsmiKhoDoiMatKhau.Size = new System.Drawing.Size(174, 22);
            this.tsmiKhoDoiMatKhau.Text = "Đổi &mật khẩu";
            // 
            // tsmiKhoCapNhatThongTin
            // 
            this.tsmiKhoCapNhatThongTin.Name = "tsmiKhoCapNhatThongTin";
            this.tsmiKhoCapNhatThongTin.Size = new System.Drawing.Size(174, 22);
            this.tsmiKhoCapNhatThongTin.Text = "&Cập nhật thông tin";
            // 
            // tsmiKhoSeparatorHeThong
            // 
            this.tsmiKhoSeparatorHeThong.Name = "tsmiKhoSeparatorHeThong";
            this.tsmiKhoSeparatorHeThong.Size = new System.Drawing.Size(243, 6);
            // 
            // tsmiKhoDangXuat
            // 
            this.tsmiKhoDangXuat.Name = "tsmiKhoDangXuat";
            this.tsmiKhoDangXuat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F4)));
            this.tsmiKhoDangXuat.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoDangXuat.Text = "Đăng &xuất";
            // 
            // tsmiKhoThoatChuongTrinh
            // 
            this.tsmiKhoThoatChuongTrinh.Name = "tsmiKhoThoatChuongTrinh";
            this.tsmiKhoThoatChuongTrinh.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.tsmiKhoThoatChuongTrinh.Size = new System.Drawing.Size(246, 22);
            this.tsmiKhoThoatChuongTrinh.Text = "&Thoát chương trình";
            this.tsmiKhoThoatChuongTrinh.Click += new System.EventHandler(this.ThoatChuongTrinh_Click);
            // 
            // tsmiKhoNghiepVu
            // 
            this.tsmiKhoNghiepVu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoThongTinHangDaBan,
            this.tsmiKhoTaoPhieuXuat,
            this.tsmiKhoInKiemKe,
            this.xemquyĐịnhNghiệpVụToolStripMenuItem});
            this.tsmiKhoNghiepVu.Name = "tsmiKhoNghiepVu";
            this.tsmiKhoNghiepVu.Size = new System.Drawing.Size(74, 20);
            this.tsmiKhoNghiepVu.Text = "&Nghiệp vụ";
            // 
            // tsmiKhoThongTinHangDaBan
            // 
            this.tsmiKhoThongTinHangDaBan.Name = "tsmiKhoThongTinHangDaBan";
            this.tsmiKhoThongTinHangDaBan.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.tsmiKhoThongTinHangDaBan.Size = new System.Drawing.Size(204, 22);
            this.tsmiKhoThongTinHangDaBan.Text = "&Nhập hàng";
            // 
            // tsmiKhoTaoPhieuXuat
            // 
            this.tsmiKhoTaoPhieuXuat.Name = "tsmiKhoTaoPhieuXuat";
            this.tsmiKhoTaoPhieuXuat.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.tsmiKhoTaoPhieuXuat.Size = new System.Drawing.Size(204, 22);
            this.tsmiKhoTaoPhieuXuat.Text = "Tạo phiếu &xuất";
            // 
            // tsmiKhoInKiemKe
            // 
            this.tsmiKhoInKiemKe.Name = "tsmiKhoInKiemKe";
            this.tsmiKhoInKiemKe.Size = new System.Drawing.Size(204, 22);
            this.tsmiKhoInKiemKe.Text = "&In kiểm kê";
            // 
            // tsmiKhoTienIch
            // 
            this.tsmiKhoTienIch.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoMayTinhMini,
            this.tsmiKhoSeparatorTienIch,
            this.tsmiKhoLichLamViec});
            this.tsmiKhoTienIch.Name = "tsmiKhoTienIch";
            this.tsmiKhoTienIch.Size = new System.Drawing.Size(61, 20);
            this.tsmiKhoTienIch.Text = "Tiện &ích";
            // 
            // tsmiKhoMayTinhMini
            // 
            this.tsmiKhoMayTinhMini.Name = "tsmiKhoMayTinhMini";
            this.tsmiKhoMayTinhMini.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.tsmiKhoMayTinhMini.Size = new System.Drawing.Size(189, 22);
            this.tsmiKhoMayTinhMini.Text = "&Máy tính mini";
            // 
            // tsmiKhoSeparatorTienIch
            // 
            this.tsmiKhoSeparatorTienIch.Name = "tsmiKhoSeparatorTienIch";
            this.tsmiKhoSeparatorTienIch.Size = new System.Drawing.Size(186, 6);
            // 
            // tsmiKhoLichLamViec
            // 
            this.tsmiKhoLichLamViec.Name = "tsmiKhoLichLamViec";
            this.tsmiKhoLichLamViec.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.tsmiKhoLichLamViec.Size = new System.Drawing.Size(189, 22);
            this.tsmiKhoLichLamViec.Text = "&Lịch làm việc";
            // 
            // tsmiKhoTroGiup
            // 
            this.tsmiKhoTroGiup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiKhoHuongDanSuDung,
            this.tsmiCapNhatChuongTrinh,
            this.tsmiKhoBaoCaoLoi,
            this.tsmiKhoSeparatorTroGiup2,
            this.tsmiKhoThongTinPhanQuanLiSieuThi,
            this.tstbKhoVersion});
            this.tsmiKhoTroGiup.Name = "tsmiKhoTroGiup";
            this.tsmiKhoTroGiup.Size = new System.Drawing.Size(64, 20);
            this.tsmiKhoTroGiup.Text = "Trợ &giúp";
            // 
            // tsmiKhoHuongDanSuDung
            // 
            this.tsmiKhoHuongDanSuDung.Name = "tsmiKhoHuongDanSuDung";
            this.tsmiKhoHuongDanSuDung.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.tsmiKhoHuongDanSuDung.Size = new System.Drawing.Size(267, 22);
            this.tsmiKhoHuongDanSuDung.Text = "Hướng dẫn &sử dụng";
            // 
            // tsmiCapNhatChuongTrinh
            // 
            this.tsmiCapNhatChuongTrinh.Name = "tsmiCapNhatChuongTrinh";
            this.tsmiCapNhatChuongTrinh.Size = new System.Drawing.Size(267, 22);
            this.tsmiCapNhatChuongTrinh.Text = "&Cập nhật chương trình";
            // 
            // tsmiKhoBaoCaoLoi
            // 
            this.tsmiKhoBaoCaoLoi.Name = "tsmiKhoBaoCaoLoi";
            this.tsmiKhoBaoCaoLoi.Size = new System.Drawing.Size(267, 22);
            this.tsmiKhoBaoCaoLoi.Text = "Báo cáo &lỗi";
            // 
            // tsmiKhoSeparatorTroGiup2
            // 
            this.tsmiKhoSeparatorTroGiup2.Name = "tsmiKhoSeparatorTroGiup2";
            this.tsmiKhoSeparatorTroGiup2.Size = new System.Drawing.Size(264, 6);
            // 
            // tsmiKhoThongTinPhanQuanLiSieuThi
            // 
            this.tsmiKhoThongTinPhanQuanLiSieuThi.Name = "tsmiKhoThongTinPhanQuanLiSieuThi";
            this.tsmiKhoThongTinPhanQuanLiSieuThi.Size = new System.Drawing.Size(267, 22);
            this.tsmiKhoThongTinPhanQuanLiSieuThi.Text = "Thông tin phần mềm &quản lí siêu thị";
            // 
            // tstbKhoVersion
            // 
            this.tstbKhoVersion.BackColor = System.Drawing.Color.White;
            this.tstbKhoVersion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tstbKhoVersion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.tstbKhoVersion.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.tstbKhoVersion.Name = "tstbKhoVersion";
            this.tstbKhoVersion.Size = new System.Drawing.Size(120, 12);
            this.tstbKhoVersion.Text = "© 2011 QLST – Version 1.0";
            // 
            // stasKho
            // 
            this.stasKho.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstlKhoReady,
            this.tspbKhoProcess});
            this.stasKho.Location = new System.Drawing.Point(0, 616);
            this.stasKho.Name = "stasKho";
            this.stasKho.Size = new System.Drawing.Size(877, 22);
            this.stasKho.TabIndex = 9;
            this.stasKho.Text = "statusStrip1";
            // 
            // tstlKhoReady
            // 
            this.tstlKhoReady.Name = "tstlKhoReady";
            this.tstlKhoReady.Size = new System.Drawing.Size(39, 17);
            this.tstlKhoReady.Text = "Ready";
            // 
            // tspbKhoProcess
            // 
            this.tspbKhoProcess.Name = "tspbKhoProcess";
            this.tspbKhoProcess.Size = new System.Drawing.Size(100, 16);
            // 
            // tblpKhoMainContainer
            // 
            this.tblpKhoMainContainer.ColumnCount = 1;
            this.tblpKhoMainContainer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpKhoMainContainer.Controls.Add(this.splcKhoContainer, 0, 1);
            this.tblpKhoMainContainer.Controls.Add(this.tbplKhoMainButton, 0, 0);
            this.tblpKhoMainContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpKhoMainContainer.Location = new System.Drawing.Point(0, 24);
            this.tblpKhoMainContainer.Name = "tblpKhoMainContainer";
            this.tblpKhoMainContainer.RowCount = 2;
            this.tblpKhoMainContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 78F));
            this.tblpKhoMainContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpKhoMainContainer.Size = new System.Drawing.Size(877, 592);
            this.tblpKhoMainContainer.TabIndex = 10;
            // 
            // splcKhoContainer
            // 
            this.splcKhoContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splcKhoContainer.Cursor = System.Windows.Forms.Cursors.Default;
            this.splcKhoContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splcKhoContainer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.splcKhoContainer.Location = new System.Drawing.Point(3, 81);
            this.splcKhoContainer.Name = "splcKhoContainer";
            // 
            // splcKhoContainer.Panel1
            // 
            this.splcKhoContainer.Panel1.Controls.Add(this.treKhoChucNang);
            this.splcKhoContainer.Panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.splcKhoContainer.Panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            // 
            // splcKhoContainer.Panel2
            // 
            this.splcKhoContainer.Panel2.Controls.Add(this.tblpMain);
            this.splcKhoContainer.Size = new System.Drawing.Size(871, 508);
            this.splcKhoContainer.SplitterDistance = 166;
            this.splcKhoContainer.TabIndex = 4;
            // 
            // treKhoChucNang
            // 
            this.treKhoChucNang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treKhoChucNang.ForeColor = System.Drawing.Color.MediumBlue;
            this.treKhoChucNang.ImeMode = System.Windows.Forms.ImeMode.Katakana;
            this.treKhoChucNang.ItemHeight = 20;
            this.treKhoChucNang.Location = new System.Drawing.Point(0, 0);
            this.treKhoChucNang.Name = "treKhoChucNang";
            treeNode1.Name = "nodePhieuNhapKho";
            treeNode1.Text = "Phiếu nhập kho";
            treeNode2.Name = "nodePhieuXuatKho";
            treeNode2.Text = "Phiếu xuất kho";
            treeNode3.Name = "nodePhieuChuyenKho";
            treeNode3.Text = "Phiếu chuyển kho";
            treeNode4.Name = "nodeSoKho";
            treeNode4.Text = "Sổ kho";
            treeNode5.Name = "nodeTheKho";
            treeNode5.Text = "Thẻ kho";
            treeNode6.Checked = true;
            treeNode6.Name = "nodeChungTu";
            treeNode6.StateImageKey = "(none)";
            treeNode6.Text = "Chứng từ";
            treeNode6.ToolTipText = "Các loại chứng từ của quản lý kho";
            treeNode7.Name = "nodeHangTonKho";
            treeNode7.Text = "Hàng tồn kho";
            treeNode8.Name = "nodeHangHoaChiTiet";
            treeNode8.Text = "Hàng hoá chi tiết";
            treeNode9.Name = "nodeDanhMucLoaiHang";
            treeNode9.Text = "Loại Hàng";
            treeNode10.Name = "nodeDanhMuc";
            treeNode10.Text = "Danh mục";
            treeNode11.Name = "nodeKhoHang";
            treeNode11.Text = "Kho hàng";
            treeNode12.Name = "nodeHangHoa";
            treeNode12.Text = "Hàng hoá";
            treeNode13.Name = "nodeThongTinHangVaoRa";
            treeNode13.Text = "Thông tin hàng vào ra";
            treeNode14.Name = "nodeTopNhap";
            treeNode14.Text = "Top nhập";
            treeNode15.Name = "nodeTopXuat";
            treeNode15.Text = "Top xuất";
            treeNode16.Name = "nodeBaoCaoThongKe";
            treeNode16.Text = "Báo cáo - thống kê";
            this.treKhoChucNang.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode6,
            treeNode12,
            treeNode16});
            this.treKhoChucNang.Size = new System.Drawing.Size(166, 508);
            this.treKhoChucNang.TabIndex = 0;
            this.treKhoChucNang.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treKhoChucNang_AfterSelect);
            // 
            // tblpMain
            // 
            this.tblpMain.ColumnCount = 1;
            this.tblpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpMain.Controls.Add(this.btnDongTabPage, 0, 0);
            this.tblpMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpMain.Location = new System.Drawing.Point(0, 0);
            this.tblpMain.Name = "tblpMain";
            this.tblpMain.RowCount = 2;
            this.tblpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblpMain.Size = new System.Drawing.Size(701, 508);
            this.tblpMain.TabIndex = 0;
            // 
            // btnDongTabPage
            // 
            this.btnDongTabPage.BackgroundImage = global::QuanLyKhoSieuThi.Properties.Resources.bullet_cross;
            this.btnDongTabPage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDongTabPage.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnDongTabPage.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDongTabPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDongTabPage.Location = new System.Drawing.Point(618, 3);
            this.btnDongTabPage.Name = "btnDongTabPage";
            this.btnDongTabPage.Size = new System.Drawing.Size(80, 24);
            this.btnDongTabPage.TabIndex = 9;
            this.btnDongTabPage.Text = "Đón&g Tab";
            this.btnDongTabPage.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDongTabPage.UseVisualStyleBackColor = true;
            this.btnDongTabPage.Click += new System.EventHandler(this.btnDongTabPage_Click);
            // 
            // tbplKhoMainButton
            // 
            this.tbplKhoMainButton.ColumnCount = 4;
            this.tbplKhoMainButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.47302F));
            this.tbplKhoMainButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.78416F));
            this.tbplKhoMainButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.18025F));
            this.tbplKhoMainButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.33295F));
            this.tbplKhoMainButton.Controls.Add(this.grbBaoCaoThongKe, 0, 0);
            this.tbplKhoMainButton.Controls.Add(this.grbNghiepVu, 0, 0);
            this.tbplKhoMainButton.Controls.Add(this.grbDanhMuc, 0, 0);
            this.tbplKhoMainButton.Controls.Add(this.grbTienIch, 3, 0);
            this.tbplKhoMainButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbplKhoMainButton.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbplKhoMainButton.Location = new System.Drawing.Point(3, 3);
            this.tbplKhoMainButton.Name = "tbplKhoMainButton";
            this.tbplKhoMainButton.RowCount = 1;
            this.tbplKhoMainButton.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbplKhoMainButton.Size = new System.Drawing.Size(871, 72);
            this.tbplKhoMainButton.TabIndex = 3;
            // 
            // grbBaoCaoThongKe
            // 
            this.grbBaoCaoThongKe.Controls.Add(this.tblpBaoCaoThongKe);
            this.grbBaoCaoThongKe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbBaoCaoThongKe.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbBaoCaoThongKe.Location = new System.Drawing.Point(493, 3);
            this.grbBaoCaoThongKe.Name = "grbBaoCaoThongKe";
            this.grbBaoCaoThongKe.Size = new System.Drawing.Size(283, 66);
            this.grbBaoCaoThongKe.TabIndex = 3;
            this.grbBaoCaoThongKe.TabStop = false;
            this.grbBaoCaoThongKe.Text = "Báo cáo - thống kê";
            // 
            // tblpBaoCaoThongKe
            // 
            this.tblpBaoCaoThongKe.ColumnCount = 3;
            this.tblpBaoCaoThongKe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblpBaoCaoThongKe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblpBaoCaoThongKe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblpBaoCaoThongKe.Controls.Add(this.btnTopXuat, 0, 0);
            this.tblpBaoCaoThongKe.Controls.Add(this.btnTopNhap, 0, 0);
            this.tblpBaoCaoThongKe.Controls.Add(this.btnThongTinVaoRa, 0, 0);
            this.tblpBaoCaoThongKe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpBaoCaoThongKe.Location = new System.Drawing.Point(3, 16);
            this.tblpBaoCaoThongKe.Name = "tblpBaoCaoThongKe";
            this.tblpBaoCaoThongKe.RowCount = 1;
            this.tblpBaoCaoThongKe.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpBaoCaoThongKe.Size = new System.Drawing.Size(277, 47);
            this.tblpBaoCaoThongKe.TabIndex = 0;
            // 
            // btnTopXuat
            // 
            this.btnTopXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTopXuat.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTopXuat.Location = new System.Drawing.Point(187, 3);
            this.btnTopXuat.Name = "btnTopXuat";
            this.btnTopXuat.Size = new System.Drawing.Size(87, 41);
            this.btnTopXuat.TabIndex = 12;
            this.btnTopXuat.Text = "Top xuất";
            this.btnTopXuat.UseVisualStyleBackColor = true;
            // 
            // btnTopNhap
            // 
            this.btnTopNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTopNhap.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTopNhap.Location = new System.Drawing.Point(95, 3);
            this.btnTopNhap.Name = "btnTopNhap";
            this.btnTopNhap.Size = new System.Drawing.Size(86, 41);
            this.btnTopNhap.TabIndex = 11;
            this.btnTopNhap.Text = "Top nhập";
            this.btnTopNhap.UseVisualStyleBackColor = true;
            // 
            // btnThongTinVaoRa
            // 
            this.btnThongTinVaoRa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnThongTinVaoRa.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongTinVaoRa.Location = new System.Drawing.Point(3, 3);
            this.btnThongTinVaoRa.Name = "btnThongTinVaoRa";
            this.btnThongTinVaoRa.Size = new System.Drawing.Size(86, 41);
            this.btnThongTinVaoRa.TabIndex = 10;
            this.btnThongTinVaoRa.Text = "Thông tin vào ra kho";
            this.btnThongTinVaoRa.UseVisualStyleBackColor = true;
            // 
            // grbNghiepVu
            // 
            this.grbNghiepVu.Controls.Add(this.tblpNghiepVu);
            this.grbNghiepVu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbNghiepVu.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbNghiepVu.Location = new System.Drawing.Point(251, 3);
            this.grbNghiepVu.Name = "grbNghiepVu";
            this.grbNghiepVu.Size = new System.Drawing.Size(236, 66);
            this.grbNghiepVu.TabIndex = 2;
            this.grbNghiepVu.TabStop = false;
            this.grbNghiepVu.Text = "Nghiệp vụ";
            // 
            // tblpNghiepVu
            // 
            this.tblpNghiepVu.ColumnCount = 3;
            this.tblpNghiepVu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblpNghiepVu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblpNghiepVu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblpNghiepVu.Controls.Add(this.btnDanhMucHang, 0, 0);
            this.tblpNghiepVu.Controls.Add(this.btnHangTonKho, 0, 0);
            this.tblpNghiepVu.Controls.Add(this.btnKhoHang, 0, 0);
            this.tblpNghiepVu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpNghiepVu.Location = new System.Drawing.Point(3, 16);
            this.tblpNghiepVu.Name = "tblpNghiepVu";
            this.tblpNghiepVu.RowCount = 1;
            this.tblpNghiepVu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpNghiepVu.Size = new System.Drawing.Size(230, 47);
            this.tblpNghiepVu.TabIndex = 0;
            // 
            // btnDanhMucHang
            // 
            this.btnDanhMucHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDanhMucHang.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDanhMucHang.Location = new System.Drawing.Point(155, 3);
            this.btnDanhMucHang.Name = "btnDanhMucHang";
            this.btnDanhMucHang.Size = new System.Drawing.Size(72, 41);
            this.btnDanhMucHang.TabIndex = 9;
            this.btnDanhMucHang.Text = "Danh mục hàng";
            this.btnDanhMucHang.UseVisualStyleBackColor = true;
            // 
            // btnHangTonKho
            // 
            this.btnHangTonKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHangTonKho.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHangTonKho.Location = new System.Drawing.Point(79, 3);
            this.btnHangTonKho.Name = "btnHangTonKho";
            this.btnHangTonKho.Size = new System.Drawing.Size(70, 41);
            this.btnHangTonKho.TabIndex = 8;
            this.btnHangTonKho.Text = "Hàng tồn kho";
            this.btnHangTonKho.UseVisualStyleBackColor = true;
            // 
            // btnKhoHang
            // 
            this.btnKhoHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnKhoHang.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhoHang.Location = new System.Drawing.Point(3, 3);
            this.btnKhoHang.Name = "btnKhoHang";
            this.btnKhoHang.Size = new System.Drawing.Size(70, 41);
            this.btnKhoHang.TabIndex = 7;
            this.btnKhoHang.Text = "Kho hàng";
            this.btnKhoHang.UseVisualStyleBackColor = true;
            // 
            // grbDanhMuc
            // 
            this.grbDanhMuc.Controls.Add(this.tblpDanhMuc);
            this.grbDanhMuc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbDanhMuc.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDanhMuc.Location = new System.Drawing.Point(3, 3);
            this.grbDanhMuc.Name = "grbDanhMuc";
            this.grbDanhMuc.Size = new System.Drawing.Size(242, 66);
            this.grbDanhMuc.TabIndex = 0;
            this.grbDanhMuc.TabStop = false;
            this.grbDanhMuc.Text = "Danh mục";
            // 
            // tblpDanhMuc
            // 
            this.tblpDanhMuc.ColumnCount = 3;
            this.tblpDanhMuc.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblpDanhMuc.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblpDanhMuc.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblpDanhMuc.Controls.Add(this.btnSoKho, 0, 0);
            this.tblpDanhMuc.Controls.Add(this.btnDSPhieuXuat, 0, 0);
            this.tblpDanhMuc.Controls.Add(this.btnDSPhieuNhap, 0, 0);
            this.tblpDanhMuc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpDanhMuc.Location = new System.Drawing.Point(3, 16);
            this.tblpDanhMuc.Name = "tblpDanhMuc";
            this.tblpDanhMuc.RowCount = 1;
            this.tblpDanhMuc.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpDanhMuc.Size = new System.Drawing.Size(236, 47);
            this.tblpDanhMuc.TabIndex = 0;
            // 
            // btnSoKho
            // 
            this.btnSoKho.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSoKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSoKho.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoKho.Location = new System.Drawing.Point(159, 3);
            this.btnSoKho.Name = "btnSoKho";
            this.btnSoKho.Size = new System.Drawing.Size(74, 41);
            this.btnSoKho.TabIndex = 6;
            this.btnSoKho.Text = "Sổ kho";
            this.btnSoKho.UseVisualStyleBackColor = true;
            // 
            // btnDSPhieuXuat
            // 
            this.btnDSPhieuXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDSPhieuXuat.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDSPhieuXuat.Location = new System.Drawing.Point(81, 3);
            this.btnDSPhieuXuat.Name = "btnDSPhieuXuat";
            this.btnDSPhieuXuat.Size = new System.Drawing.Size(72, 41);
            this.btnDSPhieuXuat.TabIndex = 5;
            this.btnDSPhieuXuat.Text = "DS Phiếu xuất";
            this.btnDSPhieuXuat.UseVisualStyleBackColor = true;
            // 
            // btnDSPhieuNhap
            // 
            this.btnDSPhieuNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDSPhieuNhap.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDSPhieuNhap.Location = new System.Drawing.Point(3, 3);
            this.btnDSPhieuNhap.Name = "btnDSPhieuNhap";
            this.btnDSPhieuNhap.Size = new System.Drawing.Size(72, 41);
            this.btnDSPhieuNhap.TabIndex = 4;
            this.btnDSPhieuNhap.Text = "DS Phiếu nhập";
            this.btnDSPhieuNhap.UseVisualStyleBackColor = true;
            // 
            // grbTienIch
            // 
            this.grbTienIch.Controls.Add(this.tblpTienIch);
            this.grbTienIch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbTienIch.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTienIch.Location = new System.Drawing.Point(782, 3);
            this.grbTienIch.Name = "grbTienIch";
            this.grbTienIch.Size = new System.Drawing.Size(86, 66);
            this.grbTienIch.TabIndex = 3;
            this.grbTienIch.TabStop = false;
            this.grbTienIch.Text = "Tiện ích";
            // 
            // tblpTienIch
            // 
            this.tblpTienIch.ColumnCount = 1;
            this.tblpTienIch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpTienIch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblpTienIch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblpTienIch.Controls.Add(this.btnLichLamViec, 0, 0);
            this.tblpTienIch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblpTienIch.Location = new System.Drawing.Point(3, 16);
            this.tblpTienIch.Name = "tblpTienIch";
            this.tblpTienIch.RowCount = 1;
            this.tblpTienIch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblpTienIch.Size = new System.Drawing.Size(80, 47);
            this.tblpTienIch.TabIndex = 0;
            // 
            // btnLichLamViec
            // 
            this.btnLichLamViec.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLichLamViec.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLichLamViec.Location = new System.Drawing.Point(3, 3);
            this.btnLichLamViec.Name = "btnLichLamViec";
            this.btnLichLamViec.Size = new System.Drawing.Size(74, 41);
            this.btnLichLamViec.TabIndex = 13;
            this.btnLichLamViec.Text = "Lịch Làm Việc";
            this.btnLichLamViec.UseVisualStyleBackColor = true;
            // 
            // xemquyĐịnhNghiệpVụToolStripMenuItem
            // 
            this.xemquyĐịnhNghiệpVụToolStripMenuItem.Name = "xemquyĐịnhNghiệpVụToolStripMenuItem";
            this.xemquyĐịnhNghiệpVụToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.xemquyĐịnhNghiệpVụToolStripMenuItem.Text = "Xem &quy định nghiệp vụ";
            // 
            // frmKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 638);
            this.Controls.Add(this.tblpKhoMainContainer);
            this.Controls.Add(this.stasKho);
            this.Controls.Add(this.mnusKho);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.mnusKho;
            this.MinimumSize = new System.Drawing.Size(885, 665);
            this.Name = "frmKho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QLST --- Quản lý kho";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmKho_Load);
            this.mnusKho.ResumeLayout(false);
            this.mnusKho.PerformLayout();
            this.stasKho.ResumeLayout(false);
            this.stasKho.PerformLayout();
            this.tblpKhoMainContainer.ResumeLayout(false);
            this.splcKhoContainer.Panel1.ResumeLayout(false);
            this.splcKhoContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splcKhoContainer)).EndInit();
            this.splcKhoContainer.ResumeLayout(false);
            this.tblpMain.ResumeLayout(false);
            this.tbplKhoMainButton.ResumeLayout(false);
            this.grbBaoCaoThongKe.ResumeLayout(false);
            this.tblpBaoCaoThongKe.ResumeLayout(false);
            this.grbNghiepVu.ResumeLayout(false);
            this.tblpNghiepVu.ResumeLayout(false);
            this.grbDanhMuc.ResumeLayout(false);
            this.tblpDanhMuc.ResumeLayout(false);
            this.grbTienIch.ResumeLayout(false);
            this.tblpTienIch.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnusKho;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoHeThong;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThongTinPhienLamViec;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTaiKhoan;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoDoiMatKhau;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoCapNhatThongTin;
        private System.Windows.Forms.ToolStripSeparator tsmiKhoSeparatorHeThong;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoDangXuat;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThoatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoNghiepVu;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThongTinHangDaBan;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTaoPhieuXuat;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoInKiemKe;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTienIch;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoMayTinhMini;
        private System.Windows.Forms.ToolStripSeparator tsmiKhoSeparatorTienIch;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoLichLamViec;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoTroGiup;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoHuongDanSuDung;
        private System.Windows.Forms.ToolStripMenuItem tsmiCapNhatChuongTrinh;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoBaoCaoLoi;
        private System.Windows.Forms.ToolStripSeparator tsmiKhoSeparatorTroGiup2;
        private System.Windows.Forms.ToolStripMenuItem tsmiKhoThongTinPhanQuanLiSieuThi;
        private System.Windows.Forms.ToolStripTextBox tstbKhoVersion;
        private System.Windows.Forms.StatusStrip stasKho;
        private System.Windows.Forms.ToolStripStatusLabel tstlKhoReady;
        private System.Windows.Forms.ToolStripProgressBar tspbKhoProcess;
        private System.Windows.Forms.TableLayoutPanel tblpKhoMainContainer;
        private System.Windows.Forms.TableLayoutPanel tbplKhoMainButton;
        private System.Windows.Forms.GroupBox grbDanhMuc;
        private System.Windows.Forms.GroupBox grbNghiepVu;
        private System.Windows.Forms.GroupBox grbBaoCaoThongKe;
        private System.Windows.Forms.GroupBox grbTienIch;
        private System.Windows.Forms.SplitContainer splcKhoContainer;
        private System.Windows.Forms.TreeView treKhoChucNang;
        private System.Windows.Forms.TableLayoutPanel tblpMain;
        private System.Windows.Forms.TableLayoutPanel tblpDanhMuc;
        private System.Windows.Forms.TableLayoutPanel tblpNghiepVu;
        private System.Windows.Forms.TableLayoutPanel tblpTienIch;
        private System.Windows.Forms.TableLayoutPanel tblpBaoCaoThongKe;
        private System.Windows.Forms.Button btnDSPhieuNhap;
        private System.Windows.Forms.Button btnDSPhieuXuat;
        private System.Windows.Forms.Button btnSoKho;
        private System.Windows.Forms.Button btnKhoHang;
        private System.Windows.Forms.Button btnHangTonKho;
        private System.Windows.Forms.Button btnDanhMucHang;
        private System.Windows.Forms.Button btnThongTinVaoRa;
        private System.Windows.Forms.Button btnTopNhap;
        private System.Windows.Forms.Button btnTopXuat;
        private System.Windows.Forms.Button btnLichLamViec;
        private System.Windows.Forms.Button btnDongTabPage;
        private System.Windows.Forms.ToolStripMenuItem xemquyĐịnhNghiệpVụToolStripMenuItem;
    }
}

