﻿namespace QuanLyKhoSieuThi.Presentation_Layer
{
    partial class ucTopXuat
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucTopXuat));
            this.tlpThongTinTopNhap = new System.Windows.Forms.TableLayoutPanel();
            this.bindingNavigatorTX = new System.Windows.Forms.BindingNavigator(this.components);
            this.tslCountItem = new System.Windows.Forms.ToolStripLabel();
            this.tsbMoveFirstItemTX = new System.Windows.Forms.ToolStripButton();
            this.tsbMovePreviousItemTX = new System.Windows.Forms.ToolStripButton();
            this.tsSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.tstbPositionItemTX = new System.Windows.Forms.ToolStripTextBox();
            this.tslSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbMoveNextItemTX = new System.Windows.Forms.ToolStripButton();
            this.tsbMoveLastItemTX = new System.Windows.Forms.ToolStripButton();
            this.tslSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.grbThongTinTopXuat = new System.Windows.Forms.GroupBox();
            this.tlpThongtibTopXuat = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblChonThoiGian = new System.Windows.Forms.Label();
            this.dtmpTuNgay = new System.Windows.Forms.DateTimePicker();
            this.dtmpDenNgay = new System.Windows.Forms.DateTimePicker();
            this.lblDenNgay = new System.Windows.Forms.Label();
            this.lblTuNgay = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rbtnTheoGiaTri = new System.Windows.Forms.RadioButton();
            this.rbtnTheoSoLuong = new System.Windows.Forms.RadioButton();
            this.lblChonCachTinh = new System.Windows.Forms.Label();
            this.grbChiTietTopXuat = new System.Windows.Forms.GroupBox();
            this.grvChiTietTopXuat = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ngay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongGiaTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NhomHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tlpThongTinTopNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorTX)).BeginInit();
            this.bindingNavigatorTX.SuspendLayout();
            this.grbThongTinTopXuat.SuspendLayout();
            this.tlpThongtibTopXuat.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.grbChiTietTopXuat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grvChiTietTopXuat)).BeginInit();
            this.SuspendLayout();
            // 
            // tlpThongTinTopNhap
            // 
            this.tlpThongTinTopNhap.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpThongTinTopNhap.ColumnCount = 1;
            this.tlpThongTinTopNhap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinTopNhap.Controls.Add(this.bindingNavigatorTX, 0, 2);
            this.tlpThongTinTopNhap.Controls.Add(this.grbThongTinTopXuat, 0, 0);
            this.tlpThongTinTopNhap.Controls.Add(this.grbChiTietTopXuat, 0, 1);
            this.tlpThongTinTopNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpThongTinTopNhap.Location = new System.Drawing.Point(0, 0);
            this.tlpThongTinTopNhap.Name = "tlpThongTinTopNhap";
            this.tlpThongTinTopNhap.RowCount = 3;
            this.tlpThongTinTopNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tlpThongTinTopNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongTinTopNhap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tlpThongTinTopNhap.Size = new System.Drawing.Size(591, 350);
            this.tlpThongTinTopNhap.TabIndex = 1;
            // 
            // bindingNavigatorTX
            // 
            this.bindingNavigatorTX.AddNewItem = null;
            this.bindingNavigatorTX.CountItem = this.tslCountItem;
            this.bindingNavigatorTX.DeleteItem = null;
            this.bindingNavigatorTX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bindingNavigatorTX.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMoveFirstItemTX,
            this.tsbMovePreviousItemTX,
            this.tsSeparator,
            this.tstbPositionItemTX,
            this.tslCountItem,
            this.tslSeparator1,
            this.tsbMoveNextItemTX,
            this.tsbMoveLastItemTX,
            this.tslSeparator2});
            this.bindingNavigatorTX.Location = new System.Drawing.Point(3, 321);
            this.bindingNavigatorTX.MoveFirstItem = this.tsbMoveFirstItemTX;
            this.bindingNavigatorTX.MoveLastItem = this.tsbMoveLastItemTX;
            this.bindingNavigatorTX.MoveNextItem = this.tsbMoveNextItemTX;
            this.bindingNavigatorTX.MovePreviousItem = this.tsbMovePreviousItemTX;
            this.bindingNavigatorTX.Name = "bindingNavigatorTX";
            this.bindingNavigatorTX.PositionItem = this.tstbPositionItemTX;
            this.bindingNavigatorTX.Size = new System.Drawing.Size(585, 26);
            this.bindingNavigatorTX.TabIndex = 14;
            this.bindingNavigatorTX.Text = "bindingNavigator1";
            // 
            // tslCountItem
            // 
            this.tslCountItem.Name = "tslCountItem";
            this.tslCountItem.Size = new System.Drawing.Size(35, 23);
            this.tslCountItem.Text = "of {0}";
            this.tslCountItem.ToolTipText = "Total number of items";
            // 
            // tsbMoveFirstItemTX
            // 
            this.tsbMoveFirstItemTX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveFirstItemTX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveFirstItemTX.Image")));
            this.tsbMoveFirstItemTX.Name = "tsbMoveFirstItemTX";
            this.tsbMoveFirstItemTX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveFirstItemTX.Size = new System.Drawing.Size(23, 23);
            this.tsbMoveFirstItemTX.Text = "Move first";
            // 
            // tsbMovePreviousItemTX
            // 
            this.tsbMovePreviousItemTX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMovePreviousItemTX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMovePreviousItemTX.Image")));
            this.tsbMovePreviousItemTX.Name = "tsbMovePreviousItemTX";
            this.tsbMovePreviousItemTX.RightToLeftAutoMirrorImage = true;
            this.tsbMovePreviousItemTX.Size = new System.Drawing.Size(23, 23);
            this.tsbMovePreviousItemTX.Text = "Move previous";
            // 
            // tsSeparator
            // 
            this.tsSeparator.Name = "tsSeparator";
            this.tsSeparator.Size = new System.Drawing.Size(6, 26);
            // 
            // tstbPositionItemTX
            // 
            this.tstbPositionItemTX.AccessibleName = "Position";
            this.tstbPositionItemTX.AutoSize = false;
            this.tstbPositionItemTX.Name = "tstbPositionItemTX";
            this.tstbPositionItemTX.Size = new System.Drawing.Size(50, 23);
            this.tstbPositionItemTX.Text = "0";
            this.tstbPositionItemTX.ToolTipText = "Current position";
            // 
            // tslSeparator1
            // 
            this.tslSeparator1.Name = "tslSeparator1";
            this.tslSeparator1.Size = new System.Drawing.Size(6, 26);
            // 
            // tsbMoveNextItemTX
            // 
            this.tsbMoveNextItemTX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveNextItemTX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveNextItemTX.Image")));
            this.tsbMoveNextItemTX.Name = "tsbMoveNextItemTX";
            this.tsbMoveNextItemTX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveNextItemTX.Size = new System.Drawing.Size(23, 23);
            this.tsbMoveNextItemTX.Text = "Move next";
            // 
            // tsbMoveLastItemTX
            // 
            this.tsbMoveLastItemTX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMoveLastItemTX.Image = ((System.Drawing.Image)(resources.GetObject("tsbMoveLastItemTX.Image")));
            this.tsbMoveLastItemTX.Name = "tsbMoveLastItemTX";
            this.tsbMoveLastItemTX.RightToLeftAutoMirrorImage = true;
            this.tsbMoveLastItemTX.Size = new System.Drawing.Size(23, 23);
            this.tsbMoveLastItemTX.Text = "Move last";
            // 
            // tslSeparator2
            // 
            this.tslSeparator2.Name = "tslSeparator2";
            this.tslSeparator2.Size = new System.Drawing.Size(6, 26);
            // 
            // grbThongTinTopXuat
            // 
            this.grbThongTinTopXuat.Controls.Add(this.tlpThongtibTopXuat);
            this.grbThongTinTopXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbThongTinTopXuat.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinTopXuat.Location = new System.Drawing.Point(6, 6);
            this.grbThongTinTopXuat.Name = "grbThongTinTopXuat";
            this.grbThongTinTopXuat.Size = new System.Drawing.Size(579, 106);
            this.grbThongTinTopXuat.TabIndex = 0;
            this.grbThongTinTopXuat.TabStop = false;
            this.grbThongTinTopXuat.Text = "Thông tin top xuất";
            // 
            // tlpThongtibTopXuat
            // 
            this.tlpThongtibTopXuat.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tlpThongtibTopXuat.ColumnCount = 2;
            this.tlpThongtibTopXuat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 290F));
            this.tlpThongtibTopXuat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongtibTopXuat.Controls.Add(this.panel1, 0, 0);
            this.tlpThongtibTopXuat.Controls.Add(this.panel2, 1, 0);
            this.tlpThongtibTopXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpThongtibTopXuat.Location = new System.Drawing.Point(3, 16);
            this.tlpThongtibTopXuat.Name = "tlpThongtibTopXuat";
            this.tlpThongtibTopXuat.RowCount = 1;
            this.tlpThongtibTopXuat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpThongtibTopXuat.Size = new System.Drawing.Size(573, 87);
            this.tlpThongtibTopXuat.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblChonThoiGian);
            this.panel1.Controls.Add(this.dtmpTuNgay);
            this.panel1.Controls.Add(this.dtmpDenNgay);
            this.panel1.Controls.Add(this.lblDenNgay);
            this.panel1.Controls.Add(this.lblTuNgay);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(284, 75);
            this.panel1.TabIndex = 0;
            // 
            // lblChonThoiGian
            // 
            this.lblChonThoiGian.AutoSize = true;
            this.lblChonThoiGian.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChonThoiGian.Location = new System.Drawing.Point(3, 6);
            this.lblChonThoiGian.Name = "lblChonThoiGian";
            this.lblChonThoiGian.Size = new System.Drawing.Size(89, 15);
            this.lblChonThoiGian.TabIndex = 12;
            this.lblChonThoiGian.Text = "Chọn thời gian";
            // 
            // dtmpTuNgay
            // 
            this.dtmpTuNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmpTuNgay.Location = new System.Drawing.Point(64, 24);
            this.dtmpTuNgay.Name = "dtmpTuNgay";
            this.dtmpTuNgay.Size = new System.Drawing.Size(212, 21);
            this.dtmpTuNgay.TabIndex = 10;
            // 
            // dtmpDenNgay
            // 
            this.dtmpDenNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtmpDenNgay.Location = new System.Drawing.Point(64, 51);
            this.dtmpDenNgay.Name = "dtmpDenNgay";
            this.dtmpDenNgay.Size = new System.Drawing.Size(212, 21);
            this.dtmpDenNgay.TabIndex = 11;
            // 
            // lblDenNgay
            // 
            this.lblDenNgay.AutoSize = true;
            this.lblDenNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDenNgay.Location = new System.Drawing.Point(-2, 51);
            this.lblDenNgay.Name = "lblDenNgay";
            this.lblDenNgay.Size = new System.Drawing.Size(60, 15);
            this.lblDenNgay.TabIndex = 9;
            this.lblDenNgay.Text = "Đến ngày";
            // 
            // lblTuNgay
            // 
            this.lblTuNgay.AutoSize = true;
            this.lblTuNgay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTuNgay.Location = new System.Drawing.Point(-2, 27);
            this.lblTuNgay.Name = "lblTuNgay";
            this.lblTuNgay.Size = new System.Drawing.Size(53, 15);
            this.lblTuNgay.TabIndex = 8;
            this.lblTuNgay.Text = "Từ ngày";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rbtnTheoGiaTri);
            this.panel2.Controls.Add(this.rbtnTheoSoLuong);
            this.panel2.Controls.Add(this.lblChonCachTinh);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(299, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(268, 75);
            this.panel2.TabIndex = 1;
            // 
            // rbtnTheoGiaTri
            // 
            this.rbtnTheoGiaTri.AutoSize = true;
            this.rbtnTheoGiaTri.Location = new System.Drawing.Point(21, 48);
            this.rbtnTheoGiaTri.Name = "rbtnTheoGiaTri";
            this.rbtnTheoGiaTri.Size = new System.Drawing.Size(87, 18);
            this.rbtnTheoGiaTri.TabIndex = 14;
            this.rbtnTheoGiaTri.TabStop = true;
            this.rbtnTheoGiaTri.Text = "Theo giá trị";
            this.rbtnTheoGiaTri.UseVisualStyleBackColor = true;
            // 
            // rbtnTheoSoLuong
            // 
            this.rbtnTheoSoLuong.AutoSize = true;
            this.rbtnTheoSoLuong.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnTheoSoLuong.Location = new System.Drawing.Point(21, 27);
            this.rbtnTheoSoLuong.Name = "rbtnTheoSoLuong";
            this.rbtnTheoSoLuong.Size = new System.Drawing.Size(106, 18);
            this.rbtnTheoSoLuong.TabIndex = 13;
            this.rbtnTheoSoLuong.TabStop = true;
            this.rbtnTheoSoLuong.Text = "Theo số lượng";
            this.rbtnTheoSoLuong.UseVisualStyleBackColor = true;
            // 
            // lblChonCachTinh
            // 
            this.lblChonCachTinh.AutoSize = true;
            this.lblChonCachTinh.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChonCachTinh.Location = new System.Drawing.Point(8, 9);
            this.lblChonCachTinh.Name = "lblChonCachTinh";
            this.lblChonCachTinh.Size = new System.Drawing.Size(91, 15);
            this.lblChonCachTinh.TabIndex = 12;
            this.lblChonCachTinh.Text = "Chọn cách tính";
            // 
            // grbChiTietTopXuat
            // 
            this.grbChiTietTopXuat.Controls.Add(this.grvChiTietTopXuat);
            this.grbChiTietTopXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbChiTietTopXuat.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbChiTietTopXuat.Location = new System.Drawing.Point(6, 121);
            this.grbChiTietTopXuat.Name = "grbChiTietTopXuat";
            this.grbChiTietTopXuat.Size = new System.Drawing.Size(579, 194);
            this.grbChiTietTopXuat.TabIndex = 0;
            this.grbChiTietTopXuat.TabStop = false;
            this.grbChiTietTopXuat.Text = "Chi tiết top xuất";
            // 
            // grvChiTietTopXuat
            // 
            this.grvChiTietTopXuat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grvChiTietTopXuat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grvChiTietTopXuat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.Ngay,
            this.SoLuong,
            this.TongGiaTri,
            this.NhomHang});
            this.grvChiTietTopXuat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grvChiTietTopXuat.Location = new System.Drawing.Point(3, 16);
            this.grvChiTietTopXuat.Name = "grvChiTietTopXuat";
            this.grvChiTietTopXuat.Size = new System.Drawing.Size(573, 175);
            this.grvChiTietTopXuat.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            this.MaHang.ReadOnly = true;
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            this.TenHang.ReadOnly = true;
            // 
            // Ngay
            // 
            this.Ngay.HeaderText = "Ngày";
            this.Ngay.Name = "Ngay";
            this.Ngay.ReadOnly = true;
            // 
            // SoLuong
            // 
            this.SoLuong.HeaderText = "Số lượng";
            this.SoLuong.Name = "SoLuong";
            this.SoLuong.ReadOnly = true;
            // 
            // TongGiaTri
            // 
            this.TongGiaTri.HeaderText = "Tổng giá trị";
            this.TongGiaTri.Name = "TongGiaTri";
            this.TongGiaTri.ReadOnly = true;
            // 
            // NhomHang
            // 
            this.NhomHang.HeaderText = "Nhóm hàng";
            this.NhomHang.Name = "NhomHang";
            this.NhomHang.ReadOnly = true;
            // 
            // ucTopXuat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tlpThongTinTopNhap);
            this.Name = "ucTopXuat";
            this.Size = new System.Drawing.Size(591, 350);
            this.tlpThongTinTopNhap.ResumeLayout(false);
            this.tlpThongTinTopNhap.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorTX)).EndInit();
            this.bindingNavigatorTX.ResumeLayout(false);
            this.bindingNavigatorTX.PerformLayout();
            this.grbThongTinTopXuat.ResumeLayout(false);
            this.tlpThongtibTopXuat.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.grbChiTietTopXuat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grvChiTietTopXuat)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpThongTinTopNhap;
        private System.Windows.Forms.BindingNavigator bindingNavigatorTX;
        private System.Windows.Forms.ToolStripLabel tslCountItem;
        private System.Windows.Forms.ToolStripButton tsbMoveFirstItemTX;
        private System.Windows.Forms.ToolStripButton tsbMovePreviousItemTX;
        private System.Windows.Forms.ToolStripSeparator tsSeparator;
        private System.Windows.Forms.ToolStripTextBox tstbPositionItemTX;
        private System.Windows.Forms.ToolStripSeparator tslSeparator1;
        private System.Windows.Forms.ToolStripButton tsbMoveNextItemTX;
        private System.Windows.Forms.ToolStripButton tsbMoveLastItemTX;
        private System.Windows.Forms.ToolStripSeparator tslSeparator2;
        private System.Windows.Forms.GroupBox grbThongTinTopXuat;
        private System.Windows.Forms.TableLayoutPanel tlpThongtibTopXuat;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblChonThoiGian;
        private System.Windows.Forms.DateTimePicker dtmpTuNgay;
        private System.Windows.Forms.DateTimePicker dtmpDenNgay;
        private System.Windows.Forms.Label lblDenNgay;
        private System.Windows.Forms.Label lblTuNgay;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rbtnTheoGiaTri;
        private System.Windows.Forms.RadioButton rbtnTheoSoLuong;
        private System.Windows.Forms.Label lblChonCachTinh;
        private System.Windows.Forms.GroupBox grbChiTietTopXuat;
        private System.Windows.Forms.DataGridView grvChiTietTopXuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ngay;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongGiaTri;
        private System.Windows.Forms.DataGridViewTextBoxColumn NhomHang;
    }
}
