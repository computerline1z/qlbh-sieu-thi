﻿namespace QuanLyKhoSieuThi
{
    partial class ucHangTonKho
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbDanhMucHangTonKho = new System.Windows.Forms.GroupBox();
            this.dgvDanhMucHangTonKho = new System.Windows.Forms.DataGridView();
            this.MaHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNhom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ViTri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gdbThongTinHangTonKho = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lblDonViTinh = new System.Windows.Forms.Label();
            this.imgSP = new System.Windows.Forms.PictureBox();
            this.btnTimTenHang = new System.Windows.Forms.Button();
            this.btnTimMH = new System.Windows.Forms.Button();
            this.cbTenHang = new System.Windows.Forms.ComboBox();
            this.cboMaLoai = new System.Windows.Forms.ComboBox();
            this.cboMaNhom = new System.Windows.Forms.ComboBox();
            this.vboMaHang = new System.Windows.Forms.ComboBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.txtViTriKho = new System.Windows.Forms.TextBox();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.lblNCC = new System.Windows.Forms.Label();
            this.lblMaLoai = new System.Windows.Forms.Label();
            this.lblTenHang = new System.Windows.Forms.Label();
            this.lblMaNhom = new System.Windows.Forms.Label();
            this.lblViTriKho = new System.Windows.Forms.Label();
            this.lblDonGia = new System.Windows.Forms.Label();
            this.lblMaHang = new System.Windows.Forms.Label();
            this.grbDanhMucHangTonKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHangTonKho)).BeginInit();
            this.gdbThongTinHangTonKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).BeginInit();
            this.SuspendLayout();
            // 
            // grbDanhMucHangTonKho
            // 
            this.grbDanhMucHangTonKho.Controls.Add(this.dgvDanhMucHangTonKho);
            this.grbDanhMucHangTonKho.Dock = System.Windows.Forms.DockStyle.Top;
            this.grbDanhMucHangTonKho.Location = new System.Drawing.Point(0, 119);
            this.grbDanhMucHangTonKho.Name = "grbDanhMucHangTonKho";
            this.grbDanhMucHangTonKho.Size = new System.Drawing.Size(785, 333);
            this.grbDanhMucHangTonKho.TabIndex = 11;
            this.grbDanhMucHangTonKho.TabStop = false;
            this.grbDanhMucHangTonKho.Text = "Danh mục hàng tồn kho";
            // 
            // dgvDanhMucHangTonKho
            // 
            this.dgvDanhMucHangTonKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhMucHangTonKho.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgvDanhMucHangTonKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhMucHangTonKho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHang,
            this.TenHang,
            this.SoLuong,
            this.MaNhom,
            this.MaLoai,
            this.DonGia,
            this.DVT,
            this.ViTri});
            this.dgvDanhMucHangTonKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhMucHangTonKho.Location = new System.Drawing.Point(3, 16);
            this.dgvDanhMucHangTonKho.Name = "dgvDanhMucHangTonKho";
            this.dgvDanhMucHangTonKho.Size = new System.Drawing.Size(779, 314);
            this.dgvDanhMucHangTonKho.TabIndex = 0;
            // 
            // MaHang
            // 
            this.MaHang.HeaderText = "Mã hàng";
            this.MaHang.Name = "MaHang";
            // 
            // TenHang
            // 
            this.TenHang.HeaderText = "Tên hàng";
            this.TenHang.Name = "TenHang";
            // 
            // SoLuong
            // 
            this.SoLuong.HeaderText = "Số lượng";
            this.SoLuong.Name = "SoLuong";
            // 
            // MaNhom
            // 
            this.MaNhom.HeaderText = "Mã nhóm";
            this.MaNhom.Name = "MaNhom";
            // 
            // MaLoai
            // 
            this.MaLoai.HeaderText = "Mã loại";
            this.MaLoai.Name = "MaLoai";
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Đơn giá";
            this.DonGia.Name = "DonGia";
            // 
            // DVT
            // 
            this.DVT.HeaderText = "Đơn vị tính";
            this.DVT.Name = "DVT";
            // 
            // ViTri
            // 
            this.ViTri.HeaderText = "Vị trí kho";
            this.ViTri.Name = "ViTri";
            // 
            // gdbThongTinHangTonKho
            // 
            this.gdbThongTinHangTonKho.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gdbThongTinHangTonKho.Controls.Add(this.comboBox1);
            this.gdbThongTinHangTonKho.Controls.Add(this.lblDonViTinh);
            this.gdbThongTinHangTonKho.Controls.Add(this.imgSP);
            this.gdbThongTinHangTonKho.Controls.Add(this.btnTimTenHang);
            this.gdbThongTinHangTonKho.Controls.Add(this.btnTimMH);
            this.gdbThongTinHangTonKho.Controls.Add(this.cbTenHang);
            this.gdbThongTinHangTonKho.Controls.Add(this.cboMaLoai);
            this.gdbThongTinHangTonKho.Controls.Add(this.cboMaNhom);
            this.gdbThongTinHangTonKho.Controls.Add(this.vboMaHang);
            this.gdbThongTinHangTonKho.Controls.Add(this.txtSoLuong);
            this.gdbThongTinHangTonKho.Controls.Add(this.txtViTriKho);
            this.gdbThongTinHangTonKho.Controls.Add(this.txtDonGia);
            this.gdbThongTinHangTonKho.Controls.Add(this.lblNCC);
            this.gdbThongTinHangTonKho.Controls.Add(this.lblMaLoai);
            this.gdbThongTinHangTonKho.Controls.Add(this.lblTenHang);
            this.gdbThongTinHangTonKho.Controls.Add(this.lblMaNhom);
            this.gdbThongTinHangTonKho.Controls.Add(this.lblViTriKho);
            this.gdbThongTinHangTonKho.Controls.Add(this.lblDonGia);
            this.gdbThongTinHangTonKho.Controls.Add(this.lblMaHang);
            this.gdbThongTinHangTonKho.Dock = System.Windows.Forms.DockStyle.Top;
            this.gdbThongTinHangTonKho.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gdbThongTinHangTonKho.Location = new System.Drawing.Point(0, 0);
            this.gdbThongTinHangTonKho.Name = "gdbThongTinHangTonKho";
            this.gdbThongTinHangTonKho.Size = new System.Drawing.Size(785, 119);
            this.gdbThongTinHangTonKho.TabIndex = 10;
            this.gdbThongTinHangTonKho.TabStop = false;
            this.gdbThongTinHangTonKho.Text = "Thông tin tồn kho";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(231, 85);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(72, 23);
            this.comboBox1.TabIndex = 8;
            // 
            // lblDonViTinh
            // 
            this.lblDonViTinh.AutoSize = true;
            this.lblDonViTinh.Location = new System.Drawing.Point(157, 88);
            this.lblDonViTinh.Name = "lblDonViTinh";
            this.lblDonViTinh.Size = new System.Drawing.Size(68, 15);
            this.lblDonViTinh.TabIndex = 7;
            this.lblDonViTinh.Text = "Đơn vị tính";
            // 
            // imgSP
            // 
            this.imgSP.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.imgSP.Location = new System.Drawing.Point(655, 19);
            this.imgSP.Name = "imgSP";
            this.imgSP.Size = new System.Drawing.Size(122, 94);
            this.imgSP.TabIndex = 6;
            this.imgSP.TabStop = false;
            // 
            // btnTimTenHang
            // 
            this.btnTimTenHang.Image = global::QuanLyKhoSieuThi.Properties.Resources.search;
            this.btnTimTenHang.Location = new System.Drawing.Point(277, 56);
            this.btnTimTenHang.Name = "btnTimTenHang";
            this.btnTimTenHang.Size = new System.Drawing.Size(26, 23);
            this.btnTimTenHang.TabIndex = 4;
            this.btnTimTenHang.UseVisualStyleBackColor = true;
            // 
            // btnTimMH
            // 
            this.btnTimMH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTimMH.Image = global::QuanLyKhoSieuThi.Properties.Resources.search;
            this.btnTimMH.Location = new System.Drawing.Point(277, 27);
            this.btnTimMH.Name = "btnTimMH";
            this.btnTimMH.Size = new System.Drawing.Size(26, 23);
            this.btnTimMH.TabIndex = 4;
            this.btnTimMH.UseVisualStyleBackColor = true;
            // 
            // cbTenHang
            // 
            this.cbTenHang.FormattingEnabled = true;
            this.cbTenHang.Location = new System.Drawing.Point(77, 56);
            this.cbTenHang.Name = "cbTenHang";
            this.cbTenHang.Size = new System.Drawing.Size(194, 23);
            this.cbTenHang.TabIndex = 3;
            // 
            // cboMaLoai
            // 
            this.cboMaLoai.FormattingEnabled = true;
            this.cboMaLoai.Location = new System.Drawing.Point(552, 23);
            this.cboMaLoai.Name = "cboMaLoai";
            this.cboMaLoai.Size = new System.Drawing.Size(60, 23);
            this.cboMaLoai.TabIndex = 3;
            // 
            // cboMaNhom
            // 
            this.cboMaNhom.FormattingEnabled = true;
            this.cboMaNhom.Location = new System.Drawing.Point(412, 23);
            this.cboMaNhom.Name = "cboMaNhom";
            this.cboMaNhom.Size = new System.Drawing.Size(63, 23);
            this.cboMaNhom.TabIndex = 3;
            // 
            // vboMaHang
            // 
            this.vboMaHang.FormattingEnabled = true;
            this.vboMaHang.Location = new System.Drawing.Point(78, 27);
            this.vboMaHang.Name = "vboMaHang";
            this.vboMaHang.Size = new System.Drawing.Size(193, 23);
            this.vboMaHang.TabIndex = 3;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(78, 85);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(71, 21);
            this.txtSoLuong.TabIndex = 2;
            // 
            // txtViTriKho
            // 
            this.txtViTriKho.Location = new System.Drawing.Point(403, 88);
            this.txtViTriKho.Name = "txtViTriKho";
            this.txtViTriKho.Size = new System.Drawing.Size(209, 21);
            this.txtViTriKho.TabIndex = 2;
            // 
            // txtDonGia
            // 
            this.txtDonGia.Location = new System.Drawing.Point(403, 57);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(209, 21);
            this.txtDonGia.TabIndex = 2;
            // 
            // lblNCC
            // 
            this.lblNCC.AutoSize = true;
            this.lblNCC.Location = new System.Drawing.Point(13, 88);
            this.lblNCC.Name = "lblNCC";
            this.lblNCC.Size = new System.Drawing.Size(60, 15);
            this.lblNCC.TabIndex = 1;
            this.lblNCC.Text = "Số lượng";
            // 
            // lblMaLoai
            // 
            this.lblMaLoai.AutoSize = true;
            this.lblMaLoai.Location = new System.Drawing.Point(499, 27);
            this.lblMaLoai.Name = "lblMaLoai";
            this.lblMaLoai.Size = new System.Drawing.Size(47, 15);
            this.lblMaLoai.TabIndex = 1;
            this.lblMaLoai.Text = "Mã loại";
            // 
            // lblTenHang
            // 
            this.lblTenHang.AutoSize = true;
            this.lblTenHang.Location = new System.Drawing.Point(13, 58);
            this.lblTenHang.Name = "lblTenHang";
            this.lblTenHang.Size = new System.Drawing.Size(60, 15);
            this.lblTenHang.TabIndex = 1;
            this.lblTenHang.Text = "Tên Hàng";
            // 
            // lblMaNhom
            // 
            this.lblMaNhom.AutoSize = true;
            this.lblMaNhom.Location = new System.Drawing.Point(347, 27);
            this.lblMaNhom.Name = "lblMaNhom";
            this.lblMaNhom.Size = new System.Drawing.Size(59, 15);
            this.lblMaNhom.TabIndex = 1;
            this.lblMaNhom.Text = "Mã nhóm";
            // 
            // lblViTriKho
            // 
            this.lblViTriKho.AutoSize = true;
            this.lblViTriKho.Location = new System.Drawing.Point(345, 91);
            this.lblViTriKho.Name = "lblViTriKho";
            this.lblViTriKho.Size = new System.Drawing.Size(57, 15);
            this.lblViTriKho.TabIndex = 1;
            this.lblViTriKho.Text = "Vị trí kho";
            // 
            // lblDonGia
            // 
            this.lblDonGia.AutoSize = true;
            this.lblDonGia.Location = new System.Drawing.Point(345, 60);
            this.lblDonGia.Name = "lblDonGia";
            this.lblDonGia.Size = new System.Drawing.Size(52, 15);
            this.lblDonGia.TabIndex = 1;
            this.lblDonGia.Text = "Đơn giá";
            // 
            // lblMaHang
            // 
            this.lblMaHang.AutoSize = true;
            this.lblMaHang.Location = new System.Drawing.Point(17, 31);
            this.lblMaHang.Name = "lblMaHang";
            this.lblMaHang.Size = new System.Drawing.Size(55, 15);
            this.lblMaHang.TabIndex = 1;
            this.lblMaHang.Text = "Mã hàng";
            // 
            // ucHangTonKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grbDanhMucHangTonKho);
            this.Controls.Add(this.gdbThongTinHangTonKho);
            this.Name = "ucHangTonKho";
            this.Size = new System.Drawing.Size(785, 457);
            this.grbDanhMucHangTonKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucHangTonKho)).EndInit();
            this.gdbThongTinHangTonKho.ResumeLayout(false);
            this.gdbThongTinHangTonKho.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSP)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbDanhMucHangTonKho;
        private System.Windows.Forms.DataGridView dgvDanhMucHangTonKho;
        private System.Windows.Forms.GroupBox gdbThongTinHangTonKho;
        private System.Windows.Forms.PictureBox imgSP;
        private System.Windows.Forms.Button btnTimTenHang;
        private System.Windows.Forms.Button btnTimMH;
        private System.Windows.Forms.ComboBox cbTenHang;
        private System.Windows.Forms.ComboBox cboMaLoai;
        private System.Windows.Forms.ComboBox cboMaNhom;
        private System.Windows.Forms.ComboBox vboMaHang;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.Label lblNCC;
        private System.Windows.Forms.Label lblMaLoai;
        private System.Windows.Forms.Label lblTenHang;
        private System.Windows.Forms.Label lblMaNhom;
        private System.Windows.Forms.Label lblDonGia;
        private System.Windows.Forms.Label lblMaHang;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lblDonViTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNhom;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn DVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn ViTri;
        private System.Windows.Forms.TextBox txtViTriKho;
        private System.Windows.Forms.Label lblViTriKho;

    }
}
