namespace ClosableTabs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNewTabPage = new System.Windows.Forms.Button();
            this.edttabPageName = new System.Windows.Forms.TextBox();
            this.tabControl1 = new Yoramo.GuiLib.TabControlEx();
            this.SuspendLayout();
            // 
            // btnNewTabPage
            // 
            this.btnNewTabPage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnNewTabPage.Location = new System.Drawing.Point(191, 12);
            this.btnNewTabPage.Name = "btnNewTabPage";
            this.btnNewTabPage.Size = new System.Drawing.Size(89, 23);
            this.btnNewTabPage.TabIndex = 0;
            this.btnNewTabPage.Text = "New Tab Page";
            this.btnNewTabPage.Click += new System.EventHandler(this.btnNewTabPage_Click);
            // 
            // edttabPageName
            // 
            this.edttabPageName.Location = new System.Drawing.Point(12, 12);
            this.edttabPageName.Name = "edttabPageName";
            this.edttabPageName.Size = new System.Drawing.Size(127, 20);
            this.edttabPageName.TabIndex = 1;
            this.edttabPageName.Text = "Page 1";
            // 
            // tabControl1
            // 
            this.tabControl1.Location = new System.Drawing.Point(1, 42);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(289, 222);
            this.tabControl1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.edttabPageName);
            this.Controls.Add(this.btnNewTabPage);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNewTabPage;
        private System.Windows.Forms.TextBox edttabPageName;
        private Yoramo.GuiLib.TabControlEx tabControl1;
        
    }
}

